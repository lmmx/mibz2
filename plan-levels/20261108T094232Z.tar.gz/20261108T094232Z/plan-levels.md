# bench-plan-levels: levels 1 and 2 on 0.2.6 against 0.2.4 (diagnostic)

Registration 5 of docs/journal/2026-11-07-general-plan-policy.md (docs/journal/2026-11-07-plan-levels-registration.md). Diagnostic only (RULES C1).

## Validity

- every line of the runs files JSON (unreadable: none): **yes**
- a clean tree (`git-status.txt` present and empty): **yes**
- no `NOT-FROZEN.txt` (the frozen inputs unchanged): **yes**
- no `DRY-RUN.txt` (not a dry run): **yes**
- `commit.txt` (a5dcaebda28fecaa8165e81604bb2824d3842c71) is the checkout's head (a5dcaebda28fecaa8165e81604bb2824d3842c71): **yes**
- the ten-core topology: 1 socket, 10 cores, 2 threads a core, a 20 MiB L3 (lscpu: 1 socket, 10 cores, 2 threads a core, L3 20 MiB (1 instance)): **yes**
- the base is v0.2.4's release commit 1e644f9a, by its SHA (`commits.txt`): **yes**
- the corpus `wikidata-l1` is the registered one (SHA-256 2ae39adffbfbaab6...): **yes**
- the corpus `wikidata-l2` is the registered one (SHA-256 aa55dcfa36b98b5d...): **yes**
- the corpus `wikidata-l3` is the registered one (SHA-256 380cbfda616222f8...): **yes**
- every run the same bytes, none failed (360 runs, 0 failed, 1 outputs): **yes**
- `L10`: the registered mask (every CPU: all), recorded `all`, every run under it: **yes**
- `L10`: no arm, thread count or corpus beyond the registered (seen: none): **yes**
- `L10`: one base binary (seen 1): **yes**
- `L10` `mibz2` on `wikidata-l1`: rounds 0-19 once each (seen 20): **yes**
- `L10` `mibz2` on `wikidata-l1`: every run's observed plan 3 decoders, no helpers (seen: 3 decoders, no helpers): **yes**
- `L10` `mibz2` on `wikidata-l2`: rounds 0-19 once each (seen 20): **yes**
- `L10` `mibz2` on `wikidata-l2`: every run's observed plan 3 decoders, no helpers (seen: 3 decoders, no helpers): **yes**
- `L10` `mibz2` on `wikidata-l3`: rounds 0-19 once each (seen 20): **yes**
- `L10` `mibz2` on `wikidata-l3`: every run's observed plan 3x3p (seen: 3x3p): **yes**
- `L10` `mibz2-plan-4x2` on `wikidata-l1`: rounds 0-19 once each (seen 20): **yes**
- `L10` `mibz2-plan-4x2` on `wikidata-l1`: every run's observed plan 4 decoders, no helpers (seen: 4 decoders, no helpers): **yes**
- `L10` `mibz2-plan-4x2` on `wikidata-l2`: rounds 0-19 once each (seen 20): **yes**
- `L10` `mibz2-plan-4x2` on `wikidata-l2`: every run's observed plan 4 decoders, no helpers (seen: 4 decoders, no helpers): **yes**
- `L10` `mibz2-plan-4x2` on `wikidata-l3`: rounds 0-19 once each (seen 20): **yes**
- `L10` `mibz2-plan-4x2` on `wikidata-l3`: every run's observed plan 4x2 (seen: 4x2): **yes**
- `L10` `base` on `wikidata-l1`: rounds 0-19 once each (seen 20): **yes**
- `L10` `base` on `wikidata-l1`: every run's observed plan 4 decoders, no helpers (seen: 4 decoders, no helpers): **yes**
- `L10` `base` on `wikidata-l2`: rounds 0-19 once each (seen 20): **yes**
- `L10` `base` on `wikidata-l2`: every run's observed plan 4 decoders, no helpers (seen: 4 decoders, no helpers): **yes**
- `L10` `base` on `wikidata-l3`: rounds 0-19 once each (seen 20): **yes**
- `L10` `base` on `wikidata-l3`: every run's observed plan 4x2 (seen: 4x2): **yes**
- `L20`: the registered mask (every CPU: all), recorded `all`, every run under it: **yes**
- `L20`: no arm, thread count or corpus beyond the registered (seen: none): **yes**
- `L20`: one base binary (seen 1): **yes**
- `L20` `mibz2` on `wikidata-l1`: rounds 0-19 once each (seen 20): **yes**
- `L20` `mibz2` on `wikidata-l1`: every run's observed plan 3 decoders, no helpers (seen: 3 decoders, no helpers): **yes**
- `L20` `mibz2` on `wikidata-l2`: rounds 0-19 once each (seen 20): **yes**
- `L20` `mibz2` on `wikidata-l2`: every run's observed plan 3 decoders, no helpers (seen: 3 decoders, no helpers): **yes**
- `L20` `mibz2` on `wikidata-l3`: rounds 0-19 once each (seen 20): **yes**
- `L20` `mibz2` on `wikidata-l3`: every run's observed plan 3x3p (seen: 3x3p): **yes**
- `L20` `mibz2-plan-4x2` on `wikidata-l1`: rounds 0-19 once each (seen 20): **yes**
- `L20` `mibz2-plan-4x2` on `wikidata-l1`: every run's observed plan 4 decoders, no helpers (seen: 4 decoders, no helpers): **yes**
- `L20` `mibz2-plan-4x2` on `wikidata-l2`: rounds 0-19 once each (seen 20): **yes**
- `L20` `mibz2-plan-4x2` on `wikidata-l2`: every run's observed plan 4 decoders, no helpers (seen: 4 decoders, no helpers): **yes**
- `L20` `mibz2-plan-4x2` on `wikidata-l3`: rounds 0-19 once each (seen 20): **yes**
- `L20` `mibz2-plan-4x2` on `wikidata-l3`: every run's observed plan 4x2 (seen: 4x2): **yes**
- `L20` `base` on `wikidata-l1`: rounds 0-19 once each (seen 20): **yes**
- `L20` `base` on `wikidata-l1`: every run's observed plan 4 decoders, no helpers (seen: 4 decoders, no helpers): **yes**
- `L20` `base` on `wikidata-l2`: rounds 0-19 once each (seen 20): **yes**
- `L20` `base` on `wikidata-l2`: every run's observed plan 4 decoders, no helpers (seen: 4 decoders, no helpers): **yes**
- `L20` `base` on `wikidata-l3`: rounds 0-19 once each (seen 20): **yes**
- `L20` `base` on `wikidata-l3`: every run's observed plan 4x2 (seen: 4x2): **yes**

Run: **VALID**


## Levels 1 and 2: the family of 12 (Bonferroni, each interval at 1 - 0.05/24 a tail, t19 = 3.255)

| level | threads | comparison | speed [interval] word, CPU | MHz, ref → arm |
|---|--:|---|---|---|
| 1 | 10 | S: 0.2.6's default against 0.2.4's (the slowdown) | 0.763 [0.752, 0.775] **SLOWER**, CPU 1.007 | 1620 → 2235 |
| 1 | 10 | K: 0.2.6 forced to 4x2 against 0.2.6's default (the decoder count) | 1.320 [1.301, 1.338] **FASTER**, CPU 0.990 | 2235 → 1722 |
| 1 | 10 | R: 0.2.6 forced to 4x2 against 0.2.4's default (the same plan: everything else) | 1.008 [0.997, 1.018] **UNRESOLVED**, CPU 0.998 | 1620 → 1722 |
| 1 | 20 | S: 0.2.6's default against 0.2.4's (the slowdown) | 0.765 [0.758, 0.773] **SLOWER**, CPU 1.002 | 1525 → 2235 |
| 1 | 20 | K: 0.2.6 forced to 4x2 against 0.2.6's default (the decoder count) | 1.317 [1.302, 1.332] **FASTER**, CPU 0.993 | 2235 → 1621 |
| 1 | 20 | R: 0.2.6 forced to 4x2 against 0.2.4's default (the same plan: everything else) | 1.008 [0.995, 1.020] **UNRESOLVED**, CPU 0.994 | 1525 → 1621 |
| 2 | 10 | S: 0.2.6's default against 0.2.4's (the slowdown) | 0.776 [0.759, 0.794] **SLOWER**, CPU 0.988 | 1620 → 1887 |
| 2 | 10 | K: 0.2.6 forced to 4x2 against 0.2.6's default (the decoder count) | 1.297 [1.266, 1.329] **FASTER**, CPU 1.012 | 1887 → 1622 |
| 2 | 10 | R: 0.2.6 forced to 4x2 against 0.2.4's default (the same plan: everything else) | 1.007 [0.990, 1.025] **UNRESOLVED**, CPU 1.000 | 1620 → 1622 |
| 2 | 20 | S: 0.2.6's default against 0.2.4's (the slowdown) | 0.772 [0.751, 0.794] **SLOWER**, CPU 0.983 | 1620 → 2030 |
| 2 | 20 | K: 0.2.6 forced to 4x2 against 0.2.6's default (the decoder count) | 1.307 [1.276, 1.338] **FASTER**, CPU 1.011 | 2030 → 1631 |
| 2 | 20 | R: 0.2.6 forced to 4x2 against 0.2.4's default (the same plan: everything else) | 1.009 [0.986, 1.033] **UNRESOLVED**, CPU 0.994 | 1620 → 1631 |

## Level 3, a separate question: its own family of 6 (each interval at 1 - 0.05/12 a tail, t19 = 2.9439), in no reading

| level | threads | comparison | speed [interval] word, CPU | MHz, ref → arm |
|---|--:|---|---|---|
| 3 | 10 | S: 0.2.6's default against 0.2.4's (the slowdown) | 1.047 [1.015, 1.081] **FASTER**, CPU 1.177 | 2030 → 2235 |
| 3 | 10 | K: 0.2.6 forced to 4x2 against 0.2.6's default (the decoder count) | 0.962 [0.933, 0.992] **SLOWER**, CPU 0.844 | 2235 → 2030 |
| 3 | 10 | R: 0.2.6 forced to 4x2 against 0.2.4's default (the same plan: everything else) | 1.007 [0.985, 1.030] **UNRESOLVED**, CPU 0.994 | 2030 → 2030 |
| 3 | 20 | S: 0.2.6's default against 0.2.4's (the slowdown) | 1.067 [1.030, 1.106] **FASTER**, CPU 1.152 | 2030 → 2166 |
| 3 | 20 | K: 0.2.6 forced to 4x2 against 0.2.6's default (the decoder count) | 0.933 [0.900, 0.967] **SLOWER**, CPU 0.884 | 2166 → 2030 |
| 3 | 20 | R: 0.2.6 forced to 4x2 against 0.2.4's default (the same plan: everything else) | 0.996 [0.979, 1.013] **UNRESOLVED**, CPU 1.018 | 2030 → 2030 |

## Readings (levels 1 and 2)

- **Level 1:** SLOWDOWN SHOWN (0.2.6 slower than 0.2.4 at 10 and 20 threads); from: THE DECODER COUNT: the fix to register is the scheduling one (the journal's registration 5)
- **Level 2:** SLOWDOWN SHOWN (0.2.6 slower than 0.2.4 at 10 and 20 threads); from: THE DECODER COUNT: the fix to register is the scheduling one (the journal's registration 5)
- The inference under test: 0.2.6 at 0.76-0.83 of 0.2.4 (§1.6).
