# bench-plan-boundaries: the general plan policy's boundaries on the i9 (diagnostic)

Registration 1 of docs/journal/2026-11-07-general-plan-policy.md (docs/journal/2026-11-07-plan-boundaries-registration.md). Diagnostic only (RULES C1): it can't qualify a production change.

## Validity

- every line of the runs files JSON (unreadable: none): **yes**
- a clean tree (`git-status.txt` present and empty): **yes**
- no `NOT-FROZEN.txt` (the frozen inputs unchanged): **yes**
- no `DRY-RUN.txt` (not a dry run): **yes**
- `commit.txt` (a5dcaebda28fecaa8165e81604bb2824d3842c71) is the checkout's head (a5dcaebda28fecaa8165e81604bb2824d3842c71): **yes**
- the ten-core topology: 1 socket, 10 cores, 2 threads a core, a 20 MiB L3 (lscpu: 1 socket, 10 cores, 2 threads a core, L3 20 MiB (1 instance)): **yes**
- the corpus `wikidata` is the registered one (SHA-256 82f65ace0731962d...): **yes**
- every run the same bytes, none failed (320 runs, 0 failed, 1 outputs): **yes**
- `U8`: the registered mask (every CPU: all), recorded `all`, every run under it: **yes**
- `U8`: no arm, thread count or corpus beyond the registered (seen: none): **yes**
- `U8` `mibz2-plan-4x2`: rounds 0-19 once each (seen 20): **yes**
- `U8` `mibz2-plan-4x2`: every run's observed plan 4x2 (seen: 4x2): **yes**
- `U8` `mibz2-plan-3x2`: rounds 0-19 once each (seen 20): **yes**
- `U8` `mibz2-plan-3x2`: every run's observed plan 3x2 (seen: 3x2): **yes**
- `U8` `mibz2-plan-2x4p`: rounds 0-19 once each (seen 20): **yes**
- `U8` `mibz2-plan-2x4p`: every run's observed plan 2x4p (seen: 2x4p): **yes**
- `U9`: the registered mask (every CPU: all), recorded `all`, every run under it: **yes**
- `U9`: no arm, thread count or corpus beyond the registered (seen: none): **yes**
- `U9` `mibz2-plan-4x2`: rounds 0-19 once each (seen 20): **yes**
- `U9` `mibz2-plan-4x2`: every run's observed plan 4x2 (seen: 4x2): **yes**
- `U9` `mibz2-plan-3x3p`: rounds 0-19 once each (seen 20): **yes**
- `U9` `mibz2-plan-3x3p`: every run's observed plan 3x3p (seen: 3x3p): **yes**
- `M8`: the registered mask (8 cores, one CPU a core: [0, 1, 2, 3, 4, 5, 6, 7]), recorded `0,1,2,3,4,5,6,7`, every run under it: **yes**
- `M8`: no arm, thread count or corpus beyond the registered (seen: none): **yes**
- `M8` `mibz2-plan-4x2`: rounds 0-19 once each (seen 20): **yes**
- `M8` `mibz2-plan-4x2`: every run's observed plan 4x2 (seen: 4x2): **yes**
- `M8` `mibz2-plan-3x2`: rounds 0-19 once each (seen 20): **yes**
- `M8` `mibz2-plan-3x2`: every run's observed plan 3x2 (seen: 3x2): **yes**
- `M8S`: the registered mask (8 cores, both CPUs of each: [0, 1, 2, 3, 4, 5, 6, 7, 10, 11, 12, 13, 14, 15, 16, 17]), recorded `0,1,2,3,4,5,6,7,10,11,12,13,14,15,16,17`, every run under it: **yes**
- `M8S`: no arm, thread count or corpus beyond the registered (seen: none): **yes**
- `M8S` `mibz2-plan-4x2`: rounds 0-19 once each (seen 20): **yes**
- `M8S` `mibz2-plan-4x2`: every run's observed plan 4x2 (seen: 4x2): **yes**
- `M8S` `mibz2-plan-3x2`: rounds 0-19 once each (seen 20): **yes**
- `M8S` `mibz2-plan-3x2`: every run's observed plan 3x2 (seen: 3x2): **yes**
- `M9`: the registered mask (9 cores, one CPU a core: [0, 1, 2, 3, 4, 5, 6, 7, 8]), recorded `0,1,2,3,4,5,6,7,8`, every run under it: **yes**
- `M9`: no arm, thread count or corpus beyond the registered (seen: none): **yes**
- `M9` `mibz2-plan-4x2`: rounds 0-19 once each (seen 20): **yes**
- `M9` `mibz2-plan-4x2`: every run's observed plan 4x2 (seen: 4x2): **yes**
- `M9` `mibz2-plan-3x2`: rounds 0-19 once each (seen 20): **yes**
- `M9` `mibz2-plan-3x2`: every run's observed plan 3x2 (seen: 3x2): **yes**
- `M9` `mibz2-plan-3x3p`: rounds 0-19 once each (seen 20): **yes**
- `M9` `mibz2-plan-3x3p`: every run's observed plan 3x3p (seen: 3x3p): **yes**
- `C6`: the registered mask (every CPU: all), recorded `all`, every run under it: **yes**
- `C6`: no arm, thread count or corpus beyond the registered (seen: none): **yes**
- `C6` `mibz2`: rounds 0-19 once each (seen 20): **yes**
- `C6` `mibz2`: every run's observed plan 3x2 (seen: 3x2): **yes**
- `C6` `mibz2-plan-3x2`: rounds 0-19 once each (seen 20): **yes**
- `C6` `mibz2-plan-3x2`: every run's observed plan 3x2 (seen: 3x2): **yes**
- `C6M`: the registered mask (6 cores, one CPU a core: [0, 1, 2, 3, 4, 5]), recorded `0,1,2,3,4,5`, every run under it: **yes**
- `C6M`: no arm, thread count or corpus beyond the registered (seen: none): **yes**
- `C6M` `mibz2`: rounds 0-19 once each (seen 20): **yes**
- `C6M` `mibz2`: every run's observed plan 3x2 (seen: 3x2): **yes**
- `C6M` `mibz2-plan-3x2`: rounds 0-19 once each (seen 20): **yes**
- `C6M` `mibz2-plan-3x2`: every run's observed plan 3x2 (seen: 3x2): **yes**

Run: **VALID**

## The family: 7 comparisons against 4x2 (speed: 4x2's wall over the arm's; Bonferroni, each interval at 1 - 0.05/14 a tail, t19 = 3.0136)

| cell | arm | speed [interval] word, CPU | MHz, 4x2 → arm | role |
|---|---|---|---|---|
| U8 | `mibz2-plan-3x2` | 0.989 [0.969, 1.009] **UNRESOLVED**, CPU 0.774 | 2031 → 1825 | 8 threads: rules A and B |
| U8 | `mibz2-plan-2x4p` | 1.079 [1.055, 1.102] **FASTER**, CPU 0.865 | 2031 → 2031 | 8 threads: rules A and B |
| U9 | `mibz2-plan-3x3p` | 1.141 [1.119, 1.163] **FASTER**, CPU 0.950 | 2084 → 2138 | the shared 9-thread cell |
| M8 | `mibz2-plan-3x2` | 0.988 [0.975, 1.002] **UNRESOLVED**, CPU 0.796 | 2850 → 2853 | 8 threads: rules A and B |
| M8S | `mibz2-plan-3x2` | 1.011 [0.986, 1.036] **UNRESOLVED**, CPU 0.752 | 2338 → 2008 | 8 threads: rules A and B |
| M9 | `mibz2-plan-3x2` | 1.001 [0.985, 1.018] **UNRESOLVED**, CPU 0.767 | 2851 → 2850 | in the family; enters no listed reading |
| M9 | `mibz2-plan-3x3p` | 1.146 [1.127, 1.166] **FASTER**, CPU 0.889 | 2851 → 2850 | information only (the core-left-over assumption) |

## Controls (reported, not judged): today's default against 3x2 forced, the same plan (95% intervals, outside the family)

- C6: `mibz2-plan-3x2` against `mibz2`: 1.001 [0.989, 1.013] **UNRESOLVED**, CPU 1.014
- C6M: `mibz2-plan-3x2` against `mibz2`: 1.005 [0.997, 1.012] **UNRESOLVED**, CPU 1.001

## Readings

- **The shared 9-thread cell:** SUPPORTS BOTH RULES (unmasked 9 threads: 3x3p faster than 4x2)
- **Rule A at 8 threads:** FALSIFIED AT 8 (U8 mibz2-plan-2x4p faster than 4x2)
- **Rule B at 8 threads:** NEITHER FALSIFIED NOR SUPPORTED AT 8
- **At 8 threads:** rule A FALSIFIED AT 8 (U8 mibz2-plan-2x4p faster than 4x2); rule B NEITHER FALSIFIED NOR SUPPORTED AT 8
- **The 9-core mask (information only):** FASTER: the core-left-over assumption is unnecessary; the 9-core shape becomes a candidate envelope entry, by its own registration
- **What it does not show:** anything about the L3 extrapolation.
