# The pipelined team's levers: the workstation run's report

## Validity

- the registered 20 rounds (seen: 20): **yes**
- a clean tree (`git-status.txt` present and empty): **yes**
- no `NOT-FROZEN.txt` (the frozen inputs unchanged): **yes**
- no `DRY-RUN.txt` (not a dry run): **yes**
- `commit.txt` (7a5be722ac1162effa8bf079de885e6963f6f5a5) is the checkout's head (7a5be722ac1162effa8bf079de885e6963f6f5a5): **yes**
- every run the same bytes, none failed: **yes**
- `mibz2@10`: rounds 0-19 once each, every run 3 x 3 (seen: 3 × 3): **yes**
- `mibz2-team3@10`: rounds 0-19 once each, every run 3 x 3 (seen: 3 × 3): **yes**
- `mibz2-team4@12`: rounds 0-19 once each, every run 3 x 4 (seen: 3 × 4): **yes**
- `mibz2-pipe3@10`: rounds 0-19 once each, every run 3 x 3 (seen: 3 × 3): **yes**
- `mibz2-pipe3-park@10`: rounds 0-19 once each, every run 3 x 3 (seen: 3 × 3): **yes**
- `mibz2-pipe3-spin2k@10`: rounds 0-19 once each, every run 3 x 3 (seen: 3 × 3): **yes**
- `mibz2-pipe3-small@10`: rounds 0-19 once each, every run 3 x 3 (seen: 3 × 3): **yes**
- `mibz2-pipe3-both@10`: rounds 0-19 once each, every run 3 x 3 (seen: 3 × 3): **yes**
- `mibz2-pipe4@12`: rounds 0-19 once each, every run 3 x 4 (seen: 3 × 4): **yes**
- `mibz2-pipe4-park@12`: rounds 0-19 once each, every run 3 x 4 (seen: 3 × 4): **yes**
- `mibz2-pipe4-spin2k@12`: rounds 0-19 once each, every run 3 x 4 (seen: 3 × 4): **yes**
- `mibz2-pipe4-small@12`: rounds 0-19 once each, every run 3 x 4 (seen: 3 × 4): **yes**
- `mibz2-pipe4-both@12`: rounds 0-19 once each, every run 3 x 4 (seen: 3 × 4): **yes**
- no cell beyond the registered ones (seen: none): **yes**
- the noise control N1, `mibz2-team3@10` against `mibz2@10` (the same plan): 1.007 [0.987, 1.027] over 20 rounds, within 1 ± 0.03: **yes**

Run: **VALID**

## The registered comparisons (each lever against the pipe)

| | lever | arm | against | speed [95% CI] | speed outcome | CPU [95% CI] | CPU outcome | lever A's question |
|---|---|---|---|---|---|---|---|---|
| A1 | park | `mibz2-pipe3-park@10` | `mibz2-pipe3@10` | 0.999 [0.981, 1.017] | NULL | 1.055 [1.039, 1.071] | CPU SAVING | YES: CPU falls, the wall holds |
| A2 | park | `mibz2-pipe4-park@12` | `mibz2-pipe4@12` | 0.995 [0.981, 1.010] | NULL | 1.051 [1.037, 1.065] | CPU SAVING | YES: CPU falls, the wall holds |
| S1 | spin2k | `mibz2-pipe3-spin2k@10` | `mibz2-pipe3@10` | 1.004 [0.984, 1.024] | NULL | 1.006 [0.986, 1.027] | NULL |  |
| S2 | spin2k | `mibz2-pipe4-spin2k@12` | `mibz2-pipe4@12` | 1.005 [0.994, 1.016] | NULL | 1.003 [0.991, 1.015] | NULL |  |
| B1 | small | `mibz2-pipe3-small@10` | `mibz2-pipe3@10` | 1.043 [1.020, 1.066] | GAIN | 1.007 [0.987, 1.028] | NULL |  |
| B2 | small | `mibz2-pipe4-small@12` | `mibz2-pipe4@12` | 1.034 [1.023, 1.045] | GAIN | 0.994 [0.982, 1.006] | NULL |  |
| AB1 | both | `mibz2-pipe3-both@10` | `mibz2-pipe3@10` | 1.038 [1.021, 1.055] | GAIN | 1.032 [1.018, 1.046] | SMALL CPU SAVING (above 1, not above the threshold) |  |
| AB2 | both | `mibz2-pipe4-both@12` | `mibz2-pipe4@12` | 1.033 [1.023, 1.043] | GAIN | 1.031 [1.018, 1.044] | SMALL CPU SAVING (above 1, not above the threshold) |  |

**Interaction** (both against each lever alone, on the lever's own figure):

- AB1: **INTERACTION: CPU below park's**
- AB2: **INTERACTION: CPU below park's**

(Speed: the reference's wall over the arm's, > 1 the arm is faster. CPU: the reference's CPU over the arm's, > 1 the arm spends less.)

## Reported, never judged

| | arm | against | speed [95% CI] | CPU [95% CI] |
|---|---|---|---|---|
| R1 | `mibz2-pipe3@10` | `mibz2-team3@10` | 1.033 [1.017, 1.049] | 0.922 [0.907, 0.937] |
| R2 | `mibz2-pipe4@12` | `mibz2-team4@12` | 1.040 [1.023, 1.057] | 0.896 [0.885, 0.908] |
| T-park1 | `mibz2-pipe3-park@10` | `mibz2-team3@10` | 1.031 [1.012, 1.051] | 0.973 [0.957, 0.989] |
| T-park2 | `mibz2-pipe4-park@12` | `mibz2-team4@12` | 1.035 [1.018, 1.053] | 0.942 [0.931, 0.952] |
| T-spin2k1 | `mibz2-pipe3-spin2k@10` | `mibz2-team3@10` | 1.037 [1.015, 1.059] | 0.928 [0.910, 0.946] |
| T-spin2k2 | `mibz2-pipe4-spin2k@12` | `mibz2-team4@12` | 1.045 [1.029, 1.060] | 0.898 [0.886, 0.911] |
| T-small1 | `mibz2-pipe3-small@10` | `mibz2-team3@10` | 1.077 [1.053, 1.102] | 0.929 [0.911, 0.946] |
| T-small2 | `mibz2-pipe4-small@12` | `mibz2-team4@12` | 1.075 [1.058, 1.092] | 0.890 [0.880, 0.901] |
| T-both1 | `mibz2-pipe3-both@10` | `mibz2-team3@10` | 1.072 [1.053, 1.091] | 0.951 [0.937, 0.966] |
| T-both2 | `mibz2-pipe4-both@12` | `mibz2-team4@12` | 1.074 [1.058, 1.090] | 0.924 [0.912, 0.936] |
| PS1 | `mibz2-pipe3-park@10` | `mibz2-pipe3-spin2k@10` | 0.995 [0.979, 1.011] | 1.048 [1.035, 1.062] |
| PS2 | `mibz2-pipe4-park@12` | `mibz2-pipe4-spin2k@12` | 0.991 [0.976, 1.006] | 1.048 [1.031, 1.065] |
| P-park | `mibz2-pipe4-park@12` | `mibz2@10` | 1.048 [1.035, 1.062] | 0.801 [0.789, 0.812] |

## Every cell (medians)

| cell | plan | wall s | CPU s | peak RSS MB | rounds |
|---|---|---|---|---|---|
| `mibz2-pipe3-both@10` | 3 × 3 | 0.142 | 1.030 | 75 | 20 |
| `mibz2-pipe3-park@10` | 3 × 3 | 0.148 | 1.005 | 75 | 20 |
| `mibz2-pipe3-small@10` | 3 × 3 | 0.142 | 1.058 | 75 | 20 |
| `mibz2-pipe3-spin2k@10` | 3 × 3 | 0.146 | 1.048 | 75 | 20 |
| `mibz2-pipe3@10` | 3 × 3 | 0.148 | 1.060 | 75 | 20 |
| `mibz2-pipe4-both@12` | 3 × 4 | 0.141 | 1.234 | 74 | 20 |
| `mibz2-pipe4-park@12` | 3 × 4 | 0.146 | 1.215 | 76 | 20 |
| `mibz2-pipe4-small@12` | 3 × 4 | 0.141 | 1.278 | 74 | 20 |
| `mibz2-pipe4-spin2k@12` | 3 × 4 | 0.146 | 1.267 | 75 | 20 |
| `mibz2-pipe4@12` | 3 × 4 | 0.146 | 1.269 | 75 | 20 |
| `mibz2-team3@10` | 3 × 3 | 0.151 | 0.968 | 67 | 20 |
| `mibz2-team4@12` | 3 × 4 | 0.152 | 1.138 | 67 | 20 |
| `mibz2@10` | 3 × 3 | 0.154 | 0.973 | 67 | 20 |

## The traces (occupancy, medians over complete rounds)

| trace | complete rounds | blocks | MTFs | MTF overlapped (cross thread) | (same thread) | RLE overlapped (cross thread) | build wait ms | build + walk ms | lead ms | join delay ms | runs: late joins / missed / all |
|---|---|---|---|---|---|---|---|---|---|---|---|
| occupancy-t10-pipe3 | 6 | 431 | 431 | 144 | 221 | 144.5 | 80.816588 | 594.1 | 68.788273 | 14.308159 | 62 / 0 / 233 |
| occupancy-t10-pipe3-both | 6 | 431 | 431 | 229.5 | 280.5 | 231.5 | 71.062001 | 593.4 | 101.411894 | 22.351268 | 100.5 / 0 / 233 |
| occupancy-t10-pipe3-park | 6 | 431 | 431 | 146 | 225.5 | 150 | 89.215398 | 597.0 | 70.427782 | 14.743058 | 61 / 1 / 233 |
| occupancy-t10-pipe3-small | 6 | 431 | 431 | 236.5 | 290.5 | 237 | 57.322252 | 604.1 | 109.798619 | 26.023996 | 113 / 0 / 233 |
| occupancy-t10-pipe3-spin2k | 6 | 431 | 431 | 150 | 224 | 154 | 89.760794 | 591.1 | 68.38676 | 13.549687 | 56.5 / 0 / 233 |
| occupancy-t12-pipe4 | 6 | 431 | 431 | 147 | 222 | 155.5 | 111.906445 | 711.7 | 82.300921 | 28.080871 | 91.5 / 9 / 233 |
| occupancy-t12-pipe4-both | 6 | 431 | 431 | 229 | 284 | 232 | 106.300563 | 731.6 | 114.183958 | 37.557447 | 124.5 / 8 / 233 |
| occupancy-t12-pipe4-park | 6 | 431 | 431 | 146.5 | 217 | 152 | 129.48316 | 705.7 | 76.040473 | 22.523876 | 78 / 5.5 / 233 |
| occupancy-t12-pipe4-small | 6 | 431 | 431 | 219 | 276 | 225 | 93.225047 | 748.3 | 118.852353 | 40.881656 | 131.5 / 11 / 233 |
| occupancy-t12-pipe4-spin2k | 6 | 431 | 431 | 147 | 219.5 | 153 | 111.807269 | 735.6 | 84.993399 | 30.013426 | 91.5 / 8 / 233 |

**Lever B's mechanism** (registered: its cross-thread overlap above the pipe's by at least 10% of the blocks), and its counterexample (a later join: the leader's summed join delay at least 1.2x the pipe's and 5 ms more). `pipeline_counts` (jobs taken in a run) is context only, never evidence:

- small at 3 x 3 (10 threads): cross-thread overlap 236.5 against 144 of 431 blocks: **SHOWN**; the leader's join delay 26.023996 against 14.308159 ms: **LATER JOIN**
- both at 3 x 3 (10 threads): cross-thread overlap 229.5 against 144 of 431 blocks: **SHOWN**; the leader's join delay 22.351268 against 14.308159 ms: **LATER JOIN**
- small at 3 x 4 (12 threads): cross-thread overlap 219 against 147 of 431 blocks: **SHOWN**; the leader's join delay 40.881656 against 28.080871 ms: **LATER JOIN**
- both at 3 x 4 (12 threads): cross-thread overlap 229 against 147 of 431 blocks: **SHOWN**; the leader's join delay 37.557447 against 28.080871 ms: **LATER JOIN**

A pipelined trace with no cross-thread overlap, or lever B's mechanism not shown, means no mechanism verdict for that arm (the registration's outcome map).
