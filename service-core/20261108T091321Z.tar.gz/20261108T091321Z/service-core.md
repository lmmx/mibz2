# The service core: the workstation run's report

## Validity

- the registered 20 rounds (seen: 20): **yes**
- a clean tree (`git-status.txt` present and empty): **yes**
- no `NOT-FROZEN.txt` (the frozen inputs unchanged): **yes**
- no `DRY-RUN.txt` (not a dry run): **yes**
- `commit.txt` (223d93bb2e431dd8f46598348b2f71321d4c46d9) is the checkout's head (223d93bb2e431dd8f46598348b2f71321d4c46d9): **yes**
- the ten-core topology, so `mibz2` is the pipelined default (lscpu: 1 socket, 10 cores, L3 20 MiB (1 instance)): **yes**
- every run the same bytes, none failed: **yes**
- `mibz2@10`: rounds 0-19 once each, every run 3 leaders, 6 helpers, 0 service threads (seen: 3 leaders, 6 helpers, 0 service): **yes**
- `mibz2@12`: rounds 0-19 once each, every run 3 leaders, 6 helpers, 0 service threads (seen: 3 leaders, 6 helpers, 0 service): **yes**
- `mibz2-team3@10`: rounds 0-19 once each, every run 3 leaders, 6 helpers, 0 service threads (seen: 3 leaders, 6 helpers, 0 service): **yes**
- `mibz2-team3-twin@10`: rounds 0-19 once each, every run 3 leaders, 6 helpers, 0 service threads (seen: 3 leaders, 6 helpers, 0 service): **yes**
- `mibz2-team3@12`: rounds 0-19 once each, every run 4 leaders, 8 helpers, 0 service threads (seen: 4 leaders, 8 helpers, 0 service): **yes**
- `mibz2-svc1@10`: rounds 0-19 once each, every run 3 leaders, 6 helpers, 1 service threads (seen: 3 leaders, 6 helpers, 1 service): **yes**
- `mibz2-svc1@12`: rounds 0-19 once each, every run 3 leaders, 6 helpers, 1 service threads (seen: 3 leaders, 6 helpers, 1 service): **yes**
- `mibz2-svc2@10`: rounds 0-19 once each, every run 2 leaders, 4 helpers, 2 service threads (seen: 2 leaders, 4 helpers, 2 service): **yes**
- `mibz2-svc2@12`: rounds 0-19 once each, every run 3 leaders, 6 helpers, 2 service threads (seen: 3 leaders, 6 helpers, 2 service): **yes**
- `mibz2-svc1-t2@10`: rounds 0-19 once each, every run 3 leaders, 3 helpers, 1 service threads (seen: 3 leaders, 3 helpers, 1 service): **yes**
- `mibz2-svc1-t2@12`: rounds 0-19 once each, every run 3 leaders, 3 helpers, 1 service threads (seen: 3 leaders, 3 helpers, 1 service): **yes**
- no cell beyond the registered ones (seen: none): **yes**
- the trace `occupancy-t10-svc1` complete (rounds: 6): **yes**
- the trace `occupancy-t10-svc2` complete (rounds: 6): **yes**
- the trace `occupancy-t10-svc1t2` complete (rounds: 6): **yes**
- the trace `occupancy-t12-svc1` complete (rounds: 6): **yes**
- the trace `occupancy-t12-svc2` complete (rounds: 6): **yes**
- the trace `occupancy-t12-svc1t2` complete (rounds: 6): **yes**
- the noise control N1, `mibz2-team3-twin@10` against `mibz2-team3@10` (the same plan): 1.018 [1.000, 1.035] over 20 rounds, within 1 ± 0.03: **NO**

Run: **INVALID**

## The causal comparisons (equal budget; judged; C2 and C4 are also the product comparisons, against today's default)

| | arm | against | decode threads | speed [95% CI] | speed outcome | CPU [95% CI] | CPU outcome | the extra thread |
|---|---|---|---|---|---|---|---|---|
| C1 | `mibz2-svc1@10` | `mibz2-team3@10` | 10 against 9 | 0.855 [0.839, 0.871] | NONE (the run is invalid) | 1.061 [1.041, 1.083] | NONE (the run is invalid) | NONE (the run is invalid) |
| C2 | `mibz2-svc1@10` | `mibz2@10` | 10 against 9 | 0.805 [0.787, 0.823] | NONE (the run is invalid) | 1.119 [1.099, 1.138] | NONE (the run is invalid) | NONE (the run is invalid) |
| C3 | `mibz2-svc2@12` | `mibz2-team3@12` | 11 against 12 | 1.190 [1.172, 1.208] | NONE (the run is invalid) | 1.203 [1.187, 1.218] | NONE (the run is invalid) | NONE (the run is invalid) |
| C4 | `mibz2-svc2@12` | `mibz2@12` | 11 against 9 | 1.069 [1.045, 1.094] | NONE (the run is invalid) | 0.915 [0.900, 0.929] | NONE (the run is invalid) | NONE (the run is invalid) |
| D1 | `mibz2-svc2@12` | `mibz2-svc1@12` | 11 against 10 | 1.331 [1.307, 1.355] | NONE (the run is invalid) | 0.826 [0.806, 0.846] | NONE (the run is invalid) | NONE (the run is invalid) |

**The architecture's reading** (the registration's rule, computed from C1–C4): **NONE (the run is invalid)**

## Reported, never judged

| | arm | against | decode threads | speed [95% CI] | CPU [95% CI] |
|---|---|---|---|---|---|
| S1 | `mibz2-svc1@12` | `mibz2-team3@12` | 10 against 12 | 0.894 [0.881, 0.908] | 1.456 [1.427, 1.486] |
| S2 | `mibz2-svc1@12` | `mibz2@12` | 10 against 9 | 0.804 [0.789, 0.819] | 1.108 [1.086, 1.130] |
| S3 | `mibz2-svc2@10` | `mibz2-team3@10` | 8 against 9 | 1.130 [1.102, 1.159] | 1.093 [1.066, 1.120] |
| S4 | `mibz2-svc2@10` | `mibz2@10` | 8 against 9 | 1.064 [1.037, 1.092] | 1.152 [1.128, 1.177] |
| S5 | `mibz2-svc1-t2@10` | `mibz2-team3@10` | 7 against 9 | 0.865 [0.849, 0.881] | 1.196 [1.168, 1.225] |
| S6 | `mibz2-svc1-t2@12` | `mibz2-team3@12` | 7 against 12 | 0.915 [0.906, 0.923] | 1.678 [1.655, 1.701] |
| S7 | `mibz2-svc2@10` | `mibz2-svc1@10` | 8 against 10 | 1.322 [1.284, 1.362] | 1.030 [1.006, 1.054] |
| R1 | `mibz2@10` | `mibz2-team3@10` | 9 against 9 | 1.062 [1.040, 1.085] | 0.949 [0.932, 0.965] |
| R2 | `mibz2@12` | `mibz2-team3@12` | 9 against 12 | 1.113 [1.100, 1.126] | 1.315 [1.299, 1.331] |

(Speed: the reference's wall over the arm's, > 1 the arm is faster. CPU: the reference's CPU over the arm's, > 1 the arm spends less.)

## Every cell (medians), with the service workers' utilisation

Utilisation is each service thread's busy time over the run's span, from its trace (the occupancy pass of the same arm and budget, medians over its complete rounds): the headroom left, whatever the speed outcome.

| cell | decode threads (leaders + helpers + service) | wall s | CPU s | peak RSS MB | rounds | service utilisation (each; max) |
|---|---|---|---|---|---|---|
| `mibz2-svc1-t2@10` | 3+3+1 | 0.178 | 0.814 | 76 | 20 | 0.96; max 0.96 |
| `mibz2-svc1-t2@12` | 3+3+1 | 0.177 | 0.806 | 76 | 20 | 0.96; max 0.96 |
| `mibz2-svc1@10` | 3+6+1 | 0.180 | 0.921 | 76 | 20 | 0.96; max 0.96 |
| `mibz2-svc1@12` | 3+6+1 | 0.180 | 0.924 | 75 | 20 | 0.96; max 0.96 |
| `mibz2-svc2@10` | 2+4+2 | 0.136 | 0.901 | 64 | 20 | 0.68, 0.68; max 0.70 |
| `mibz2-svc2@12` | 3+6+2 | 0.136 | 1.132 | 83 | 20 | 0.85, 0.85; max 0.86 |
| `mibz2-team3-twin@10` | 3+6+0 | 0.151 | 0.970 | 67 | 20 | – |
| `mibz2-team3@10` | 3+6+0 | 0.154 | 0.991 | 67 | 20 | – |
| `mibz2-team3@12` | 4+8+0 | 0.161 | 1.358 | 82 | 20 | – |
| `mibz2@10` | 3+6+0 | 0.145 | 1.034 | 74 | 20 | – |
| `mibz2@12` | 3+6+0 | 0.144 | 1.032 | 75 | 20 | – |

## The traces (occupancy, medians over complete rounds)

| trace | rounds | blocks | util max | prep wait median / p90 ms | finish wait median / p90 ms | job wait median ms | backlog prep / finish (mean; max) | teams idle: prep / back share | run wait ms | saturation | prep starvation | finish backlog |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| occupancy-t10-svc1 | 6 | 431 | 0.96 | 0.003 / 0.004 | 0.537 / 1.378 | 2.290 | 0.04 / 1.65 (3; 4) | 0.551 / 0.000 | 107.0 | NONE | NONE | NONE |
| occupancy-t10-svc1t2 | 6 | 431 | 0.96 | 0.003 / 0.004 | 0.560 / 1.236 | 2.259 | 0.05 / 1.47 (3; 4) | 0.471 / 0.000 | 40.2 | NONE | NONE | NONE |
| occupancy-t10-svc2 | 6 | 431 | 0.70 | 0.138 / 0.563 | 0.048 / 0.332 | 0.132 | 0.77 / 0.42 (3; 4) | 0.154 / 0.013 | 79.9 | NONE | NONE | NONE |
| occupancy-t12-svc1 | 6 | 431 | 0.96 | 0.003 / 0.004 | 0.537 / 1.452 | 2.372 | 0.04 / 1.63 (3; 4) | 0.562 / 0.000 | 110.3 | NONE | NONE | NONE |
| occupancy-t12-svc1t2 | 6 | 431 | 0.96 | 0.003 / 0.004 | 0.534 / 1.269 | 2.196 | 0.05 / 1.46 (3; 4) | 0.438 / 0.000 | 41.3 | NONE | NONE | NONE |
| occupancy-t12-svc2 | 6 | 431 | 0.86 | 0.045 / 0.529 | 0.193 / 0.672 | 0.430 | 0.65 / 0.96 (4; 5) | 0.210 / 0.009 | 141.1 | NONE | NONE | NONE |

**The registered counterexample, service-worker saturation:** **NONE (the run is invalid)**
