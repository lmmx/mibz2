# The service core: the workstation run's report

## Validity

- the registered 20 rounds (seen: 20): **yes**
- a clean tree (`git-status.txt` present and empty): **yes**
- no `NOT-FROZEN.txt` (the frozen inputs unchanged): **yes**
- no `DRY-RUN.txt` (not a dry run): **yes**
- `commit.txt` (1394dd97148330665a6781227ba2afa136ef2939) is the checkout's head (1394dd97148330665a6781227ba2afa136ef2939): **yes**
- the ten-core topology, so `mibz2` is the pipelined default (lscpu: 1 socket, 10 cores, L3 20 MiB (1 instance)): **yes**
- every run the same bytes, none failed: **yes**
- `mibz2@10`: rounds 0-19 once each, every run 3 leaders, 6 helpers, 0 service threads (seen: 3 leaders, 6 helpers, 0 service): **yes**
- `mibz2@12`: rounds 0-19 once each, every run 3 leaders, 6 helpers, 0 service threads (seen: 3 leaders, 6 helpers, 0 service): **yes**
- `mibz2-team3@10`: rounds 0-19 once each, every run 3 leaders, 6 helpers, 0 service threads (seen: 3 leaders, 6 helpers, 0 service): **yes**
- `mibz2-team3-twin@10`: rounds 0-19 once each, every run 3 leaders, 6 helpers, 0 service threads (seen: 3 leaders, 6 helpers, 0 service): **yes**
- `mibz2-team3@12`: rounds 0-19 once each, every run 4 leaders, 8 helpers, 0 service threads (seen: 4 leaders, 8 helpers, 0 service): **yes**
- `mibz2-svc1@10`: rounds 0-19 once each, every run 3 leaders, 6 helpers, 1 service threads (seen: 3 leaders, 6 helpers, 1 service): **yes**
- `mibz2-svc1@12`: rounds 0-19 once each, every run 3 leaders, 6 helpers, 1 service threads (seen: 3 leaders, 6 helpers, 1 service): **yes**
- `mibz2-svc2@10`: rounds 0-19 once each, every run 2 leaders, 4 helpers, 2 service threads (seen: 2 leaders, 4 helpers, 2 service): **yes**
- `mibz2-svc2@12`: rounds 0-19 once each, every run 3 leaders, 6 helpers, 2 service threads (seen: 3 leaders, 6 helpers, 2 service): **yes**
- `mibz2-svc1-t2@10`: rounds 0-19 once each, every run 3 leaders, 3 helpers, 1 service threads (seen: 3 leaders, 3 helpers, 1 service): **yes**
- `mibz2-svc1-t2@12`: rounds 0-19 once each, every run 3 leaders, 3 helpers, 1 service threads (seen: 3 leaders, 3 helpers, 1 service): **yes**
- no cell beyond the registered ones (seen: none): **yes**
- the trace `occupancy-t10-svc1` complete (rounds: 6): **yes**
- the trace `occupancy-t10-svc2` complete (rounds: 6): **yes**
- the trace `occupancy-t10-svc1t2` complete (rounds: 6): **yes**
- the trace `occupancy-t12-svc1` complete (rounds: 6): **yes**
- the trace `occupancy-t12-svc2` complete (rounds: 6): **yes**
- the trace `occupancy-t12-svc1t2` complete (rounds: 6): **yes**
- the noise control N1, `mibz2-team3-twin@10` against `mibz2-team3@10` (the same plan): 1.003 [0.988, 1.018] over 20 rounds, within 1 ± 0.03: **yes**

Run: **VALID**

## The causal comparisons (equal budget; judged; C2 and C4 are also the product comparisons, against today's default)

| | arm | against | decode threads | speed [95% CI] | speed outcome | CPU [95% CI] | CPU outcome | the extra thread |
|---|---|---|---|---|---|---|---|---|
| C1 | `mibz2-svc1@10` | `mibz2-team3@10` | 10 against 9 | 0.854 [0.840, 0.869] | REGRESSION | 1.049 [1.019, 1.080] | SMALL CPU SAVING (above 1, not above the threshold) | (no gain) |
| C2 | `mibz2-svc1@10` | `mibz2@10` | 10 against 9 | 0.799 [0.786, 0.812] | REGRESSION | 1.099 [1.079, 1.118] | CPU SAVING | (no gain) |
| C3 | `mibz2-svc2@12` | `mibz2-team3@12` | 11 against 12 | 1.201 [1.181, 1.221] | GAIN | 1.206 [1.187, 1.226] | CPU SAVING | no more decode threads than the reference |
| C4 | `mibz2-svc2@12` | `mibz2@12` | 11 against 9 | 1.058 [1.035, 1.081] | GAIN | 0.901 [0.888, 0.914] | CPU COST | NOT SHOWN BEYOND ITS THREADS (11 against 9: needs a lower bound above 1.222) |
| D1 | `mibz2-svc2@12` | `mibz2-svc1@12` | 11 against 10 | 1.318 [1.297, 1.339] | GAIN | 0.806 [0.789, 0.823] | CPU COST | BEYOND ITS THREADS (lower bound above 1.100) |

**The architecture's reading** (the registration's rule, computed from C1–C4): **A TRADE (C2 or C4: a gain over today's default for a CPU cost, for Louis to weigh)**

## Reported, never judged

| | arm | against | decode threads | speed [95% CI] | CPU [95% CI] |
|---|---|---|---|---|---|
| S1 | `mibz2-svc1@12` | `mibz2-team3@12` | 10 against 12 | 0.911 [0.903, 0.920] | 1.497 [1.481, 1.513] |
| S2 | `mibz2-svc1@12` | `mibz2@12` | 10 against 9 | 0.802 [0.790, 0.815] | 1.118 [1.100, 1.137] |
| S3 | `mibz2-svc2@10` | `mibz2-team3@10` | 8 against 9 | 1.117 [1.089, 1.146] | 1.086 [1.058, 1.115] |
| S4 | `mibz2-svc2@10` | `mibz2@10` | 8 against 9 | 1.045 [1.023, 1.068] | 1.138 [1.118, 1.158] |
| S5 | `mibz2-svc1-t2@10` | `mibz2-team3@10` | 7 against 9 | 0.858 [0.839, 0.877] | 1.194 [1.165, 1.224] |
| S6 | `mibz2-svc1-t2@12` | `mibz2-team3@12` | 7 against 12 | 0.917 [0.902, 0.932] | 1.666 [1.640, 1.692] |
| S7 | `mibz2-svc2@10` | `mibz2-svc1@10` | 8 against 10 | 1.307 [1.279, 1.336] | 1.036 [1.010, 1.062] |
| R1 | `mibz2@10` | `mibz2-team3@10` | 9 against 9 | 1.069 [1.047, 1.091] | 0.954 [0.934, 0.976] |
| R2 | `mibz2@12` | `mibz2-team3@12` | 9 against 12 | 1.135 [1.118, 1.153] | 1.338 [1.322, 1.355] |

(Speed: the reference's wall over the arm's, > 1 the arm is faster. CPU: the reference's CPU over the arm's, > 1 the arm spends less.)

## Every cell (medians), with the service workers' utilisation

Utilisation is each service thread's busy time over the run's span, from its trace (the occupancy pass of the same arm and budget, medians over its complete rounds): the headroom left, whatever the speed outcome.

| cell | decode threads (leaders + helpers + service) | wall s | CPU s | peak RSS MB | rounds | service utilisation (each; max) |
|---|---|---|---|---|---|---|
| `mibz2-svc1-t2@10` | 3+3+1 | 0.178 | 0.809 | 76 | 20 | 0.96; max 0.96 |
| `mibz2-svc1-t2@12` | 3+3+1 | 0.177 | 0.816 | 76 | 20 | 0.96; max 0.96 |
| `mibz2-svc1@10` | 3+6+1 | 0.178 | 0.925 | 76 | 20 | 0.96; max 0.96 |
| `mibz2-svc1@12` | 3+6+1 | 0.178 | 0.911 | 76 | 20 | 0.96; max 0.96 |
| `mibz2-svc2@10` | 2+4+2 | 0.136 | 0.894 | 64 | 20 | 0.67, 0.69; max 0.70 |
| `mibz2-svc2@12` | 3+6+2 | 0.134 | 1.130 | 83 | 20 | 0.85, 0.85; max 0.85 |
| `mibz2-team3-twin@10` | 3+6+0 | 0.153 | 0.974 | 67 | 20 | – |
| `mibz2-team3@10` | 3+6+0 | 0.152 | 0.975 | 67 | 20 | – |
| `mibz2-team3@12` | 4+8+0 | 0.162 | 1.369 | 82 | 20 | – |
| `mibz2@10` | 3+6+0 | 0.143 | 1.025 | 74 | 20 | – |
| `mibz2@12` | 3+6+0 | 0.143 | 1.021 | 75 | 20 | – |

## The traces (occupancy, medians over complete rounds)

| trace | rounds | blocks | util max | prep wait median / p90 ms | finish wait median / p90 ms | job wait median ms | backlog prep / finish (mean; max) | teams idle: prep / back share | run wait ms | saturation | prep starvation | finish backlog |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| occupancy-t10-svc1 | 6 | 431 | 0.96 | 0.003 / 0.004 | 0.521 / 1.396 | 2.443 | 0.04 / 1.66 (3; 5) | 0.560 / 0.000 | 107.6 | SATURATED | PREP STARVATION | FINISH BACKLOG |
| occupancy-t10-svc1t2 | 6 | 431 | 0.96 | 0.003 / 0.004 | 0.581 / 1.305 | 2.229 | 0.05 / 1.48 (3; 5) | 0.457 / 0.000 | 40.9 | SATURATED | PREP STARVATION | FINISH BACKLOG |
| occupancy-t10-svc2 | 6 | 431 | 0.70 | 0.129 / 0.579 | 0.049 / 0.337 | 0.134 | 0.77 / 0.44 (3; 4) | 0.151 / 0.015 | 79.0 | not saturated | PREP STARVATION | no finish backlog |
| occupancy-t12-svc1 | 6 | 431 | 0.96 | 0.003 / 0.004 | 0.516 / 1.442 | 2.381 | 0.03 / 1.66 (3; 4) | 0.566 / 0.000 | 95.5 | SATURATED | PREP STARVATION | FINISH BACKLOG |
| occupancy-t12-svc1t2 | 6 | 431 | 0.96 | 0.003 / 0.004 | 0.540 / 1.283 | 2.251 | 0.04 / 1.47 (3; 5) | 0.462 / 0.000 | 40.5 | SATURATED | PREP STARVATION | FINISH BACKLOG |
| occupancy-t12-svc2 | 6 | 431 | 0.85 | 0.037 / 0.492 | 0.211 / 0.635 | 0.385 | 0.64 / 0.97 (4; 4) | 0.227 / 0.007 | 132.8 | not saturated | PREP STARVATION | no finish backlog |

**The registered counterexample, service-worker saturation:** **SATURATION BINDS AT K = 1 (svc1@12 saturated, and K = 2 faster at the same teams)**
