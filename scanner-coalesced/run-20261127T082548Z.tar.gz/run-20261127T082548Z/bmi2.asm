/home/louis/dev/mibz2/target/scanner-coalesced/tmp07k9z8ao/head-real:     file format elf64-x86-64


Disassembly of section .fini:

Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000004b600 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2>:
   4b600:	55                   	push   %rbp
   4b601:	41 57                	push   %r15
   4b603:	41 56                	push   %r14
   4b605:	41 55                	push   %r13
   4b607:	41 54                	push   %r12
   4b609:	53                   	push   %rbx
   4b60a:	48 81 ec 68 01 00 00 	sub    $0x168,%rsp
   4b611:	4d 89 ca             	mov    %r9,%r10
   4b614:	4c 89 84 24 80 00 00 	mov    %r8,0x80(%rsp)
   4b61b:	00 
   4b61c:	48 89 b4 24 d8 00 00 	mov    %rsi,0xd8(%rsp)
   4b623:	00 
   4b624:	48 89 bc 24 b0 00 00 	mov    %rdi,0xb0(%rsp)
   4b62b:	00 
   4b62c:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4b633:	00 
   4b634:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4b63b:	00 
   4b63c:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4b643:	00 
   4b644:	4a 8d 04 dd 00 00 00 	lea    0x0(,%r11,8),%rax
   4b64b:	00 
   4b64c:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
   4b653:	00 
   4b654:	31 db                	xor    %ebx,%ebx
   4b656:	45 31 f6             	xor    %r14d,%r14d
   4b659:	89 44 24 7c          	mov    %eax,0x7c(%rsp)
   4b65d:	4c 89 54 24 30       	mov    %r10,0x30(%rsp)
   4b662:	48 89 8c 24 e8 00 00 	mov    %rcx,0xe8(%rsp)
   4b669:	00 
   4b66a:	48 89 94 24 e0 00 00 	mov    %rdx,0xe0(%rsp)
   4b671:	00 
   4b672:	0f b6 3c 1a          	movzbl (%rdx,%rbx,1),%edi
   4b676:	48 8d 43 01          	lea    0x1(%rbx),%rax
   4b67a:	48 39 c8             	cmp    %rcx,%rax
   4b67d:	73 31                	jae    4b6b0 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xb0>
   4b67f:	48 89 ce             	mov    %rcx,%rsi
   4b682:	48 29 de             	sub    %rbx,%rsi
   4b685:	bb 01 00 00 00       	mov    $0x1,%ebx
   4b68a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   4b690:	40 38 3c 02          	cmp    %dil,(%rdx,%rax,1)
   4b694:	75 1f                	jne    4b6b5 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xb5>
   4b696:	48 ff c3             	inc    %rbx
   4b699:	48 ff c0             	inc    %rax
   4b69c:	48 39 c1             	cmp    %rax,%rcx
   4b69f:	75 ef                	jne    4b690 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x90>
   4b6a1:	48 89 f3             	mov    %rsi,%rbx
   4b6a4:	48 89 c8             	mov    %rcx,%rax
   4b6a7:	eb 0c                	jmp    4b6b5 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xb5>
   4b6a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   4b6b0:	bb 01 00 00 00       	mov    $0x1,%ebx
   4b6b5:	40 80 ff 06          	cmp    $0x6,%dil
   4b6b9:	0f 83 94 27 00 00    	jae    4de53 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x2853>
   4b6bf:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
   4b6c6:	00 
   4b6c7:	48 69 ff c8 1a 00 00 	imul   $0x1ac8,%rdi,%rdi
   4b6ce:	48 03 bc 24 d8 00 00 	add    0xd8(%rsp),%rdi
   4b6d5:	00 
   4b6d6:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   4b6dd:	00 
   4b6de:	4c 8b 20             	mov    (%rax),%r12
   4b6e1:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
   4b6e6:	48 6b c3 7d          	imul   $0x7d,%rbx,%rax
   4b6ea:	48 83 c0 10          	add    $0x10,%rax
   4b6ee:	4c 01 e0             	add    %r12,%rax
   4b6f1:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
   4b6f8:	48 0f 42 c1          	cmovb  %rcx,%rax
   4b6fc:	48 89 da             	mov    %rbx,%rdx
   4b6ff:	4c 39 d8             	cmp    %r11,%rax
   4b702:	48 89 9c 24 f0 00 00 	mov    %rbx,0xf0(%rsp)
   4b709:	00 
   4b70a:	0f 86 2c 07 00 00    	jbe    4be3c <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x83c>
   4b710:	4c 89 e0             	mov    %r12,%rax
   4b713:	48 83 c0 10          	add    $0x10,%rax
   4b717:	48 0f 42 c1          	cmovb  %rcx,%rax
   4b71b:	4c 89 da             	mov    %r11,%rdx
   4b71e:	48 29 c2             	sub    %rax,%rdx
   4b721:	b8 00 00 00 00       	mov    $0x0,%eax
   4b726:	48 0f 42 d0          	cmovb  %rax,%rdx
   4b72a:	48 83 fa 7c          	cmp    $0x7c,%rdx
   4b72e:	0f 87 ec 06 00 00    	ja     4be20 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x820>
   4b734:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   4b73b:	00 
   4b73c:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
   4b740:	8b 42 10             	mov    0x10(%rdx),%eax
   4b743:	8b 52 14             	mov    0x14(%rdx),%edx
   4b746:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4b74a:	0f b7 97 c4 1a 00 00 	movzwl 0x1ac4(%rdi),%edx
   4b751:	66 89 94 24 88 00 00 	mov    %dx,0x88(%rsp)
   4b758:	00 
   4b759:	49 83 fc f7          	cmp    $0xfffffffffffffff7,%r12
   4b75d:	0f 87 fb 17 00 00    	ja     4cf5e <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x195e>
   4b763:	49 8d 54 24 08       	lea    0x8(%r12),%rdx
   4b768:	4c 39 da             	cmp    %r11,%rdx
   4b76b:	0f 87 ed 17 00 00    	ja     4cf5e <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x195e>
   4b771:	4b 8b 14 22          	mov    (%r10,%r12,1),%rdx
   4b775:	48 0f ca             	bswap  %rdx
   4b778:	c4 e2 fb f7 ea       	shrx   %rax,%rdx,%rbp
   4b77d:	48 09 cd             	or     %rcx,%rbp
   4b780:	41 bd 3f 00 00 00    	mov    $0x3f,%r13d
   4b786:	41 29 c5             	sub    %eax,%r13d
   4b789:	44 89 e9             	mov    %r13d,%ecx
   4b78c:	c1 e9 03             	shr    $0x3,%ecx
   4b78f:	49 01 cc             	add    %rcx,%r12
   4b792:	41 83 e5 f8          	and    $0xfffffff8,%r13d
   4b796:	41 01 c5             	add    %eax,%r13d
   4b799:	b8 32 00 00 00       	mov    $0x32,%eax
   4b79e:	4c 89 f1             	mov    %r14,%rcx
   4b7a1:	eb 6e                	jmp    4b811 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x211>
   4b7a3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   4b7aa:	84 00 00 00 00 00 
   4b7b0:	48 8d 3c 1b          	lea    (%rbx,%rbx,1),%rdi
   4b7b4:	49 03 79 08          	add    0x8(%r9),%rdi
   4b7b8:	4b 8d 14 36          	lea    (%r14,%r14,1),%rdx
   4b7bc:	4c 89 c6             	mov    %r8,%rsi
   4b7bf:	ff 15 63 50 05 00    	call   *0x55063(%rip)        # a0828 <memcpy@GLIBC_2.14>
   4b7c5:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4b7cc:	00 
   4b7cd:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4b7d4:	00 
   4b7d5:	4c 01 f3             	add    %r14,%rbx
   4b7d8:	49 89 59 10          	mov    %rbx,0x10(%r9)
   4b7dc:	45 31 ff             	xor    %r15d,%r15d
   4b7df:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4b7e4:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4b7eb:	00 
   4b7ec:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4b7f1:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
   4b7f8:	00 
   4b7f9:	48 03 84 24 c0 00 00 	add    0xc0(%rsp),%rax
   4b800:	00 
   4b801:	4c 29 f0             	sub    %r14,%rax
   4b804:	4c 89 f9             	mov    %r15,%rcx
   4b807:	48 83 f8 09          	cmp    $0x9,%rax
   4b80b:	0f 86 5c 09 00 00    	jbe    4c16d <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xb6d>
   4b811:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
   4b818:	00 
   4b819:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
   4b81d:	48 83 c2 f6          	add    $0xfffffffffffffff6,%rdx
   4b821:	48 81 fa e8 03 00 00 	cmp    $0x3e8,%rdx
   4b828:	b8 e8 03 00 00       	mov    $0x3e8,%eax
   4b82d:	48 0f 43 d0          	cmovae %rax,%rdx
   4b831:	49 89 ce             	mov    %rcx,%r14
   4b834:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
   4b83b:	00 
   4b83c:	48 89 94 24 a8 00 00 	mov    %rdx,0xa8(%rsp)
   4b843:	00 
   4b844:	48 39 d1             	cmp    %rdx,%rcx
   4b847:	76 67                	jbe    4b8b0 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x2b0>
   4b849:	4d 89 f7             	mov    %r14,%r15
   4b84c:	49 81 fe e8 03 00 00 	cmp    $0x3e8,%r14
   4b853:	76 9c                	jbe    4b7f1 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1f1>
   4b855:	49 81 fe 13 04 00 00 	cmp    $0x413,%r14
   4b85c:	0f 83 f9 23 00 00    	jae    4dc5b <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x265b>
   4b862:	49 8b 01             	mov    (%r9),%rax
   4b865:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4b869:	48 29 d8             	sub    %rbx,%rax
   4b86c:	49 39 c6             	cmp    %rax,%r14
   4b86f:	0f 86 3b ff ff ff    	jbe    4b7b0 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1b0>
   4b875:	b9 02 00 00 00       	mov    $0x2,%ecx
   4b87a:	41 b8 02 00 00 00    	mov    $0x2,%r8d
   4b880:	4c 89 cf             	mov    %r9,%rdi
   4b883:	48 89 de             	mov    %rbx,%rsi
   4b886:	4c 89 f2             	mov    %r14,%rdx
   4b889:	e8 62 b4 fe ff       	call   36cf0 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECshzyx7VBzFal_5mibz2>
   4b88e:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4b895:	00 
   4b896:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4b89d:	00 
   4b89e:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4b8a2:	e9 09 ff ff ff       	jmp    4b7b0 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1b0>
   4b8a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   4b8ae:	00 00 
   4b8b0:	49 8d 76 12          	lea    0x12(%r14),%rsi
   4b8b4:	48 81 fe 13 04 00 00 	cmp    $0x413,%rsi
   4b8bb:	0f 83 ed 22 00 00    	jae    4dbae <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x25ae>
   4b8c1:	4c 89 e6             	mov    %r12,%rsi
   4b8c4:	4f 8d 24 70          	lea    (%r8,%r14,2),%r12
   4b8c8:	48 89 e8             	mov    %rbp,%rax
   4b8cb:	48 c1 e8 36          	shr    $0x36,%rax
   4b8cf:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4b8d2:	41 89 d7             	mov    %edx,%r15d
   4b8d5:	41 c1 ef 1e          	shr    $0x1e,%r15d
   4b8d9:	0f 84 57 01 00 00    	je     4ba36 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x436>
   4b8df:	c4 e2 e9 f7 dd       	shlx   %rdx,%rbp,%rbx
   4b8e4:	0f b6 c2             	movzbl %dl,%eax
   4b8e7:	41 29 c5             	sub    %eax,%r13d
   4b8ea:	0f b6 c6             	movzbl %dh,%eax
   4b8ed:	66 41 89 04 24       	mov    %ax,(%r12)
   4b8f2:	c1 ea 10             	shr    $0x10,%edx
   4b8f5:	0f b6 c2             	movzbl %dl,%eax
   4b8f8:	66 41 89 44 24 02    	mov    %ax,0x2(%r12)
   4b8fe:	48 89 d8             	mov    %rbx,%rax
   4b901:	48 c1 e8 36          	shr    $0x36,%rax
   4b905:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4b908:	89 d0                	mov    %edx,%eax
   4b90a:	c1 e8 1e             	shr    $0x1e,%eax
   4b90d:	0f 84 d3 01 00 00    	je     4bae6 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x4e6>
   4b913:	c4 e2 e9 f7 db       	shlx   %rdx,%rbx,%rbx
   4b918:	0f b6 ca             	movzbl %dl,%ecx
   4b91b:	41 29 cd             	sub    %ecx,%r13d
   4b91e:	0f b6 ce             	movzbl %dh,%ecx
   4b921:	66 43 89 0c 7c       	mov    %cx,(%r12,%r15,2)
   4b926:	c1 ea 10             	shr    $0x10,%edx
   4b929:	0f b6 ca             	movzbl %dl,%ecx
   4b92c:	66 43 89 4c 7c 02    	mov    %cx,0x2(%r12,%r15,2)
   4b932:	49 01 c7             	add    %rax,%r15
   4b935:	48 89 d8             	mov    %rbx,%rax
   4b938:	48 c1 e8 36          	shr    $0x36,%rax
   4b93c:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4b93f:	89 d0                	mov    %edx,%eax
   4b941:	c1 e8 1e             	shr    $0x1e,%eax
   4b944:	0f 84 49 02 00 00    	je     4bb93 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x593>
   4b94a:	c4 e2 e9 f7 db       	shlx   %rdx,%rbx,%rbx
   4b94f:	0f b6 ca             	movzbl %dl,%ecx
   4b952:	41 29 cd             	sub    %ecx,%r13d
   4b955:	0f b6 ce             	movzbl %dh,%ecx
   4b958:	66 43 89 0c 7c       	mov    %cx,(%r12,%r15,2)
   4b95d:	c1 ea 10             	shr    $0x10,%edx
   4b960:	0f b6 ca             	movzbl %dl,%ecx
   4b963:	66 43 89 4c 7c 02    	mov    %cx,0x2(%r12,%r15,2)
   4b969:	49 01 c7             	add    %rax,%r15
   4b96c:	48 89 d8             	mov    %rbx,%rax
   4b96f:	48 c1 e8 36          	shr    $0x36,%rax
   4b973:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4b976:	89 d0                	mov    %edx,%eax
   4b978:	c1 e8 1e             	shr    $0x1e,%eax
   4b97b:	0f 84 bf 02 00 00    	je     4bc40 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x640>
   4b981:	c4 e2 e9 f7 db       	shlx   %rdx,%rbx,%rbx
   4b986:	0f b6 ca             	movzbl %dl,%ecx
   4b989:	41 29 cd             	sub    %ecx,%r13d
   4b98c:	0f b6 ce             	movzbl %dh,%ecx
   4b98f:	66 43 89 0c 7c       	mov    %cx,(%r12,%r15,2)
   4b994:	c1 ea 10             	shr    $0x10,%edx
   4b997:	0f b6 ca             	movzbl %dl,%ecx
   4b99a:	66 43 89 4c 7c 02    	mov    %cx,0x2(%r12,%r15,2)
   4b9a0:	49 01 c7             	add    %rax,%r15
   4b9a3:	48 89 d8             	mov    %rbx,%rax
   4b9a6:	48 c1 e8 36          	shr    $0x36,%rax
   4b9aa:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4b9ad:	89 d0                	mov    %edx,%eax
   4b9af:	c1 e8 1e             	shr    $0x1e,%eax
   4b9b2:	0f 84 35 03 00 00    	je     4bced <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x6ed>
   4b9b8:	c4 e2 e9 f7 db       	shlx   %rdx,%rbx,%rbx
   4b9bd:	0f b6 ca             	movzbl %dl,%ecx
   4b9c0:	41 29 cd             	sub    %ecx,%r13d
   4b9c3:	0f b6 ce             	movzbl %dh,%ecx
   4b9c6:	66 43 89 0c 7c       	mov    %cx,(%r12,%r15,2)
   4b9cb:	c1 ea 10             	shr    $0x10,%edx
   4b9ce:	0f b6 ca             	movzbl %dl,%ecx
   4b9d1:	66 43 89 4c 7c 02    	mov    %cx,0x2(%r12,%r15,2)
   4b9d7:	49 01 c7             	add    %rax,%r15
   4b9da:	44 89 ea             	mov    %r13d,%edx
   4b9dd:	49 89 f4             	mov    %rsi,%r12
   4b9e0:	48 83 fe f7          	cmp    $0xfffffffffffffff7,%rsi
   4b9e4:	0f 87 b7 03 00 00    	ja     4bda1 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x7a1>
   4b9ea:	49 8d 44 24 08       	lea    0x8(%r12),%rax
   4b9ef:	4c 39 d8             	cmp    %r11,%rax
   4b9f2:	0f 87 a9 03 00 00    	ja     4bda1 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x7a1>
   4b9f8:	4b 8b 04 22          	mov    (%r10,%r12,1),%rax
   4b9fc:	48 0f c8             	bswap  %rax
   4b9ff:	c4 e2 eb f7 e8       	shrx   %rdx,%rax,%rbp
   4ba04:	48 09 dd             	or     %rbx,%rbp
   4ba07:	41 bd 3f 00 00 00    	mov    $0x3f,%r13d
   4ba0d:	41 29 d5             	sub    %edx,%r13d
   4ba10:	44 89 e8             	mov    %r13d,%eax
   4ba13:	c1 e8 03             	shr    $0x3,%eax
   4ba16:	49 01 c4             	add    %rax,%r12
   4ba19:	41 83 e5 f8          	and    $0xfffffff8,%r13d
   4ba1d:	41 01 d5             	add    %edx,%r13d
   4ba20:	4d 01 fe             	add    %r15,%r14
   4ba23:	4c 3b b4 24 a8 00 00 	cmp    0xa8(%rsp),%r14
   4ba2a:	00 
   4ba2b:	0f 86 7f fe ff ff    	jbe    4b8b0 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x2b0>
   4ba31:	e9 13 fe ff ff       	jmp    4b849 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x249>
   4ba36:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4ba3b:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4ba40:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4ba45:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4ba49:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4ba4d:	48 89 fe             	mov    %rdi,%rsi
   4ba50:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4ba55:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4ba5a:	4d 89 d0             	mov    %r10,%r8
   4ba5d:	4d 89 d9             	mov    %r11,%r9
   4ba60:	e8 bb f7 ff ff       	call   4b220 <_RNvMs_NtCshzyx7VBzFal_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4ba65:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4ba6a:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4ba6f:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4ba74:	0f 10 02             	movups (%rdx),%xmm0
   4ba77:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4ba7c:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4ba80:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4ba85:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   4ba8a:	48 8b 5c 24 68       	mov    0x68(%rsp),%rbx
   4ba8f:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4ba94:	8b 6c 24 74          	mov    0x74(%rsp),%ebp
   4ba98:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4ba9c:	0f 85 c3 0b 00 00    	jne    4c665 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1065>
   4baa2:	66 41 89 04 24       	mov    %ax,(%r12)
   4baa7:	66 3b 84 24 88 00 00 	cmp    0x88(%rsp),%ax
   4baae:	00 
   4baaf:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4bab6:	00 
   4bab7:	0f 84 00 0c 00 00    	je     4c6bd <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x10bd>
   4babd:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4bac1:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   4bac7:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4bace:	00 
   4bacf:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4bad4:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4badb:	00 
   4badc:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4bae1:	e9 18 fe ff ff       	jmp    4b8fe <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x2fe>
   4bae6:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4baeb:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   4baf0:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4baf5:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4baf9:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4bafd:	48 89 fe             	mov    %rdi,%rsi
   4bb00:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4bb05:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4bb0a:	4d 89 d0             	mov    %r10,%r8
   4bb0d:	4d 89 d9             	mov    %r11,%r9
   4bb10:	e8 0b f7 ff ff       	call   4b220 <_RNvMs_NtCshzyx7VBzFal_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4bb15:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4bb1a:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4bb1f:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4bb24:	0f 10 02             	movups (%rdx),%xmm0
   4bb27:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4bb2c:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4bb30:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4bb35:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   4bb3a:	48 8b 5c 24 68       	mov    0x68(%rsp),%rbx
   4bb3f:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4bb44:	8b 6c 24 74          	mov    0x74(%rsp),%ebp
   4bb48:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4bb4c:	0f 85 1b 0b 00 00    	jne    4c66d <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x106d>
   4bb52:	66 43 89 04 7c       	mov    %ax,(%r12,%r15,2)
   4bb57:	49 ff c7             	inc    %r15
   4bb5a:	66 3b 84 24 88 00 00 	cmp    0x88(%rsp),%ax
   4bb61:	00 
   4bb62:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4bb69:	00 
   4bb6a:	0f 84 58 0b 00 00    	je     4c6c8 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x10c8>
   4bb70:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4bb74:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4bb7b:	00 
   4bb7c:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4bb81:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4bb88:	00 
   4bb89:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4bb8e:	e9 a2 fd ff ff       	jmp    4b935 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x335>
   4bb93:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4bb98:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   4bb9d:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4bba2:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4bba6:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4bbaa:	48 89 fe             	mov    %rdi,%rsi
   4bbad:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4bbb2:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4bbb7:	4d 89 d0             	mov    %r10,%r8
   4bbba:	4d 89 d9             	mov    %r11,%r9
   4bbbd:	e8 5e f6 ff ff       	call   4b220 <_RNvMs_NtCshzyx7VBzFal_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4bbc2:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4bbc7:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4bbcc:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4bbd1:	0f 10 02             	movups (%rdx),%xmm0
   4bbd4:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4bbd9:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4bbdd:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4bbe2:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   4bbe7:	48 8b 5c 24 68       	mov    0x68(%rsp),%rbx
   4bbec:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4bbf1:	8b 6c 24 74          	mov    0x74(%rsp),%ebp
   4bbf5:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4bbf9:	0f 85 6e 0a 00 00    	jne    4c66d <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x106d>
   4bbff:	66 43 89 04 7c       	mov    %ax,(%r12,%r15,2)
   4bc04:	49 ff c7             	inc    %r15
   4bc07:	66 3b 84 24 88 00 00 	cmp    0x88(%rsp),%ax
   4bc0e:	00 
   4bc0f:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4bc16:	00 
   4bc17:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4bc1e:	00 
   4bc1f:	0f 84 ab 0a 00 00    	je     4c6d0 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x10d0>
   4bc25:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4bc29:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4bc2e:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4bc35:	00 
   4bc36:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4bc3b:	e9 2c fd ff ff       	jmp    4b96c <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x36c>
   4bc40:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4bc45:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   4bc4a:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4bc4f:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4bc53:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4bc57:	48 89 fe             	mov    %rdi,%rsi
   4bc5a:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4bc5f:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4bc64:	4d 89 d0             	mov    %r10,%r8
   4bc67:	4d 89 d9             	mov    %r11,%r9
   4bc6a:	e8 b1 f5 ff ff       	call   4b220 <_RNvMs_NtCshzyx7VBzFal_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4bc6f:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4bc74:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4bc79:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4bc7e:	0f 10 02             	movups (%rdx),%xmm0
   4bc81:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4bc86:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4bc8a:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4bc8f:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   4bc94:	48 8b 5c 24 68       	mov    0x68(%rsp),%rbx
   4bc99:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4bc9e:	8b 6c 24 74          	mov    0x74(%rsp),%ebp
   4bca2:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4bca6:	0f 85 c1 09 00 00    	jne    4c66d <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x106d>
   4bcac:	66 43 89 04 7c       	mov    %ax,(%r12,%r15,2)
   4bcb1:	49 ff c7             	inc    %r15
   4bcb4:	66 3b 84 24 88 00 00 	cmp    0x88(%rsp),%ax
   4bcbb:	00 
   4bcbc:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4bcc3:	00 
   4bcc4:	0f 84 fe 09 00 00    	je     4c6c8 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x10c8>
   4bcca:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4bcce:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4bcd5:	00 
   4bcd6:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4bcdb:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4bce2:	00 
   4bce3:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4bce8:	e9 b6 fc ff ff       	jmp    4b9a3 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x3a3>
   4bced:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4bcf2:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   4bcf7:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4bcfc:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4bd00:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4bd04:	48 89 fe             	mov    %rdi,%rsi
   4bd07:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4bd0c:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4bd11:	4d 89 d0             	mov    %r10,%r8
   4bd14:	4d 89 d9             	mov    %r11,%r9
   4bd17:	e8 04 f5 ff ff       	call   4b220 <_RNvMs_NtCshzyx7VBzFal_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4bd1c:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4bd21:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4bd26:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4bd2b:	0f 10 02             	movups (%rdx),%xmm0
   4bd2e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4bd33:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4bd37:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4bd3c:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   4bd41:	48 8b 5c 24 68       	mov    0x68(%rsp),%rbx
   4bd46:	8b 54 24 70          	mov    0x70(%rsp),%edx
   4bd4a:	8b 6c 24 74          	mov    0x74(%rsp),%ebp
   4bd4e:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4bd52:	0f 85 12 09 00 00    	jne    4c66a <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x106a>
   4bd58:	66 43 89 04 7c       	mov    %ax,(%r12,%r15,2)
   4bd5d:	49 ff c7             	inc    %r15
   4bd60:	66 3b 84 24 88 00 00 	cmp    0x88(%rsp),%ax
   4bd67:	00 
   4bd68:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4bd6f:	00 
   4bd70:	0f 84 4f 09 00 00    	je     4c6c5 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x10c5>
   4bd76:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4bd7a:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4bd81:	00 
   4bd82:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4bd87:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4bd8e:	00 
   4bd8f:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4bd94:	49 89 f4             	mov    %rsi,%r12
   4bd97:	48 83 fe f7          	cmp    $0xfffffffffffffff7,%rsi
   4bd9b:	0f 86 49 fc ff ff    	jbe    4b9ea <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x3ea>
   4bda1:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
   4bda6:	48 89 5c 24 48       	mov    %rbx,0x48(%rsp)
   4bdab:	89 54 24 50          	mov    %edx,0x50(%rsp)
   4bdaf:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4bdb3:	89 44 24 54          	mov    %eax,0x54(%rsp)
   4bdb7:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   4bdbc:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   4bdc1:	4c 89 d2             	mov    %r10,%rdx
   4bdc4:	4c 89 d9             	mov    %r11,%rcx
   4bdc7:	e8 c4 9e ff ff       	call   45c90 <_RNvMNtCshzyx7VBzFal_5mibz24bitsNtB2_3Reg11refill_slow>
   4bdcc:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4bdd1:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4bdd8:	00 
   4bdd9:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4bdde:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4bde5:	00 
   4bde6:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4bded:	00 
   4bdee:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   4bdf3:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   4bdf8:	44 8b 6c 24 20       	mov    0x20(%rsp),%r13d
   4bdfd:	8b 44 24 24          	mov    0x24(%rsp),%eax
   4be01:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   4be05:	4d 01 fe             	add    %r15,%r14
   4be08:	4c 3b b4 24 a8 00 00 	cmp    0xa8(%rsp),%r14
   4be0f:	00 
   4be10:	0f 86 9a fa ff ff    	jbe    4b8b0 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x2b0>
   4be16:	e9 2e fa ff ff       	jmp    4b849 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x249>
   4be1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   4be20:	48 b8 77 be 9f 1a 2f 	movabs $0x624dd2f1a9fbe77,%rax
   4be27:	dd 24 06 
   4be2a:	c4 e2 fb f6 c0       	mulx   %rax,%rax,%rax
   4be2f:	48 29 c2             	sub    %rax,%rdx
   4be32:	48 d1 ea             	shr    $1,%rdx
   4be35:	48 01 c2             	add    %rax,%rdx
   4be38:	48 c1 ea 06          	shr    $0x6,%rdx
   4be3c:	48 89 94 24 88 00 00 	mov    %rdx,0x88(%rsp)
   4be43:	00 
   4be44:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   4be4b:	00 
   4be4c:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
   4be50:	8b 42 10             	mov    0x10(%rdx),%eax
   4be53:	8b 52 14             	mov    0x14(%rdx),%edx
   4be56:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4be5a:	0f b7 97 c4 1a 00 00 	movzwl 0x1ac4(%rdi),%edx
   4be61:	66 89 54 24 2e       	mov    %dx,0x2e(%rsp)
   4be66:	49 83 fc f7          	cmp    $0xfffffffffffffff7,%r12
   4be6a:	0f 87 05 09 00 00    	ja     4c775 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1175>
   4be70:	49 8d 54 24 08       	lea    0x8(%r12),%rdx
   4be75:	4c 39 da             	cmp    %r11,%rdx
   4be78:	0f 87 f7 08 00 00    	ja     4c775 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1175>
   4be7e:	4b 8b 14 22          	mov    (%r10,%r12,1),%rdx
   4be82:	48 0f ca             	bswap  %rdx
   4be85:	c4 e2 fb f7 ea       	shrx   %rax,%rdx,%rbp
   4be8a:	48 09 cd             	or     %rcx,%rbp
   4be8d:	41 bd 3f 00 00 00    	mov    $0x3f,%r13d
   4be93:	41 29 c5             	sub    %eax,%r13d
   4be96:	44 89 e9             	mov    %r13d,%ecx
   4be99:	c1 e9 03             	shr    $0x3,%ecx
   4be9c:	49 01 cc             	add    %rcx,%r12
   4be9f:	41 83 e5 f8          	and    $0xfffffff8,%r13d
   4bea3:	41 01 c5             	add    %eax,%r13d
   4bea6:	48 6b 94 24 88 00 00 	imul   $0x32,0x88(%rsp),%rdx
   4bead:	00 32 
   4beaf:	48 83 fa 0a          	cmp    $0xa,%rdx
   4beb3:	0f 83 95 09 00 00    	jae    4c84e <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x124e>
   4beb9:	48 85 d2             	test   %rdx,%rdx
   4bebc:	0f 84 63 02 00 00    	je     4c125 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xb25>
   4bec2:	4a 8d 0c 32          	lea    (%rdx,%r14,1),%rcx
   4bec6:	48 83 fa 01          	cmp    $0x1,%rdx
   4beca:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
   4bed1:	00 
   4bed2:	0f 84 3f 01 00 00    	je     4c017 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xa17>
   4bed8:	48 8d 59 fe          	lea    -0x2(%rcx),%rbx
   4bedc:	49 39 de             	cmp    %rbx,%r14
   4bedf:	0f 87 29 01 00 00    	ja     4c00e <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xa0e>
   4bee5:	48 89 e8             	mov    %rbp,%rax
   4bee8:	48 c1 e8 36          	shr    $0x36,%rax
   4beec:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4beef:	89 d0                	mov    %edx,%eax
   4bef1:	c1 e8 1e             	shr    $0x1e,%eax
   4bef4:	0f 84 6c 12 00 00    	je     4d166 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1b66>
   4befa:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4beff:	0f b6 ca             	movzbl %dl,%ecx
   4bf02:	41 29 cd             	sub    %ecx,%r13d
   4bf05:	4d 89 f7             	mov    %r14,%r15
   4bf08:	44 89 f9             	mov    %r15d,%ecx
   4bf0b:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4bf11:	0f b6 f6             	movzbl %dh,%esi
   4bf14:	66 41 89 34 48       	mov    %si,(%r8,%rcx,2)
   4bf19:	c1 ea 10             	shr    $0x10,%edx
   4bf1c:	0f b6 d2             	movzbl %dl,%edx
   4bf1f:	66 41 89 54 48 02    	mov    %dx,0x2(%r8,%rcx,2)
   4bf25:	49 01 c7             	add    %rax,%r15
   4bf28:	4d 89 fe             	mov    %r15,%r14
   4bf2b:	49 39 df             	cmp    %rbx,%r15
   4bf2e:	0f 87 da 00 00 00    	ja     4c00e <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xa0e>
   4bf34:	48 89 e8             	mov    %rbp,%rax
   4bf37:	48 c1 e8 36          	shr    $0x36,%rax
   4bf3b:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4bf3e:	89 d0                	mov    %edx,%eax
   4bf40:	c1 e8 1e             	shr    $0x1e,%eax
   4bf43:	0f 84 26 15 00 00    	je     4d46f <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1e6f>
   4bf49:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4bf4e:	0f b6 ca             	movzbl %dl,%ecx
   4bf51:	41 29 cd             	sub    %ecx,%r13d
   4bf54:	4d 89 f7             	mov    %r14,%r15
   4bf57:	44 89 f9             	mov    %r15d,%ecx
   4bf5a:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4bf60:	0f b6 f6             	movzbl %dh,%esi
   4bf63:	66 41 89 34 48       	mov    %si,(%r8,%rcx,2)
   4bf68:	c1 ea 10             	shr    $0x10,%edx
   4bf6b:	0f b6 d2             	movzbl %dl,%edx
   4bf6e:	66 41 89 54 48 02    	mov    %dx,0x2(%r8,%rcx,2)
   4bf74:	49 01 c7             	add    %rax,%r15
   4bf77:	4d 89 fe             	mov    %r15,%r14
   4bf7a:	49 39 df             	cmp    %rbx,%r15
   4bf7d:	0f 87 8b 00 00 00    	ja     4c00e <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xa0e>
   4bf83:	48 89 e8             	mov    %rbp,%rax
   4bf86:	48 c1 e8 36          	shr    $0x36,%rax
   4bf8a:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4bf8d:	89 d0                	mov    %edx,%eax
   4bf8f:	c1 e8 1e             	shr    $0x1e,%eax
   4bf92:	0f 84 5e 16 00 00    	je     4d5f6 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1ff6>
   4bf98:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4bf9d:	0f b6 ca             	movzbl %dl,%ecx
   4bfa0:	41 29 cd             	sub    %ecx,%r13d
   4bfa3:	4d 89 f7             	mov    %r14,%r15
   4bfa6:	44 89 f9             	mov    %r15d,%ecx
   4bfa9:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4bfaf:	0f b6 f6             	movzbl %dh,%esi
   4bfb2:	66 41 89 34 48       	mov    %si,(%r8,%rcx,2)
   4bfb7:	c1 ea 10             	shr    $0x10,%edx
   4bfba:	0f b6 d2             	movzbl %dl,%edx
   4bfbd:	66 41 89 54 48 02    	mov    %dx,0x2(%r8,%rcx,2)
   4bfc3:	49 01 c7             	add    %rax,%r15
   4bfc6:	4d 89 fe             	mov    %r15,%r14
   4bfc9:	49 39 df             	cmp    %rbx,%r15
   4bfcc:	77 40                	ja     4c00e <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xa0e>
   4bfce:	48 89 e8             	mov    %rbp,%rax
   4bfd1:	48 c1 e8 36          	shr    $0x36,%rax
   4bfd5:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4bfd8:	89 d0                	mov    %edx,%eax
   4bfda:	c1 e8 1e             	shr    $0x1e,%eax
   4bfdd:	0f 84 d0 17 00 00    	je     4d7b3 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x21b3>
   4bfe3:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4bfe8:	0f b6 ca             	movzbl %dl,%ecx
   4bfeb:	41 29 cd             	sub    %ecx,%r13d
   4bfee:	44 89 f1             	mov    %r14d,%ecx
   4bff1:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4bff7:	0f b6 f6             	movzbl %dh,%esi
   4bffa:	66 41 89 34 48       	mov    %si,(%r8,%rcx,2)
   4bfff:	c1 ea 10             	shr    $0x10,%edx
   4c002:	0f b6 d2             	movzbl %dl,%edx
   4c005:	66 41 89 54 48 02    	mov    %dx,0x2(%r8,%rcx,2)
   4c00b:	49 01 c6             	add    %rax,%r14
   4c00e:	49 39 de             	cmp    %rbx,%r14
   4c011:	0f 86 b8 03 00 00    	jbe    4c3cf <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xdcf>
   4c017:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
   4c01e:	00 
   4c01f:	48 ff c8             	dec    %rax
   4c022:	49 39 c6             	cmp    %rax,%r14
   4c025:	0f 85 8a 00 00 00    	jne    4c0b5 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xab5>
   4c02b:	41 83 fd 09          	cmp    $0x9,%r13d
   4c02f:	77 3e                	ja     4c06f <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xa6f>
   4c031:	49 83 fc f7          	cmp    $0xfffffffffffffff7,%r12
   4c035:	0f 87 8c 10 00 00    	ja     4d0c7 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1ac7>
   4c03b:	49 8d 44 24 08       	lea    0x8(%r12),%rax
   4c040:	4c 39 d8             	cmp    %r11,%rax
   4c043:	0f 87 7e 10 00 00    	ja     4d0c7 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1ac7>
   4c049:	4b 8b 04 22          	mov    (%r10,%r12,1),%rax
   4c04d:	48 0f c8             	bswap  %rax
   4c050:	c4 e2 93 f7 c0       	shrx   %r13,%rax,%rax
   4c055:	48 09 c5             	or     %rax,%rbp
   4c058:	44 89 e8             	mov    %r13d,%eax
   4c05b:	83 f0 3f             	xor    $0x3f,%eax
   4c05e:	89 c1                	mov    %eax,%ecx
   4c060:	c1 e9 03             	shr    $0x3,%ecx
   4c063:	49 01 cc             	add    %rcx,%r12
   4c066:	83 e0 38             	and    $0x38,%eax
   4c069:	44 01 e8             	add    %r13d,%eax
   4c06c:	41 89 c5             	mov    %eax,%r13d
   4c06f:	48 89 e8             	mov    %rbp,%rax
   4c072:	48 c1 e8 36          	shr    $0x36,%rax
   4c076:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4c079:	48 81 fa 00 00 00 40 	cmp    $0x40000000,%rdx
   4c080:	0f 82 41 0f 00 00    	jb     4cfc7 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x19c7>
   4c086:	89 d0                	mov    %edx,%eax
   4c088:	c1 e8 18             	shr    $0x18,%eax
   4c08b:	83 e0 1f             	and    $0x1f,%eax
   4c08e:	c4 e2 f9 f7 ed       	shlx   %rax,%rbp,%rbp
   4c093:	41 29 c5             	sub    %eax,%r13d
   4c096:	0f b6 c6             	movzbl %dh,%eax
   4c099:	44 89 f1             	mov    %r14d,%ecx
   4c09c:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4c0a2:	66 41 89 04 48       	mov    %ax,(%r8,%rcx,2)
   4c0a7:	49 ff c6             	inc    %r14
   4c0aa:	66 3b 44 24 2e       	cmp    0x2e(%rsp),%ax
   4c0af:	0f 84 0d 1b 00 00    	je     4dbc2 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x25c2>
   4c0b5:	49 81 fe e8 03 00 00 	cmp    $0x3e8,%r14
   4c0bc:	76 67                	jbe    4c125 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xb25>
   4c0be:	49 81 fe 13 04 00 00 	cmp    $0x413,%r14
   4c0c5:	4d 89 f2             	mov    %r14,%r10
   4c0c8:	0f 83 0b 1c 00 00    	jae    4dcd9 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x26d9>
   4c0ce:	49 8b 01             	mov    (%r9),%rax
   4c0d1:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4c0d5:	48 29 d8             	sub    %rbx,%rax
   4c0d8:	49 39 c2             	cmp    %rax,%r10
   4c0db:	0f 87 50 10 00 00    	ja     4d131 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1b31>
   4c0e1:	48 8d 3c 1b          	lea    (%rbx,%rbx,1),%rdi
   4c0e5:	49 03 79 08          	add    0x8(%r9),%rdi
   4c0e9:	4b 8d 14 12          	lea    (%r10,%r10,1),%rdx
   4c0ed:	4c 89 c6             	mov    %r8,%rsi
   4c0f0:	4d 89 d6             	mov    %r10,%r14
   4c0f3:	ff 15 2f 47 05 00    	call   *0x5472f(%rip)        # a0828 <memcpy@GLIBC_2.14>
   4c0f9:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4c100:	00 
   4c101:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4c108:	00 
   4c109:	4c 01 f3             	add    %r14,%rbx
   4c10c:	49 89 59 10          	mov    %rbx,0x10(%r9)
   4c110:	45 31 f6             	xor    %r14d,%r14d
   4c113:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4c118:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4c11f:	00 
   4c120:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4c125:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   4c12c:	00 
   4c12d:	4c 89 20             	mov    %r12,(%rax)
   4c130:	48 89 68 08          	mov    %rbp,0x8(%rax)
   4c134:	44 89 68 10          	mov    %r13d,0x10(%rax)
   4c138:	8b 4c 24 0c          	mov    0xc(%rsp),%ecx
   4c13c:	89 48 14             	mov    %ecx,0x14(%rax)
   4c13f:	48 8b 94 24 88 00 00 	mov    0x88(%rsp),%rdx
   4c146:	00 
   4c147:	48 8b 9c 24 f0 00 00 	mov    0xf0(%rsp),%rbx
   4c14e:	00 
   4c14f:	48 29 d3             	sub    %rdx,%rbx
   4c152:	48 8b 8c 24 e8 00 00 	mov    0xe8(%rsp),%rcx
   4c159:	00 
   4c15a:	48 8b 94 24 e0 00 00 	mov    0xe0(%rsp),%rdx
   4c161:	00 
   4c162:	0f 85 7e f5 ff ff    	jne    4b6e6 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xe6>
   4c168:	e9 ee 19 00 00       	jmp    4db5b <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x255b>
   4c16d:	48 85 c0             	test   %rax,%rax
   4c170:	0f 84 0d 02 00 00    	je     4c383 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xd83>
   4c176:	4a 8d 1c 38          	lea    (%rax,%r15,1),%rbx
   4c17a:	48 83 f8 01          	cmp    $0x1,%rax
   4c17e:	0f 84 05 01 00 00    	je     4c289 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xc89>
   4c184:	4c 8d 73 fe          	lea    -0x2(%rbx),%r14
   4c188:	4d 39 f7             	cmp    %r14,%r15
   4c18b:	0f 87 ef 00 00 00    	ja     4c280 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xc80>
   4c191:	48 89 e8             	mov    %rbp,%rax
   4c194:	48 c1 e8 36          	shr    $0x36,%rax
   4c198:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4c19b:	89 d0                	mov    %edx,%eax
   4c19d:	c1 e8 1e             	shr    $0x1e,%eax
   4c1a0:	0f 84 92 13 00 00    	je     4d538 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1f38>
   4c1a6:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4c1ab:	0f b6 ca             	movzbl %dl,%ecx
   4c1ae:	41 29 cd             	sub    %ecx,%r13d
   4c1b1:	0f b6 ce             	movzbl %dh,%ecx
   4c1b4:	66 43 89 0c 78       	mov    %cx,(%r8,%r15,2)
   4c1b9:	c1 ea 10             	shr    $0x10,%edx
   4c1bc:	0f b6 ca             	movzbl %dl,%ecx
   4c1bf:	66 43 89 4c 78 02    	mov    %cx,0x2(%r8,%r15,2)
   4c1c5:	49 01 c7             	add    %rax,%r15
   4c1c8:	4d 39 f7             	cmp    %r14,%r15
   4c1cb:	0f 87 af 00 00 00    	ja     4c280 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xc80>
   4c1d1:	48 89 e8             	mov    %rbp,%rax
   4c1d4:	48 c1 e8 36          	shr    $0x36,%rax
   4c1d8:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4c1db:	89 d0                	mov    %edx,%eax
   4c1dd:	c1 e8 1e             	shr    $0x1e,%eax
   4c1e0:	0f 84 0f 15 00 00    	je     4d6f5 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x20f5>
   4c1e6:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4c1eb:	0f b6 ca             	movzbl %dl,%ecx
   4c1ee:	41 29 cd             	sub    %ecx,%r13d
   4c1f1:	0f b6 ce             	movzbl %dh,%ecx
   4c1f4:	66 43 89 0c 78       	mov    %cx,(%r8,%r15,2)
   4c1f9:	c1 ea 10             	shr    $0x10,%edx
   4c1fc:	0f b6 ca             	movzbl %dl,%ecx
   4c1ff:	66 43 89 4c 78 02    	mov    %cx,0x2(%r8,%r15,2)
   4c205:	49 01 c7             	add    %rax,%r15
   4c208:	4d 39 f7             	cmp    %r14,%r15
   4c20b:	77 73                	ja     4c280 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xc80>
   4c20d:	48 89 e8             	mov    %rbp,%rax
   4c210:	48 c1 e8 36          	shr    $0x36,%rax
   4c214:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4c217:	89 d0                	mov    %edx,%eax
   4c219:	c1 e8 1e             	shr    $0x1e,%eax
   4c21c:	0f 84 6b 16 00 00    	je     4d88d <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x228d>
   4c222:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4c227:	0f b6 ca             	movzbl %dl,%ecx
   4c22a:	41 29 cd             	sub    %ecx,%r13d
   4c22d:	0f b6 ce             	movzbl %dh,%ecx
   4c230:	66 43 89 0c 78       	mov    %cx,(%r8,%r15,2)
   4c235:	c1 ea 10             	shr    $0x10,%edx
   4c238:	0f b6 ca             	movzbl %dl,%ecx
   4c23b:	66 43 89 4c 78 02    	mov    %cx,0x2(%r8,%r15,2)
   4c241:	49 01 c7             	add    %rax,%r15
   4c244:	4d 39 f7             	cmp    %r14,%r15
   4c247:	77 37                	ja     4c280 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xc80>
   4c249:	48 89 e8             	mov    %rbp,%rax
   4c24c:	48 c1 e8 36          	shr    $0x36,%rax
   4c250:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4c253:	89 d0                	mov    %edx,%eax
   4c255:	c1 e8 1e             	shr    $0x1e,%eax
   4c258:	0f 84 b0 17 00 00    	je     4da0e <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x240e>
   4c25e:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4c263:	0f b6 ca             	movzbl %dl,%ecx
   4c266:	41 29 cd             	sub    %ecx,%r13d
   4c269:	0f b6 ce             	movzbl %dh,%ecx
   4c26c:	66 43 89 0c 78       	mov    %cx,(%r8,%r15,2)
   4c271:	c1 ea 10             	shr    $0x10,%edx
   4c274:	0f b6 ca             	movzbl %dl,%ecx
   4c277:	66 43 89 4c 78 02    	mov    %cx,0x2(%r8,%r15,2)
   4c27d:	49 01 c7             	add    %rax,%r15
   4c280:	4d 39 f7             	cmp    %r14,%r15
   4c283:	0f 86 95 02 00 00    	jbe    4c51e <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xf1e>
   4c289:	48 ff cb             	dec    %rbx
   4c28c:	49 39 df             	cmp    %rbx,%r15
   4c28f:	0f 85 84 00 00 00    	jne    4c319 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xd19>
   4c295:	41 83 fd 09          	cmp    $0x9,%r13d
   4c299:	77 3e                	ja     4c2d9 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xcd9>
   4c29b:	49 83 fc f7          	cmp    $0xfffffffffffffff7,%r12
   4c29f:	0f 87 2e 11 00 00    	ja     4d3d3 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1dd3>
   4c2a5:	49 8d 44 24 08       	lea    0x8(%r12),%rax
   4c2aa:	4c 39 d8             	cmp    %r11,%rax
   4c2ad:	0f 87 20 11 00 00    	ja     4d3d3 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1dd3>
   4c2b3:	4b 8b 04 22          	mov    (%r10,%r12,1),%rax
   4c2b7:	48 0f c8             	bswap  %rax
   4c2ba:	c4 e2 93 f7 c0       	shrx   %r13,%rax,%rax
   4c2bf:	48 09 c5             	or     %rax,%rbp
   4c2c2:	44 89 e8             	mov    %r13d,%eax
   4c2c5:	83 f0 3f             	xor    $0x3f,%eax
   4c2c8:	89 c1                	mov    %eax,%ecx
   4c2ca:	c1 e9 03             	shr    $0x3,%ecx
   4c2cd:	49 01 cc             	add    %rcx,%r12
   4c2d0:	83 e0 38             	and    $0x38,%eax
   4c2d3:	44 01 e8             	add    %r13d,%eax
   4c2d6:	41 89 c5             	mov    %eax,%r13d
   4c2d9:	48 89 e8             	mov    %rbp,%rax
   4c2dc:	48 c1 e8 36          	shr    $0x36,%rax
   4c2e0:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4c2e3:	48 81 fa 00 00 00 40 	cmp    $0x40000000,%rdx
   4c2ea:	0f 82 cd 0f 00 00    	jb     4d2bd <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1cbd>
   4c2f0:	89 d0                	mov    %edx,%eax
   4c2f2:	c1 e8 18             	shr    $0x18,%eax
   4c2f5:	83 e0 1f             	and    $0x1f,%eax
   4c2f8:	c4 e2 f9 f7 ed       	shlx   %rax,%rbp,%rbp
   4c2fd:	41 29 c5             	sub    %eax,%r13d
   4c300:	0f b6 c6             	movzbl %dh,%eax
   4c303:	66 43 89 04 78       	mov    %ax,(%r8,%r15,2)
   4c308:	49 ff c7             	inc    %r15
   4c30b:	66 3b 84 24 88 00 00 	cmp    0x88(%rsp),%ax
   4c312:	00 
   4c313:	0f 84 58 19 00 00    	je     4dc71 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x2671>
   4c319:	49 81 ff e8 03 00 00 	cmp    $0x3e8,%r15
   4c320:	76 61                	jbe    4c383 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xd83>
   4c322:	49 81 ff 13 04 00 00 	cmp    $0x413,%r15
   4c329:	0f 83 c0 19 00 00    	jae    4dcef <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x26ef>
   4c32f:	49 8b 01             	mov    (%r9),%rax
   4c332:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4c336:	48 29 d8             	sub    %rbx,%rax
   4c339:	49 39 c7             	cmp    %rax,%r15
   4c33c:	0f 87 fb 10 00 00    	ja     4d43d <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1e3d>
   4c342:	48 8d 3c 1b          	lea    (%rbx,%rbx,1),%rdi
   4c346:	49 03 79 08          	add    0x8(%r9),%rdi
   4c34a:	4b 8d 14 3f          	lea    (%r15,%r15,1),%rdx
   4c34e:	4c 89 c6             	mov    %r8,%rsi
   4c351:	ff 15 d1 44 05 00    	call   *0x544d1(%rip)        # a0828 <memcpy@GLIBC_2.14>
   4c357:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4c35e:	00 
   4c35f:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4c366:	00 
   4c367:	4c 01 fb             	add    %r15,%rbx
   4c36a:	49 89 59 10          	mov    %rbx,0x10(%r9)
   4c36e:	45 31 ff             	xor    %r15d,%r15d
   4c371:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4c376:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4c37d:	00 
   4c37e:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4c383:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   4c38a:	00 
   4c38b:	4c 89 20             	mov    %r12,(%rax)
   4c38e:	48 89 68 08          	mov    %rbp,0x8(%rax)
   4c392:	44 89 68 10          	mov    %r13d,0x10(%rax)
   4c396:	8b 4c 24 0c          	mov    0xc(%rsp),%ecx
   4c39a:	89 48 14             	mov    %ecx,0x14(%rax)
   4c39d:	4d 89 fe             	mov    %r15,%r14
   4c3a0:	ba 01 00 00 00       	mov    $0x1,%edx
   4c3a5:	4d 39 dc             	cmp    %r11,%r12
   4c3a8:	0f 86 99 fd ff ff    	jbe    4c147 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xb47>
   4c3ae:	4a 8d 04 e5 00 00 00 	lea    0x0(,%r12,8),%rax
   4c3b5:	00 
   4c3b6:	44 89 e9             	mov    %r13d,%ecx
   4c3b9:	48 29 c8             	sub    %rcx,%rax
   4c3bc:	48 3b 84 24 d0 00 00 	cmp    0xd0(%rsp),%rax
   4c3c3:	00 
   4c3c4:	0f 86 7d fd ff ff    	jbe    4c147 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xb47>
   4c3ca:	e9 5a 18 00 00       	jmp    4dc29 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x2629>
   4c3cf:	49 83 fc f7          	cmp    $0xfffffffffffffff7,%r12
   4c3d3:	0f 87 84 0c 00 00    	ja     4d05d <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1a5d>
   4c3d9:	49 8d 44 24 08       	lea    0x8(%r12),%rax
   4c3de:	4c 39 d8             	cmp    %r11,%rax
   4c3e1:	0f 87 76 0c 00 00    	ja     4d05d <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1a5d>
   4c3e7:	4b 8b 04 22          	mov    (%r10,%r12,1),%rax
   4c3eb:	48 0f c8             	bswap  %rax
   4c3ee:	c4 e2 93 f7 c0       	shrx   %r13,%rax,%rax
   4c3f3:	48 09 c5             	or     %rax,%rbp
   4c3f6:	b8 3f 00 00 00       	mov    $0x3f,%eax
   4c3fb:	44 29 e8             	sub    %r13d,%eax
   4c3fe:	89 c1                	mov    %eax,%ecx
   4c400:	c1 e9 03             	shr    $0x3,%ecx
   4c403:	49 01 cc             	add    %rcx,%r12
   4c406:	83 e0 f8             	and    $0xfffffff8,%eax
   4c409:	44 01 e8             	add    %r13d,%eax
   4c40c:	41 89 c5             	mov    %eax,%r13d
   4c40f:	90                   	nop
   4c410:	48 89 e8             	mov    %rbp,%rax
   4c413:	48 c1 e8 36          	shr    $0x36,%rax
   4c417:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4c41a:	89 d0                	mov    %edx,%eax
   4c41c:	c1 e8 1e             	shr    $0x1e,%eax
   4c41f:	74 3b                	je     4c45c <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xe5c>
   4c421:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4c426:	0f b6 ca             	movzbl %dl,%ecx
   4c429:	41 29 cd             	sub    %ecx,%r13d
   4c42c:	4d 89 f7             	mov    %r14,%r15
   4c42f:	44 89 f9             	mov    %r15d,%ecx
   4c432:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4c438:	0f b6 f6             	movzbl %dh,%esi
   4c43b:	66 41 89 34 48       	mov    %si,(%r8,%rcx,2)
   4c440:	c1 ea 10             	shr    $0x10,%edx
   4c443:	0f b6 d2             	movzbl %dl,%edx
   4c446:	66 41 89 54 48 02    	mov    %dx,0x2(%r8,%rcx,2)
   4c44c:	49 01 c7             	add    %rax,%r15
   4c44f:	4d 89 fe             	mov    %r15,%r14
   4c452:	49 39 df             	cmp    %rbx,%r15
   4c455:	76 b9                	jbe    4c410 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xe10>
   4c457:	e9 bb fb ff ff       	jmp    4c017 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xa17>
   4c45c:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4c461:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4c466:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4c46b:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4c46f:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4c473:	48 89 fe             	mov    %rdi,%rsi
   4c476:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4c47b:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4c480:	4d 89 d0             	mov    %r10,%r8
   4c483:	4d 89 d9             	mov    %r11,%r9
   4c486:	e8 95 ed ff ff       	call   4b220 <_RNvMs_NtCshzyx7VBzFal_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4c48b:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4c490:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4c495:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4c49a:	0f 10 02             	movups (%rdx),%xmm0
   4c49d:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4c4a2:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4c4a6:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4c4ab:	4c 8b 64 24 60       	mov    0x60(%rsp),%r12
   4c4b0:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
   4c4b5:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4c4ba:	8b 74 24 74          	mov    0x74(%rsp),%esi
   4c4be:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4c4c2:	0f 85 60 0d 00 00    	jne    4d228 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1c28>
   4c4c8:	44 89 f1             	mov    %r14d,%ecx
   4c4cb:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4c4d1:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4c4d8:	00 
   4c4d9:	66 41 89 04 48       	mov    %ax,(%r8,%rcx,2)
   4c4de:	49 ff c6             	inc    %r14
   4c4e1:	66 3b 44 24 2e       	cmp    0x2e(%rsp),%ax
   4c4e6:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4c4ed:	00 
   4c4ee:	0f 84 61 0d 00 00    	je     4d255 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1c55>
   4c4f4:	89 74 24 0c          	mov    %esi,0xc(%rsp)
   4c4f8:	4d 89 f7             	mov    %r14,%r15
   4c4fb:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4c500:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4c507:	00 
   4c508:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4c50d:	4d 89 fe             	mov    %r15,%r14
   4c510:	49 39 df             	cmp    %rbx,%r15
   4c513:	0f 86 f7 fe ff ff    	jbe    4c410 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xe10>
   4c519:	e9 f9 fa ff ff       	jmp    4c017 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xa17>
   4c51e:	49 83 fc f7          	cmp    $0xfffffffffffffff7,%r12
   4c522:	0f 87 41 0e 00 00    	ja     4d369 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1d69>
   4c528:	49 8d 44 24 08       	lea    0x8(%r12),%rax
   4c52d:	4c 39 d8             	cmp    %r11,%rax
   4c530:	0f 87 33 0e 00 00    	ja     4d369 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1d69>
   4c536:	4b 8b 04 22          	mov    (%r10,%r12,1),%rax
   4c53a:	48 0f c8             	bswap  %rax
   4c53d:	c4 e2 93 f7 c0       	shrx   %r13,%rax,%rax
   4c542:	48 09 c5             	or     %rax,%rbp
   4c545:	b8 3f 00 00 00       	mov    $0x3f,%eax
   4c54a:	44 29 e8             	sub    %r13d,%eax
   4c54d:	89 c1                	mov    %eax,%ecx
   4c54f:	c1 e9 03             	shr    $0x3,%ecx
   4c552:	49 01 cc             	add    %rcx,%r12
   4c555:	83 e0 f8             	and    $0xfffffff8,%eax
   4c558:	44 01 e8             	add    %r13d,%eax
   4c55b:	41 89 c5             	mov    %eax,%r13d
   4c55e:	66 90                	xchg   %ax,%ax
   4c560:	48 89 e8             	mov    %rbp,%rax
   4c563:	48 c1 e8 36          	shr    $0x36,%rax
   4c567:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4c56a:	89 d0                	mov    %edx,%eax
   4c56c:	c1 e8 1e             	shr    $0x1e,%eax
   4c56f:	74 35                	je     4c5a6 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xfa6>
   4c571:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4c576:	0f b6 ca             	movzbl %dl,%ecx
   4c579:	41 29 cd             	sub    %ecx,%r13d
   4c57c:	44 89 f9             	mov    %r15d,%ecx
   4c57f:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4c585:	0f b6 f6             	movzbl %dh,%esi
   4c588:	66 41 89 34 48       	mov    %si,(%r8,%rcx,2)
   4c58d:	c1 ea 10             	shr    $0x10,%edx
   4c590:	0f b6 d2             	movzbl %dl,%edx
   4c593:	66 41 89 54 48 02    	mov    %dx,0x2(%r8,%rcx,2)
   4c599:	49 01 c7             	add    %rax,%r15
   4c59c:	4d 39 f7             	cmp    %r14,%r15
   4c59f:	76 bf                	jbe    4c560 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xf60>
   4c5a1:	e9 e3 fc ff ff       	jmp    4c289 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xc89>
   4c5a6:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4c5ab:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4c5b0:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4c5b5:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4c5b9:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4c5bd:	48 89 fe             	mov    %rdi,%rsi
   4c5c0:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4c5c5:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4c5ca:	4d 89 d0             	mov    %r10,%r8
   4c5cd:	4d 89 d9             	mov    %r11,%r9
   4c5d0:	e8 4b ec ff ff       	call   4b220 <_RNvMs_NtCshzyx7VBzFal_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4c5d5:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4c5da:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4c5df:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4c5e4:	0f 10 02             	movups (%rdx),%xmm0
   4c5e7:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4c5ec:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4c5f0:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4c5f5:	4c 8b 64 24 60       	mov    0x60(%rsp),%r12
   4c5fa:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
   4c5ff:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4c604:	8b 54 24 74          	mov    0x74(%rsp),%edx
   4c608:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4c60c:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4c610:	0f 85 68 14 00 00    	jne    4da7e <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x247e>
   4c616:	44 89 f9             	mov    %r15d,%ecx
   4c619:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4c61f:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4c626:	00 
   4c627:	66 41 89 04 48       	mov    %ax,(%r8,%rcx,2)
   4c62c:	49 ff c7             	inc    %r15
   4c62f:	66 3b 84 24 88 00 00 	cmp    0x88(%rsp),%ax
   4c636:	00 
   4c637:	0f 84 82 10 00 00    	je     4d6bf <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x20bf>
   4c63d:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4c644:	00 
   4c645:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4c64a:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4c651:	00 
   4c652:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4c657:	4d 39 f7             	cmp    %r14,%r15
   4c65a:	0f 86 00 ff ff ff    	jbe    4c560 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xf60>
   4c660:	e9 24 fc ff ff       	jmp    4c289 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xc89>
   4c665:	45 31 ff             	xor    %r15d,%r15d
   4c668:	eb 03                	jmp    4c66d <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x106d>
   4c66a:	41 89 d5             	mov    %edx,%r13d
   4c66d:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4c674:	00 
   4c675:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4c67c:	00 
   4c67d:	89 c2                	mov    %eax,%edx
   4c67f:	c1 ea 08             	shr    $0x8,%edx
   4c682:	89 54 24 7c          	mov    %edx,0x7c(%rsp)
   4c686:	48 8b 54 24 1e       	mov    0x1e(%rsp),%rdx
   4c68b:	48 89 94 24 9e 00 00 	mov    %rdx,0x9e(%rsp)
   4c692:	00 
   4c693:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
   4c698:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
   4c69f:	00 
   4c6a0:	4d 01 f7             	add    %r14,%r15
   4c6a3:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4c6a8:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4c6af:	00 
   4c6b0:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4c6b5:	49 89 f4             	mov    %rsi,%r12
   4c6b8:	e9 88 00 00 00       	jmp    4c745 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1145>
   4c6bd:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   4c6c3:	eb 03                	jmp    4c6c8 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x10c8>
   4c6c5:	41 89 d5             	mov    %edx,%r13d
   4c6c8:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4c6cf:	00 
   4c6d0:	49 89 f4             	mov    %rsi,%r12
   4c6d3:	4d 01 f7             	add    %r14,%r15
   4c6d6:	49 81 ff 13 04 00 00 	cmp    $0x413,%r15
   4c6dd:	0f 83 38 16 00 00    	jae    4dd1b <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x271b>
   4c6e3:	49 8b 01             	mov    (%r9),%rax
   4c6e6:	4d 8b 71 10          	mov    0x10(%r9),%r14
   4c6ea:	4c 29 f0             	sub    %r14,%rax
   4c6ed:	49 39 c7             	cmp    %rax,%r15
   4c6f0:	0f 87 55 12 00 00    	ja     4d94b <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x234b>
   4c6f6:	4d 85 ff             	test   %r15,%r15
   4c6f9:	74 25                	je     4c720 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1120>
   4c6fb:	4b 8d 3c 36          	lea    (%r14,%r14,1),%rdi
   4c6ff:	49 03 79 08          	add    0x8(%r9),%rdi
   4c703:	4b 8d 14 3f          	lea    (%r15,%r15,1),%rdx
   4c707:	4c 89 c6             	mov    %r8,%rsi
   4c70a:	ff 15 18 41 05 00    	call   *0x54118(%rip)        # a0828 <memcpy@GLIBC_2.14>
   4c710:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4c717:	00 
   4c718:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4c71f:	00 
   4c720:	4d 01 fe             	add    %r15,%r14
   4c723:	4d 89 71 10          	mov    %r14,0x10(%r9)
   4c727:	b0 01                	mov    $0x1,%al
   4c729:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
   4c730:	45 31 ff             	xor    %r15d,%r15d
   4c733:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4c738:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4c73f:	00 
   4c740:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4c745:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   4c74c:	00 
   4c74d:	4c 89 22             	mov    %r12,(%rdx)
   4c750:	48 89 5a 08          	mov    %rbx,0x8(%rdx)
   4c754:	44 89 6a 10          	mov    %r13d,0x10(%rdx)
   4c758:	89 6a 14             	mov    %ebp,0x14(%rdx)
   4c75b:	4d 89 fe             	mov    %r15,%r14
   4c75e:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4c762:	0f 85 9a 16 00 00    	jne    4de02 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x2802>
   4c768:	a8 01                	test   $0x1,%al
   4c76a:	0f 84 30 fc ff ff    	je     4c3a0 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xda0>
   4c770:	e9 24 15 00 00       	jmp    4dc99 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x2699>
   4c775:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
   4c77a:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
   4c77f:	89 44 24 50          	mov    %eax,0x50(%rsp)
   4c783:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4c787:	89 44 24 54          	mov    %eax,0x54(%rsp)
   4c78b:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   4c790:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   4c795:	4c 89 d2             	mov    %r10,%rdx
   4c798:	4c 89 d9             	mov    %r11,%rcx
   4c79b:	e8 f0 94 ff ff       	call   45c90 <_RNvMNtCshzyx7VBzFal_5mibz24bitsNtB2_3Reg11refill_slow>
   4c7a0:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4c7a5:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4c7ac:	00 
   4c7ad:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4c7b2:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4c7b9:	00 
   4c7ba:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4c7c1:	00 
   4c7c2:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   4c7c7:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   4c7cc:	44 8b 6c 24 20       	mov    0x20(%rsp),%r13d
   4c7d1:	8b 44 24 24          	mov    0x24(%rsp),%eax
   4c7d5:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   4c7d9:	48 6b 94 24 88 00 00 	imul   $0x32,0x88(%rsp),%rdx
   4c7e0:	00 32 
   4c7e2:	48 83 fa 0a          	cmp    $0xa,%rdx
   4c7e6:	73 66                	jae    4c84e <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x124e>
   4c7e8:	e9 cc f6 ff ff       	jmp    4beb9 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x8b9>
   4c7ed:	0f 1f 00             	nopl   (%rax)
   4c7f0:	48 8d 3c 1b          	lea    (%rbx,%rbx,1),%rdi
   4c7f4:	49 03 79 08          	add    0x8(%r9),%rdi
   4c7f8:	4b 8d 14 3f          	lea    (%r15,%r15,1),%rdx
   4c7fc:	4c 89 c6             	mov    %r8,%rsi
   4c7ff:	ff 15 23 40 05 00    	call   *0x54023(%rip)        # a0828 <memcpy@GLIBC_2.14>
   4c805:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4c80c:	00 
   4c80d:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4c814:	00 
   4c815:	4c 01 fb             	add    %r15,%rbx
   4c818:	49 89 59 10          	mov    %rbx,0x10(%r9)
   4c81c:	45 31 f6             	xor    %r14d,%r14d
   4c81f:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4c824:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4c82b:	00 
   4c82c:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4c831:	48 8b 94 24 b8 00 00 	mov    0xb8(%rsp),%rdx
   4c838:	00 
   4c839:	48 03 94 24 c0 00 00 	add    0xc0(%rsp),%rdx
   4c840:	00 
   4c841:	4c 29 fa             	sub    %r15,%rdx
   4c844:	48 83 fa 09          	cmp    $0x9,%rdx
   4c848:	0f 86 6b f6 ff ff    	jbe    4beb9 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x8b9>
   4c84e:	48 89 94 24 b8 00 00 	mov    %rdx,0xb8(%rsp)
   4c855:	00 
   4c856:	4c 01 f2             	add    %r14,%rdx
   4c859:	48 83 c2 f6          	add    $0xfffffffffffffff6,%rdx
   4c85d:	48 81 fa e8 03 00 00 	cmp    $0x3e8,%rdx
   4c864:	b8 e8 03 00 00       	mov    $0x3e8,%eax
   4c869:	48 0f 43 d0          	cmovae %rax,%rdx
   4c86d:	4d 89 f7             	mov    %r14,%r15
   4c870:	4c 89 b4 24 c0 00 00 	mov    %r14,0xc0(%rsp)
   4c877:	00 
   4c878:	48 89 94 24 a8 00 00 	mov    %rdx,0xa8(%rsp)
   4c87f:	00 
   4c880:	49 39 d6             	cmp    %rdx,%r14
   4c883:	76 6b                	jbe    4c8f0 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x12f0>
   4c885:	4d 89 fe             	mov    %r15,%r14
   4c888:	49 81 ff e8 03 00 00 	cmp    $0x3e8,%r15
   4c88f:	76 a0                	jbe    4c831 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1231>
   4c891:	49 81 ff 13 04 00 00 	cmp    $0x413,%r15
   4c898:	0f 83 75 13 00 00    	jae    4dc13 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x2613>
   4c89e:	49 8b 01             	mov    (%r9),%rax
   4c8a1:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4c8a5:	48 29 d8             	sub    %rbx,%rax
   4c8a8:	49 39 c7             	cmp    %rax,%r15
   4c8ab:	0f 86 3f ff ff ff    	jbe    4c7f0 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x11f0>
   4c8b1:	b9 02 00 00 00       	mov    $0x2,%ecx
   4c8b6:	41 b8 02 00 00 00    	mov    $0x2,%r8d
   4c8bc:	4c 89 cf             	mov    %r9,%rdi
   4c8bf:	48 89 de             	mov    %rbx,%rsi
   4c8c2:	4c 89 fa             	mov    %r15,%rdx
   4c8c5:	e8 26 a4 fe ff       	call   36cf0 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECshzyx7VBzFal_5mibz2>
   4c8ca:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4c8d1:	00 
   4c8d2:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4c8d9:	00 
   4c8da:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4c8de:	e9 0d ff ff ff       	jmp    4c7f0 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x11f0>
   4c8e3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   4c8ea:	84 00 00 00 00 00 
   4c8f0:	49 8d 77 12          	lea    0x12(%r15),%rsi
   4c8f4:	48 81 fe 13 04 00 00 	cmp    $0x413,%rsi
   4c8fb:	0f 83 99 12 00 00    	jae    4db9a <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x259a>
   4c901:	4c 89 e6             	mov    %r12,%rsi
   4c904:	4f 8d 24 78          	lea    (%r8,%r15,2),%r12
   4c908:	48 89 e8             	mov    %rbp,%rax
   4c90b:	48 c1 e8 36          	shr    $0x36,%rax
   4c90f:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4c912:	89 d3                	mov    %edx,%ebx
   4c914:	c1 eb 1e             	shr    $0x1e,%ebx
   4c917:	0f 84 57 01 00 00    	je     4ca74 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1474>
   4c91d:	c4 62 e9 f7 f5       	shlx   %rdx,%rbp,%r14
   4c922:	0f b6 c2             	movzbl %dl,%eax
   4c925:	41 29 c5             	sub    %eax,%r13d
   4c928:	0f b6 c6             	movzbl %dh,%eax
   4c92b:	66 41 89 04 24       	mov    %ax,(%r12)
   4c930:	c1 ea 10             	shr    $0x10,%edx
   4c933:	0f b6 c2             	movzbl %dl,%eax
   4c936:	66 41 89 44 24 02    	mov    %ax,0x2(%r12)
   4c93c:	4c 89 f0             	mov    %r14,%rax
   4c93f:	48 c1 e8 36          	shr    $0x36,%rax
   4c943:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4c946:	89 d0                	mov    %edx,%eax
   4c948:	c1 e8 1e             	shr    $0x1e,%eax
   4c94b:	0f 84 cf 01 00 00    	je     4cb20 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1520>
   4c951:	c4 42 e9 f7 f6       	shlx   %rdx,%r14,%r14
   4c956:	0f b6 ca             	movzbl %dl,%ecx
   4c959:	41 29 cd             	sub    %ecx,%r13d
   4c95c:	0f b6 ce             	movzbl %dh,%ecx
   4c95f:	66 41 89 0c 5c       	mov    %cx,(%r12,%rbx,2)
   4c964:	c1 ea 10             	shr    $0x10,%edx
   4c967:	0f b6 ca             	movzbl %dl,%ecx
   4c96a:	66 41 89 4c 5c 02    	mov    %cx,0x2(%r12,%rbx,2)
   4c970:	48 01 c3             	add    %rax,%rbx
   4c973:	4c 89 f0             	mov    %r14,%rax
   4c976:	48 c1 e8 36          	shr    $0x36,%rax
   4c97a:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4c97d:	89 d0                	mov    %edx,%eax
   4c97f:	c1 e8 1e             	shr    $0x1e,%eax
   4c982:	0f 84 42 02 00 00    	je     4cbca <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x15ca>
   4c988:	c4 42 e9 f7 f6       	shlx   %rdx,%r14,%r14
   4c98d:	0f b6 ca             	movzbl %dl,%ecx
   4c990:	41 29 cd             	sub    %ecx,%r13d
   4c993:	0f b6 ce             	movzbl %dh,%ecx
   4c996:	66 41 89 0c 5c       	mov    %cx,(%r12,%rbx,2)
   4c99b:	c1 ea 10             	shr    $0x10,%edx
   4c99e:	0f b6 ca             	movzbl %dl,%ecx
   4c9a1:	66 41 89 4c 5c 02    	mov    %cx,0x2(%r12,%rbx,2)
   4c9a7:	48 01 c3             	add    %rax,%rbx
   4c9aa:	4c 89 f0             	mov    %r14,%rax
   4c9ad:	48 c1 e8 36          	shr    $0x36,%rax
   4c9b1:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4c9b4:	89 d0                	mov    %edx,%eax
   4c9b6:	c1 e8 1e             	shr    $0x1e,%eax
   4c9b9:	0f 84 b5 02 00 00    	je     4cc74 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1674>
   4c9bf:	c4 42 e9 f7 f6       	shlx   %rdx,%r14,%r14
   4c9c4:	0f b6 ca             	movzbl %dl,%ecx
   4c9c7:	41 29 cd             	sub    %ecx,%r13d
   4c9ca:	0f b6 ce             	movzbl %dh,%ecx
   4c9cd:	66 41 89 0c 5c       	mov    %cx,(%r12,%rbx,2)
   4c9d2:	c1 ea 10             	shr    $0x10,%edx
   4c9d5:	0f b6 ca             	movzbl %dl,%ecx
   4c9d8:	66 41 89 4c 5c 02    	mov    %cx,0x2(%r12,%rbx,2)
   4c9de:	48 01 c3             	add    %rax,%rbx
   4c9e1:	4c 89 f0             	mov    %r14,%rax
   4c9e4:	48 c1 e8 36          	shr    $0x36,%rax
   4c9e8:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4c9eb:	89 d0                	mov    %edx,%eax
   4c9ed:	c1 e8 1e             	shr    $0x1e,%eax
   4c9f0:	0f 84 28 03 00 00    	je     4cd1e <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x171e>
   4c9f6:	c4 42 e9 f7 f6       	shlx   %rdx,%r14,%r14
   4c9fb:	0f b6 ca             	movzbl %dl,%ecx
   4c9fe:	41 29 cd             	sub    %ecx,%r13d
   4ca01:	0f b6 ce             	movzbl %dh,%ecx
   4ca04:	66 41 89 0c 5c       	mov    %cx,(%r12,%rbx,2)
   4ca09:	c1 ea 10             	shr    $0x10,%edx
   4ca0c:	0f b6 ca             	movzbl %dl,%ecx
   4ca0f:	66 41 89 4c 5c 02    	mov    %cx,0x2(%r12,%rbx,2)
   4ca15:	48 01 c3             	add    %rax,%rbx
   4ca18:	44 89 ea             	mov    %r13d,%edx
   4ca1b:	49 89 f4             	mov    %rsi,%r12
   4ca1e:	48 83 fe f7          	cmp    $0xfffffffffffffff7,%rsi
   4ca22:	0f 87 a7 03 00 00    	ja     4cdcf <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x17cf>
   4ca28:	49 8d 44 24 08       	lea    0x8(%r12),%rax
   4ca2d:	4c 39 d8             	cmp    %r11,%rax
   4ca30:	0f 87 99 03 00 00    	ja     4cdcf <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x17cf>
   4ca36:	4b 8b 04 22          	mov    (%r10,%r12,1),%rax
   4ca3a:	48 0f c8             	bswap  %rax
   4ca3d:	c4 e2 eb f7 e8       	shrx   %rdx,%rax,%rbp
   4ca42:	4c 09 f5             	or     %r14,%rbp
   4ca45:	41 bd 3f 00 00 00    	mov    $0x3f,%r13d
   4ca4b:	41 29 d5             	sub    %edx,%r13d
   4ca4e:	44 89 e8             	mov    %r13d,%eax
   4ca51:	c1 e8 03             	shr    $0x3,%eax
   4ca54:	49 01 c4             	add    %rax,%r12
   4ca57:	41 83 e5 f8          	and    $0xfffffff8,%r13d
   4ca5b:	41 01 d5             	add    %edx,%r13d
   4ca5e:	49 01 df             	add    %rbx,%r15
   4ca61:	4c 3b bc 24 a8 00 00 	cmp    0xa8(%rsp),%r15
   4ca68:	00 
   4ca69:	0f 86 81 fe ff ff    	jbe    4c8f0 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x12f0>
   4ca6f:	e9 11 fe ff ff       	jmp    4c885 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1285>
   4ca74:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4ca79:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4ca7e:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4ca83:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4ca87:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4ca8b:	48 89 fe             	mov    %rdi,%rsi
   4ca8e:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4ca93:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4ca98:	4d 89 d0             	mov    %r10,%r8
   4ca9b:	4d 89 d9             	mov    %r11,%r9
   4ca9e:	e8 7d e7 ff ff       	call   4b220 <_RNvMs_NtCshzyx7VBzFal_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4caa3:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4caa8:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4caad:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4cab2:	0f 10 02             	movups (%rdx),%xmm0
   4cab5:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4caba:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4cabe:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4cac3:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   4cac8:	4c 8b 74 24 68       	mov    0x68(%rsp),%r14
   4cacd:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4cad2:	8b 6c 24 74          	mov    0x74(%rsp),%ebp
   4cad6:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4cada:	0f 85 69 03 00 00    	jne    4ce49 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1849>
   4cae0:	66 41 89 04 24       	mov    %ax,(%r12)
   4cae5:	66 3b 44 24 2e       	cmp    0x2e(%rsp),%ax
   4caea:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4caf1:	00 
   4caf2:	0f 84 a8 03 00 00    	je     4cea0 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x18a0>
   4caf8:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4cafc:	bb 01 00 00 00       	mov    $0x1,%ebx
   4cb01:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4cb08:	00 
   4cb09:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4cb0e:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4cb15:	00 
   4cb16:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4cb1b:	e9 1c fe ff ff       	jmp    4c93c <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x133c>
   4cb20:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4cb25:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   4cb2a:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4cb2f:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4cb33:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4cb37:	48 89 fe             	mov    %rdi,%rsi
   4cb3a:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4cb3f:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4cb44:	4d 89 d0             	mov    %r10,%r8
   4cb47:	4d 89 d9             	mov    %r11,%r9
   4cb4a:	e8 d1 e6 ff ff       	call   4b220 <_RNvMs_NtCshzyx7VBzFal_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4cb4f:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4cb54:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4cb59:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4cb5e:	0f 10 02             	movups (%rdx),%xmm0
   4cb61:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4cb66:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4cb6a:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4cb6f:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   4cb74:	4c 8b 74 24 68       	mov    0x68(%rsp),%r14
   4cb79:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4cb7e:	8b 6c 24 74          	mov    0x74(%rsp),%ebp
   4cb82:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4cb86:	0f 85 c4 02 00 00    	jne    4ce50 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1850>
   4cb8c:	66 41 89 04 5c       	mov    %ax,(%r12,%rbx,2)
   4cb91:	48 ff c3             	inc    %rbx
   4cb94:	66 3b 44 24 2e       	cmp    0x2e(%rsp),%ax
   4cb99:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4cba0:	00 
   4cba1:	0f 84 03 03 00 00    	je     4ceaa <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x18aa>
   4cba7:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4cbab:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4cbb2:	00 
   4cbb3:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4cbb8:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4cbbf:	00 
   4cbc0:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4cbc5:	e9 a9 fd ff ff       	jmp    4c973 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1373>
   4cbca:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4cbcf:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   4cbd4:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4cbd9:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4cbdd:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4cbe1:	48 89 fe             	mov    %rdi,%rsi
   4cbe4:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4cbe9:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4cbee:	4d 89 d0             	mov    %r10,%r8
   4cbf1:	4d 89 d9             	mov    %r11,%r9
   4cbf4:	e8 27 e6 ff ff       	call   4b220 <_RNvMs_NtCshzyx7VBzFal_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4cbf9:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4cbfe:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4cc03:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4cc08:	0f 10 02             	movups (%rdx),%xmm0
   4cc0b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4cc10:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4cc14:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4cc19:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   4cc1e:	4c 8b 74 24 68       	mov    0x68(%rsp),%r14
   4cc23:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4cc28:	8b 6c 24 74          	mov    0x74(%rsp),%ebp
   4cc2c:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4cc30:	0f 85 1a 02 00 00    	jne    4ce50 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1850>
   4cc36:	66 41 89 04 5c       	mov    %ax,(%r12,%rbx,2)
   4cc3b:	48 ff c3             	inc    %rbx
   4cc3e:	66 3b 44 24 2e       	cmp    0x2e(%rsp),%ax
   4cc43:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4cc4a:	00 
   4cc4b:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4cc52:	00 
   4cc53:	0f 84 59 02 00 00    	je     4ceb2 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x18b2>
   4cc59:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4cc5d:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4cc62:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4cc69:	00 
   4cc6a:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4cc6f:	e9 36 fd ff ff       	jmp    4c9aa <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x13aa>
   4cc74:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4cc79:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   4cc7e:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4cc83:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4cc87:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4cc8b:	48 89 fe             	mov    %rdi,%rsi
   4cc8e:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4cc93:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4cc98:	4d 89 d0             	mov    %r10,%r8
   4cc9b:	4d 89 d9             	mov    %r11,%r9
   4cc9e:	e8 7d e5 ff ff       	call   4b220 <_RNvMs_NtCshzyx7VBzFal_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4cca3:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4cca8:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4ccad:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4ccb2:	0f 10 02             	movups (%rdx),%xmm0
   4ccb5:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4ccba:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4ccbe:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4ccc3:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   4ccc8:	4c 8b 74 24 68       	mov    0x68(%rsp),%r14
   4cccd:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4ccd2:	8b 6c 24 74          	mov    0x74(%rsp),%ebp
   4ccd6:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4ccda:	0f 85 70 01 00 00    	jne    4ce50 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1850>
   4cce0:	66 41 89 04 5c       	mov    %ax,(%r12,%rbx,2)
   4cce5:	48 ff c3             	inc    %rbx
   4cce8:	66 3b 44 24 2e       	cmp    0x2e(%rsp),%ax
   4cced:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4ccf4:	00 
   4ccf5:	0f 84 af 01 00 00    	je     4ceaa <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x18aa>
   4ccfb:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4ccff:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4cd06:	00 
   4cd07:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4cd0c:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4cd13:	00 
   4cd14:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4cd19:	e9 c3 fc ff ff       	jmp    4c9e1 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x13e1>
   4cd1e:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4cd23:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   4cd28:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4cd2d:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4cd31:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4cd35:	48 89 fe             	mov    %rdi,%rsi
   4cd38:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4cd3d:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4cd42:	4d 89 d0             	mov    %r10,%r8
   4cd45:	4d 89 d9             	mov    %r11,%r9
   4cd48:	e8 d3 e4 ff ff       	call   4b220 <_RNvMs_NtCshzyx7VBzFal_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4cd4d:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4cd52:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4cd57:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4cd5c:	0f 10 02             	movups (%rdx),%xmm0
   4cd5f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4cd64:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4cd68:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4cd6d:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   4cd72:	4c 8b 74 24 68       	mov    0x68(%rsp),%r14
   4cd77:	8b 54 24 70          	mov    0x70(%rsp),%edx
   4cd7b:	8b 6c 24 74          	mov    0x74(%rsp),%ebp
   4cd7f:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4cd83:	0f 85 c4 00 00 00    	jne    4ce4d <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x184d>
   4cd89:	66 41 89 04 5c       	mov    %ax,(%r12,%rbx,2)
   4cd8e:	48 ff c3             	inc    %rbx
   4cd91:	66 3b 44 24 2e       	cmp    0x2e(%rsp),%ax
   4cd96:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4cd9d:	00 
   4cd9e:	0f 84 03 01 00 00    	je     4cea7 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x18a7>
   4cda4:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4cda8:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4cdaf:	00 
   4cdb0:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4cdb5:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4cdbc:	00 
   4cdbd:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4cdc2:	49 89 f4             	mov    %rsi,%r12
   4cdc5:	48 83 fe f7          	cmp    $0xfffffffffffffff7,%rsi
   4cdc9:	0f 86 59 fc ff ff    	jbe    4ca28 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1428>
   4cdcf:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
   4cdd4:	4c 89 74 24 48       	mov    %r14,0x48(%rsp)
   4cdd9:	89 54 24 50          	mov    %edx,0x50(%rsp)
   4cddd:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4cde1:	89 44 24 54          	mov    %eax,0x54(%rsp)
   4cde5:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   4cdea:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   4cdef:	4c 89 d2             	mov    %r10,%rdx
   4cdf2:	4c 89 d9             	mov    %r11,%rcx
   4cdf5:	e8 96 8e ff ff       	call   45c90 <_RNvMNtCshzyx7VBzFal_5mibz24bitsNtB2_3Reg11refill_slow>
   4cdfa:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4cdff:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4ce06:	00 
   4ce07:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4ce0c:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4ce13:	00 
   4ce14:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4ce1b:	00 
   4ce1c:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   4ce21:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   4ce26:	44 8b 6c 24 20       	mov    0x20(%rsp),%r13d
   4ce2b:	8b 44 24 24          	mov    0x24(%rsp),%eax
   4ce2f:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   4ce33:	49 01 df             	add    %rbx,%r15
   4ce36:	4c 3b bc 24 a8 00 00 	cmp    0xa8(%rsp),%r15
   4ce3d:	00 
   4ce3e:	0f 86 ac fa ff ff    	jbe    4c8f0 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x12f0>
   4ce44:	e9 3c fa ff ff       	jmp    4c885 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1285>
   4ce49:	31 db                	xor    %ebx,%ebx
   4ce4b:	eb 03                	jmp    4ce50 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1850>
   4ce4d:	41 89 d5             	mov    %edx,%r13d
   4ce50:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4ce57:	00 
   4ce58:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4ce5f:	00 
   4ce60:	89 c2                	mov    %eax,%edx
   4ce62:	c1 ea 08             	shr    $0x8,%edx
   4ce65:	89 54 24 7c          	mov    %edx,0x7c(%rsp)
   4ce69:	48 8b 54 24 1e       	mov    0x1e(%rsp),%rdx
   4ce6e:	48 89 94 24 9e 00 00 	mov    %rdx,0x9e(%rsp)
   4ce75:	00 
   4ce76:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
   4ce7b:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
   4ce82:	00 
   4ce83:	4c 01 fb             	add    %r15,%rbx
   4ce86:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4ce8b:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4ce92:	00 
   4ce93:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4ce98:	49 89 f4             	mov    %rsi,%r12
   4ce9b:	e9 86 00 00 00       	jmp    4cf26 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1926>
   4cea0:	bb 01 00 00 00       	mov    $0x1,%ebx
   4cea5:	eb 03                	jmp    4ceaa <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x18aa>
   4cea7:	41 89 d5             	mov    %edx,%r13d
   4ceaa:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4ceb1:	00 
   4ceb2:	49 89 f4             	mov    %rsi,%r12
   4ceb5:	4c 01 fb             	add    %r15,%rbx
   4ceb8:	48 81 fb 13 04 00 00 	cmp    $0x413,%rbx
   4cebf:	0f 83 40 0e 00 00    	jae    4dd05 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x2705>
   4cec5:	49 8b 01             	mov    (%r9),%rax
   4cec8:	4d 8b 79 10          	mov    0x10(%r9),%r15
   4cecc:	4c 29 f8             	sub    %r15,%rax
   4cecf:	48 39 c3             	cmp    %rax,%rbx
   4ced2:	0f 87 83 09 00 00    	ja     4d85b <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x225b>
   4ced8:	48 85 db             	test   %rbx,%rbx
   4cedb:	74 25                	je     4cf02 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1902>
   4cedd:	4b 8d 3c 3f          	lea    (%r15,%r15,1),%rdi
   4cee1:	49 03 79 08          	add    0x8(%r9),%rdi
   4cee5:	48 8d 14 1b          	lea    (%rbx,%rbx,1),%rdx
   4cee9:	4c 89 c6             	mov    %r8,%rsi
   4ceec:	ff 15 36 39 05 00    	call   *0x53936(%rip)        # a0828 <memcpy@GLIBC_2.14>
   4cef2:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4cef9:	00 
   4cefa:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4cf01:	00 
   4cf02:	49 01 df             	add    %rbx,%r15
   4cf05:	4d 89 79 10          	mov    %r15,0x10(%r9)
   4cf09:	b0 01                	mov    $0x1,%al
   4cf0b:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
   4cf12:	31 db                	xor    %ebx,%ebx
   4cf14:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4cf19:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4cf20:	00 
   4cf21:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4cf26:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   4cf2d:	00 
   4cf2e:	4c 89 22             	mov    %r12,(%rdx)
   4cf31:	4c 89 72 08          	mov    %r14,0x8(%rdx)
   4cf35:	44 89 6a 10          	mov    %r13d,0x10(%rdx)
   4cf39:	89 6a 14             	mov    %ebp,0x14(%rdx)
   4cf3c:	49 89 de             	mov    %rbx,%r14
   4cf3f:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4cf43:	48 8b 94 24 88 00 00 	mov    0x88(%rsp),%rdx
   4cf4a:	00 
   4cf4b:	0f 85 b1 0e 00 00    	jne    4de02 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x2802>
   4cf51:	a8 01                	test   $0x1,%al
   4cf53:	0f 84 ee f1 ff ff    	je     4c147 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xb47>
   4cf59:	e9 3b 0d 00 00       	jmp    4dc99 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x2699>
   4cf5e:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
   4cf63:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
   4cf68:	89 44 24 50          	mov    %eax,0x50(%rsp)
   4cf6c:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4cf70:	89 44 24 54          	mov    %eax,0x54(%rsp)
   4cf74:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   4cf79:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   4cf7e:	4c 89 d2             	mov    %r10,%rdx
   4cf81:	4c 89 d9             	mov    %r11,%rcx
   4cf84:	e8 07 8d ff ff       	call   45c90 <_RNvMNtCshzyx7VBzFal_5mibz24bitsNtB2_3Reg11refill_slow>
   4cf89:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4cf8e:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4cf95:	00 
   4cf96:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4cf9b:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4cfa2:	00 
   4cfa3:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4cfaa:	00 
   4cfab:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   4cfb0:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   4cfb5:	44 8b 6c 24 20       	mov    0x20(%rsp),%r13d
   4cfba:	8b 44 24 24          	mov    0x24(%rsp),%eax
   4cfbe:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   4cfc2:	e9 d2 e7 ff ff       	jmp    4b799 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x199>
   4cfc7:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
   4cfcc:	48 89 6c 24 48       	mov    %rbp,0x48(%rsp)
   4cfd1:	44 89 6c 24 50       	mov    %r13d,0x50(%rsp)
   4cfd6:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4cfda:	89 44 24 54          	mov    %eax,0x54(%rsp)
   4cfde:	48 89 fe             	mov    %rdi,%rsi
   4cfe1:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   4cfe8:	00 
   4cfe9:	48 8d 4c 24 40       	lea    0x40(%rsp),%rcx
   4cfee:	4d 89 d0             	mov    %r10,%r8
   4cff1:	4d 89 d9             	mov    %r11,%r9
   4cff4:	e8 27 e2 ff ff       	call   4b220 <_RNvMs_NtCshzyx7VBzFal_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4cff9:	48 8b 8c 24 30 01 00 	mov    0x130(%rsp),%rcx
   4d000:	00 
   4d001:	0f b7 84 24 38 01 00 	movzwl 0x138(%rsp),%eax
   4d008:	00 
   4d009:	4c 8b a4 24 50 01 00 	mov    0x150(%rsp),%r12
   4d010:	00 
   4d011:	48 8b ac 24 58 01 00 	mov    0x158(%rsp),%rbp
   4d018:	00 
   4d019:	44 8b ac 24 60 01 00 	mov    0x160(%rsp),%r13d
   4d020:	00 
   4d021:	8b 94 24 64 01 00 00 	mov    0x164(%rsp),%edx
   4d028:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4d02c:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4d030:	0f 85 11 0d 00 00    	jne    4dd47 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x2747>
   4d036:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d03d:	00 
   4d03e:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d045:	00 
   4d046:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4d04b:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4d052:	00 
   4d053:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4d058:	e9 3c f0 ff ff       	jmp    4c099 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xa99>
   4d05d:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
   4d062:	48 89 6c 24 48       	mov    %rbp,0x48(%rsp)
   4d067:	44 89 6c 24 50       	mov    %r13d,0x50(%rsp)
   4d06c:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4d070:	89 44 24 54          	mov    %eax,0x54(%rsp)
   4d074:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   4d079:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   4d07e:	4c 89 d2             	mov    %r10,%rdx
   4d081:	4c 89 d9             	mov    %r11,%rcx
   4d084:	e8 07 8c ff ff       	call   45c90 <_RNvMNtCshzyx7VBzFal_5mibz24bitsNtB2_3Reg11refill_slow>
   4d089:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4d08e:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4d095:	00 
   4d096:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4d09b:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d0a2:	00 
   4d0a3:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d0aa:	00 
   4d0ab:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   4d0b0:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   4d0b5:	44 8b 6c 24 20       	mov    0x20(%rsp),%r13d
   4d0ba:	8b 44 24 24          	mov    0x24(%rsp),%eax
   4d0be:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   4d0c2:	e9 49 f3 ff ff       	jmp    4c410 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xe10>
   4d0c7:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
   4d0cc:	48 89 6c 24 48       	mov    %rbp,0x48(%rsp)
   4d0d1:	44 89 6c 24 50       	mov    %r13d,0x50(%rsp)
   4d0d6:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4d0da:	89 44 24 54          	mov    %eax,0x54(%rsp)
   4d0de:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   4d0e3:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   4d0e8:	4c 89 d2             	mov    %r10,%rdx
   4d0eb:	4c 89 d9             	mov    %r11,%rcx
   4d0ee:	e8 9d 8b ff ff       	call   45c90 <_RNvMNtCshzyx7VBzFal_5mibz24bitsNtB2_3Reg11refill_slow>
   4d0f3:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4d0f8:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4d0ff:	00 
   4d100:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4d105:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d10c:	00 
   4d10d:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d114:	00 
   4d115:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   4d11a:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   4d11f:	44 8b 6c 24 20       	mov    0x20(%rsp),%r13d
   4d124:	8b 44 24 24          	mov    0x24(%rsp),%eax
   4d128:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   4d12c:	e9 3e ef ff ff       	jmp    4c06f <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xa6f>
   4d131:	b9 02 00 00 00       	mov    $0x2,%ecx
   4d136:	41 b8 02 00 00 00    	mov    $0x2,%r8d
   4d13c:	4c 89 cf             	mov    %r9,%rdi
   4d13f:	48 89 de             	mov    %rbx,%rsi
   4d142:	4c 89 d2             	mov    %r10,%rdx
   4d145:	e8 a6 9b fe ff       	call   36cf0 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECshzyx7VBzFal_5mibz2>
   4d14a:	4d 89 f2             	mov    %r14,%r10
   4d14d:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d154:	00 
   4d155:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d15c:	00 
   4d15d:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4d161:	e9 7b ef ff ff       	jmp    4c0e1 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xae1>
   4d166:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4d16b:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4d170:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4d175:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4d179:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4d17d:	48 89 fe             	mov    %rdi,%rsi
   4d180:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4d185:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4d18a:	4d 89 d0             	mov    %r10,%r8
   4d18d:	4d 89 d9             	mov    %r11,%r9
   4d190:	e8 8b e0 ff ff       	call   4b220 <_RNvMs_NtCshzyx7VBzFal_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4d195:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4d19a:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4d19f:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4d1a4:	0f 10 02             	movups (%rdx),%xmm0
   4d1a7:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4d1ac:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4d1b0:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4d1b5:	4c 8b 64 24 60       	mov    0x60(%rsp),%r12
   4d1ba:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
   4d1bf:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4d1c4:	8b 54 24 74          	mov    0x74(%rsp),%edx
   4d1c8:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4d1cc:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4d1d0:	0f 85 4d 06 00 00    	jne    4d823 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x2223>
   4d1d6:	44 89 f1             	mov    %r14d,%ecx
   4d1d9:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4d1df:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d1e6:	00 
   4d1e7:	66 41 89 04 48       	mov    %ax,(%r8,%rcx,2)
   4d1ec:	49 ff c6             	inc    %r14
   4d1ef:	66 3b 44 24 2e       	cmp    0x2e(%rsp),%ax
   4d1f4:	0f 84 a6 07 00 00    	je     4d9a0 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x23a0>
   4d1fa:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d201:	00 
   4d202:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4d207:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4d20e:	00 
   4d20f:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4d214:	4d 89 f7             	mov    %r14,%r15
   4d217:	4d 89 fe             	mov    %r15,%r14
   4d21a:	49 39 df             	cmp    %rbx,%r15
   4d21d:	0f 86 11 ed ff ff    	jbe    4bf34 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x934>
   4d223:	e9 e6 ed ff ff       	jmp    4c00e <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xa0e>
   4d228:	89 c2                	mov    %eax,%edx
   4d22a:	c1 ea 08             	shr    $0x8,%edx
   4d22d:	89 54 24 7c          	mov    %edx,0x7c(%rsp)
   4d231:	48 8b 54 24 1e       	mov    0x1e(%rsp),%rdx
   4d236:	48 89 94 24 9e 00 00 	mov    %rdx,0x9e(%rsp)
   4d23d:	00 
   4d23e:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
   4d243:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
   4d24a:	00 
   4d24b:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d252:	00 
   4d253:	eb 33                	jmp    4d288 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1c88>
   4d255:	49 81 fe 13 04 00 00 	cmp    $0x413,%r14
   4d25c:	0f 83 02 0c 00 00    	jae    4de64 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x2864>
   4d262:	89 f3                	mov    %esi,%ebx
   4d264:	4c 89 cf             	mov    %r9,%rdi
   4d267:	4c 89 c6             	mov    %r8,%rsi
   4d26a:	4c 89 f2             	mov    %r14,%rdx
   4d26d:	e8 1e e3 ff ff       	call   4b590 <_RNvMs_NtCsgFX3jaOk65H_5alloc3vecINtB4_3VectE15append_elementsCshzyx7VBzFal_5mibz2>
   4d272:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d279:	00 
   4d27a:	b0 01                	mov    $0x1,%al
   4d27c:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
   4d283:	45 31 f6             	xor    %r14d,%r14d
   4d286:	89 de                	mov    %ebx,%esi
   4d288:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   4d28f:	00 
   4d290:	4c 89 22             	mov    %r12,(%rdx)
   4d293:	48 89 6a 08          	mov    %rbp,0x8(%rdx)
   4d297:	44 89 6a 10          	mov    %r13d,0x10(%rdx)
   4d29b:	89 72 14             	mov    %esi,0x14(%rdx)
   4d29e:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d2a5:	00 
   4d2a6:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4d2ab:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4d2b2:	00 
   4d2b3:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4d2b8:	e9 82 fc ff ff       	jmp    4cf3f <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x193f>
   4d2bd:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
   4d2c2:	48 89 6c 24 48       	mov    %rbp,0x48(%rsp)
   4d2c7:	44 89 6c 24 50       	mov    %r13d,0x50(%rsp)
   4d2cc:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4d2d0:	89 44 24 54          	mov    %eax,0x54(%rsp)
   4d2d4:	48 89 fe             	mov    %rdi,%rsi
   4d2d7:	48 8d bc 24 f8 00 00 	lea    0xf8(%rsp),%rdi
   4d2de:	00 
   4d2df:	48 8d 4c 24 40       	lea    0x40(%rsp),%rcx
   4d2e4:	4d 89 d0             	mov    %r10,%r8
   4d2e7:	4d 89 d9             	mov    %r11,%r9
   4d2ea:	e8 31 df ff ff       	call   4b220 <_RNvMs_NtCshzyx7VBzFal_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4d2ef:	48 8b 8c 24 f8 00 00 	mov    0xf8(%rsp),%rcx
   4d2f6:	00 
   4d2f7:	0f b7 84 24 00 01 00 	movzwl 0x100(%rsp),%eax
   4d2fe:	00 
   4d2ff:	4c 8b a4 24 18 01 00 	mov    0x118(%rsp),%r12
   4d306:	00 
   4d307:	48 8b ac 24 20 01 00 	mov    0x120(%rsp),%rbp
   4d30e:	00 
   4d30f:	44 8b ac 24 28 01 00 	mov    0x128(%rsp),%r13d
   4d316:	00 
   4d317:	8b 94 24 2c 01 00 00 	mov    0x12c(%rsp),%edx
   4d31e:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4d322:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4d326:	0f 85 94 0a 00 00    	jne    4ddc0 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x27c0>
   4d32c:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d333:	00 
   4d334:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d33b:	00 
   4d33c:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4d341:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4d348:	00 
   4d349:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4d34e:	66 43 89 04 78       	mov    %ax,(%r8,%r15,2)
   4d353:	49 ff c7             	inc    %r15
   4d356:	66 3b 84 24 88 00 00 	cmp    0x88(%rsp),%ax
   4d35d:	00 
   4d35e:	0f 85 b5 ef ff ff    	jne    4c319 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xd19>
   4d364:	e9 08 09 00 00       	jmp    4dc71 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x2671>
   4d369:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
   4d36e:	48 89 6c 24 48       	mov    %rbp,0x48(%rsp)
   4d373:	44 89 6c 24 50       	mov    %r13d,0x50(%rsp)
   4d378:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4d37c:	89 44 24 54          	mov    %eax,0x54(%rsp)
   4d380:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   4d385:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   4d38a:	4c 89 d2             	mov    %r10,%rdx
   4d38d:	4c 89 d9             	mov    %r11,%rcx
   4d390:	e8 fb 88 ff ff       	call   45c90 <_RNvMNtCshzyx7VBzFal_5mibz24bitsNtB2_3Reg11refill_slow>
   4d395:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4d39a:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4d3a1:	00 
   4d3a2:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4d3a7:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d3ae:	00 
   4d3af:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d3b6:	00 
   4d3b7:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   4d3bc:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   4d3c1:	44 8b 6c 24 20       	mov    0x20(%rsp),%r13d
   4d3c6:	8b 44 24 24          	mov    0x24(%rsp),%eax
   4d3ca:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   4d3ce:	e9 8d f1 ff ff       	jmp    4c560 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xf60>
   4d3d3:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
   4d3d8:	48 89 6c 24 48       	mov    %rbp,0x48(%rsp)
   4d3dd:	44 89 6c 24 50       	mov    %r13d,0x50(%rsp)
   4d3e2:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4d3e6:	89 44 24 54          	mov    %eax,0x54(%rsp)
   4d3ea:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   4d3ef:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   4d3f4:	4c 89 d2             	mov    %r10,%rdx
   4d3f7:	4c 89 d9             	mov    %r11,%rcx
   4d3fa:	e8 91 88 ff ff       	call   45c90 <_RNvMNtCshzyx7VBzFal_5mibz24bitsNtB2_3Reg11refill_slow>
   4d3ff:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4d404:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4d40b:	00 
   4d40c:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4d411:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d418:	00 
   4d419:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d420:	00 
   4d421:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   4d426:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   4d42b:	44 8b 6c 24 20       	mov    0x20(%rsp),%r13d
   4d430:	8b 44 24 24          	mov    0x24(%rsp),%eax
   4d434:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   4d438:	e9 9c ee ff ff       	jmp    4c2d9 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xcd9>
   4d43d:	b9 02 00 00 00       	mov    $0x2,%ecx
   4d442:	41 b8 02 00 00 00    	mov    $0x2,%r8d
   4d448:	4c 89 cf             	mov    %r9,%rdi
   4d44b:	48 89 de             	mov    %rbx,%rsi
   4d44e:	4c 89 fa             	mov    %r15,%rdx
   4d451:	e8 9a 98 fe ff       	call   36cf0 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECshzyx7VBzFal_5mibz2>
   4d456:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d45d:	00 
   4d45e:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d465:	00 
   4d466:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4d46a:	e9 d3 ee ff ff       	jmp    4c342 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xd42>
   4d46f:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4d474:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4d479:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4d47e:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4d482:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4d486:	48 89 fe             	mov    %rdi,%rsi
   4d489:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4d48e:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4d493:	4d 89 d0             	mov    %r10,%r8
   4d496:	4d 89 d9             	mov    %r11,%r9
   4d499:	e8 82 dd ff ff       	call   4b220 <_RNvMs_NtCshzyx7VBzFal_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4d49e:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4d4a3:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4d4a8:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4d4ad:	0f 10 02             	movups (%rdx),%xmm0
   4d4b0:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4d4b5:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4d4b9:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4d4be:	4c 8b 64 24 60       	mov    0x60(%rsp),%r12
   4d4c3:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
   4d4c8:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4d4cd:	8b 54 24 74          	mov    0x74(%rsp),%edx
   4d4d1:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4d4d5:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4d4d9:	0f 85 44 03 00 00    	jne    4d823 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x2223>
   4d4df:	44 89 f1             	mov    %r14d,%ecx
   4d4e2:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4d4e8:	48 8b 94 24 a8 01 00 	mov    0x1a8(%rsp),%rdx
   4d4ef:	00 
   4d4f0:	66 89 04 4a          	mov    %ax,(%rdx,%rcx,2)
   4d4f4:	49 ff c6             	inc    %r14
   4d4f7:	66 3b 44 24 2e       	cmp    0x2e(%rsp),%ax
   4d4fc:	0f 84 9e 04 00 00    	je     4d9a0 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x23a0>
   4d502:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d509:	00 
   4d50a:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d511:	00 
   4d512:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4d517:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4d51e:	00 
   4d51f:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4d524:	4d 89 f7             	mov    %r14,%r15
   4d527:	4d 89 fe             	mov    %r15,%r14
   4d52a:	49 39 df             	cmp    %rbx,%r15
   4d52d:	0f 86 50 ea ff ff    	jbe    4bf83 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x983>
   4d533:	e9 d6 ea ff ff       	jmp    4c00e <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xa0e>
   4d538:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4d53d:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4d542:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4d547:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4d54b:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4d54f:	48 89 fe             	mov    %rdi,%rsi
   4d552:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4d557:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4d55c:	4d 89 d0             	mov    %r10,%r8
   4d55f:	4d 89 d9             	mov    %r11,%r9
   4d562:	e8 b9 dc ff ff       	call   4b220 <_RNvMs_NtCshzyx7VBzFal_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4d567:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4d56c:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4d571:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4d576:	0f 10 02             	movups (%rdx),%xmm0
   4d579:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4d57e:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4d582:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4d587:	4c 8b 64 24 60       	mov    0x60(%rsp),%r12
   4d58c:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
   4d591:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4d596:	8b 54 24 74          	mov    0x74(%rsp),%edx
   4d59a:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4d59e:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4d5a2:	0f 85 d6 04 00 00    	jne    4da7e <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x247e>
   4d5a8:	48 8b 8c 24 a8 01 00 	mov    0x1a8(%rsp),%rcx
   4d5af:	00 
   4d5b0:	66 42 89 04 79       	mov    %ax,(%rcx,%r15,2)
   4d5b5:	49 ff c7             	inc    %r15
   4d5b8:	66 3b 84 24 88 00 00 	cmp    0x88(%rsp),%ax
   4d5bf:	00 
   4d5c0:	0f 84 06 01 00 00    	je     4d6cc <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x20cc>
   4d5c6:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d5cd:	00 
   4d5ce:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d5d5:	00 
   4d5d6:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4d5db:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4d5e2:	00 
   4d5e3:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4d5e8:	4d 39 f7             	cmp    %r14,%r15
   4d5eb:	0f 86 e0 eb ff ff    	jbe    4c1d1 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xbd1>
   4d5f1:	e9 8a ec ff ff       	jmp    4c280 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xc80>
   4d5f6:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4d5fb:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4d600:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4d605:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4d609:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4d60d:	48 89 fe             	mov    %rdi,%rsi
   4d610:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4d615:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4d61a:	4d 89 d0             	mov    %r10,%r8
   4d61d:	4d 89 d9             	mov    %r11,%r9
   4d620:	e8 fb db ff ff       	call   4b220 <_RNvMs_NtCshzyx7VBzFal_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4d625:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4d62a:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4d62f:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4d634:	0f 10 02             	movups (%rdx),%xmm0
   4d637:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4d63c:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4d640:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4d645:	4c 8b 64 24 60       	mov    0x60(%rsp),%r12
   4d64a:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
   4d64f:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4d654:	8b 54 24 74          	mov    0x74(%rsp),%edx
   4d658:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4d65c:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4d660:	0f 85 bd 01 00 00    	jne    4d823 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x2223>
   4d666:	44 89 f1             	mov    %r14d,%ecx
   4d669:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4d66f:	48 8b 94 24 a8 01 00 	mov    0x1a8(%rsp),%rdx
   4d676:	00 
   4d677:	66 89 04 4a          	mov    %ax,(%rdx,%rcx,2)
   4d67b:	49 ff c6             	inc    %r14
   4d67e:	66 3b 44 24 2e       	cmp    0x2e(%rsp),%ax
   4d683:	0f 84 17 03 00 00    	je     4d9a0 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x23a0>
   4d689:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d690:	00 
   4d691:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d698:	00 
   4d699:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4d69e:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4d6a5:	00 
   4d6a6:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4d6ab:	4d 89 f7             	mov    %r14,%r15
   4d6ae:	4d 89 fe             	mov    %r15,%r14
   4d6b1:	49 39 df             	cmp    %rbx,%r15
   4d6b4:	0f 86 14 e9 ff ff    	jbe    4bfce <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x9ce>
   4d6ba:	e9 4f e9 ff ff       	jmp    4c00e <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xa0e>
   4d6bf:	49 81 ff 13 04 00 00 	cmp    $0x413,%r15
   4d6c6:	0f 83 c4 07 00 00    	jae    4de90 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x2890>
   4d6cc:	48 8b bc 24 b0 01 00 	mov    0x1b0(%rsp),%rdi
   4d6d3:	00 
   4d6d4:	48 8b b4 24 a8 01 00 	mov    0x1a8(%rsp),%rsi
   4d6db:	00 
   4d6dc:	4c 89 fa             	mov    %r15,%rdx
   4d6df:	e8 ac de ff ff       	call   4b590 <_RNvMs_NtCsgFX3jaOk65H_5alloc3vecINtB4_3VectE15append_elementsCshzyx7VBzFal_5mibz2>
   4d6e4:	b0 01                	mov    $0x1,%al
   4d6e6:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
   4d6ed:	45 31 ff             	xor    %r15d,%r15d
   4d6f0:	e9 ac 03 00 00       	jmp    4daa1 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x24a1>
   4d6f5:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4d6fa:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4d6ff:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4d704:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4d708:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4d70c:	48 89 fe             	mov    %rdi,%rsi
   4d70f:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4d714:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4d719:	4d 89 d0             	mov    %r10,%r8
   4d71c:	4d 89 d9             	mov    %r11,%r9
   4d71f:	e8 fc da ff ff       	call   4b220 <_RNvMs_NtCshzyx7VBzFal_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4d724:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4d729:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4d72e:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4d733:	0f 10 02             	movups (%rdx),%xmm0
   4d736:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4d73b:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4d73f:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4d744:	4c 8b 64 24 60       	mov    0x60(%rsp),%r12
   4d749:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
   4d74e:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4d753:	8b 54 24 74          	mov    0x74(%rsp),%edx
   4d757:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4d75b:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4d75f:	0f 85 19 03 00 00    	jne    4da7e <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x247e>
   4d765:	48 8b 8c 24 a8 01 00 	mov    0x1a8(%rsp),%rcx
   4d76c:	00 
   4d76d:	66 42 89 04 79       	mov    %ax,(%rcx,%r15,2)
   4d772:	49 ff c7             	inc    %r15
   4d775:	66 3b 84 24 88 00 00 	cmp    0x88(%rsp),%ax
   4d77c:	00 
   4d77d:	0f 84 49 ff ff ff    	je     4d6cc <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x20cc>
   4d783:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d78a:	00 
   4d78b:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d792:	00 
   4d793:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4d798:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4d79f:	00 
   4d7a0:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4d7a5:	4d 39 f7             	cmp    %r14,%r15
   4d7a8:	0f 86 5f ea ff ff    	jbe    4c20d <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xc0d>
   4d7ae:	e9 cd ea ff ff       	jmp    4c280 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xc80>
   4d7b3:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4d7b8:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4d7bd:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4d7c2:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4d7c6:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4d7ca:	48 89 fe             	mov    %rdi,%rsi
   4d7cd:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4d7d2:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4d7d7:	4d 89 d0             	mov    %r10,%r8
   4d7da:	4d 89 d9             	mov    %r11,%r9
   4d7dd:	e8 3e da ff ff       	call   4b220 <_RNvMs_NtCshzyx7VBzFal_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4d7e2:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4d7e7:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4d7ec:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4d7f1:	0f 10 02             	movups (%rdx),%xmm0
   4d7f4:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4d7f9:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4d7fd:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4d802:	4c 8b 64 24 60       	mov    0x60(%rsp),%r12
   4d807:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
   4d80c:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4d811:	8b 54 24 74          	mov    0x74(%rsp),%edx
   4d815:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4d819:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4d81d:	0f 84 5a 01 00 00    	je     4d97d <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x237d>
   4d823:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d82a:	00 
   4d82b:	89 c2                	mov    %eax,%edx
   4d82d:	c1 ea 08             	shr    $0x8,%edx
   4d830:	89 54 24 7c          	mov    %edx,0x7c(%rsp)
   4d834:	48 8b 54 24 1e       	mov    0x1e(%rsp),%rdx
   4d839:	48 89 94 24 9e 00 00 	mov    %rdx,0x9e(%rsp)
   4d840:	00 
   4d841:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
   4d846:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
   4d84d:	00 
   4d84e:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d855:	00 
   4d856:	e9 82 01 00 00       	jmp    4d9dd <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x23dd>
   4d85b:	b9 02 00 00 00       	mov    $0x2,%ecx
   4d860:	41 b8 02 00 00 00    	mov    $0x2,%r8d
   4d866:	4c 89 cf             	mov    %r9,%rdi
   4d869:	4c 89 fe             	mov    %r15,%rsi
   4d86c:	48 89 da             	mov    %rbx,%rdx
   4d86f:	e8 7c 94 fe ff       	call   36cf0 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECshzyx7VBzFal_5mibz2>
   4d874:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d87b:	00 
   4d87c:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d883:	00 
   4d884:	4d 8b 79 10          	mov    0x10(%r9),%r15
   4d888:	e9 50 f6 ff ff       	jmp    4cedd <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x18dd>
   4d88d:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4d892:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4d897:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4d89c:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4d8a0:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4d8a4:	48 89 fe             	mov    %rdi,%rsi
   4d8a7:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4d8ac:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4d8b1:	4d 89 d0             	mov    %r10,%r8
   4d8b4:	4d 89 d9             	mov    %r11,%r9
   4d8b7:	e8 64 d9 ff ff       	call   4b220 <_RNvMs_NtCshzyx7VBzFal_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4d8bc:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4d8c1:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4d8c6:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4d8cb:	0f 10 02             	movups (%rdx),%xmm0
   4d8ce:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4d8d3:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4d8d7:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4d8dc:	4c 8b 64 24 60       	mov    0x60(%rsp),%r12
   4d8e1:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
   4d8e6:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4d8eb:	8b 54 24 74          	mov    0x74(%rsp),%edx
   4d8ef:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4d8f3:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4d8f7:	0f 85 81 01 00 00    	jne    4da7e <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x247e>
   4d8fd:	48 8b 8c 24 a8 01 00 	mov    0x1a8(%rsp),%rcx
   4d904:	00 
   4d905:	66 42 89 04 79       	mov    %ax,(%rcx,%r15,2)
   4d90a:	49 ff c7             	inc    %r15
   4d90d:	66 3b 84 24 88 00 00 	cmp    0x88(%rsp),%ax
   4d914:	00 
   4d915:	0f 84 b1 fd ff ff    	je     4d6cc <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x20cc>
   4d91b:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d922:	00 
   4d923:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d92a:	00 
   4d92b:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4d930:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4d937:	00 
   4d938:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4d93d:	4d 39 f7             	cmp    %r14,%r15
   4d940:	0f 86 03 e9 ff ff    	jbe    4c249 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xc49>
   4d946:	e9 35 e9 ff ff       	jmp    4c280 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xc80>
   4d94b:	b9 02 00 00 00       	mov    $0x2,%ecx
   4d950:	41 b8 02 00 00 00    	mov    $0x2,%r8d
   4d956:	4c 89 cf             	mov    %r9,%rdi
   4d959:	4c 89 f6             	mov    %r14,%rsi
   4d95c:	4c 89 fa             	mov    %r15,%rdx
   4d95f:	e8 8c 93 fe ff       	call   36cf0 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECshzyx7VBzFal_5mibz2>
   4d964:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d96b:	00 
   4d96c:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d973:	00 
   4d974:	4d 8b 71 10          	mov    0x10(%r9),%r14
   4d978:	e9 7e ed ff ff       	jmp    4c6fb <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x10fb>
   4d97d:	44 89 f1             	mov    %r14d,%ecx
   4d980:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4d986:	48 8b 94 24 a8 01 00 	mov    0x1a8(%rsp),%rdx
   4d98d:	00 
   4d98e:	66 89 04 4a          	mov    %ax,(%rdx,%rcx,2)
   4d992:	49 ff c6             	inc    %r14
   4d995:	66 3b 44 24 2e       	cmp    0x2e(%rsp),%ax
   4d99a:	0f 85 4f 01 00 00    	jne    4daef <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x24ef>
   4d9a0:	4c 89 f2             	mov    %r14,%rdx
   4d9a3:	49 81 fe 13 04 00 00 	cmp    $0x413,%r14
   4d9aa:	0f 83 ca 04 00 00    	jae    4de7a <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x287a>
   4d9b0:	48 8b 9c 24 b0 01 00 	mov    0x1b0(%rsp),%rbx
   4d9b7:	00 
   4d9b8:	48 89 df             	mov    %rbx,%rdi
   4d9bb:	4c 8b b4 24 a8 01 00 	mov    0x1a8(%rsp),%r14
   4d9c2:	00 
   4d9c3:	4c 89 f6             	mov    %r14,%rsi
   4d9c6:	e8 c5 db ff ff       	call   4b590 <_RNvMs_NtCsgFX3jaOk65H_5alloc3vecINtB4_3VectE15append_elementsCshzyx7VBzFal_5mibz2>
   4d9cb:	4d 89 f0             	mov    %r14,%r8
   4d9ce:	49 89 d9             	mov    %rbx,%r9
   4d9d1:	b0 01                	mov    $0x1,%al
   4d9d3:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
   4d9da:	45 31 f6             	xor    %r14d,%r14d
   4d9dd:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4d9e2:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4d9e9:	00 
   4d9ea:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4d9ef:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   4d9f6:	00 
   4d9f7:	4c 89 22             	mov    %r12,(%rdx)
   4d9fa:	48 89 6a 08          	mov    %rbp,0x8(%rdx)
   4d9fe:	44 89 6a 10          	mov    %r13d,0x10(%rdx)
   4da02:	8b 74 24 0c          	mov    0xc(%rsp),%esi
   4da06:	89 72 14             	mov    %esi,0x14(%rdx)
   4da09:	e9 31 f5 ff ff       	jmp    4cf3f <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x193f>
   4da0e:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4da13:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4da18:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4da1d:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4da21:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4da25:	48 89 fe             	mov    %rdi,%rsi
   4da28:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4da2d:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4da32:	4d 89 d0             	mov    %r10,%r8
   4da35:	4d 89 d9             	mov    %r11,%r9
   4da38:	e8 e3 d7 ff ff       	call   4b220 <_RNvMs_NtCshzyx7VBzFal_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4da3d:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4da42:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4da47:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4da4c:	0f 10 02             	movups (%rdx),%xmm0
   4da4f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4da54:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4da58:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4da5d:	4c 8b 64 24 60       	mov    0x60(%rsp),%r12
   4da62:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
   4da67:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4da6c:	8b 54 24 74          	mov    0x74(%rsp),%edx
   4da70:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4da74:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4da78:	0f 84 98 00 00 00    	je     4db16 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x2516>
   4da7e:	89 c2                	mov    %eax,%edx
   4da80:	c1 ea 08             	shr    $0x8,%edx
   4da83:	89 54 24 7c          	mov    %edx,0x7c(%rsp)
   4da87:	48 8b 54 24 1e       	mov    0x1e(%rsp),%rdx
   4da8c:	48 89 94 24 9e 00 00 	mov    %rdx,0x9e(%rsp)
   4da93:	00 
   4da94:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
   4da99:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
   4daa0:	00 
   4daa1:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   4daa8:	00 
   4daa9:	4c 89 22             	mov    %r12,(%rdx)
   4daac:	48 89 6a 08          	mov    %rbp,0x8(%rdx)
   4dab0:	44 89 6a 10          	mov    %r13d,0x10(%rdx)
   4dab4:	8b 74 24 0c          	mov    0xc(%rsp),%esi
   4dab8:	89 72 14             	mov    %esi,0x14(%rdx)
   4dabb:	4d 89 fe             	mov    %r15,%r14
   4dabe:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4dac5:	00 
   4dac6:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4dacd:	00 
   4dace:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4dad3:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4dada:	00 
   4dadb:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4dae0:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4dae4:	0f 84 7e ec ff ff    	je     4c768 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x1168>
   4daea:	e9 13 03 00 00       	jmp    4de02 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x2802>
   4daef:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4daf6:	00 
   4daf7:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4dafe:	00 
   4daff:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4db04:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4db0b:	00 
   4db0c:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4db11:	e9 f8 e4 ff ff       	jmp    4c00e <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xa0e>
   4db16:	48 8b 8c 24 a8 01 00 	mov    0x1a8(%rsp),%rcx
   4db1d:	00 
   4db1e:	66 42 89 04 79       	mov    %ax,(%rcx,%r15,2)
   4db23:	49 ff c7             	inc    %r15
   4db26:	66 3b 84 24 88 00 00 	cmp    0x88(%rsp),%ax
   4db2d:	00 
   4db2e:	0f 84 98 fb ff ff    	je     4d6cc <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x20cc>
   4db34:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4db3b:	00 
   4db3c:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4db43:	00 
   4db44:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4db49:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4db50:	00 
   4db51:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4db56:	e9 25 e7 ff ff       	jmp    4c280 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0xc80>
   4db5b:	48 8b 9c 24 c8 00 00 	mov    0xc8(%rsp),%rbx
   4db62:	00 
   4db63:	48 39 cb             	cmp    %rcx,%rbx
   4db66:	0f 82 06 db ff ff    	jb     4b672 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x72>
   4db6c:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   4db73:	00 
   4db74:	48 8b 42 10          	mov    0x10(%rdx),%rax
   4db78:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
   4db7f:	00 
   4db80:	48 89 41 30          	mov    %rax,0x30(%rcx)
   4db84:	0f 10 02             	movups (%rdx),%xmm0
   4db87:	0f 11 41 20          	movups %xmm0,0x20(%rcx)
   4db8b:	48 b8 0b 00 00 00 00 	movabs $0x800000000000000b,%rax
   4db92:	00 00 80 
   4db95:	e9 bc 00 00 00       	jmp    4dc56 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x2656>
   4db9a:	48 8d 0d ef 08 05 00 	lea    0x508ef(%rip),%rcx        # 9e490 <_TLS_MODULE_BASE_+0x18f0>
   4dba1:	ba 12 04 00 00       	mov    $0x412,%edx
   4dba6:	4c 89 ff             	mov    %r15,%rdi
   4dba9:	e8 12 f5 fd ff       	call   2d0c0 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4dbae:	48 8d 0d db 08 05 00 	lea    0x508db(%rip),%rcx        # 9e490 <_TLS_MODULE_BASE_+0x18f0>
   4dbb5:	ba 12 04 00 00       	mov    $0x412,%edx
   4dbba:	4c 89 f7             	mov    %r14,%rdi
   4dbbd:	e8 fe f4 fd ff       	call   2d0c0 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4dbc2:	4d 89 f2             	mov    %r14,%r10
   4dbc5:	49 81 fe 13 04 00 00 	cmp    $0x413,%r14
   4dbcc:	0f 83 5f 01 00 00    	jae    4dd31 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x2731>
   4dbd2:	49 8b 01             	mov    (%r9),%rax
   4dbd5:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4dbd9:	48 29 d8             	sub    %rbx,%rax
   4dbdc:	49 39 c2             	cmp    %rax,%r10
   4dbdf:	0f 87 a6 01 00 00    	ja     4dd8b <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x278b>
   4dbe5:	4d 85 d2             	test   %r10,%r10
   4dbe8:	74 20                	je     4dc0a <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x260a>
   4dbea:	48 8d 3c 1b          	lea    (%rbx,%rbx,1),%rdi
   4dbee:	49 03 79 08          	add    0x8(%r9),%rdi
   4dbf2:	4b 8d 14 12          	lea    (%r10,%r10,1),%rdx
   4dbf6:	4c 89 c6             	mov    %r8,%rsi
   4dbf9:	ff 15 29 2c 05 00    	call   *0x52c29(%rip)        # a0828 <memcpy@GLIBC_2.14>
   4dbff:	4d 89 f2             	mov    %r14,%r10
   4dc02:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4dc09:	00 
   4dc0a:	4c 01 d3             	add    %r10,%rbx
   4dc0d:	49 89 59 10          	mov    %rbx,0x10(%r9)
   4dc11:	eb 6c                	jmp    4dc7f <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x267f>
   4dc13:	48 8d 0d 46 08 05 00 	lea    0x50846(%rip),%rcx        # 9e460 <_TLS_MODULE_BASE_+0x18c0>
   4dc1a:	ba 12 04 00 00       	mov    $0x412,%edx
   4dc1f:	31 ff                	xor    %edi,%edi
   4dc21:	4c 89 fe             	mov    %r15,%rsi
   4dc24:	e8 97 f4 fd ff       	call   2d0c0 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4dc29:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   4dc30:	00 
   4dc31:	48 8b 42 10          	mov    0x10(%rdx),%rax
   4dc35:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
   4dc3c:	00 
   4dc3d:	48 89 41 30          	mov    %rax,0x30(%rcx)
   4dc41:	0f 10 02             	movups (%rdx),%xmm0
   4dc44:	0f 11 41 20          	movups %xmm0,0x20(%rcx)
   4dc48:	48 b8 0b 00 00 00 00 	movabs $0x800000000000000b,%rax
   4dc4f:	00 00 80 
   4dc52:	48 83 c0 06          	add    $0x6,%rax
   4dc56:	48 89 01             	mov    %rax,(%rcx)
   4dc59:	eb 6c                	jmp    4dcc7 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x26c7>
   4dc5b:	48 8d 0d fe 07 05 00 	lea    0x507fe(%rip),%rcx        # 9e460 <_TLS_MODULE_BASE_+0x18c0>
   4dc62:	ba 12 04 00 00       	mov    $0x412,%edx
   4dc67:	31 ff                	xor    %edi,%edi
   4dc69:	4c 89 f6             	mov    %r14,%rsi
   4dc6c:	e8 4f f4 fd ff       	call   2d0c0 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4dc71:	4c 89 cf             	mov    %r9,%rdi
   4dc74:	4c 89 c6             	mov    %r8,%rsi
   4dc77:	4c 89 fa             	mov    %r15,%rdx
   4dc7a:	e8 11 d9 ff ff       	call   4b590 <_RNvMs_NtCsgFX3jaOk65H_5alloc3vecINtB4_3VectE15append_elementsCshzyx7VBzFal_5mibz2>
   4dc7f:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   4dc86:	00 
   4dc87:	4c 89 20             	mov    %r12,(%rax)
   4dc8a:	48 89 68 08          	mov    %rbp,0x8(%rax)
   4dc8e:	44 89 68 10          	mov    %r13d,0x10(%rax)
   4dc92:	8b 4c 24 0c          	mov    0xc(%rsp),%ecx
   4dc96:	89 48 14             	mov    %ecx,0x14(%rax)
   4dc99:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   4dca0:	00 
   4dca1:	48 8b 42 10          	mov    0x10(%rdx),%rax
   4dca5:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
   4dcac:	00 
   4dcad:	48 89 41 30          	mov    %rax,0x30(%rcx)
   4dcb1:	48 8b 02             	mov    (%rdx),%rax
   4dcb4:	48 89 41 20          	mov    %rax,0x20(%rcx)
   4dcb8:	48 8b 42 08          	mov    0x8(%rdx),%rax
   4dcbc:	48 89 41 28          	mov    %rax,0x28(%rcx)
   4dcc0:	48 c7 01 ff ff ff ff 	movq   $0xffffffffffffffff,(%rcx)
   4dcc7:	48 81 c4 68 01 00 00 	add    $0x168,%rsp
   4dcce:	5b                   	pop    %rbx
   4dccf:	41 5c                	pop    %r12
   4dcd1:	41 5d                	pop    %r13
   4dcd3:	41 5e                	pop    %r14
   4dcd5:	41 5f                	pop    %r15
   4dcd7:	5d                   	pop    %rbp
   4dcd8:	c3                   	ret
   4dcd9:	48 8d 0d 38 07 05 00 	lea    0x50738(%rip),%rcx        # 9e418 <_TLS_MODULE_BASE_+0x1878>
   4dce0:	ba 12 04 00 00       	mov    $0x412,%edx
   4dce5:	31 ff                	xor    %edi,%edi
   4dce7:	4c 89 d6             	mov    %r10,%rsi
   4dcea:	e8 d1 f3 fd ff       	call   2d0c0 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4dcef:	48 8d 0d 22 07 05 00 	lea    0x50722(%rip),%rcx        # 9e418 <_TLS_MODULE_BASE_+0x1878>
   4dcf6:	ba 12 04 00 00       	mov    $0x412,%edx
   4dcfb:	31 ff                	xor    %edi,%edi
   4dcfd:	4c 89 fe             	mov    %r15,%rsi
   4dd00:	e8 bb f3 fd ff       	call   2d0c0 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4dd05:	48 8d 0d 6c 07 05 00 	lea    0x5076c(%rip),%rcx        # 9e478 <_TLS_MODULE_BASE_+0x18d8>
   4dd0c:	ba 12 04 00 00       	mov    $0x412,%edx
   4dd11:	31 ff                	xor    %edi,%edi
   4dd13:	48 89 de             	mov    %rbx,%rsi
   4dd16:	e8 a5 f3 fd ff       	call   2d0c0 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4dd1b:	48 8d 0d 56 07 05 00 	lea    0x50756(%rip),%rcx        # 9e478 <_TLS_MODULE_BASE_+0x18d8>
   4dd22:	ba 12 04 00 00       	mov    $0x412,%edx
   4dd27:	31 ff                	xor    %edi,%edi
   4dd29:	4c 89 fe             	mov    %r15,%rsi
   4dd2c:	e8 8f f3 fd ff       	call   2d0c0 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4dd31:	48 8d 0d f8 06 05 00 	lea    0x506f8(%rip),%rcx        # 9e430 <_TLS_MODULE_BASE_+0x1890>
   4dd38:	ba 12 04 00 00       	mov    $0x412,%edx
   4dd3d:	31 ff                	xor    %edi,%edi
   4dd3f:	4c 89 d6             	mov    %r10,%rsi
   4dd42:	e8 79 f3 fd ff       	call   2d0c0 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4dd47:	89 c2                	mov    %eax,%edx
   4dd49:	c1 ea 08             	shr    $0x8,%edx
   4dd4c:	89 54 24 7c          	mov    %edx,0x7c(%rsp)
   4dd50:	48 8d b4 24 3a 01 00 	lea    0x13a(%rsp),%rsi
   4dd57:	00 
   4dd58:	48 8b 56 0e          	mov    0xe(%rsi),%rdx
   4dd5c:	48 89 94 24 9e 00 00 	mov    %rdx,0x9e(%rsp)
   4dd63:	00 
   4dd64:	0f 10 06             	movups (%rsi),%xmm0
   4dd67:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
   4dd6e:	00 
   4dd6f:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   4dd76:	00 
   4dd77:	4c 89 22             	mov    %r12,(%rdx)
   4dd7a:	48 89 6a 08          	mov    %rbp,0x8(%rdx)
   4dd7e:	44 89 6a 10          	mov    %r13d,0x10(%rdx)
   4dd82:	8b 74 24 0c          	mov    0xc(%rsp),%esi
   4dd86:	89 72 14             	mov    %esi,0x14(%rdx)
   4dd89:	eb 77                	jmp    4de02 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x2802>
   4dd8b:	b9 02 00 00 00       	mov    $0x2,%ecx
   4dd90:	41 b8 02 00 00 00    	mov    $0x2,%r8d
   4dd96:	4c 89 cf             	mov    %r9,%rdi
   4dd99:	48 89 de             	mov    %rbx,%rsi
   4dd9c:	4c 89 d2             	mov    %r10,%rdx
   4dd9f:	e8 4c 8f fe ff       	call   36cf0 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECshzyx7VBzFal_5mibz2>
   4dda4:	4d 89 f2             	mov    %r14,%r10
   4dda7:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4ddae:	00 
   4ddaf:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4ddb6:	00 
   4ddb7:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4ddbb:	e9 2a fe ff ff       	jmp    4dbea <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x25ea>
   4ddc0:	48 8d b4 24 02 01 00 	lea    0x102(%rsp),%rsi
   4ddc7:	00 
   4ddc8:	48 8b 56 0e          	mov    0xe(%rsi),%rdx
   4ddcc:	48 89 94 24 9e 00 00 	mov    %rdx,0x9e(%rsp)
   4ddd3:	00 
   4ddd4:	0f 10 06             	movups (%rsi),%xmm0
   4ddd7:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
   4ddde:	00 
   4dddf:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   4dde6:	00 
   4dde7:	4c 89 22             	mov    %r12,(%rdx)
   4ddea:	48 89 6a 08          	mov    %rbp,0x8(%rdx)
   4ddee:	44 89 6a 10          	mov    %r13d,0x10(%rdx)
   4ddf2:	8b 74 24 0c          	mov    0xc(%rsp),%esi
   4ddf6:	89 72 14             	mov    %esi,0x14(%rdx)
   4ddf9:	89 c2                	mov    %eax,%edx
   4ddfb:	c1 ea 08             	shr    $0x8,%edx
   4ddfe:	89 54 24 7c          	mov    %edx,0x7c(%rsp)
   4de02:	48 8b 94 24 9e 00 00 	mov    0x9e(%rsp),%rdx
   4de09:	00 
   4de0a:	48 8b b4 24 b0 00 00 	mov    0xb0(%rsp),%rsi
   4de11:	00 
   4de12:	48 89 56 18          	mov    %rdx,0x18(%rsi)
   4de16:	0f 28 84 24 90 00 00 	movaps 0x90(%rsp),%xmm0
   4de1d:	00 
   4de1e:	0f 11 46 0a          	movups %xmm0,0xa(%rsi)
   4de22:	48 8b bc 24 80 00 00 	mov    0x80(%rsp),%rdi
   4de29:	00 
   4de2a:	48 8b 17             	mov    (%rdi),%rdx
   4de2d:	48 89 56 20          	mov    %rdx,0x20(%rsi)
   4de31:	48 8b 57 08          	mov    0x8(%rdi),%rdx
   4de35:	48 89 56 28          	mov    %rdx,0x28(%rsi)
   4de39:	48 8b 57 10          	mov    0x10(%rdi),%rdx
   4de3d:	48 89 56 30          	mov    %rdx,0x30(%rsi)
   4de41:	48 89 0e             	mov    %rcx,(%rsi)
   4de44:	88 46 08             	mov    %al,0x8(%rsi)
   4de47:	8b 44 24 7c          	mov    0x7c(%rsp),%eax
   4de4b:	88 46 09             	mov    %al,0x9(%rsi)
   4de4e:	e9 74 fe ff ff       	jmp    4dcc7 <_RNvNtCshzyx7VBzFal_5mibz25block16decode_runs_bmi2+0x26c7>
   4de53:	48 8d 15 36 0c 05 00 	lea    0x50c36(%rip),%rdx        # 9ea90 <_TLS_MODULE_BASE_+0x1ef0>
   4de5a:	be 06 00 00 00       	mov    $0x6,%esi
   4de5f:	e8 3d f3 fd ff       	call   2d1a1 <_RNvNtCskADBYZwJmSU_4core9panicking18panic_bounds_check>
   4de64:	48 8d 0d dd 05 05 00 	lea    0x505dd(%rip),%rcx        # 9e448 <_TLS_MODULE_BASE_+0x18a8>
   4de6b:	ba 12 04 00 00       	mov    $0x412,%edx
   4de70:	31 ff                	xor    %edi,%edi
   4de72:	4c 89 f6             	mov    %r14,%rsi
   4de75:	e8 46 f2 fd ff       	call   2d0c0 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4de7a:	48 8d 0d 7f 05 05 00 	lea    0x5057f(%rip),%rcx        # 9e400 <_TLS_MODULE_BASE_+0x1860>
   4de81:	48 89 d6             	mov    %rdx,%rsi
   4de84:	ba 12 04 00 00       	mov    $0x412,%edx
   4de89:	31 ff                	xor    %edi,%edi
   4de8b:	e8 30 f2 fd ff       	call   2d0c0 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4de90:	48 8d 0d b1 05 05 00 	lea    0x505b1(%rip),%rcx        # 9e448 <_TLS_MODULE_BASE_+0x18a8>
   4de97:	ba 12 04 00 00       	mov    $0x412,%edx
   4de9c:	31 ff                	xor    %edi,%edi
   4de9e:	4c 89 fe             	mov    %r15,%rsi
   4dea1:	e8 1a f2 fd ff       	call   2d0c0 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
