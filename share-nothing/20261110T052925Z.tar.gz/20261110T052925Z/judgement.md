VALID: -2 CPU growth 4->10 x1.18 [1.15-1.22], against the historical band 1.1-1.44: within the band; -9 x3.26 [3.21-3.31]; ratio of ratios x0.36 [0.35-0.38]: a favourable interaction

Rounds analysed: 60 (after 1 warm-up). Intervals: moving-block bootstrap, block 5 rounds, 10000 resamples, 95% percentile, conditional on this attempt and on the assumed dependence (a circular moving-block bootstrap over chronological rounds); not a guaranteed 95% coverage: dependence longer than the block, or a shock common to the whole attempt, is not bounded.

## Growth from 4 to 10 workers (4-to-10 inflation, not 1-to-10)

| reading | -2 | -9 | ratio of ratios |
|---|--:|--:|--:|
| cpu | x1.18 [1.15-1.22] | x3.26 [3.21-3.31] | x0.36 [0.35-0.38] |
| wall | x0.75 [0.72-0.78] | x1.51 [1.49-1.54] | x0.49 [0.47-0.52] |

## Model check (CPU-seconds)

- -2 growth against §2's historical band 1.1-1.44: within the band (point in band: True)
- -9 growth against §2's historical x3.5: excludes x3.5
- ratio of ratios (the level x worker interaction): below 1: a favourable level x worker interaction (not isolated table capacity)
- HISTORICAL MODEL (§3 of the share-nothing entry), not observed: 3.76 GB/s / G2, its numerator fixed (10 x one thread's 400 MB/s x 0.94); it takes the unmeasured 1-to-4 factor as 1, and the Workers arm's 4-to-10 growth as a finder-fed kernel's, which it does not identify: 3.18 GB/s [3.08-3.26]

## Sensitivity (block length)

- block1: -2 x1.18 [1.16-1.22], -9 x3.26 [3.21-3.31], ratio of ratios x0.36 [0.35-0.37]
- block10: -2 x1.18 [1.16-1.21], -9 x3.26 [3.22-3.31], ratio of ratios x0.36 [0.35-0.37]
- t intervals (independent rounds) and lag-1 autocorrelation: -2 [1.15-1.22] lag1 0.20, -9 [3.21-3.31] lag1 0.07, R [0.35-0.37] lag1 0.31

## Grid (medians)

| corpus | workers | CPU s | wall s | MB/s | CPU growth vs 4 | pre-run clock MHz (unread) |
|---|--:|--:|--:|--:|--:|--:|
| wikidata-l2 | 2 | 0.655 | 0.304 | 689 | x0.96 [0.95-0.97] | 823 (0) |
| wikidata-l2 | 4 | 0.682 | 0.160 | 1309 | 1 | 815 (0) |
| wikidata-l2 | 6 | 0.692 | 0.117 | 1792 | x1.02 [1.01-1.03] | 824 (0) |
| wikidata-l2 | 8 | 0.730 | 0.113 | 1862 | x1.07 [1.06-1.08] | 816 (0) |
| wikidata-l2 | 10 | 0.793 | 0.115 | 1819 | x1.18 [1.15-1.22] | 805 (0) |
| wikidata-l9 | 2 | 0.604 | 0.293 | 716 | x0.76 [0.75-0.78] | 816 (0) |
| wikidata-l9 | 4 | 0.792 | 0.195 | 1076 | 1 | 808 (0) |
| wikidata-l9 | 6 | 1.262 | 0.211 | 994 | x1.62 [1.58-1.65] | 815 (0) |
| wikidata-l9 | 8 | 2.119 | 0.267 | 784 | x2.63 [2.58-2.69] | 801 (0) |
| wikidata-l9 | 10 | 2.576 | 0.298 | 704 | x3.26 [3.21-3.31] | 821 (0) |

Pre-run sysfs state (720 runs; recorded, never an exclusion): unread {'freq_mhz': 0, 'governor': 0, 'epp': 0, 'turbo': 0, 'pkg_temp_c': 0}; read but not as declared {'governor': 0, 'epp': 0, 'turbo': 0}

## Busy-gate waits (described, never an exclusion)

| group | runs | runs that waited | total s | max s |
|---|--:|--:|--:|--:|
| cell sentinel | 120 | 0 | 0 | 0 |
| cell wikidata-l2@10 | 60 | 0 | 0 | 0 |
| cell wikidata-l2@2 | 60 | 0 | 0 | 0 |
| cell wikidata-l2@4 | 60 | 0 | 0 | 0 |
| cell wikidata-l2@6 | 60 | 0 | 0 | 0 |
| cell wikidata-l2@8 | 60 | 0 | 0 | 0 |
| cell wikidata-l9@10 | 60 | 0 | 0 | 0 |
| cell wikidata-l9@2 | 60 | 0 | 0 | 0 |
| cell wikidata-l9@4 | 60 | 0 | 0 | 0 |
| cell wikidata-l9@6 | 60 | 0 | 0 | 0 |
| cell wikidata-l9@8 | 60 | 0 | 0 | 0 |
| position 0 | 60 | 0 | 0 | 0 |
| position 1 | 60 | 0 | 0 | 0 |
| position 10 | 60 | 0 | 0 | 0 |
| position 11 | 60 | 0 | 0 | 0 |
| position 2 | 60 | 0 | 0 | 0 |
| position 3 | 60 | 0 | 0 | 0 |
| position 4 | 60 | 0 | 0 | 0 |
| position 5 | 60 | 0 | 0 | 0 |
| position 6 | 60 | 0 | 0 | 0 |
| position 7 | 60 | 0 | 0 | 0 |
| position 8 | 60 | 0 | 0 | 0 |
| position 9 | 60 | 0 | 0 | 0 |

## Mode split

DESCRIPTIVE: rounds classed by their two sentinels' walls (threshold 0.21 s), an endpoint-bracketed indicator of another plan's state; not a mode identification of the cells, never an exclusion; point estimates only

Rounds: {'fast': 55, 'slow': 0, 'mixed': 5, 'unread': 0}

- fast (55 rounds): -2 x1.18, -9 x3.24, ratio of ratios x0.36, pre-run clock median 814 MHz
- mixed (5 rounds): -2 x1.25, -9 x3.55, ratio of ratios x0.35, pre-run clock median 818 MHz

## Chronological rounds

| round | start s | duration s | waited s | sentinel walls | class | log r -2 | log r -9 | log R | pre clock |
|--:|--:|--:|--:|---|---|--:|--:|--:|--:|
| 1 | 0.0 | 6.4 | 0 | 0.145, 0.147 | fast | 0.061 | 1.165 | -1.104 | 800 |
| 2 | 6.4 | 6.4 | 0 | 0.146, 0.142 | fast | 0.197 | 1.250 | -1.053 | 814 |
| 3 | 12.7 | 6.4 | 0 | 0.140, 0.135 | fast | 0.149 | 1.169 | -1.020 | 800 |
| 4 | 19.1 | 6.6 | 0 | 0.138, 0.136 | fast | 0.191 | 1.091 | -0.900 | 852 |
| 5 | 25.7 | 6.4 | 0 | 0.142, 0.138 | fast | 0.193 | 1.185 | -0.992 | 805 |
| 6 | 32.1 | 6.4 | 0 | 0.139, 0.144 | fast | 0.129 | 1.131 | -1.002 | 810 |
| 7 | 38.5 | 6.5 | 0 | 0.133, 0.147 | fast | 0.146 | 1.007 | -0.862 | 822 |
| 8 | 45.0 | 6.3 | 0 | 0.137, 0.136 | fast | 0.161 | 1.164 | -1.003 | 808 |
| 9 | 51.4 | 6.6 | 0 | 0.140, 0.152 | fast | 0.118 | 1.237 | -1.118 | 802 |
| 10 | 57.9 | 6.4 | 0 | 0.133, 0.143 | fast | 0.077 | 1.216 | -1.139 | 837 |
| 11 | 64.3 | 6.5 | 0 | 0.139, 0.160 | fast | 0.144 | 1.209 | -1.065 | 800 |
| 12 | 70.8 | 6.5 | 0 | 0.149, 0.298 | mixed | 0.183 | 1.269 | -1.086 | 800 |
| 13 | 77.3 | 6.6 | 0 | 0.158, 0.155 | fast | 0.206 | 1.097 | -0.891 | 809 |
| 14 | 83.9 | 6.5 | 0 | 0.139, 0.130 | fast | 0.168 | 1.143 | -0.975 | 800 |
| 15 | 90.3 | 6.4 | 0 | 0.142, 0.134 | fast | 0.127 | 1.169 | -1.043 | 851 |
| 16 | 96.8 | 6.4 | 0 | 0.133, 0.139 | fast | 0.256 | 1.182 | -0.926 | 825 |
| 17 | 103.2 | 6.5 | 0 | 0.139, 0.144 | fast | 0.171 | 1.160 | -0.989 | 800 |
| 18 | 109.6 | 6.6 | 0 | 0.138, 0.158 | fast | 0.135 | 1.041 | -0.906 | 804 |
| 19 | 116.2 | 6.3 | 0 | 0.148, 0.133 | fast | 0.112 | 1.162 | -1.050 | 803 |
| 20 | 122.5 | 6.5 | 0 | 0.144, 0.147 | fast | 0.134 | 1.187 | -1.052 | 803 |
| 21 | 129.0 | 6.4 | 0 | 0.144, 0.144 | fast | 0.158 | 1.177 | -1.019 | 810 |
| 22 | 135.4 | 6.5 | 0 | 0.143, 0.132 | fast | 0.091 | 1.153 | -1.063 | 858 |
| 23 | 141.8 | 6.4 | 0 | 0.137, 0.155 | fast | 0.152 | 1.192 | -1.040 | 811 |
| 24 | 148.2 | 6.4 | 0 | 0.146, 0.134 | fast | 0.208 | 1.203 | -0.995 | 800 |
| 25 | 154.6 | 6.4 | 0 | 0.136, 0.138 | fast | 0.168 | 1.147 | -0.980 | 800 |
| 26 | 160.9 | 6.4 | 0 | 0.142, 0.134 | fast | 0.794 | 1.205 | -0.411 | 834 |
| 27 | 167.4 | 6.5 | 0 | 0.142, 0.144 | fast | 0.334 | 1.139 | -0.805 | 805 |
| 28 | 173.9 | 6.6 | 0 | 0.144, 0.140 | fast | 0.152 | 1.209 | -1.057 | 821 |
| 29 | 180.5 | 6.4 | 0 | 0.139, 0.139 | fast | 0.099 | 1.198 | -1.099 | 821 |
| 30 | 186.9 | 6.5 | 0 | 0.141, 0.138 | fast | 0.136 | 1.249 | -1.113 | 854 |
| 31 | 193.4 | 6.6 | 0 | 0.136, 0.141 | fast | 0.068 | 1.168 | -1.100 | 805 |
| 32 | 200.0 | 6.5 | 0 | 0.135, 0.143 | fast | 0.154 | 1.117 | -0.963 | 871 |
| 33 | 206.5 | 6.6 | 0 | 0.140, 0.138 | fast | 0.139 | 1.239 | -1.100 | 844 |
| 34 | 213.0 | 6.7 | 0 | 0.137, 0.143 | fast | 0.180 | 1.284 | -1.105 | 813 |
| 35 | 219.7 | 6.3 | 0 | 0.145, 0.141 | fast | 0.128 | 1.142 | -1.014 | 854 |
| 36 | 226.0 | 6.5 | 0 | 0.141, 0.136 | fast | 0.322 | 1.231 | -0.909 | 806 |
| 37 | 232.5 | 6.3 | 0 | 0.133, 0.142 | fast | 0.131 | 1.182 | -1.050 | 825 |
| 38 | 238.9 | 6.5 | 0 | 0.148, 0.136 | fast | 0.104 | 1.139 | -1.035 | 808 |
| 39 | 245.3 | 6.3 | 0 | 0.137, 0.136 | fast | 0.194 | 1.249 | -1.055 | 821 |
| 40 | 251.7 | 6.6 | 0 | 0.133, 0.140 | fast | 0.168 | 1.148 | -0.980 | 830 |
| 41 | 258.2 | 6.5 | 0 | 0.138, 0.141 | fast | 0.051 | 1.205 | -1.155 | 807 |
| 42 | 264.7 | 6.5 | 0 | 0.147, 0.136 | fast | 0.109 | 1.182 | -1.073 | 821 |
| 43 | 271.3 | 6.4 | 0 | 0.137, 0.136 | fast | 0.111 | 1.118 | -1.007 | 856 |
| 44 | 277.7 | 6.5 | 0 | 0.138, 0.144 | fast | 0.218 | 1.169 | -0.951 | 800 |
| 45 | 284.2 | 6.5 | 0 | 0.132, 0.147 | fast | 0.181 | 1.286 | -1.104 | 821 |
| 46 | 290.7 | 6.4 | 0 | 0.135, 0.135 | fast | 0.082 | 1.203 | -1.121 | 856 |
| 47 | 297.1 | 6.6 | 0 | 0.137, 0.137 | fast | 0.092 | 1.179 | -1.087 | 806 |
| 48 | 303.7 | 6.4 | 0 | 0.137, 0.149 | fast | 0.178 | 1.134 | -0.956 | 884 |
| 49 | 310.1 | 6.5 | 0 | 0.141, 0.195 | fast | 0.145 | 1.191 | -1.046 | 813 |
| 50 | 316.6 | 6.5 | 0 | 0.150, 0.151 | fast | 0.148 | 1.230 | -1.082 | 800 |
| 51 | 323.1 | 6.4 | 0 | 0.144, 0.134 | fast | 0.184 | 1.145 | -0.961 | 827 |
| 52 | 329.5 | 6.4 | 0 | 0.137, 0.140 | fast | 0.189 | 1.099 | -0.910 | 807 |
| 53 | 335.9 | 6.6 | 0 | 0.140, 0.263 | mixed | 0.461 | 1.285 | -0.823 | 903 |
| 54 | 342.5 | 6.6 | 0 | 0.277, 0.136 | mixed | 0.195 | 1.264 | -1.070 | 811 |
| 55 | 349.1 | 6.4 | 0 | 0.139, 0.324 | mixed | 0.105 | 1.224 | -1.119 | 820 |
| 56 | 355.6 | 6.7 | 0 | 0.312, 0.149 | mixed | 0.156 | 1.297 | -1.141 | 814 |
| 57 | 362.3 | 6.4 | 0 | 0.141, 0.137 | fast | 0.119 | 1.165 | -1.046 | 812 |
| 58 | 368.7 | 6.4 | 0 | 0.142, 0.158 | fast | 0.148 | 1.228 | -1.080 | 800 |
| 59 | 375.1 | 6.5 | 0 | 0.140, 0.141 | fast | 0.173 | 1.193 | -1.019 | 813 |
| 60 | 381.5 | 6.5 | 0 | 0.135, 0.136 | fast | 0.119 | 1.122 | -1.003 | 830 |
