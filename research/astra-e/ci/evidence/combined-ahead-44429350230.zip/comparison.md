### Astra E paired research benchmark

16 paired rounds on Wikidata ×4, with 4W slots and a 2 s settle. Ratios compare the PR candidate with the base kernel in the same worker configuration. Eager Cells is the low-worker production kernel. The one-worker row uses the worker pool.

| Workers | Reference | Wall ratio [95% CI] | Median peak RSS ratio |
| ---: | --- | ---: | ---: |
| 1 | master LazyCells | 0.8894 [0.8727, 0.9065] | 0.9693 |
| 1 | master eager Cells | 1.2339 [1.2075, 1.2609] | 0.9787 |
| 1 | master opend | 0.9581 [0.9493, 0.9670] | 1.0002 |
| 2 | master LazyCells | 0.8938 [0.8844, 0.9032] | 0.9452 |
| 2 | master eager Cells | 1.2039 [1.1945, 1.2133] | 0.9514 |
| 2 | master opend | 0.9632 [0.9533, 0.9733] | 0.9899 |
| 4 | master LazyCells | 0.8332 [0.8024, 0.8651] | 0.8710 |
| 4 | master eager Cells | 1.0168 [0.9876, 1.0470] | 0.9091 |
| 4 | master opend | 0.9639 [0.9594, 0.9684] | 0.9801 |
