### Astra E paired research benchmark

20 paired rounds on Wikidata ×4, with 4W slots and a 2 s settle. Ratios compare the PR candidate with each reference kernel in the same worker configuration. Eager Cells is the low-worker production kernel. The one-worker row uses the worker pool.

| Workers | Reference | Wall ratio [95% CI] | Median peak RSS ratio |
| ---: | --- | ---: | ---: |
| 1 | master LazyCells | 0.9419 [0.9285, 0.9554] | 0.9108 |
| 1 | master eager Cells | 1.2532 [1.2388, 1.2679] | 0.9199 |
| 1 | master opend | 0.9631 [0.9518, 0.9746] | 0.9400 |
| 1 | frozen narrow-short/ahead | 1.0071 [0.9986, 1.0156] | 0.9383 |
| 2 | master LazyCells | 0.9345 [0.9246, 0.9446] | 0.8387 |
| 2 | master eager Cells | 1.2185 [1.2070, 1.2301] | 0.8443 |
| 2 | master opend | 0.9655 [0.9555, 0.9756] | 0.8822 |
| 2 | frozen narrow-short/ahead | 1.0096 [1.0031, 1.0161] | 0.8904 |
| 4 | master LazyCells | 0.9074 [0.9029, 0.9119] | 0.7129 |
| 4 | master eager Cells | 1.0534 [1.0453, 1.0615] | 0.7593 |
| 4 | master opend | 0.9768 [0.9725, 0.9811] | 0.8275 |
| 4 | frozen narrow-short/ahead | 1.0027 [0.9995, 1.0058] | 0.8334 |
