### Astra E paired research benchmark

20 paired rounds on Wikidata ×4, with 4W slots and a 2 s settle. Ratios compare the PR candidate with each reference kernel in the same worker configuration. Eager Cells is the low-worker production kernel. The one-worker row uses the worker pool.

| Workers | Reference | Wall ratio [95% CI] | Median peak RSS ratio |
| ---: | --- | ---: | ---: |
| 1 | master LazyCells | 0.7060 [0.6958, 0.7164] | 0.9904 |
| 1 | master eager Cells | 0.9764 [0.9548, 0.9984] | 1.0005 |
| 1 | master opend | 0.7759 [0.7698, 0.7821] | 1.0220 |
| 1 | frozen predecessor | 0.7804 [0.7723, 0.7886] | 1.0861 |
| 2 | master LazyCells | 0.8114 [0.8027, 0.8201] | 0.8990 |
| 2 | master eager Cells | 1.0891 [1.0770, 1.1013] | 0.9068 |
| 2 | master opend | 0.8791 [0.8698, 0.8884] | 0.9508 |
| 2 | frozen predecessor | 0.8861 [0.8714, 0.9010] | 1.0784 |
| 4 | master LazyCells | 0.8292 [0.8074, 0.8516] | 0.7750 |
| 4 | master eager Cells | 1.0188 [0.9947, 1.0434] | 0.8067 |
| 4 | master opend | 0.9642 [0.9603, 0.9682] | 0.8675 |
| 4 | frozen predecessor | 0.9876 [0.9836, 0.9916] | 1.0578 |
