### Astra E paired research benchmark

20 paired rounds on Wikidata ×4, with 4W slots and a 2 s settle. Ratios compare the PR candidate with each reference kernel in the same worker configuration. Eager Cells is the low-worker production kernel. The one-worker row uses the worker pool.

| Workers | Reference | Wall ratio [95% CI] | Median peak RSS ratio |
| ---: | --- | ---: | ---: |
| 1 | master LazyCells | 0.9561 [0.9404, 0.9720] | 0.9683 |
| 1 | master eager Cells | 1.3138 [1.2835, 1.3448] | 0.9783 |
| 1 | master opend | 0.9961 [0.9797, 1.0127] | 0.9990 |
| 1 | frozen predecessor | 1.0110 [0.9946, 1.0276] | 0.9986 |
| 2 | master LazyCells | 0.9606 [0.9461, 0.9752] | 0.9439 |
| 2 | master eager Cells | 1.2745 [1.2503, 1.2992] | 0.9602 |
| 2 | master opend | 0.9952 [0.9822, 1.0083] | 0.9963 |
| 2 | frozen predecessor | 1.0212 [1.0084, 1.0342] | 0.9998 |
| 4 | master LazyCells | 0.9029 [0.8843, 0.9220] | 0.8776 |
| 4 | master eager Cells | 1.0539 [1.0336, 1.0747] | 0.9268 |
| 4 | master opend | 0.9859 [0.9700, 1.0022] | 1.0091 |
| 4 | frozen predecessor | 1.0122 [0.9946, 1.0301] | 1.0208 |
