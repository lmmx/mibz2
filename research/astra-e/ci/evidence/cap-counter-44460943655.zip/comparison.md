### Astra E paired research benchmark

28 paired rounds on Wikidata ×4, with 4W slots and a 2 s settle. Ratios compare the PR candidate with each reference kernel in the same worker configuration. Eager Cells is the low-worker production kernel. The one-worker row uses the worker pool.

| Workers | Reference | Wall ratio [95% CI] | Median peak RSS ratio |
| ---: | --- | ---: | ---: |
| 1 | master LazyCells | 0.9092 [0.9024, 0.9160] | 0.9111 |
| 1 | master eager Cells | 1.2505 [1.2337, 1.2675] | 0.9204 |
| 1 | master opend | 0.9707 [0.9580, 0.9835] | 0.9409 |
| 1 | frozen predecessor | 0.9894 [0.9837, 0.9950] | 1.0004 |
| 1 | frozen edge | 0.9912 [0.9861, 0.9963] | 1.0001 |
| 1 | frozen counter | 1.0033 [0.9979, 1.0087] | 0.9998 |
| 2 | master LazyCells | 0.9022 [0.8884, 0.9161] | 0.8380 |
| 2 | master eager Cells | 1.2030 [1.1872, 1.2191] | 0.8394 |
| 2 | master opend | 0.9786 [0.9680, 0.9894] | 0.8782 |
| 2 | frozen predecessor | 0.9902 [0.9770, 1.0035] | 1.0019 |
| 2 | frozen edge | 0.9906 [0.9807, 1.0006] | 0.9984 |
| 2 | frozen counter | 1.0011 [0.9903, 1.0120] | 1.0019 |
| 4 | master LazyCells | 0.8468 [0.8442, 0.8494] | 0.7098 |
| 4 | master eager Cells | 1.0239 [1.0110, 1.0370] | 0.7638 |
| 4 | master opend | 0.9470 [0.9245, 0.9701] | 0.8228 |
| 4 | frozen predecessor | 0.9843 [0.9760, 0.9927] | 0.9982 |
| 4 | frozen edge | 0.9877 [0.9838, 0.9917] | 1.0034 |
| 4 | frozen counter | 0.9862 [0.9723, 1.0003] | 1.0021 |
