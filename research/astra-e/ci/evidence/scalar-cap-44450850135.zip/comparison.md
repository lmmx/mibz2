### Astra E paired research benchmark

20 paired rounds on Wikidata ×4, with 4W slots and a 2 s settle. Ratios compare the PR candidate with each reference kernel in the same worker configuration. Eager Cells is the low-worker production kernel. The one-worker row uses the worker pool.

| Workers | Reference | Wall ratio [95% CI] | Median peak RSS ratio |
| ---: | --- | ---: | ---: |
| 1 | master LazyCells | 0.9554 [0.9457, 0.9651] | 0.9117 |
| 1 | master eager Cells | 1.2766 [1.2688, 1.2844] | 0.9205 |
| 1 | master opend | 0.9748 [0.9670, 0.9827] | 0.9409 |
| 1 | frozen predecessor | 1.0119 [1.0023, 1.0216] | 1.0007 |
| 2 | master LazyCells | 0.9441 [0.9393, 0.9490] | 0.8379 |
| 2 | master eager Cells | 1.2102 [1.1934, 1.2272] | 0.8439 |
| 2 | master opend | 0.9686 [0.9616, 0.9756] | 0.8988 |
| 2 | frozen predecessor | 1.0056 [1.0015, 1.0097] | 1.0015 |
| 4 | master LazyCells | 0.9069 [0.9032, 0.9105] | 0.7225 |
| 4 | master eager Cells | 1.0505 [1.0437, 1.0573] | 0.7654 |
| 4 | master opend | 0.9745 [0.9703, 0.9787] | 0.8209 |
| 4 | frozen predecessor | 0.9956 [0.9915, 0.9998] | 0.9980 |
