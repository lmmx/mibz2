### Astra E paired research benchmark

20 paired rounds on Wikidata ×4, with 4W slots and a 2 s settle. Ratios compare the PR candidate with each reference kernel in the same worker configuration. Eager Cells is the low-worker production kernel. The one-worker row uses the worker pool.

| Workers | Reference | Wall ratio [95% CI] | Median peak RSS ratio |
| ---: | --- | ---: | ---: |
| 1 | master LazyCells | 0.9894 [0.9797, 0.9992] | 0.9116 |
| 1 | master eager Cells | 1.3774 [1.3544, 1.4008] | 0.9213 |
| 1 | master opend | 1.0108 [0.9896, 1.0326] | 0.9411 |
| 1 | frozen predecessor | 1.0133 [1.0003, 1.0265] | 0.9999 |
| 2 | master LazyCells | 0.9563 [0.9443, 0.9685] | 0.8263 |
| 2 | master eager Cells | 1.2722 [1.2427, 1.3024] | 0.8341 |
| 2 | master opend | 1.0140 [0.9998, 1.0283] | 0.8786 |
| 2 | frozen predecessor | 1.0105 [0.9970, 1.0243] | 0.9965 |
| 4 | master LazyCells | 0.9078 [0.8856, 0.9305] | 0.7249 |
| 4 | master eager Cells | 1.0676 [1.0365, 1.0997] | 0.7710 |
| 4 | master opend | 1.0031 [0.9779, 1.0289] | 0.8262 |
| 4 | frozen predecessor | 1.0302 [1.0093, 1.0516] | 0.9995 |
