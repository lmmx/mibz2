### Astra E paired research benchmark

20 paired rounds on Wikidata ×4, with 4W slots and a 2 s settle. Ratios compare the PR candidate with each reference kernel in the same worker configuration. Eager Cells is the low-worker production kernel. The one-worker row uses the worker pool.

| Workers | Reference | Wall ratio [95% CI] | Median peak RSS ratio |
| ---: | --- | ---: | ---: |
| 1 | master LazyCells | 0.8468 [0.8339, 0.8599] | 0.9931 |
| 1 | master eager Cells | 1.1279 [1.1079, 1.1483] | 1.0030 |
| 1 | master opend | 0.8817 [0.8622, 0.9016] | 1.0248 |
| 1 | frozen predecessor | 0.9134 [0.9066, 0.9203] | 0.9945 |
| 2 | master LazyCells | 0.8631 [0.8534, 0.8729] | 0.9819 |
| 2 | master eager Cells | 1.1264 [1.1117, 1.1413] | 0.9920 |
| 2 | master opend | 0.9112 [0.8982, 0.9245] | 1.0369 |
| 2 | frozen predecessor | 0.9151 [0.9047, 0.9256] | 0.9963 |
| 4 | master LazyCells | 0.8904 [0.8878, 0.8929] | 0.9140 |
| 4 | master eager Cells | 1.0701 [1.0649, 1.0754] | 0.9839 |
| 4 | master opend | 1.0069 [1.0033, 1.0105] | 1.0735 |
| 4 | frozen predecessor | 0.9225 [0.9198, 0.9251] | 0.9867 |
