### Astra E paired research benchmark

16 paired rounds on Wikidata ×4, with 4W slots and a 2 s settle. Ratios compare the PR candidate with the base kernel in the same worker configuration. Eager Cells is the low-worker production kernel. The one-worker row uses the worker pool.

| Workers | Reference | Wall ratio [95% CI] | Median peak RSS ratio |
| ---: | --- | ---: | ---: |
| 1 | master LazyCells | 0.9021 [0.8881, 0.9163] | 0.9702 |
| 1 | master eager Cells | 1.2516 [1.2343, 1.2692] | 0.9803 |
| 1 | master opend | 0.9718 [0.9532, 0.9907] | 1.0019 |
| 2 | master LazyCells | 0.8953 [0.8897, 0.9009] | 0.9461 |
| 2 | master eager Cells | 1.2044 [1.1950, 1.2138] | 0.9580 |
| 2 | master opend | 0.9666 [0.9474, 0.9862] | 0.9956 |
| 4 | master LazyCells | 0.8379 [0.8344, 0.8413] | 0.8617 |
| 4 | master eager Cells | 1.0314 [1.0139, 1.0493] | 0.9127 |
| 4 | master opend | 0.9569 [0.9290, 0.9856] | 0.9814 |
