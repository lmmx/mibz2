### Astra E paired research benchmark

12 paired rounds on Wikidata ×4, with 4W slots and a 2 s settle. Ratios compare the PR candidate with the base kernel in the same worker configuration. Eager Cells is the low-worker production kernel. The one-worker row uses the worker pool.

| Workers | Reference | Wall ratio [95% CI] | Median peak RSS ratio |
| ---: | --- | ---: | ---: |
| 1 | master LazyCells | 1.0357 [1.0258, 1.0457] | 0.9564 |
| 1 | master eager Cells | 1.3810 [1.3683, 1.3939] | 0.9656 |
| 2 | master LazyCells | 1.0272 [1.0217, 1.0327] | 0.9282 |
| 2 | master eager Cells | 1.3239 [1.3188, 1.3289] | 0.9321 |
| 4 | master LazyCells | 0.9773 [0.9743, 0.9803] | 0.8487 |
| 4 | master eager Cells | 1.1351 [1.1304, 1.1398] | 0.9142 |
