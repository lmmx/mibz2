### Astra E paired research benchmark

20 paired rounds on Wikidata ×4, with 4W slots and a 2 s settle. Ratios compare the PR candidate with each reference kernel in the same worker configuration. Eager Cells is the low-worker production kernel. The one-worker row uses the worker pool.

| Workers | Reference | Wall ratio [95% CI] | Median peak RSS ratio |
| ---: | --- | ---: | ---: |
| 1 | master LazyCells | 0.8772 [0.8681, 0.8863] | 0.9982 |
| 1 | master eager Cells | 1.1593 [1.1431, 1.1757] | 1.0077 |
| 1 | master opend | 0.8873 [0.8726, 0.9022] | 1.0302 |
| 1 | frozen predecessor | 0.9184 [0.9100, 0.9269] | 0.9996 |
| 2 | master LazyCells | 0.8893 [0.8828, 0.8958] | 0.9894 |
| 2 | master eager Cells | 1.1413 [1.1303, 1.1524] | 0.9862 |
| 2 | master opend | 0.9135 [0.9069, 0.9202] | 1.0462 |
| 2 | frozen predecessor | 0.9215 [0.9152, 0.9279] | 1.0006 |
| 4 | master LazyCells | 0.9366 [0.9327, 0.9406] | 0.9281 |
| 4 | master eager Cells | 1.0939 [1.0887, 1.0991] | 0.9874 |
| 4 | master opend | 1.0093 [1.0055, 1.0130] | 1.0743 |
| 4 | frozen predecessor | 0.9317 [0.9283, 0.9350] | 0.9994 |
