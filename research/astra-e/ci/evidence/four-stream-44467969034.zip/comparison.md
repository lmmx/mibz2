### Astra E paired research benchmark

20 paired rounds on Wikidata ×4, with 4W slots and a 2 s settle. Ratios compare the PR candidate with each reference kernel in the same worker configuration. Eager Cells is the low-worker production kernel. The one-worker row uses the worker pool.

| Workers | Reference | Wall ratio [95% CI] | Median peak RSS ratio |
| ---: | --- | ---: | ---: |
| 1 | master LazyCells | 0.9439 [0.9304, 0.9575] | 0.9126 |
| 1 | master eager Cells | 1.2456 [1.2212, 1.2704] | 0.9211 |
| 1 | master opend | 0.9925 [0.9800, 1.0052] | 0.9418 |
| 1 | frozen predecessor | 1.0277 [1.0171, 1.0384] | 1.0009 |
| 2 | master LazyCells | 0.9375 [0.9305, 0.9446] | 0.8369 |
| 2 | master eager Cells | 1.2081 [1.1918, 1.2246] | 0.8408 |
| 2 | master opend | 0.9813 [0.9691, 0.9937] | 0.8793 |
| 2 | frozen predecessor | 1.0154 [1.0049, 1.0259] | 1.0005 |
| 4 | master LazyCells | 0.9172 [0.9091, 0.9253] | 0.7061 |
| 4 | master eager Cells | 1.0895 [1.0762, 1.1029] | 0.7540 |
| 4 | master opend | 1.0065 [0.9978, 1.0152] | 0.8218 |
| 4 | frozen predecessor | 1.0368 [1.0263, 1.0475] | 1.0035 |
