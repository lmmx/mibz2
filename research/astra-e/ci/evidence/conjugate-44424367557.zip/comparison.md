### Astra E paired research benchmark

12 paired rounds on Wikidata ×4, with 4W slots and a 2 s settle. Ratios compare the PR candidate with the base kernel in the same worker configuration. Eager Cells is the low-worker production kernel. The one-worker row uses the worker pool.

| Workers | Reference | Wall ratio [95% CI] | Median peak RSS ratio |
| ---: | --- | ---: | ---: |
| 1 | master LazyCells | 0.9511 [0.9347, 0.9679] | 0.9562 |
| 1 | master eager Cells | 1.3368 [1.3084, 1.3658] | 0.9652 |
| 2 | master LazyCells | 0.9508 [0.9272, 0.9750] | 0.9387 |
| 2 | master eager Cells | 1.2891 [1.2698, 1.3086] | 0.9189 |
| 4 | master LazyCells | 0.8931 [0.8907, 0.8955] | 0.8494 |
| 4 | master eager Cells | 1.1068 [1.1022, 1.1115] | 0.9022 |
