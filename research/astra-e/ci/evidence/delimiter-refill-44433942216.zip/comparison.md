### Astra E paired research benchmark

20 paired rounds on Wikidata ×4, with 4W slots and a 2 s settle. Ratios compare the PR candidate with each reference kernel in the same worker configuration. Eager Cells is the low-worker production kernel. The one-worker row uses the worker pool.

| Workers | Reference | Wall ratio [95% CI] | Median peak RSS ratio |
| ---: | --- | ---: | ---: |
| 1 | master LazyCells | 1.0252 [1.0116, 1.0390] | 0.9992 |
| 1 | master eager Cells | 1.3121 [1.2855, 1.3392] | 1.0093 |
| 1 | master opend | 1.0511 [1.0338, 1.0687] | 1.0319 |
| 1 | frozen predecessor | 0.9561 [0.9437, 0.9687] | 1.0021 |
| 2 | master LazyCells | 1.0153 [1.0003, 1.0306] | 0.9949 |
| 2 | master eager Cells | 1.2562 [1.2371, 1.2757] | 1.0068 |
| 2 | master opend | 1.0488 [1.0321, 1.0658] | 1.0439 |
| 2 | frozen predecessor | 0.9586 [0.9477, 0.9696] | 1.0029 |
| 4 | master LazyCells | 1.0196 [1.0021, 1.0374] | 0.9461 |
| 4 | master eager Cells | 1.1644 [1.1419, 1.1874] | 0.9945 |
| 4 | master opend | 1.1256 [1.1032, 1.1486] | 1.0677 |
| 4 | frozen predecessor | 0.9784 [0.9594, 0.9977] | 1.0025 |
