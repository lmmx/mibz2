### Astra E paired research benchmark

20 paired rounds on Wikidata ×4, with 4W slots and a 2 s settle. Ratios compare the PR candidate with each reference kernel in the same worker configuration. Eager Cells is the low-worker production kernel. The one-worker row uses the worker pool.

| Workers | Reference | Wall ratio [95% CI] | Median peak RSS ratio |
| ---: | --- | ---: | ---: |
| 1 | master LazyCells | 0.7213 [0.7111, 0.7315] | 0.9906 |
| 1 | master eager Cells | 1.0001 [0.9811, 1.0195] | 1.0006 |
| 1 | master opend | 0.7830 [0.7738, 0.7922] | 1.0227 |
| 1 | frozen predecessor | 0.7906 [0.7818, 0.7995] | 1.0869 |
| 2 | master LazyCells | 0.8171 [0.7956, 0.8392] | 0.9006 |
| 2 | master eager Cells | 1.0969 [1.0781, 1.1160] | 0.9048 |
| 2 | master opend | 0.8917 [0.8766, 0.9070] | 0.9524 |
| 2 | frozen predecessor | 0.9095 [0.8977, 0.9215] | 1.0789 |
| 4 | master LazyCells | 0.8351 [0.8018, 0.8698] | 0.7567 |
| 4 | master eager Cells | 1.0457 [1.0208, 1.0711] | 0.8094 |
| 4 | master opend | 0.9650 [0.9369, 0.9940] | 0.8770 |
| 4 | frozen predecessor | 0.9881 [0.9537, 1.0238] | 1.0701 |
