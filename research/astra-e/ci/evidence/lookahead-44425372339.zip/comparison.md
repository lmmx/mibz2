### Astra E paired research benchmark

16 paired rounds on Wikidata ×4, with 4W slots and a 2 s settle. Ratios compare the PR candidate with the base kernel in the same worker configuration. Eager Cells is the low-worker production kernel. The one-worker row uses the worker pool.

| Workers | Reference | Wall ratio [95% CI] | Median peak RSS ratio |
| ---: | --- | ---: | ---: |
| 1 | master LazyCells | 0.8896 [0.8816, 0.8976] | 0.9689 |
| 1 | master eager Cells | 1.2464 [1.2381, 1.2548] | 0.9787 |
| 1 | master opend | 0.9694 [0.9625, 0.9764] | 1.0003 |
| 2 | master LazyCells | 0.8959 [0.8845, 0.9075] | 0.9314 |
| 2 | master eager Cells | 1.1947 [1.1742, 1.2156] | 0.9471 |
| 2 | master opend | 0.9690 [0.9585, 0.9795] | 0.9989 |
| 4 | master LazyCells | 0.8475 [0.8124, 0.8842] | 0.8682 |
| 4 | master eager Cells | 1.0550 [1.0208, 1.0904] | 0.9088 |
| 4 | master opend | 0.9869 [0.9546, 1.0202] | 0.9841 |
