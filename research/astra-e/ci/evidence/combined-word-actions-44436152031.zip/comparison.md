### Astra E paired research benchmark

20 paired rounds on Wikidata ×4, with 4W slots and a 2 s settle. Ratios compare the PR candidate with each reference kernel in the same worker configuration. Eager Cells is the low-worker production kernel. The one-worker row uses the worker pool.

| Workers | Reference | Wall ratio [95% CI] | Median peak RSS ratio |
| ---: | --- | ---: | ---: |
| 1 | master LazyCells | 0.9161 [0.8992, 0.9334] | 0.9753 |
| 1 | master eager Cells | 1.2183 [1.1915, 1.2458] | 0.9847 |
| 1 | master opend | 0.9666 [0.9445, 0.9891] | 1.0060 |
| 1 | frozen predecessor | 1.0046 [0.9918, 1.0176] | 1.0058 |
| 2 | master LazyCells | 0.9236 [0.9148, 0.9325] | 0.9542 |
| 2 | master eager Cells | 1.1898 [1.1730, 1.2068] | 0.9489 |
| 2 | master opend | 0.9839 [0.9698, 0.9983] | 1.0033 |
| 2 | frozen predecessor | 1.0136 [1.0052, 1.0220] | 1.0083 |
| 4 | master LazyCells | 0.8686 [0.8605, 0.8767] | 0.8750 |
| 4 | master eager Cells | 1.0273 [1.0182, 1.0365] | 0.9066 |
| 4 | master opend | 0.9884 [0.9813, 0.9955] | 0.9973 |
| 4 | frozen predecessor | 1.0142 [1.0063, 1.0221] | 1.0049 |
