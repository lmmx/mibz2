INDEPENDENT GUARDIAN AUDIT — 4 November 2026

Read report.html in a browser; it is a self-contained static research report.
report.txt is a plain-text rendering of the same report.

This bundle preserves read-only evidence and scratch-based analytical work.
It contains NO new Rust constructor, compiled candidate, benchmark, or new timing.
The original capture remains INVALID. The 225,253,100-instruction result is a
conditional compilation target; 10–15% completion headroom is not established.

Reproduce with Python 3.12+ (standard library only):
  python3 run_all.py

The runner verifies the original archive hash, verifies all 69 archive MANIFEST
file hashes and 12 fetched Git blob hashes, reconstructs static/census budgets,
runs mathematical models/counterexamples, and reconstructs existing timing
statistics and explicit conditional models. The full economics sweep may take
about a minute. Outputs and logs are under the component directories and results/.
No repository, compiler, constructor, registered analyzer, benchmark or network
is invoked. The only writes are analytical outputs within this bundle.

Principal files:
  report.html / report.txt             Full report, sections A–L
  inputs/                             Three original supplied attachments
  evidence/                           Frozen files and extracted capture
  evidence/source_blob_hashes.json     GitHub-reported source blob hashes
  results/provenance.json              Independently verified hashes
  baseline/                           Structural census, path ledger, E floor
  epoch/                              State proof, epoch models, counterexamples
  scanner/                            Scanner model and cross-component review
  descriptor/                         Four scalar loops and added-work sensitivity
  descriptor/secondary/               Entire secondary portfolio, overlap example
  economics/                          Raw reconstruction and time-per-event models
  scripts/reconstruct_portfolio.py     Original/revised cumulative target formulas
  results/portfolio.json / .csv        Independently reconstructed budgets
  results/source_locations.csv         Concise material evidence index

Individual scripts accept explicit paths; see each script header and component
notes. Most defaults resolve relative to this bundle; run descriptor scripts
from the bundle root or pass --evidence and --out explicitly.

Economics example (the coefficients are ASSUMPTIONS, not estimated latencies):
  python3 economics/conditional_completion.py inputs/c30-construction-v2-20261103T222928Z.tar.gz --no-break-even --saving fast_full_lower=4 --saving full_tiles=0.5 --saving rows_scalar=0.1 --output results/explicit-sensitivity.json

Interpretation safeguards:
- Structural counts weight frozen false-build paths; they are not measured
  retired instructions. Mathematical checks do not verify compiler output.
- The original caps are 40 instructions per fast body, 10 added per slow finish,
  20,000 epoch/setup, 1,000,000 scanner overhead, and 5,000,000 descriptor overhead.
  All must hold jointly, with caller costs charged and no overlap.
- Correctness proof and release-mode initialization/bounds/provenance are required;
  debug assertions or successful finite checks are not substitutes.
- Completion models assume effective nanoseconds saved per event; they do not
  convert instruction counts to time, update confidence intervals, or change
  registered validity. Starts are held fixed and step maxima are recomputed.

Evidence locations and revisions are listed in report.html. Original files are
unaltered snapshots. The archive's existing data includes its original dry-run
evidence; no new performance experiment was performed in this audit.
