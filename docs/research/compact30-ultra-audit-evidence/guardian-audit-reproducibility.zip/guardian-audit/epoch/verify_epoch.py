#!/usr/bin/env python3
"""Static and finite-model checks; never runs or builds the constructor.
Run from any cwd: python verify_epoch.py --evidence ../evidence --out results.json
"""
import argparse, collections, itertools, json, re
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--evidence',type=Path,default=Path(__file__).resolve().parents[1]/'evidence');p.add_argument('--out',type=Path,default=Path(__file__).with_name('results.json'));a=p.parse_args()
def phi(i): return 32*(i//30)+i%30
MAX_N=30*((2**20-1)//32);EPOCH=61440
assert MAX_N==983010 and (MAX_N+EPOCH-1)//EPOCH==16
assert all(phi(i)<2**20 for i in (0,MAX_N-1))
# Exhaustive local label domain; monotonicity proves all pairwise spans.
labels=[phi(i) for i in range(EPOCH)]
assert labels[0]==0 and labels[-1]==65533
assert all(x<y for x,y in zip(labels,labels[1:]))
# Exhaust all legal epochs and labels for header identity; c bits are disjoint,
# and testing c=255 sets all eight low bits.
for e in range(16):
    tag=0x80000000 | e<<24
    assert tag!=0xffffffff
    for u in labels:
        assert (tag & 0x7fffffff) | (u<<8) | 255 == ((65536*e+u)<<8)|255
# At most one RAW block per group, all legal provisional indices high-bit clear.
assert (MAX_N+29)//30==32767
assert all(idx & 0x80000000==0 for idx in range(32767))
# Source order implies nondecreasing epochs. Exhaust all epoch multisets (0..3)
# for each portion length 1..30, and each legal finish epoch >= its final epoch.
# Snapshots A_q count character occurrences strictly before epoch q.
cases=0
for k in range(1,31):
    for e in itertools.combinations_with_replacement(range(4),k):
        for current in range(e[-1],4):
            before=sum(x<current for x in e)
            tagged=(e[0]==current)
            snapshot=(before<=0) # subtract absolute portion r0 from A_current
            assert tagged==snapshot
            assert not tagged or all(x==current for x in e)
            cases+=1
# Greatest-snapshot <=rank handles repeated equal snapshots.
snaps=[0,1,1,1]
assert max(i for i,x in enumerate(snaps) if x<=1)==3
# Counterexamples to tempting incorrect implementations.
examples={
 'unchanged_NO_RAW_dispatch': {'n':1,'char':0,'tag':hex(0x80000000),'fields':1,'fast_full':False,'old_ordinary_predicate':False,'incorrect_raw_index':2**31},
 'advanced_y_at_exact_epoch_eof': {'n':EPOCH,'active_epoch':0,'phi_n_epoch':phi(EPOCH)>>16,'last_source_epoch':(EPOCH-1)//EPOCH},
 'ordinary_exact_boundary': {'first':3,'last':EPOCH,'span':phi(EPOCH)-phi(3)},
 'wide_exact_boundary': {'first':2,'last':EPOCH,'span':phi(EPOCH)-phi(2)},
 'far_wide_looks_small_modularly': {'first':0,'last':2*EPOCH,'span':phi(2*EPOCH),'u16_difference':phi(2*EPOCH)%65536},
 'deferred_previous_epoch_full': {'first_epoch':0,'last_epoch':0,'finish_epoch':1,'fast':False},
 'repeated_snapshots': {'A':snaps,'rank':1,'epoch':3}
}
assert examples['ordinary_exact_boundary']['span']==65533
assert examples['wide_exact_boundary']['span']==65534
asm=a.evidence/'cd14fa9/ctor2-finish-false.asm'
ins={int(m[1],16):m[2] for l in asm.read_text().splitlines() if (m:=re.match(r'\s*([0-9a-f]+):\s+(.+)',l))}
ranges=[(0x61d30,0x61d93),(0x61e08,0x61e17),(0x61f1b,0x61fb8),(0x6231b,0x62329)]
parts=[{'first':hex(lo),'last':hex(hi),'instructions':sum(lo<=ip<=hi for ip in ins)} for lo,hi in ranges]
assert [x['instructions'] for x in parts]==[29,5,39,8]
current=sum(x['instructions'] for x in parts);assert current==81
census=[json.loads(l) for l in (a.evidence/'cd14fa9/corpora.jsonl').read_text().splitlines()]
c=[r for r in census if r['input']=='wikidata-20261026.bz2' and r['permille']==0 and not r['extra_starts']]
assert len(c)==1;c=c[0]
P=sum(c[k] for k in ['fin_fast','fin_ordinary','fin_wide','fin_crossing','fin_forced'])
F=c['fin_fast']-c['norm_partial'];Fmax_original=c['fin_fast'];O=c['fin_fast']+c['fin_ordinary']+c['fin_wide']
# Per-block constraints sharpen the upper bound: each block can have at most
# min(fin_fast, norm_full) full fast normalizations. Retain original bound too.
capture=a.evidence/'capture/c30-construction-v2-20261103T222928Z/c30-construction.jsonl'
with capture.open() as f:
    blocks=[r for line in f if (r:=json.loads(line)).get('kind')=='counters']
assert len(blocks)==434
for key in ['fin_fast','fin_ordinary','fin_wide','norm_partial','norm_full']:
    assert sum(r[key] for r in blocks)==c[key]
Fmin_block=sum(max(0,r['fin_fast']-r['norm_partial']) for r in blocks)
Fmax=sum(min(r['fin_fast'],r['norm_full']) for r in blocks)
assert Fmin_block==F and Fmax==1647407 and Fmax_original-Fmax==9
partial_fast_witness_blocks=[r['block'] for r in blocks if r['fin_fast']>r['norm_full']]
# b is replacement body cost with same calling convention. Old/new entry calls
# cancel. All introduced caller work must instead be charged explicitly.
budgets=[]
for b in [35,40,45,50,60,81]:
 for extra_open in [0,1,2]:
  value=(81-b)*F-10*(P-F)-20000-extra_open*O
  budgets.append({'body_max':b,'extra_instr_per_ordinary_open':extra_open,'slow_extra_max':10,'setup_max':20000,'conditional_net_instructions':value})
result={'purpose':'static/model verification only; not candidate assembly or a performance experiment','max_n':MAX_N,'max_raw_groups':32767,'max_epochs':16,'model_cases':cases,'exact_epoch_domain':[labels[0],labels[-1]],'counterexamples':examples,'baseline_ranges':parts,'body_instructions':current,'with_entry_call':current+1,'fast_full_count_range_original_aggregate':[F,Fmax_original],'fast_full_count_range_revised_per_block':[Fmin_block,Fmax],'fast_full_count_range':[Fmin_block,Fmax],'at_least_partial_fast':Fmax_original-Fmax,'partial_fast_witness_blocks':partial_fast_witness_blocks,'all_portions':P,'ordinary_openings':O,'opening_reads_added_if_one_load_each':O,'conditional_budgets':budgets,'ultra_reconstructed_net':(81-40)*F-10*(P-F)-20000,'compiler_established_saving':None,'fast_success_existing_explicit_reads':17,'fast_success_existing_explicit_writes':8,'fast_success_existing_pushes':6,'fast_success_existing_pops':6}
a.out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
