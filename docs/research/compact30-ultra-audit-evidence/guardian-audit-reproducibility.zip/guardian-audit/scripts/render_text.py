#!/usr/bin/env python3
"""Render the self-contained report to plain text, with no external packages."""
from pathlib import Path
from html.parser import HTMLParser
class ReportText(HTMLParser):
    def __init__(self):
        super().__init__();self.out=[];self.skip=False
    def handle_starttag(self,tag,attrs):
        if tag in ('style','script'):self.skip=True
        if tag in ('h1','h2','h3','p','tr','li','pre'):self.out.append('\n')
    def handle_endtag(self,tag):
        if tag in ('style','script'):self.skip=False
        if tag in ('h1','h2','h3','p','tr','li','pre'):self.out.append('\n')
        if tag in ('td','th'):self.out.append(' | ')
    def handle_data(self,data):
        if not self.skip:self.out.append(data)
root=Path(__file__).resolve().parents[1]
p=ReportText();p.feed((root/'report.html').read_text())
(root/'report.txt').write_text(''.join(p.out))
