#!/usr/bin/env python3
"""Reconstruct conditional instruction budgets, not codegen or performance."""
import argparse,csv,json
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
a=p.parse_args(); root=a.root
records=[json.loads(x) for x in (root/'evidence/capture/c30-construction-v2-20261103T222928Z/c30-construction.jsonl').read_text().splitlines()]
counts=[x for x in records if x['kind']=='counters']
sumc=lambda key:sum(x[key] for x in counts)
N=sumc('rows_scalar');T=sum(x['rows']//16 for x in counts);S=T-sumc('run_rows')//16
F=sum(max(0,x['fin_fast']-x['norm_partial']) for x in counts)
Fhi=sum(min(x['fin_fast'],x['norm_full']) for x in counts)
P=sum(sumc(k) for k in ('fin_fast','fin_ordinary','fin_wide','fin_crossing','fin_forced'))
O=sum(sumc(k) for k in ('fin_fast','fin_ordinary','fin_wide'))
Qhi=sum(min(x['runs'],x['epochs']) for x in counts)

def portfolio(body=40,scalar=10,extra_open=0,fold=True,fast=F,Q=0):
    epoch=(81-body)*fast-10*(P-fast)-20000-extra_open*O
    scanner=5*T+10*S+3*Q-1000000-(0 if fold else T)
    descriptor=(12-scalar)*N-5000000
    return dict(epoch=epoch,scanner=scanner,descriptor=descriptor,total=epoch+scanner+descriptor)

original=portfolio()
rows=[]
for label,kwargs in [
 ('Original caps, revised count lower bound',{}),
 ('Original caps, revised count upper bound',{'fast':Fhi,'Q':Qhi}),
 ('One added instruction per ordinary opening',{'extra_open':1}),
 ('45-instruction fast body and one added opening instruction',{'body':45,'extra_open':1}),
 ('Scanner +8 address folding fails',{'fold':False}),
 ('11-instruction scalar alternative',{'scalar':11}),
 ('50-instruction fast body, two opening instructions, 11-instruction scalar',{'body':50,'extra_open':2,'scalar':11}),
]: rows.append(dict(scenario=label,**portfolio(**kwargs)))
out={'status':'All numeric savings are conditional compilation targets or sensitivity scenarios; achieved emitted-code savings are unestablished.',
 'counts':dict(N=N,T=T,S=S,F_lower=F,F_upper=Fhi,P=P,O=O,Q_upper=Qhi),
 'original_report_rounded_M':dict(epoch=66.041,scanner=87.622,descriptor=71.590,total=225.253),
 'original_caps_reconstructed_exact':original,
 'formula':'(81-body)*F - slow_extra*(P-F) - extra_open*O - epoch_setup + (5*T+10*S+3*Q)-scanner_overhead + (12-scalar)*N-descriptor_overhead',
 'fixed_acceptance_caps':dict(slow_extra=10,epoch_setup=20000,scanner_overhead=1000000,descriptor_overhead=5000000),
 'scenarios':rows,
 'hypothetical_whole_instruction_totals':[{'total':I,'fraction_saved_if_original_caps_pass':original['total']/I} for I in [1200000000,1350000000,1500000000]],
 'completion_amdahl_sensitivities':[{'affected_component_speed_fraction':r,'required_nonoverlapped_fraction_for_10_2847618_percent':0.10284761764047023/r,'required_fraction_for_15_percent':0.15/r} for r in [.2,.3,.4,.5]]}
(root/'results/portfolio.json').write_text(json.dumps(out,indent=2)+'\n')
with (root/'results/portfolio.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print(json.dumps(out,indent=2))
