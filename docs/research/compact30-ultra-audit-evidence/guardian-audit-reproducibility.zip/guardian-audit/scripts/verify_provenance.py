#!/usr/bin/env python3
"""Verify frozen evidence without executing any project code."""
import argparse, hashlib, json, re
from pathlib import Path

def git_blob(data):
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()

def instructions(path):
    out=[]
    for line in path.read_text().splitlines():
        match=re.match(r'\s*[a-f0-9]+:\s+(.+)',line)
        if match:
            asm=match[1].split('#')[0].strip()
            asm=re.sub(r'\b[a-f0-9]+ (<.+>)',r'\1',asm)
            asm=re.sub(r'-?0x[a-f0-9]+\(%rip\)','RELOC(%rip)',asm)
            out.append(asm)
    return out

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--evidence',type=Path,default=Path(__file__).resolve().parents[1]/'evidence')
    p.add_argument('--output',type=Path)
    args=p.parse_args(); root=args.evidence
    expected=json.loads((root/'source_blob_hashes.json').read_text())
    sources=[]
    for rel,sha in expected.items():
        data=(root/rel).read_bytes()
        assert git_blob(data)==sha,rel
        sources.append({'path':rel,'git_blob_sha1':sha,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
    cap=root/'capture/c30-construction-v2-20261103T222928Z'
    manifest=json.loads((cap/'MANIFEST.json').read_text())
    for entry in manifest['files']:
        data=(cap/entry['path']).read_bytes()
        assert len(data)==entry['bytes'],entry['path']
        assert hashlib.sha256(data).hexdigest()==entry['sha256'],entry['path']
    normalized={}
    for name in ['build','finish','refill']:
        a=instructions(root/f'cd14fa9/ctor2-{name}-false.asm')
        b=instructions(cap/f'listing/ctor2-{name}-false.asm')
        assert a==b,name
        normalized[name]={'instruction_count':len(a),'prototype_capture_equal_after_relocation_normalization':True}
    out={'sources':sources,'verified_manifest_files':len(manifest['files']),'normalized_constructor_listings':normalized,
         'normalization_limit':'Addresses before symbolic targets and RIP-relative relocations are stripped. This is static listing comparison, not binary regeneration.'}
    text=json.dumps(out,indent=2)+'\n'
    if args.output: args.output.write_text(text)
    else: print(text,end='')

if __name__=='__main__': main()
