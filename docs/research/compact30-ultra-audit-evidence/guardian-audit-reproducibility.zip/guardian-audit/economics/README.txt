Independent economic and critical-worker reconstruction

Run with Python 3 (standard library only):
  python conditional_completion.py /path/to/c30-construction-v2-20261103T222928Z.tar.gz --output results.json

An extracted top-level c30-construction.jsonl is also accepted. No compiler,
constructor, benchmark, registered analyzer, or repository mutation is invoked.
The program typically takes about one minute for its complete sensitivity sweep.

To evaluate an explicit compatible combination without the default sweeps:
  python conditional_completion.py CAPTURE --no-break-even --saving fast_full_lower=4 --saving full_tiles=0.5 --saving rows_scalar=0.1 --output chosen-model.json

Every --saving coefficient is an ASSUMED effective on-CPU nanoseconds saved per
event. These example numbers are parameters, not measurements or predictions.
They must never be presented as established per-event latency or derived from
architectural-instruction counts.

Method

1. Read all raw records, select warm W4 rounds 0 through 19, retain round 5.
2. Reconstruct CPU sums and registered completion spans: for each synchronized
   step, latest build end minus earliest build start; sum over all steps.
3. Independently reconstruct geometric means and the archived log t intervals
   with 19 degrees of freedom. Intervals are emitted ONLY for archived data.
4. Reproduce G1 max/min checks with the unchanged 1.05 threshold.
5. Join raw per-block structural counters. FULL remains 899000. Full tiles are
   floor(rows/16), uniform tiles run_rows/16, nonuniform tiles their difference.
   Assert scalar rows = 16*nonuniform tiles + rows mod 16 for every block.
6. For exposure comparisons, the report's slowest worker means the longest
   individual wall duration. For completion modeling use maximum absolute end,
   preserving the registered earliest-start rule. These need not be the same.
7. Quartiles use sorted full blocks sliced [q*n//4:(q+1)*n//4], giving sizes
   57,58,57,58. Other quantile boundary conventions change the displayed shares.
8. Conservative eligible full fast finishes are max(0, fin_fast-norm_partial)
   per block; upper bounds min(fin_fast,norm_full). Exact partial-fast membership
   is not identified by the census. The main models use the lower bound.
9. Hypothetical per-block savings are the sum of event counts times explicitly
   assumed nanoseconds per event. Hold all recorded starts fixed; subtract these
   savings from candidate CPU and wall durations. Recompute the slowest end in
   every step. Report winner changes and any clipping at zero duration.
10. Solve break-even event coefficients by bisection to reach a specified
    geometric-mean reduction in candidate completion. This is an accounting
    sensitivity model; changed starts/scheduling/cache/frequency are not modeled.
11. Solve a Pareto slice for combinations: fast-full savings 0,2,4,6 ns; scanner
    savings 0 or 0.5 ns/full tile; solve the remaining scalar-row saving needed.
    The coarse grid was chosen to span the axes, not fitted to favorable results.
    All axes remain unmeasured, and distinct effects may interact in real code.

Evidence locations

- Top-level capture c30-construction.jsonl line 2: corpus metadata, assignment,
  230 full blocks, 434 total blocks, all block row counts.
- Same JSONL lines 437-870: 434 per-block structural counter records.
- Warm W4 measured records are selected by kind/regime/mode/round from lines
  6514-73349. Do not treat that entire span as warm W4: other regimes are mixed in.
- Production warm W4 round 5 is exactly lines 24308-24741.
- Example recurring critical blocks in round-0 candidate warm W4 records:
  line 7280 (step 6, worker 3, block 60); 6979 (step 31, worker 0, block 273);
  7198 (step 32, worker 2, block 280); 7217 (step 51, worker 2, block 284);
  7112 (step 55, worker 1, block 279). Models use all rounds, not these examples.
- Frozen 1dc2edf protocol: lines 256-262 define CPU, completion, and log-t
  estimator; line 306 defines G1; lines 330-343 preserve ceilings and INVALID.
- Frozen fa21f33 bench/c30_construction.py: lines 75-81 ceilings/FULL;
  96-104 log-t interval; 588-605 per-round measures; 878-894 v2 G1.

Economic interpretation

Exact upper-bound sensitivity is 1-ceiling/archived_upper_bound. It is not a
prospective confidence interval or performance prediction. The completion
requirement is materially stricter than CPU: approximately 10.285% versus 2.560%.

The proposed scalar and finish work is enriched on existing low-bulk critical
workers. That establishes relevance of location, not marginal elapsed-time cost.
Whole-tile work is almost equal across all large blocks; bulk work is greatest
on the high-bulk blocks that rarely determine synchronized completion.

Actual completion savings require removal of nonoverlapped latency or relief of
a limiting execution resource. Architectural instructions are not micro-ops,
cycles, or equal-cost units. Predicted checks may be fused or overlapped; address
formation may be overlapped across independent rows; metadata changes can add
loads/stores or register pressure elsewhere. CPU/wall ratios near one do not
rule out memory stalls, because stalled scheduled time still consumes CPU time.

Under a simplified affected-component model, a target reduction d requires
f*r >= d, where f is the affected share of completion and r its effective time
reduction. In particular f >= d even if that component vanished entirely.
The revised instruction percentage identifies neither f nor r.

No archived evidence identifies the effective nanoseconds removed by the future
safe Rust transformations. The possibility of 10-15% completion improvement is
therefore an experimentally unresolved hypothesis, not established headroom.
The script quantifies required effective savings without asserting attainability.
