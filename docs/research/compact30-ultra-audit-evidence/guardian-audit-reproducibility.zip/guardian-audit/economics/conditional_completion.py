#!/usr/bin/env python3
"""Read-only reconstruction of archived compact30 W4 timing and conditional models.

This program never runs a constructor, benchmark, compiler, or registered analyzer.
It reads only the supplied capture TAR (or an already extracted JSONL), reconstructs
archived descriptions, and models explicit assumed *nanoseconds* saved per event.
No mapping from instruction counts to time is made. Counterfactual outputs are not
measurements or prospective confidence intervals, and do not change INVALID status.

Usage:
 python conditional_completion.py CAPTURE.tar.gz --output results.json
 python conditional_completion.py CAPTURE.tar.gz --saving fin_fast=20 --saving rows_scalar=0.05

The default model holds every recorded build start fixed, subtracts the same
assumed on-CPU time from CPU and wall durations, and recomputes every step's max
end minus min start. End times cannot precede starts; CPU durations cannot become
negative. Clipping is reported. Such a model omits start/scheduling/cache/frequency
changes. It is a conditional accounting device, not a causal identification.
"""

import argparse
import collections
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics
import tarfile

FULL = 899_000
CPU_CEILING = 1.06714
COMPLETION_CEILING = 1.02
T19_975 = 2.093024054408263


def read_records(path):
    if tarfile.is_tarfile(path):
        with tarfile.open(path) as archive:
            # Exclude the nested dry-run capture without assuming the root dirname.
            matches = [m for m in archive.getmembers()
                       if m.name.endswith('/c30-construction.jsonl') and m.name.count('/') == 1]
            if len(matches) != 1:
                raise ValueError('Need exactly one top-level c30-construction.jsonl')
            data = archive.extractfile(matches[0]).read()
    else:
        data = Path(path).read_bytes()
    return [json.loads(line) for line in data.splitlines()], hashlib.sha256(data).hexdigest()


def log_stats(ratios):
    logs = [math.log(x) for x in ratios]
    mean = statistics.mean(logs)
    if len(logs) != 20:
        raise ValueError('Frozen reconstruction expects the registered twenty rounds')
    margin = T19_975 * statistics.stdev(logs) / math.sqrt(len(logs))
    return {'geometric_mean': math.exp(mean), 'archived_lower95': math.exp(mean-margin),
            'archived_upper95': math.exp(mean+margin)}


def event_counts(c):
    out = dict(c)
    out['full_tiles'] = c['rows'] // 16
    # run_rows contains exclusively 16-row uniform tiles; leftover scalar rows
    # are the less-than-16-row terminal tail in each block.
    if c['run_rows'] % 16:
        raise ValueError('Uniform run rows must be tile-aligned')
    out['uniform_tiles'] = c['run_rows'] // 16
    out['nonuniform_tiles'] = out['full_tiles'] - out['uniform_tiles']
    assert c['rows_scalar'] == 16*out['nonuniform_tiles'] + c['rows'] % 16
    out['bulk_share'] = c['rows_bulk'] / c['rows'] if c['rows'] else 0
    # Counters do not identify which fast ordinary finishes were partial. A leaf
    # restricted to full groups can only claim these conservative per-block bounds.
    out['fast_full_lower'] = max(0,c['fin_fast']-c['norm_partial'])
    out['fast_full_upper'] = min(c['fin_fast'],c['norm_full'])
    return out


def prepare(records):
    meta = next(r for r in records if r['kind'] == 'meta')
    counts = {r['block']: event_counts(r) for r in records if r['kind'] == 'counters'}
    builds = [r for r in records if r['kind'] == 'build' and r['round'] >= 0
              and r['mode'] == 'w4' and r['regime'] == 'warm']
    groups = collections.defaultdict(list)
    for r in builds:
        groups[r['round'], r['arm'], r['step']].append(r)
    assert len(builds) == 20*2*434
    assert len(counts) == 434
    assert sorted(set(r['round'] for r in builds)) == list(range(20))
    return meta, counts, builds, dict(groups)


def totals(groups, counts, savings=None):
    savings = savings or {}
    total = collections.defaultdict(lambda: {'cpu_ns': 0.0, 'completion_ns': 0.0})
    changed_winners = clipped_cpu = clipped_wall = 0
    candidate_steps = 0
    for (round_no, arm, step), rows in groups.items():
        starts = [r['start'] for r in rows]
        old_ends = [r['end'] for r in rows]
        ends = []
        for r in rows:
            delta = sum(counts[r['block']][name]*ns for name, ns in savings.items()) if arm == 'C' else 0
            wall = r['end']-r['start']
            cpu = r['cpu_end']-r['cpu_start']
            clipped_wall += delta > wall
            clipped_cpu += delta > cpu
            ends.append(r['start'] + max(0, wall-delta))
            total[round_no, arm]['cpu_ns'] += max(0, cpu-delta)
        total[round_no, arm]['completion_ns'] += max(ends)-min(starts)
        if arm == 'C':
            candidate_steps += 1
            old_winners = {rows[i]['worker'] for i,e in enumerate(old_ends) if e == max(old_ends)}
            new_winners = {rows[i]['worker'] for i,e in enumerate(ends) if e == max(ends)}
            changed_winners += old_winners != new_winners
    return dict(total), {'changed_end_winner_steps': changed_winners,
                         'candidate_steps': candidate_steps,
                         'clipped_cpu_builds': clipped_cpu,
                         'clipped_wall_builds': clipped_wall}


def ratio_stats(t):
    return {metric: log_stats([t[r,'C'][metric]/t[r,'P'][metric] for r in range(20)])
            for metric in ('cpu_ns', 'completion_ns')}


def describe_model(groups, counts, baseline, savings):
    modeled, diagnostics = totals(groups, counts, savings)
    out = {'label': 'CONDITIONAL MODEL; not measurement or prospective CI',
           'assumed_nanoseconds_saved_per_event': savings, **diagnostics}
    for metric in ('cpu_ns', 'completion_ns'):
        base_sum = sum(baseline[r,'C'][metric] for r in range(20))
        new_sum = sum(modeled[r,'C'][metric] for r in range(20))
        out[metric] = {
            'pooled_candidate_reduction': 1-new_sum/base_sum,
            'geomean_candidate_reduction': 1-math.exp(statistics.mean([
                math.log(modeled[r,'C'][metric]/baseline[r,'C'][metric]) for r in range(20)])),
            'conditional_geomean_C_over_P': math.exp(statistics.mean([
                math.log(modeled[r,'C'][metric]/modeled[r,'P'][metric]) for r in range(20)])),
            'mean_saved_ns_per_corpus_round': (base_sum-new_sum)/20,
        }
    return out


def solve_break_even(groups, counts, baseline, event, target_reduction, metric='completion_ns', fixed=None):
    # Solve on the geomean of modeled/original candidate round totals so that
    # the proportional-bound sensitivity factor is applied consistently.
    fixed = dict(fixed or {})
    if event in fixed:
        raise ValueError('The solved event must not already have a fixed coefficient')
    def reduction(ns):
        return describe_model(groups, counts, baseline, {**fixed,event: ns})[metric]['geomean_candidate_reduction']
    if reduction(0) >= target_reduction:
        out=describe_model(groups, counts, baseline, fixed)
        out.update({'solved_metric':metric,'target_candidate_reduction':target_reduction,
                    'break_even_ns_per_event':0,'fixed_coefficients_already_meet_target':True})
        return out
    lo, hi = 0.0, 1.0
    while reduction(hi) < target_reduction and hi < 1e9:
        hi *= 2
    if reduction(hi) < target_reduction:
        return {'event': event, 'target': target_reduction, 'unreachable': True}
    for _ in range(52):
        mid = (lo+hi)/2
        if reduction(mid) < target_reduction:
            lo = mid
        else:
            hi = mid
    out = describe_model(groups, counts, baseline, {**fixed,event: hi})
    out.update({'solved_metric': metric, 'target_candidate_reduction': target_reduction,
                'break_even_ns_per_event': hi})
    return out


def structural_exposure(meta, counts, builds, groups):
    full = [i for i,c in counts.items() if c['rows'] >= FULL]
    ranked = sorted(full, key=lambda i: (counts[i]['bulk_share'], i))
    # Match the report's explicit sorted-array slices [q*n//4:(q+1)*n//4]:
    # 57,58,57,58 blocks with n=230. Boundary convention matters on this corpus.
    quartile = {block: q for q in range(4)
                for block in ranked[q*len(ranked)//4:(q+1)*len(ranked)//4]}
    cpu = collections.defaultdict(list)
    for r in builds:
        cpu[r['arm'],r['block']].append(r['cpu_end']-r['cpu_start'])
    ratios = {i:statistics.median(cpu['C',i])/statistics.median(cpu['P',i]) for i in full}
    bulk = [counts[i]['bulk_share'] for i in full]
    ratio_values = [ratios[i] for i in full]
    cov = sum((x-statistics.mean(bulk))*(y-statistics.mean(ratio_values)) for x,y in zip(bulk,ratio_values))
    corr = cov/math.sqrt(sum((x-statistics.mean(bulk))**2 for x in bulk)*sum((y-statistics.mean(ratio_values))**2 for y in ratio_values))
    assigned = []
    winners = []
    winner_ids = []
    match = collections.Counter()
    penalties = collections.defaultdict(dict)
    classes = collections.defaultdict(lambda: {'P_ns':0,'C_ns':0,'steps':0})
    imbalance = collections.defaultdict(lambda:{'max_wall':0,'mean_wall':0,'unweighted':[]})
    for (rnd,arm,step),rs in groups.items():
        wall = [r['end']-r['start'] for r in rs]
        dur = max(r['end'] for r in rs)-min(r['start'] for r in rs)
        klass = 'all_full' if all(r['rows'] >= FULL for r in rs) else ('tiny_only' if all(r['rows'] < FULL for r in rs) else 'mixed')
        classes[klass][arm+'_ns'] += dur
        classes[klass]['steps'] += (arm == 'C')
        imbalance[arm]['max_wall'] += max(wall)
        imbalance[arm]['mean_wall'] += statistics.mean(wall)
        imbalance[arm]['unweighted'].append(max(wall)/statistics.mean(wall))
        penalties[step].setdefault(arm,[]).append(dur)
        if arm != 'C' or klass != 'all_full':
            continue
        # Reproduce the report's slowest-worker wall-duration criterion, while
        # the counterfactual model independently uses the registered end/start criterion.
        win = max(rs, key=lambda r:r['end']-r['start'])
        cs = [counts[r['block']] for r in rs]
        wc = counts[win['block']]
        assigned.extend(cs)
        winners.append(wc)
        winner_ids.append(win['block'])
        match['lowest_bulk'] += wc['bulk_share'] == min(c['bulk_share'] for c in cs)
        match['most_scalar'] += wc['rows_scalar'] == max(c['rows_scalar'] for c in cs)
        match['most_normalizations'] += wc['norm_full'] == max(c['norm_full'] for c in cs)
    qtable=[]
    for q in range(4):
        ids=[i for i in full if quartile[i]==q]
        qtable.append({'quartile':q+1,'blocks':len(ids), 'mean_bulk_share':statistics.mean(counts[i]['bulk_share'] for i in ids),
                       'mean_median_cpu_ratio':statistics.mean(ratios[i] for i in ids),
                       'assignment_share':sum(quartile[c['block']]==q for c in assigned)/len(assigned),
                       'winner_share':sum(quartile[i]==q for i in winner_ids)/len(winner_ids),
                       'mean_structural_exposure':{key:statistics.mean(counts[i][key] for i in ids)
                                                  for key in ('fin_fast','fast_full_lower','fast_full_upper','rows_scalar','full_tiles','nonuniform_tiles','rows_bulk','norm_full')}})
    for klass,d in classes.items():
        d['steps_per_round'] = d.pop('steps')/20
        d['P_mean_ns'] = d.pop('P_ns')/20
        d['C_mean_ns'] = d.pop('C_ns')/20
        d['C_over_P'] = d['C_mean_ns']/d['P_mean_ns']
    worst=sorted(({'step':s,'median_C_minus_P_ns':statistics.median(d['C'])-statistics.median(d['P'])}
                  for s,d in penalties.items()),key=lambda d:d['median_C_minus_P_ns'],reverse=True)[:10]
    return {'full_blocks':len(full), 'full_threshold':FULL,'all_full_candidate_steps':len(winners),
            'correlation_bulk_share_median_cpu_ratio':corr,'quartiles':qtable,
            'winner_match_fraction':{k:v/len(winners) for k,v in match.items()},
            'mean_exposures':{k:{'assigned':statistics.mean(c[k] for c in assigned),'winner':statistics.mean(c[k] for c in winners)}
                              for k in ('rows_scalar','rows_fragment','norm_full','fin_fast','fast_full_lower','fast_full_upper','full_tiles','nonuniform_tiles','runs','rows_bulk')},
            'step_classes':dict(classes),'largest_recurring_penalties':worst,
            'imbalance':{arm:{'weighted':d['max_wall']/d['mean_wall'],'unweighted':statistics.mean(d['unweighted'])} for arm,d in imbalance.items()}}


def stability_and_cpu_wall(baseline, builds):
    out = {'G1_unchanged_ceiling': 1.05, 'production_warm_w4': {}}
    for metric in ('cpu_ns', 'completion_ns'):
        values = {r: baseline[r,'P'][metric] for r in range(20)}
        max_round = max(values,key=values.get)
        min_round = min(values,key=values.get)
        ratio = values[max_round]/values[min_round]
        out['production_warm_w4'][metric] = {
            'max_over_min':ratio, 'passes_G1':ratio<=1.05,
            'max_round':max_round, 'min_round':min_round,
            'maximum_ns':values[max_round], 'minimum_ns':values[min_round],
            'round_5_ns':values[5],
            'other_rounds_min_ns':min(v for r,v in values.items() if r!=5),
            'other_rounds_max_ns':max(v for r,v in values.items() if r!=5)}
    out['all_rounds_retained'] = True
    out['cpu_over_worker_wall'] = {
        arm:sum(r['cpu_end']-r['cpu_start'] for r in builds if r['arm']==arm)/
            sum(r['end']-r['start'] for r in builds if r['arm']==arm)
        for arm in ('P','C')}
    return out


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('capture',type=Path)
    parser.add_argument('--output',type=Path)
    parser.add_argument('--saving',action='append',default=[],help='event_name=assumed_ns_saved_per_event')
    parser.add_argument('--no-break-even',action='store_true',help='Skip default break-even/frontier sweeps')
    args=parser.parse_args()
    records,sha=read_records(args.capture)
    meta,counts,builds,groups=prepare(records)
    baseline,_=totals(groups,counts)
    stats=ratio_stats(baseline)
    sensitivity={
        'CPU':1-CPU_CEILING/stats['cpu_ns']['archived_upper95'],
        'completion':1-COMPLETION_CEILING/stats['completion_ns']['archived_upper95'],
    }
    out={'status':'Archived capture remains INVALID; models are sensitivity calculations only',
         'jsonl_sha256':sha,'rounds':20,'baseline':stats,'ceilings':{'CPU':CPU_CEILING,'completion':COMPLETION_CEILING},
         'fast_finish_event_bounds':{key:sum(c[key] for c in counts.values()) for key in ('fin_fast','fast_full_lower','fast_full_upper','norm_partial')},
         'proportional_archived_upper_bound_sensitivities':sensitivity,
         'structural_exposure':structural_exposure(meta,counts,builds,groups),
         'stability_and_cpu_wall':stability_and_cpu_wall(baseline,builds)}
    out['break_even_models']=[]
    if not args.no_break_even:
        for event in ('fast_full_lower','nonuniform_tiles','full_tiles','rows_scalar','norm_full'):
            for target in (0.10,sensitivity['completion'],0.15):
                out['break_even_models'].append(solve_break_even(groups,counts,baseline,event,target))
    # This independently provides the CPU sensitivity break-even per mechanism.
    out['cpu_break_even_models']=[] if args.no_break_even else [
        solve_break_even(groups,counts,baseline,event,sensitivity['CPU'],'cpu_ns')
        for event in ('fast_full_lower','nonuniform_tiles','full_tiles','rows_scalar')]
    out['compatible_combination_frontier']=[]
    if not args.no_break_even:
        # This coarse parameter grid is a Pareto/sensitivity slice, not a claim
        # that any chosen nanosecond value is physically attainable. The scanner
        # parameter assumes a uniform effective saving on each full source tile;
        # this does NOT assume proportionality to its instruction-site count.
        for scanner_ns_per_full_tile in (0.0,0.5):
            for finish_ns in (0.0,2.0,4.0,6.0):
                fixed={'fast_full_lower':finish_ns,'full_tiles':scanner_ns_per_full_tile}
                out['compatible_combination_frontier'].append(
                    solve_break_even(groups,counts,baseline,'rows_scalar',sensitivity['completion'],fixed=fixed))
    if args.saving:
        savings={name:float(ns) for name,ns in (s.split('=',1) for s in args.saving)}
        if any(ns<0 for ns in savings.values()):
            raise ValueError('Savings must be nonnegative')
        out['specified_combination_model']=describe_model(groups,counts,baseline,savings)
    text=json.dumps(out,indent=2,sort_keys=True)+'\n'
    if args.output:
        args.output.write_text(text)
    else:
        print(text,end='')


if __name__ == '__main__':
    main()
