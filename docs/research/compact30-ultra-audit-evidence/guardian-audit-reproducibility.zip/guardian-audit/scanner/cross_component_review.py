#!/usr/bin/env python3
"""Recheck shared static-audit results and credited-address disjointness."""
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
def read(path):
    return json.loads((ROOT/path).read_text())
epoch = read('epoch/results.json')
descriptor = read('descriptor/descriptor_results.json')
scanner = read('scanner/scanner-results.json')
baseline = read('baseline/baseline_results.json')
paths = read('baseline/instruction_paths.json')
scanner_addresses = {r['address'] for group in scanner['instructions'].values() for r in group}
descriptor_addresses = {'0x33a05','0x33a09','0x34355','0x34359',
                        '0x343e4','0x343e8','0x344d5','0x344d9'}
finish_addresses = set(paths['fast_full_finish']['addresses'])
intersections = {
    'scanner_descriptor': sorted(scanner_addresses & descriptor_addresses),
    'scanner_finish': sorted(scanner_addresses & finish_addresses),
    'descriptor_finish': sorted(descriptor_addresses & finish_addresses),
}
assert not any(intersections.values())
epoch_target = epoch['ultra_reconstructed_net']
descriptor_target = descriptor['array_net_if_nonrow_overhead_at_most_5M']
scanner_target = scanner['conditional_net_with_1M_allowance'][0]
e_lower = sum(baseline['E_selected_disjoint_lower_bounds'].values())
assert e_lower == baseline['E_lower_bound']
whole_lower = baseline['subtotal_K']['lower'] + e_lower
assert whole_lower == baseline['whole_instruction_count_lower_bound']
out = {
    'credited_address_intersections':intersections,
    'joint_capped_target':epoch_target + descriptor_target + scanner_target,
    'selected_disjoint_E_floor':e_lower,
    'whole_instruction_lower_bound':whole_lower,
    'whole_instruction_upper_bound':None,
    'full_to_full_secondary_eligible_improved_lower':
        baseline['derived']['nonempty_scalar_refill_improved_min']
        - 2*baseline['structural_totals']['fin_crossing']
        - baseline['structural_totals']['norm_partial'],
    'status':'No new incompatibility found; joint code generation and net-cost caps remain unverified.',
}
(ROOT/'scanner/cross-component-results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
