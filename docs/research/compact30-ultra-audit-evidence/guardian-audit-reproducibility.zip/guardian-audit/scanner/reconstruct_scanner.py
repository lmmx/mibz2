#!/usr/bin/env python3
"""Read-only reconstruction and finite mathematical models for scanner claims.

No Rust invocation, corpus construction, timings, or performance measurements.
Run: python reconstruct_scanner.py [EVIDENCE_DIR] [OUTPUT_JSON]
"""
from __future__ import annotations
import itertools
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
EVIDENCE = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE.parent / 'evidence'
OUT = Path(sys.argv[2]) if len(sys.argv) > 2 else HERE / 'scanner-results.json'


def scanner_model(tiles):
    """One epoch, pair-valued tiles; two equal qwords mean one uniform byte.

    Symbolic qwords are repeated-byte values. Nonuniform values use two different
    qwords, sufficient to exercise both mismatch branches without source bytes.
    """
    i = 0
    held = None
    counts = dict(T=len(tiles), S=0, U=0, R=0, H=0, A=0, J=0, W=0, attempts=0)
    while i < len(tiles):
        if held is None:
            a, b = tiles[i]
            counts['A'] += 1
        else:
            a, b = held
            held = None
        if a == b:
            counts['R'] += 1
            e = i + 1
            while True:
                counts['attempts'] += 1
                if e >= len(tiles):
                    break
                a2, b2 = tiles[e]
                counts['J'] += 1
                if a2 == a and b2 == a:
                    e += 1
                else:
                    counts['H'] += 1
                    counts['W'] += a2 == a
                    held = (a2, b2)
                    break
            counts['U'] += e - i
            i = e
        else:
            counts['S'] += 1
            i += 1
    T, S, U, R, H, A, J, W = (counts[k] for k in ('T','S','U','R','H','A','J','W'))
    Q = R - H
    assert S + U == T
    assert A == S + R - H
    assert J == U - R + H
    assert A + J == T
    assert counts['attempts'] == U
    assert 0 <= Q <= 1
    assert 0 <= W <= H
    assert 8*A + 5*J + 7*S == 5*T + 10*S + 3*Q
    # Z includes matching continuations plus second-half-only mismatches.
    Z = U - R + W
    scan_expanded = 9*(S+R) + 10*A + R + 5*U + 9*J + 2*Z + 4*H + Q
    assert scan_expanded == 19*S + 16*U + 12*R - 2*Q + 2*W
    return counts


def verify_math():
    # Every control flow possibility up to 8 full tiles; runs of two different
    # bytes, first-qword mismatch and second-qword-only mismatch all represented.
    alphabet = ((0,0), (1,1), (0,1), (1,0))
    cases = 0
    for n in range(9):
        for tiles in itertools.product(alphabet, repeat=n):
            scanner_model(tiles)
            cases += 1
    # Finite induction step for the invariant on every allowed advance amount.
    phase_cases = 0
    for p in range(30):
        for k in range(31):
            p2 = p+k if p+k < 30 else p+k-30
            assert 0 <= p2 < 30
            assert p2 == (p+k) % 30
            phase_cases += 1
        for length in range(1,17):
            n1 = min(length, 30-p)
            assert 1 <= n1 <= length
            assert length-n1 >= 0
            # Label hole remains exactly represented by the two segment loops.
            labels = list(range(n1)) + list(range(n1+2, length+2))
            want = [t + 2*((p+t)//30) for t in range(length)]
            assert labels == want
    # Exact boundary arithmetic at the supported upper bound.
    max_n = 30*((2**20-1)//32)
    assert max_n == 983010
    for n in (0,1,7,8,15,16,17,29,30,31,61439,61440,61441,900000,max_n):
        i = 0
        while i < n:
            end = min(n, i+61440)
            # Enumerating indices verifies only the arithmetic, not a new constructor.
            while i+16 <= end:
                assert 0 <= i <= i+8 <= i+16 <= end <= n
                i += 16
            assert 0 <= end-i < 16
            i = end
    return dict(symbolic_tile_sequences=cases, phase_induction_steps=phase_cases,
                max_n=max_n, result='all assertions passed; models supplement written proofs')


def main():
    capture = EVIDENCE / 'capture/c30-construction-v2-20261103T222928Z/c30-construction.jsonl'
    counters = []
    with capture.open() as f:
        for line in f:
            row = json.loads(line)
            if row.get('kind') == 'counters':
                counters.append(row)
    assert len(counters) == 434
    T = sum(c['rows']//16 for c in counters)
    U = sum(c['run_rows']//16 for c in counters)
    assert all(c['run_rows'] % 16 == 0 for c in counters)
    S = T-U
    R = sum(c['runs'] for c in counters)
    epochs = sum(c['epochs'] for c in counters)
    qmax = sum(min(c['epochs'], c['runs']) for c in counters)
    assert sum(c['rows_scalar'] for c in counters) == 16*S + sum(c['rows']%16 for c in counters)
    asm = (EVIDENCE / 'cd14fa9/ctor2-build-false.asm').read_text()
    instructions = {}
    for line_number, line in enumerate(asm.splitlines(), 1):
        m = re.match(r'^\s*([0-9a-f]+):\s+(.*)$', line)
        if m:
            instructions[int(m[1],16)] = {'asm':m[2], 'line':line_number}
    ranges = dict(fresh=(0x33ae8,0x33b06),lookahead=(0x33b44,0x33b56))
    exact = {name:[{'address':hex(a),**row} for a,row in instructions.items() if lo<=a<=hi]
             for name,(lo,hi) in ranges.items()}
    exact['tile_checks'] = [{'address':hex(a),**instructions[a]} for a in
                           (0x33ba9,0x33baf,0x33bb2,0x343b0,0x343ba)]
    exact['phase_guard'] = [{'address':hex(a),**instructions[a]} for a in (0x33bc0,0x33bc4)]
    assert [len(exact[k]) for k in ('fresh','lookahead','tile_checks','phase_guard')] == [8,5,5,2]
    gross_lo = 5*T + 10*S
    gross_hi = gross_lo + 3*qmax
    result = {
        'counts':dict(T=T,U=U,S=S,R=R,epochs=epochs,Q_upper=qmax,
                      scalar_tail_rows=sum(c['rows']%16 for c in counters)),
        'frequency_formulae':{
            'A':'S+Q; fresh outer load pairs',
            'J':'U-Q; lookahead load pairs',
            'Q':'R-H; runs ending because next full tile unavailable',
            'gross':'8A+5J+7S = 5T+10S+3Q',
            'baseline_scanner':'19S+16U+12R-2Q+2W; 0<=W<=H'},
        'revised_gross_interval':[gross_lo,gross_hi],
        'conditional_net_with_1M_allowance':[gross_lo-1_000_000,gross_hi-1_000_000],
        'ultra_gross_interval':[gross_lo,gross_lo+3*epochs],
        'correction':'Upper bound tightens by 612 because the 204 short blocks have no uniform runs; lower bound unchanged.',
        'address_folding_credit':T,
        'remaining_bound_control_credit_interval':[4*T+10*S,4*T+10*S+3*qmax],
        'baseline_scanner_interval':[19*S+16*U+12*R-2*qmax,19*S+16*U+14*R],
        'instructions':exact,
        'mathematical_verification':verify_math(),
        'status':'Conditional compiler target, not established emitted-code savings or cycle prediction',
    }
    OUT.parent.mkdir(parents=True,exist_ok=True)
    OUT.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('counts','revised_gross_interval','conditional_net_with_1M_allowance','baseline_scanner_interval','mathematical_verification')},indent=2))


if __name__ == '__main__':
    main()
