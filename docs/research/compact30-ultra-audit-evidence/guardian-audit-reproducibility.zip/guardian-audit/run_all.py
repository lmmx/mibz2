#!/usr/bin/env python3
"""Reproduce static/math/archived-data audit. Never invokes project executables."""
from pathlib import Path
import hashlib,json,subprocess,sys
root=Path(__file__).resolve().parent
archive=root/'inputs/c30-construction-v2-20261103T222928Z.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='ebdb74549b39f83f07ae1f7d1c943916bac2ecb0be85868799aa30fe5e3d8af9'
commands=[
 ['scripts/verify_provenance.py','--output','results/provenance.json'],
 ['baseline/reconstruct_baseline.py','--root','.'],
 ['epoch/verify_epoch.py','--evidence','evidence','--out','epoch/results.json'],
 ['scanner/reconstruct_scanner.py','evidence','scanner/scanner-results.json'],
 ['descriptor/audit_descriptor.py','--evidence','evidence','--out','descriptor/descriptor_results.json'],
 ['descriptor/secondary/verify_secondary.py','--evidence','evidence','--output','descriptor/secondary/secondary_results.json'],
 ['scanner/cross_component_review.py'],
 ['scripts/reconstruct_portfolio.py','--root','.'],
 ['economics/conditional_completion.py',str(archive),'--output','economics/results.json'],
]
logs=root/'results/reproduction_logs';logs.mkdir(parents=True,exist_ok=True)
summary=[]
for i,args in enumerate(commands,1):
 print(f'[{i}/{len(commands)}] {args[0]}',flush=True)
 result=subprocess.run([sys.executable,*args],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 (logs/f'{i:02d}.txt').write_text(result.stdout)
 summary.append({'script':args[0],'exit_code':result.returncode})
 if result.returncode:
  print(result.stdout);raise SystemExit(result.returncode)
(root/'results/reproduction_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('All audit reconstructions completed. No constructor, compiler or benchmark was run.')
