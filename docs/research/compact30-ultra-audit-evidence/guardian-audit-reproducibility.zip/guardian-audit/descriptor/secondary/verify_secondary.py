#!/usr/bin/env python3
"""Static arithmetic and small identities only; never runs/compiles a constructor."""
import argparse, json, random, re
from pathlib import Path

def insts(path, low, high):
    return [(int(m.group(1),16),m.group(2)) for line in path.read_text().splitlines()
            if (m:=re.match(r'\s*([0-9a-f]+):\s+(.*)',line))
            and low <= int(m.group(1),16) <= high]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--evidence',type=Path,default=Path(__file__).resolve().parents[2]/'evidence')
    ap.add_argument('--output',type=Path,default=Path(__file__).with_name('secondary_results.json'))
    args=ap.parse_args()
    raw=args.evidence/'capture/c30-construction-v2-20261103T222928Z/c30-construction.jsonl'
    counters=[d for l in raw.open() if (d:=json.loads(l)).get('kind')=='counters']
    s={k:sum(d.get(k,0) for d in counters) for k in counters[0] if isinstance(counters[0][k],int)}
    p=sum(s[k] for k in ['fin_fast','fin_ordinary','fin_wide','fin_crossing','fin_forced'])
    scalar_nonempty_original=p-s['runs']-256*len(counters)
    scalar_nonempty_min=sum(max(0,sum(d[k] for k in ['fin_fast','fin_ordinary','fin_wide','fin_crossing','fin_forced'])-d['runs']-256) for d in counters)
    interior_original=scalar_nonempty_original-2*s['fin_crossing']-s['norm_partial']
    interior_min=scalar_nonempty_min-2*s['fin_crossing']-s['norm_partial']
    assert len(counters)==434 and scalar_nonempty_original==1073857 and interior_original==991575
    assert scalar_nonempty_min==1122673 and interior_min==1040391
    # Every load is within the 30 initialized u16 fields. Prove safe overlap
    # bytewise by taking immutable snapshots, and exhibit a bad schedule.
    offsets=[0,8,16,22]
    r=random.Random(227)
    for _ in range(10000):
        src=[r.randrange(65536) for _ in range(30)]
        base=src[0]
        expected=[(x-base)%65536 for x in src]
        chunks=[[((x-base)%65536) for x in src[o:o+8]] for o in offsets]
        got=src.copy()
        for o,v in zip(offsets,chunks): got[o:o+8]=v
        assert got==expected
    src=list(range(1,31)); base=src[0]; bad=src.copy()
    for o in offsets: bad[o:o+8]=[(x-base)%65536 for x in bad[o:o+8]]
    want=[(x-base)%65536 for x in src]
    mismatch=[i for i,(a,b) in enumerate(zip(bad,want)) if a!=b]
    assert mismatch==[22,23]
    # Pattern identity: each next 30-row group increases full phi by 32;
    # all 8-lane vector additions use the same modular u16 arithmetic.
    phi=lambda i:32*(i//30)+i%30
    for phase in range(30):
        for j in range(30):
            assert phi(phase+j)-phi(phase)==j+2*(phase+j>=30)
            assert phi(phase+30+j)-phi(phase+j)==32
        for y in (0,1,65520,65533,65536,1048500):
            pat=[j+2*(phase+j>=30) for j in range(30)]
            assert [((y & 65535)+v)&65535 for v in pat]==[(y+v)&65535 for v in pat]
    asm=args.evidence/'cd14fa9'
    counts={
      'fragment_vector_body':len(insts(asm/'ctor2-build-false.asm',0x34180,0x341a5)),
      'bulk_pair_body':len(insts(asm/'ctor2-build-false.asm',0x341d0,0x34233)),
      'existing_normalize_body':len(insts(asm/'ctor2-finish-false.asm',0x61f74,0x61fb3)),
      'raw_nontransition_body':len(insts(asm/'ctor2-finish-false.asm',0x62060,0x62099)),
    }
    assert counts=={'fragment_vector_body':9,'bulk_pair_body':20,'existing_normalize_body':15,'raw_nontransition_body':16}
    out={
      'counts':counts,'portions':p,'nonempty_scalar_refill_lower':scalar_nonempty_min,
      'original_corpuswide_nonempty_refill_lower':scalar_nonempty_original,
      'original_interior_natural_lower':interior_original,
      'refill_lower_bound_improvement':scalar_nonempty_min-scalar_nonempty_original,
      'interior_natural_lower':interior_min,
      'overlap_normalize_gross':3*s['norm_full'],
      'overlap_extra_logical_bytes_each_direction':4*s['norm_full'],
      'fragment_gross_ceiling':3*(s['rows_fragment']//8),
      'bulk_gross_ceiling':3*s['complete_groups'],
      'wide_zeroing_store_gross_ceiling':7*s['fin_wide'],
      'raw_nontransition_weighted':16*s['raw_fields_read'],
      'naive_overlap_counterexample':{'input':src,'base':base,'wrong_field_indices':mismatch,'actual':[bad[i] for i in mismatch],'expected':[want[i] for i in mismatch]},
      'random_overlap_identities_checked':10000,
      'caveat':'All savings are conditional gross ceilings; setup, guards, codegen, spill cost and unrecorded distributions are excluded.'
    }
    args.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()
