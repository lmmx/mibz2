#!/usr/bin/env python3
"""Read existing artifacts; verify scalar ledger/layout arithmetic, no Rust execution."""
import argparse, collections, json, pathlib, re

ap = argparse.ArgumentParser()
ap.add_argument('--evidence', type=pathlib.Path, default=pathlib.Path('evidence'))
ap.add_argument('--out', type=pathlib.Path, default=pathlib.Path('descriptor/descriptor_results.json'))
a = ap.parse_args()
asm = a.evidence / 'cd14fa9/ctor2-build-false.asm'
ins = {}
for line in asm.read_text().splitlines():
    m = re.match(r'^\s*([0-9a-f]+):\s+(\S+)\s*(.*)$', line)
    if m:
        ins[int(m[1],16)] = (m[2],m[3])
paths = [(0x33a00,0x33a29),(0x34350,0x3437a),(0x343e0,0x34406),(0x344d0,0x344f9)]
scalar = []
for lo,hi in paths:
    body = [(hex(addr),*ins[addr]) for addr in ins if lo <= addr <= hi]
    assert len(body) == 12
    assert body[1][1] == body[2][1] == 'lea'
    scalar.append({'start':hex(lo),'end':hex(hi),'instructions':len(body),'address_leas':[body[1],body[2]]})
counts = collections.Counter()
blocks = 0
blockwise_refill_lower = 0
for line in (a.evidence / 'capture/c30-construction-v2-20261103T222928Z/c30-construction.jsonl').open():
    o = json.loads(line)
    if o['kind'] == 'counters':
        blocks += 1
        block_portions = sum(o[x] for x in ['fin_fast','fin_ordinary','fin_wide','fin_crossing','fin_forced'])
        blockwise_refill_lower += max(0, block_portions-o['runs']-256)
        counts.update({k:v for k,v in o.items() if isinstance(v,int) and k != 'block'})
assert blocks == 434
N = counts['rows_scalar']
P = sum(counts[x] for x in ['fin_fast','fin_ordinary','fin_wide','fin_crossing','fin_forced'])
R = counts['runs']
F_min_original = P - R - 256*blocks
F_min = blockwise_refill_lower
assert F_min_original == 1073857 and F_min == 1122673
assert N == 38294883
# Logical layouts on frozen 64-bit target; does not assert rustc's chosen struct layout.
assert 256*40 == 2*256*8 + 256*24 == 10240
for c in range(256):
    assert 0 <= c*8 < 2048
    assert 2048 <= 2048+c*8 < 4096
    assert 4096 <= 4096+c*24 < 10240

result = {
    'scalar_paths':scalar,
    'scalar_rows':N,
    'scalar_baseline_instructions':12*N,
    'array_gross_target':2*N,
    'array_net_if_nonrow_overhead_at_most_5M':2*N-5_000_000,
    'array_plus_cached_pointer_update_gross':N,
    'array_plus_cached_pointer_update_net_if_nonrow_overhead_at_most_5M':N-5_000_000,
    'baseline_scalar_explicit_reads':4*N,
    'baseline_scalar_explicit_writes':2*N,
    'cached_pointer_read_reduction':N,
    'logical_descriptor_bytes':10240,
    'hot_pointer_bytes':4096,
    'cold_descriptor_bytes':6144,
    'successful_scalar_refill_bounds':[F_min,P],
    'original_corpuswide_nonempty_refill_lower':F_min_original,
    'revised_blockwise_nonempty_refill_lower':F_min,
    'refill_lower_bound_improvement':F_min-F_min_original,
    'one_extra_instruction_per_refill_cost_bounds':[F_min,P],
    'two_extra_instructions_per_refill_cost_bounds':[2*F_min,2*P],
    'array_net_if_one_address_lea_survives_and_5M_other_overhead':N-5_000_000,
    'array_net_if_two_address_instructions_survive_and_5M_other_overhead':-5_000_000,
    'one_extra_instruction_every_snapshot_character':256*counts['epochs'],
    'one_extra_instruction_every_finished_portion':P,
    'one_extra_instruction_every_run':R,
    'one_extra_instruction_every_block_character':256*blocks,
    'per_row_extra_instruction_cost':N,
    'qualification':'Targets and cost sensitivities, not code-generation observations or lower bounds on achieved savings.'
}
a.out.parent.mkdir(parents=True, exist_ok=True)
a.out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
