#!/usr/bin/env python3
"""Static/census reconstruction only. Never executes or compiles a constructor.

Run from an audit bundle: python baseline/reconstruct_baseline.py --root .
Requires the archived JSONL and frozen .asm files under evidence/.
Instruction counts exclude alignment NOPs, which remain in E.
"""
import argparse
from collections import Counter
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import re

ap = argparse.ArgumentParser()
ap.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
args = ap.parse_args()
root = args.root
out = root / 'baseline'
out.mkdir(parents=True, exist_ok=True)
cap = root / 'evidence/capture/c30-construction-v2-20261103T222928Z'
jl = cap / 'c30-construction.jsonl'
kinds, counters, meta = Counter(), [], None
for line in jl.open():
    x = json.loads(line)
    kinds[x['kind']] += 1
    if x['kind'] == 'counters': counters.append(x)
    if x['kind'] == 'meta': meta = x
assert len(counters) == 434
assert sorted(c['block'] for c in counters) == list(range(434))
keys = [k for k,v in counters[0].items() if isinstance(v,int) and k not in ('block','max_ordinary_span','min_wide_span')]
tot = {k: sum(c[k] for c in counters) for k in keys}
tot['blocks'] = len(counters)
tot['max_ordinary_span'] = max(c['max_ordinary_span'] for c in counters)
tot['min_wide_span'] = min(c['min_wide_span'] for c in counters if c['min_wide_span'])
proto = [json.loads(l) for l in (root/'evidence/cd14fa9/corpora.jsonl').open()]
natural = next(x for x in proto if x['input']=='wikidata-20261026.bz2' and x['permille']==0 and not x['extra_starts'])
for k,v in tot.items(): assert natural[k] == v, (k, natural[k], v)
for c in counters:
    assert c['rows'] == c['rows_scalar'] + c['rows_fragment'] + c['rows_bulk']
    assert c['run_rows'] == c['rows_fragment'] + c['rows_bulk']
    assert c['rows_bulk'] == 30*c['complete_groups']
    assert c['fin_fast']+c['fin_ordinary'] == c['norm_full']+c['norm_partial']
    assert c['raw_fields_read'] == c['raw_entries_written']
    assert c['rows'] == meta['block_rows'][c['block']]
    assert c['epochs'] == (c['rows']+61439)//61440
T = sum(c['rows']//16 for c in counters)
U = tot['run_rows']//16
assert tot['run_rows'] % 16 == 0
S = T-U
R = tot['runs']
EPOCHS = tot['epochs']
Qmax = sum(min(c['epochs'], c['runs']) for c in counters)
tail = sum(c['rows']%16 for c in counters)
assert tot['rows_scalar'] == 16*S+tail

def parse(name):
    ret = {}
    for line in (root/'evidence/cd14fa9'/name).read_text().splitlines():
        m = re.match(r'\s*([0-9a-f]+):\s+(.*)', line)
        if m: ret[int(m[1],16)] = m[2]
    return ret
b=parse('ctor2-build-false.asm'); f=parse('ctor2-finish-false.asm'); r=parse('ctor2-refill-false.asm')
paths={}
def count(name, asm, spans, expected=None):
    addresses=[]
    for low,high in spans:
        addresses += [a for a in asm if low<=a<=high]
    assert len(set(addresses))==len(addresses)
    if expected is not None: assert len(addresses)==expected, (name,len(addresses),expected)
    paths[name]={'count':len(addresses), 'addresses':[hex(a) for a in addresses], 'instructions':[asm[a] for a in addresses]}
    return len(addresses)

count('scalar_tile_first',b,[(0x34350,0x3437a)],12)
count('scalar_tile_second',b,[(0x343e0,0x34406)],12)
count('scalar_tail_first',b,[(0x33a00,0x33a29)],12)
count('scalar_tail_second',b,[(0x344d0,0x344f9)],12)
count('tile_setup_no_split',b,[(0x33b80,0x33bc4),(0x34340,0x34345),(0x3437c,0x3437c),(0x343b0,0x343c4),(0x33a90,0x33add)],41)
count('tile_split_extra',b,[(0x343ca,0x343dc),(0x34408,0x34408)],7)
count('run_entry',b,[(0x33be5,0x33c4c)],23)
count('run_return_no_bulk',b,[(0x34330,0x34335),(0x34446,0x34463),(0x33ad2,0x33add)],13)
count('run_return_after_bulk',b,[(0x34439,0x34463),(0x33ad2,0x33add)],13)
count('snapshot_2characters',b,[(0x33910,0x33948)],14)
count('descriptor_init_4characters',b,[(0x333f0,0x33464)],15)
count('descriptor_prefix_4characters',b,[(0x33480,0x334da)],20)
count('bulk_pair',b,[(0x341d0,0x34233)],20)
count('bulk_odd',b,[(0x3423a,0x34269)],11)
count('fragment_scalar_loop',b,[(0x33d00,0x33d17)],7)
count('fragment_vector_loop',b,[(0x34180,0x341a5)],9)
count('fast_full_finish',f,[(0x61d30,0x61d93),(0x61e08,0x61e17),(0x61f1b,0x61fb8),(0x6231b,0x62329)],81)
count('refill_nonempty_ordinary',r,[(0x62330,0x623d2),(0x623df,0x6240f)],62)
count('refill_empty_ordinary',r,[(0x62330,0x6234e),(0x62358,0x623d2),(0x623df,0x6240f)],60)
count('refill_nonempty_preset',r,[(0x62330,0x623dd),(0x623e4,0x6240f)],64)
count('raw_preset_iteration',f,[(0x61e70,0x61ea9)],16)
count('raw_wide_iteration',f,[(0x62060,0x62099)],16)
count('first_scalar_refill_detour',b,[(0x3437e,0x343ac)],10)
count('second_scalar_refill_detour',b,[(0x3440d,0x34437)],9)
count('tail_scalar_refill_detour',b,[(0x33a30,0x33a67)],12)
count('tail_second_refill_detour',b,[(0x34500,0x34535)],12)
count('run_room_setup',b,[(0x33c87,0x33c97)],6)
count('run_remaining_test',b,[(0x33d51,0x33d54)],2)
count('finish_common_entry_dispatch',f,[(0x61d30,0x61d93),(0x61e08,0x61e17)],34)
count('search_setup',f,[(0x61d95,0x61db4)],9)
count('search_first_iteration',f,[(0x61dc0,0x61dd6)],6)
count('search_bridge',f,[(0x61dd8,0x61de5)],4)
count('search_second_iteration',f,[(0x61df0,0x61e06)],6)

def portion(c): return sum(c[k] for k in ('fin_fast','fin_ordinary','fin_wide','fin_crossing','fin_forced'))
P=sum(map(portion,counters))
Lold=P-R-256*len(counters)
L=sum(max(0,portion(c)-c['runs']-256) for c in counters)
Fmin=sum(max(0,c['fin_fast']-c['norm_partial']) for c in counters)
Fmax=sum(min(c['fin_fast'],c['norm_full']) for c in counters)
frag=[]
for m in range(1,31):
    cost=29+7*m if m<8 else 43+9*(m//8) if m%8==0 else 44+9*(m//8)+7*(m%8)
    assert Fraction(cost,m)>=Fraction(70,24)
    assert cost <= 57+3*m
    frag.append({'length':m,'instructions':cost})
fragment_lo=(70*tot['rows_fragment']+23)//24
fragment_hi=57*2*R+3*tot['rows_fragment']
base_scan=19*S+16*U+12*R
ledger=[
    ('scalar append',12*tot['rows_scalar'],12*tot['rows_scalar'],'12 per scalar row, including 1,875 tails'),
    ('classification and scanning',base_scan-2*Qmax,base_scan+2*R,'19S+16U+12R-2Q+2W; 0<=Q<=3450, 0<=W<=R-Q'),
    ('nonuniform tile setup/advance',41*S,48*S,'41S+7X; unknown label-hole split tiles 0<=X<=S'),
    ('fragment filling',fragment_lo,fragment_hi,'cost(m) bounded by 70m/24 and 57+3m; at most 2R fills'),
    ('bulk emitter core',10*tot['complete_groups'],10*tot['complete_groups']+R,'10G+odd-emitter-invocations, at most R'),
    ('run entry',23*R,23*R,'23 per run'),
    ('run return/control',13*R,13*R,'13 per run, common outer availability counted here for runs'),
    ('snapshot rank loop',1792*EPOCHS,1792*EPOCHS,'14 instructions for 2 characters, 128 iterations'),
    ('descriptor initialization/prefix',2240*len(counters),2240*len(counters),'(15+20)*64 per block; memcpy excluded'),
    ('fast full ordinary finish',81*Fmin,81*Fmax,'blockwise max(0,fast-partial)<=fast_full<=min(fast,full); caller call excluded'),
    ('refill wrappers',62*L,62*P+2*tot['fin_crossing'],'nonempty success>=L, all opens<=P, preset opening adds2, initial refill subtracts2'),
    ('RAW reconstruction common core',16*tot['raw_fields_read'],16*tot['raw_fields_read'],'16 per field; epoch-transition detours excluded')]
Klo=sum(x[1] for x in ledger); Khi=sum(x[2] for x in ledger)
E_floor_parts={
    'scalar_refill_caller_detours':9*L,
    'run_room_and_remaining_tests':8*R,
    'other_finish_common_entry_dispatch':34*(P-Fmax),
    'nonfast_epoch_search_minimum':31*tot['epoch_searches'],
    'other_full_normalizer_bodies':15*(tot['norm_full']-Fmax),
}
result={
    'capture_sha256':hashlib.sha256(jl.read_bytes()).hexdigest(),
    'record_kinds':dict(kinds),'structural_totals':tot,
    'derived':{'full_tiles_T':T,'uniform_tiles_U':U,'nonuniform_tiles_S':S,'scalar_tail_rows':tail,'all_portions_P':P,'fast_full_min':Fmin,'fast_full_max':Fmax,'nonempty_scalar_refill_old_min':Lold,'nonempty_scalar_refill_improved_min':L,'terminal_no_held_runs_max':Qmax},
    'baseline_ledger':[dict(zip(('component','lower','upper','derivation'),v)) for v in ledger],
    'subtotal_K':{'lower':Klo,'upper':Khi},
    'original_K':{'lower':Klo-62*(L-Lold)-2*(EPOCHS-Qmax),'upper':Khi+81*(tot['fin_fast']-Fmax)},
    'E_selected_disjoint_lower_bounds':E_floor_parts,
    'E_lower_bound':sum(E_floor_parts.values()),
    'whole_instruction_count_lower_bound':Klo+sum(E_floor_parts.values()),
    'whole_instruction_count_upper_bound':None,
    'fragment_cost_table':frag,
    'limitations':['Census weights static paths; not a retired-instruction trace.','Counted true build supplies semantic event counts; false build supplies timed instructions. Their codegen is not identical.','K upper endpoint is not a whole-constructor upper bound.','E contains alignment NOPs, library internals, residual transition/control/normalization/canonicalization work.']
}
(out/'baseline_results.json').write_text(json.dumps(result,indent=2)+'\n')
(out/'instruction_paths.json').write_text(json.dumps(paths,indent=2)+'\n')
print(json.dumps({'K':result['subtotal_K'],'E_lower':result['E_lower_bound'],'I_lower':result['whole_instruction_count_lower_bound'],'structural_match':True},indent=2))
