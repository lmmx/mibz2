# Team size against live tables: wikidata

Runs: 320; errors: 0; output hashes: 1 (same bytes). Reference: `mibz2@8`. Paired ratio: the reference's wall over the cell's, by round (above 1 is faster), its geometric mean and 95% interval.

| teams × k | arm @ threads | tables | MB/s | vs ref | busy cores | leader CPU | helper CPU | scanner CPU | peak RSS | L3 hit share | L3 misses /KB | cycles /B | IPC | L3-miss stall share |
|---|---|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| 2 × 3 | `mibz2-team3@8` | 7.2 MB | 1,098 | 0.860 (0.845–0.875) | 4.4 | 0.170 | 0.086 | 0.050 | 52 MB | – | – | – | – | – |
| 2 × 4 | `mibz2-team4@8` | 7.2 MB | 1,160 | 0.910 (0.898–0.921) | 5.1 | 0.155 | 0.072 | 0.050 | 52 MB | – | – | – | – | – |
| 2 × 4 | `mibz2-team4@10` | 7.2 MB | 1,177 | 0.912 (0.895–0.929) | 5.1 | 0.155 | 0.072 | 0.050 | 52 MB | – | – | – | – | – |
| 3 × 3 | `mibz2-team3@10` | 10.8 MB | 1,377 | 1.076 (1.058–1.095) | 6.4 | 0.127 | 0.065 | 0.055 | 67 MB | – | – | – | – | – |
| 3 × 4 | `mibz2-team4@12` | 10.8 MB | 1,389 | 1.090 (1.072–1.107) | 7.5 | 0.123 | 0.059 | 0.060 | 67 MB | – | – | – | – | – |
| 4 × 2 | `mibz2@8` | 14.4 MB | 1,277 | 1.000 (1.000–1.000) | 6.6 | 0.138 | 0.080 | 0.060 | 82 MB | – | – | – | – | – |
| 4 × 2 | `mibz2-team2@8` | 14.4 MB | 1,274 | 1.004 (0.992–1.016) | 6.6 | 0.138 | 0.080 | 0.060 | 82 MB | – | – | – | – | – |
| 4 × 2 | `mibz2@10` | 14.4 MB | 1,276 | 0.999 (0.988–1.010) | 6.6 | 0.135 | 0.080 | 0.055 | 82 MB | – | – | – | – | – |
| 4 × 2 | `mibz2@12` | 14.4 MB | 1,263 | 0.995 (0.982–1.009) | 6.6 | 0.138 | 0.080 | 0.050 | 82 MB | – | – | – | – | – |
| 4 × 2 | `mibz2@16` | 14.4 MB | 1,277 | 0.999 (0.987–1.012) | 6.6 | 0.136 | 0.080 | 0.060 | 82 MB | – | – | – | – | – |
| 4 × 3 | `mibz2-team3@12` | 14.4 MB | 1,309 | 1.019 (1.008–1.030) | 8.5 | 0.133 | 0.073 | 0.070 | 81 MB | – | – | – | – | – |
| 4 × 4 | `mibz2-team4@16` | 14.4 MB | 1,284 | 1.006 (0.995–1.018) | 10.0 | 0.135 | 0.067 | 0.070 | 82 MB | – | – | – | – | – |
| 5 × 2 | `mibz2-team2@10` | 18.0 MB | 1,164 | 0.914 (0.902–0.926) | 8.2 | 0.154 | 0.094 | 0.070 | 96 MB | – | – | – | – | – |
| 5 × 3 | `mibz2-team3@16` | 18.0 MB | 1,154 | 0.904 (0.897–0.912) | 10.5 | 0.154 | 0.084 | 0.070 | 96 MB | – | – | – | – | – |
| 6 × 2 | `mibz2-team2@12` | 21.6 MB | 1,056 | 0.827 (0.819–0.835) | 10.0 | 0.166 | 0.108 | 0.085 | 110 MB | – | – | – | – | – |
| 8 × 2 | `mibz2-team2@16` | 28.8 MB | 880 | 0.693 (0.686–0.701) | 13.2 | 0.203 | 0.134 | 0.100 | 138 MB | – | – | – | – | – |

## The rule's predicates

- Every run of every cell the same output hash and length, no run failed: **yes** (1 hash(es), 1 length(s), 0 failed).
- The reference `mibz2@8`: rounds 0–19 once each, every run 4x2: **yes**.
- The whole grid, 16 cells × 20 rounds, each round once, no failed run: **yes**.
- The control `mibz2-team2@8` 1.004 (0.992–1.016), 20 pairs: **within ±2%**.

| primary | plan in every run | 20 unique pairs | mean ≥ 1.03 | lower bound > 1.00 | raises the ceiling | peak RSS / ref (≤ 1.15) | CPU / ref (≤ 1.5) |
|---|---|---|---|---|---|---|---|
| `mibz2-team4@12` (3x4) | yes | yes | yes (1.090) | yes (1.072) | **yes** | 0.82 | 1.04 |
| `mibz2-team3@10` (3x3) | yes | yes | yes (1.076) | yes (1.058) | **yes** | 0.82 | 0.90 |

A pass here is not a qualification: the same cell must pass the same predicates, within the adoption limits, in one predeclared second run of 20 rounds. The adoption limits are ratios of medians (the cell's median peak RSS and CPU-seconds over the reference's) and must hold in both runs.
