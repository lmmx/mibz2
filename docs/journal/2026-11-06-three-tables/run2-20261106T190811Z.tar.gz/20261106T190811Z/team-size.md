# Team size against live tables: wikidata

Runs: 320; errors: 0; output hashes: 1 (same bytes). Reference: `mibz2@8`. Paired ratio: the reference's wall over the cell's, by round (above 1 is faster), its geometric mean and 95% interval.

| teams × k | arm @ threads | tables | MB/s | vs ref | busy cores | leader CPU | helper CPU | scanner CPU | peak RSS | L3 hit share | L3 misses /KB | cycles /B | IPC | L3-miss stall share |
|---|---|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| 2 × 3 | `mibz2-team3@8` | 7.2 MB | 1,096 | 0.856 (0.841–0.872) | 4.4 | 0.170 | 0.086 | 0.050 | 52 MB | – | – | – | – | – |
| 2 × 4 | `mibz2-team4@8` | 7.2 MB | 1,158 | 0.907 (0.892–0.922) | 5.2 | 0.158 | 0.073 | 0.050 | 52 MB | – | – | – | – | – |
| 2 × 4 | `mibz2-team4@10` | 7.2 MB | 1,165 | 0.910 (0.896–0.925) | 5.1 | 0.158 | 0.073 | 0.050 | 52 MB | – | – | – | – | – |
| 3 × 3 | `mibz2-team3@10` | 10.8 MB | 1,382 | 1.087 (1.074–1.100) | 6.4 | 0.127 | 0.062 | 0.060 | 67 MB | – | – | – | – | – |
| 3 × 4 | `mibz2-team4@12` | 10.8 MB | 1,389 | 1.086 (1.062–1.111) | 7.5 | 0.123 | 0.060 | 0.060 | 67 MB | – | – | – | – | – |
| 4 × 2 | `mibz2@8` | 14.4 MB | 1,272 | 1.000 (1.000–1.000) | 6.6 | 0.138 | 0.081 | 0.060 | 81 MB | – | – | – | – | – |
| 4 × 2 | `mibz2-team2@8` | 14.4 MB | 1,274 | 1.000 (0.990–1.011) | 6.6 | 0.135 | 0.080 | 0.055 | 81 MB | – | – | – | – | – |
| 4 × 2 | `mibz2@10` | 14.4 MB | 1,265 | 0.999 (0.990–1.009) | 6.6 | 0.138 | 0.080 | 0.050 | 82 MB | – | – | – | – | – |
| 4 × 2 | `mibz2@12` | 14.4 MB | 1,270 | 0.999 (0.990–1.008) | 6.6 | 0.135 | 0.080 | 0.055 | 81 MB | – | – | – | – | – |
| 4 × 2 | `mibz2@16` | 14.4 MB | 1,279 | 1.007 (0.998–1.017) | 6.6 | 0.135 | 0.080 | 0.050 | 82 MB | – | – | – | – | – |
| 4 × 3 | `mibz2-team3@12` | 14.4 MB | 1,295 | 1.025 (1.017–1.033) | 8.4 | 0.133 | 0.072 | 0.070 | 82 MB | – | – | – | – | – |
| 4 × 4 | `mibz2-team4@16` | 14.4 MB | 1,282 | 1.009 (1.000–1.019) | 10.0 | 0.135 | 0.067 | 0.070 | 83 MB | – | – | – | – | – |
| 5 × 2 | `mibz2-team2@10` | 18.0 MB | 1,161 | 0.915 (0.907–0.924) | 8.3 | 0.152 | 0.098 | 0.070 | 96 MB | – | – | – | – | – |
| 5 × 3 | `mibz2-team3@16` | 18.0 MB | 1,144 | 0.901 (0.894–0.909) | 10.6 | 0.152 | 0.087 | 0.075 | 96 MB | – | – | – | – | – |
| 6 × 2 | `mibz2-team2@12` | 21.6 MB | 1,032 | 0.817 (0.809–0.826) | 9.9 | 0.168 | 0.113 | 0.080 | 110 MB | – | – | – | – | – |
| 8 × 2 | `mibz2-team2@16` | 28.8 MB | 877 | 0.694 (0.687–0.701) | 13.2 | 0.203 | 0.136 | 0.100 | 138 MB | – | – | – | – | – |

## The rule's predicates

- Every run of every cell the same output hash and length, no run failed: **yes** (1 hash(es), 1 length(s), 0 failed).
- The reference `mibz2@8`: rounds 0–19 once each, every run 4x2: **yes**.
- The whole grid, 16 cells × 20 rounds, each round once, no failed run: **yes**.
- The control `mibz2-team2@8` 1.000 (0.990–1.011), 20 pairs: **within ±2%**.

| primary | plan in every run | 20 unique pairs | mean ≥ 1.03 | lower bound > 1.00 | raises the ceiling | peak RSS / ref (≤ 1.15) | CPU / ref (≤ 1.5) |
|---|---|---|---|---|---|---|---|
| `mibz2-team4@12` (3x4) | yes | yes | yes (1.086) | yes (1.062) | **yes** | 0.83 | 1.04 |
| `mibz2-team3@10` (3x3) | yes | yes | yes (1.087) | yes (1.074) | **yes** | 0.82 | 0.89 |

A pass here is not a qualification: the same cell must pass the same predicates, within the adoption limits, in one predeclared second run of 20 rounds. The adoption limits are ratios of medians (the cell's median peak RSS and CPU-seconds over the reference's) and must hold in both runs.
