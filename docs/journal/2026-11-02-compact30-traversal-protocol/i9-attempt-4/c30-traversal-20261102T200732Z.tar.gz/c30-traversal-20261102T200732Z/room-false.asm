
/home/louis/dev/mibz2/target/c30-traversal-pin/target/rust-1.97.0/release/examples/c30walk:     file format elf64-x86-64


Disassembly of section .text:

000000000000dba0 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_>:
    dba0:	push   rbp
    dba1:	push   r15
    dba3:	push   r14
    dba5:	push   r13
    dba7:	push   r12
    dba9:	push   rbx
    dbaa:	sub    rsp,0x638
    dbb1:	mov    DWORD PTR [rsp+0x154],esi
    dbb8:	mov    rax,QWORD PTR [rdi+0xb8]
    dbbf:	mov    QWORD PTR [rsp+0x178],rax
    dbc7:	mov    eax,DWORD PTR [rdi+0x10]
    dbca:	mov    r12,QWORD PTR [rdi+0x40]
    dbce:	mov    QWORD PTR [rdi+0xb0],0x0
    dbd9:	mov    QWORD PTR [rdi+0x98],0x0
    dbe4:	test   r12,r12
    dbe7:	je     fbb1 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x2011>
    dbed:	mov    rbx,rdi
    dbf0:	shl    eax,0x5
    dbf3:	add    eax,0xffffffe0
    dbf6:	mov    DWORD PTR [rsp+0x24],eax
    dbfa:	xor    edi,edi
    dbfc:	lea    rax,[rbx+0xa0]
    dc03:	mov    QWORD PTR [rsp],rax
    dc07:	lea    rax,[rbx+0x88]
    dc0e:	mov    QWORD PTR [rsp+0x8],rax
    dc13:	mov    QWORD PTR [rsp+0x28],r12
    dc18:	jmp    dc49 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0xa9>
    dc1a:	nop    WORD PTR [rax+rax*1+0x0]
    dc20:	inc    rdi
    dc23:	mov    rax,QWORD PTR [r14+0x90]
    dc2a:	mov    WORD PTR [rax+rbx*2],bp
    dc2e:	inc    rbx
    dc31:	mov    QWORD PTR [r14+0x98],rbx
    dc38:	mov    r12,QWORD PTR [rsp+0x28]
    dc3d:	cmp    r12,rdi
    dc40:	mov    rbx,r14
    dc43:	je     dd80 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1e0>
    dc49:	mov    rsi,QWORD PTR [rbx+0x40]
    dc4d:	cmp    rdi,rsi
    dc50:	jae    faa0 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1f00>
    dc56:	mov    rsi,QWORD PTR [rbx+0x10]
    dc5a:	mov    rax,QWORD PTR [rbx+0x38]
    dc5e:	mov    ebp,DWORD PTR [rax+rdi*4]
    dc61:	mov    r12d,ebp
    dc64:	shr    r12d,0x5
    dc68:	cmp    rsi,r12
    dc6b:	jbe    fa91 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1ef1>
    dc71:	and    ebp,0x1f
    dc74:	cmp    ebp,0x1e
    dc77:	jae    fa7d <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1edd>
    dc7d:	mov    rcx,QWORD PTR [rbx+0x8]
    dc81:	mov    rdx,r12
    dc84:	shl    rdx,0x6
    dc88:	lea    rax,[rcx+rdx*1]
    dc8c:	movzx  eax,WORD PTR [rax+rbp*2]
    dc90:	mov    r13d,DWORD PTR [rcx+rdx*1+0x3c]
    dc95:	cmp    eax,0xfffe
    dc9a:	jae    dd20 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x180>
    dca0:	mov    r14,rbx
    dca3:	mov    ebx,r13d
    dca6:	shr    ebx,0x8
    dca9:	add    ebx,eax
    dcab:	mov    r15,QWORD PTR [r14+0xb0]
    dcb2:	cmp    r15,QWORD PTR [r14+0xa0]
    dcb9:	je     dd5e <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1be>
    dcbf:	shl    ebx,0x8
    dcc2:	movzx  eax,r13b
    dcc6:	or     eax,ebx
    dcc8:	mov    rcx,QWORD PTR [r14+0xa8]
    dccf:	mov    DWORD PTR [rcx+r15*4],eax
    dcd3:	inc    r15
    dcd6:	mov    QWORD PTR [r14+0xb0],r15
    dcdd:	mov    rsi,QWORD PTR [r14+0x10]
    dce1:	cmp    rsi,r12
    dce4:	jbe    fa6e <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1ece>
    dcea:	add    rdx,QWORD PTR [r14+0x8]
    dcee:	movzx  ebp,WORD PTR [rdx+rbp*2]
    dcf2:	mov    rbx,QWORD PTR [r14+0x98]
    dcf9:	cmp    rbx,QWORD PTR [r14+0x88]
    dd00:	jne    dc20 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x80>
    dd06:	mov    r15,rdi
    dd09:	mov    rdi,QWORD PTR [rsp+0x8]
    dd0e:	call   7500 <_RNvMs3_NtCs40k4W9msRzi_5alloc7raw_vecINtB5_6RawVectE8grow_oneCs3AlRknvjqqN_7c30walk>
    dd13:	mov    rdi,r15
    dd16:	jmp    dc20 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x80>
    dd1b:	nop    DWORD PTR [rax+rax*1+0x0]
    dd20:	and    r13d,0xfffff
    dd27:	mov    rsi,QWORD PTR [rbx+0x28]
    dd2b:	cmp    rsi,r13
    dd2e:	jbe    fb26 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1f86>
    dd34:	shl    r13d,0x7
    dd38:	add    r13,QWORD PTR [rbx+0x20]
    dd3c:	mov    r13d,DWORD PTR [r13+rbp*4+0x0]
    dd41:	mov    r14,rbx
    dd44:	mov    ebx,r13d
    dd47:	shr    ebx,0x8
    dd4a:	mov    r15,QWORD PTR [r14+0xb0]
    dd51:	cmp    r15,QWORD PTR [r14+0xa0]
    dd58:	jne    dcbf <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x11f>
    dd5e:	mov    QWORD PTR [rsp+0x38],rdi
    dd63:	mov    rdi,QWORD PTR [rsp]
    dd67:	mov    QWORD PTR [rsp+0x18],rdx
    dd6c:	call   7f00 <_RNvMs3_NtCs40k4W9msRzi_5alloc7raw_vecINtB5_6RawVecmE8grow_oneCs7ivwnIpGHJL_5mibz2>
    dd71:	mov    rdx,QWORD PTR [rsp+0x18]
    dd76:	mov    rdi,QWORD PTR [rsp+0x38]
    dd7b:	jmp    dcbf <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x11f>
    dd80:	xor    edi,edi
    dd82:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
    dd90:	mov    rsi,QWORD PTR [rbx+0x40]
    dd94:	cmp    rdi,rsi
    dd97:	jae    facf <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1f2f>
    dd9d:	mov    rsi,QWORD PTR [rbx+0x10]
    dda1:	mov    rax,QWORD PTR [rbx+0x38]
    dda5:	mov    eax,DWORD PTR [rax+rdi*4]
    dda8:	mov    ecx,eax
    ddaa:	shr    ecx,0x5
    ddad:	cmp    rsi,rcx
    ddb0:	jbe    fac0 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1f20>
    ddb6:	and    eax,0x1f
    ddb9:	cmp    eax,0x1e
    ddbc:	jae    faac <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1f0c>
    ddc2:	inc    rdi
    ddc5:	shl    rcx,0x6
    ddc9:	add    rcx,QWORD PTR [rbx+0x8]
    ddcd:	mov    WORD PTR [rcx+rax*2],0xfffe
    ddd3:	cmp    r12,rdi
    ddd6:	jne    dd90 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1f0>
    ddd8:	mov    r14,QWORD PTR [rbx+0x8]
    dddc:	mov    rax,QWORD PTR [rbx+0x20]
    dde0:	mov    QWORD PTR [rsp+0x38],rax
    dde5:	mov    rax,QWORD PTR [rsp+0x178]
    dded:	add    rax,rax
    ddf0:	mov    rcx,rax
    ddf3:	or     rcx,r12
    ddf6:	shr    rcx,0x20
    ddfa:	je     de52 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x2b2>
    ddfc:	xor    edx,edx
    ddfe:	div    r12
    de01:	mov    rbp,rax
    de04:	mov    r13,QWORD PTR [rbx+0x58]
    de08:	cmp    r13,r12
    de0b:	cmova  r12,r13
    de0f:	jae    de66 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x2c6>
    de11:	sub    r12,r13
    de14:	mov    rax,QWORD PTR [rbx+0x48]
    de18:	sub    rax,r13
    de1b:	mov    rdx,r13
    de1e:	cmp    r12,rax
    de21:	ja     de74 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x2d4>
    de23:	mov    rax,QWORD PTR [rbx+0x50]
    de27:	inc    r13
    de2a:	test   r12b,0x1
    de2e:	jne    de9f <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x2ff>
    de30:	cmp    QWORD PTR [rsp+0x28],r13
    de35:	jne    dece <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x32e>
    de3b:	mov    QWORD PTR [rbx+0x58],rdx
    de3f:	mov    rsi,QWORD PTR [rsp+0x28]
    de44:	cmp    rsi,rdx
    de47:	jbe    df35 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x395>
    de4d:	jmp    fa3e <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1e9e>
    de52:	xor    edx,edx
    de54:	div    r12d
    de57:	mov    ebp,eax
    de59:	mov    r13,QWORD PTR [rbx+0x58]
    de5d:	cmp    r13,r12
    de60:	cmova  r12,r13
    de64:	jb     de11 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x271>
    de66:	mov    QWORD PTR [rbx+0x58],r12
    de6a:	mov    rsi,QWORD PTR [rsp+0x28]
    de6f:	jmp    df35 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x395>
    de74:	lea    rdi,[rbx+0x48]
    de78:	mov    ecx,0x8
    de7d:	mov    r8d,0x18
    de83:	mov    rsi,r13
    de86:	mov    rdx,r12
    de89:	call   6100 <_RINvNvMs2_NtCs40k4W9msRzi_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs3AlRknvjqqN_7c30walk>
    de8e:	mov    rdx,QWORD PTR [rbx+0x58]
    de92:	mov    rax,QWORD PTR [rbx+0x50]
    de96:	inc    r13
    de99:	test   r12b,0x1
    de9d:	je     de30 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x290>
    de9f:	dec    r12
    dea2:	lea    rcx,[rdx+rdx*2]
    dea6:	mov    QWORD PTR [rax+rcx*8],0x0
    deae:	mov    QWORD PTR [rax+rcx*8+0x8],0x1
    deb7:	mov    QWORD PTR [rax+rcx*8+0x10],0x0
    dec0:	inc    rdx
    dec3:	cmp    QWORD PTR [rsp+0x28],r13
    dec8:	je     de3b <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x29b>
    dece:	lea    rcx,[rdx+rdx*2]
    ded2:	lea    rax,[rax+rcx*8]
    ded6:	add    rax,0x28
    deda:	neg    r12
    dedd:	xor    ecx,ecx
    dedf:	xorps  xmm0,xmm0
    dee2:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
    def0:	mov    QWORD PTR [rax-0x28],0x0
    def8:	mov    QWORD PTR [rax-0x20],0x1
    df00:	movups XMMWORD PTR [rax-0x18],xmm0
    df04:	mov    QWORD PTR [rax-0x8],0x1
    df0c:	mov    QWORD PTR [rax],0x0
    df13:	add    rax,0x30
    df17:	add    rcx,0xfffffffffffffffe
    df1b:	cmp    r12,rcx
    df1e:	jne    def0 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x350>
    df20:	sub    rdx,rcx
    df23:	mov    QWORD PTR [rbx+0x58],rdx
    df27:	mov    rsi,QWORD PTR [rsp+0x28]
    df2c:	cmp    rsi,rdx
    df2f:	ja     fa3e <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1e9e>
    df35:	lea    r12,[rbp+0x40]
    df39:	mov    r13,QWORD PTR [rbx+0x50]
    df3d:	lea    rax,[rsi*8+0x0]
    df45:	lea    r15,[rax+rax*2]
    df49:	nop    DWORD PTR [rax+0x0]
    df50:	mov    QWORD PTR [r13+0x10],0x0
    df58:	cmp    r12,QWORD PTR [r13+0x0]
    df5c:	ja     df6a <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x3ca>
    df5e:	add    r13,0x18
    df62:	add    r15,0xffffffffffffffe8
    df66:	jne    df50 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x3b0>
    df68:	jmp    df8c <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x3ec>
    df6a:	mov    ecx,0x1
    df6f:	mov    r8d,0x1
    df75:	mov    rdi,r13
    df78:	xor    esi,esi
    df7a:	mov    rdx,r12
    df7d:	call   6100 <_RINvNvMs2_NtCs40k4W9msRzi_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs3AlRknvjqqN_7c30walk>
    df82:	add    r13,0x18
    df86:	add    r15,0xffffffffffffffe8
    df8a:	jne    df50 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x3b0>
    df8c:	mov    QWORD PTR [rbx+0x70],0x0
    df94:	mov    r12,QWORD PTR [rsp+0x28]
    df99:	cmp    r12,QWORD PTR [rbx+0x60]
    df9d:	ja     fa4c <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1eac>
    dfa3:	xor    r15d,r15d
    dfa6:	mov    QWORD PTR [rsp+0x18],rbx
    dfab:	mov    rbx,QWORD PTR [rbx+0x68]
    dfaf:	lea    rdi,[rbx+r15*8]
    dfb3:	cmp    r12,0x1
    dfb7:	je     dfde <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x43e>
    dfb9:	lea    rdx,[r12*8-0x8]
    dfc1:	mov    esi,0xff
    dfc6:	call   QWORD PTR [rip+0x87e7c]        # 95e48 <memset@GLIBC_2.2.5>
    dfcc:	lea    rax,[r15+r12*1]
    dfd0:	lea    rdi,[rbx+rax*8]
    dfd4:	add    rdi,0xfffffffffffffff8
    dfd8:	add    r15,r12
    dfdb:	dec    r15
    dfde:	mov    QWORD PTR [rdi],0xffffffffffffffff
    dfe5:	inc    r15
    dfe8:	mov    rbx,QWORD PTR [rsp+0x18]
    dfed:	mov    QWORD PTR [rbx+0x70],r15
    dff1:	xorps  xmm0,xmm0
    dff4:	movups XMMWORD PTR [rsp+0x240],xmm0
    dffc:	mov    QWORD PTR [rsp+0x250],0x0
    e008:	movups XMMWORD PTR [rsp+0x260],xmm0
    e010:	mov    QWORD PTR [rsp+0x270],0x0
    e01c:	movups XMMWORD PTR [rsp+0x280],xmm0
    e024:	mov    QWORD PTR [rsp+0x290],0x0
    e030:	movups XMMWORD PTR [rsp+0x2a0],xmm0
    e038:	mov    QWORD PTR [rsp+0x2b0],0x0
    e044:	movups XMMWORD PTR [rsp+0x2c0],xmm0
    e04c:	mov    QWORD PTR [rsp+0x2d0],0x0
    e058:	movups XMMWORD PTR [rsp+0x2e0],xmm0
    e060:	mov    QWORD PTR [rsp+0x2f0],0x0
    e06c:	movups XMMWORD PTR [rsp+0x300],xmm0
    e074:	mov    QWORD PTR [rsp+0x310],0x0
    e080:	movups XMMWORD PTR [rsp+0x320],xmm0
    e088:	mov    QWORD PTR [rsp+0x330],0x0
    e094:	movups XMMWORD PTR [rsp+0x340],xmm0
    e09c:	mov    QWORD PTR [rsp+0x350],0x0
    e0a8:	movups XMMWORD PTR [rsp+0x360],xmm0
    e0b0:	mov    QWORD PTR [rsp+0x370],0x0
    e0bc:	movups XMMWORD PTR [rsp+0x380],xmm0
    e0c4:	mov    QWORD PTR [rsp+0x390],0x0
    e0d0:	movups XMMWORD PTR [rsp+0x3a0],xmm0
    e0d8:	mov    QWORD PTR [rsp+0x3b0],0x0
    e0e4:	movups XMMWORD PTR [rsp+0x3c0],xmm0
    e0ec:	mov    QWORD PTR [rsp+0x3d0],0x0
    e0f8:	movups XMMWORD PTR [rsp+0x3e0],xmm0
    e100:	mov    QWORD PTR [rsp+0x3f0],0x0
    e10c:	movups XMMWORD PTR [rsp+0x400],xmm0
    e114:	mov    QWORD PTR [rsp+0x410],0x0
    e120:	movups XMMWORD PTR [rsp+0x420],xmm0
    e128:	mov    QWORD PTR [rsp+0x430],0x0
    e134:	movups XMMWORD PTR [rsp+0x440],xmm0
    e13c:	mov    QWORD PTR [rsp+0x450],0x0
    e148:	movups XMMWORD PTR [rsp+0x460],xmm0
    e150:	mov    QWORD PTR [rsp+0x470],0x0
    e15c:	movups XMMWORD PTR [rsp+0x480],xmm0
    e164:	mov    QWORD PTR [rsp+0x490],0x0
    e170:	movups XMMWORD PTR [rsp+0x4a0],xmm0
    e178:	mov    QWORD PTR [rsp+0x4b0],0x0
    e184:	movups XMMWORD PTR [rsp+0x4c0],xmm0
    e18c:	mov    QWORD PTR [rsp+0x4d0],0x0
    e198:	movups XMMWORD PTR [rsp+0x4e0],xmm0
    e1a0:	mov    QWORD PTR [rsp+0x4f0],0x0
    e1ac:	movups XMMWORD PTR [rsp+0x500],xmm0
    e1b4:	mov    QWORD PTR [rsp+0x510],0x0
    e1c0:	movups XMMWORD PTR [rsp+0x520],xmm0
    e1c8:	mov    QWORD PTR [rsp+0x530],0x0
    e1d4:	movups XMMWORD PTR [rsp+0x540],xmm0
    e1dc:	mov    QWORD PTR [rsp+0x550],0x0
    e1e8:	movups XMMWORD PTR [rsp+0x560],xmm0
    e1f0:	mov    QWORD PTR [rsp+0x570],0x0
    e1fc:	movups XMMWORD PTR [rsp+0x580],xmm0
    e204:	mov    QWORD PTR [rsp+0x590],0x0
    e210:	movups XMMWORD PTR [rsp+0x5a0],xmm0
    e218:	mov    QWORD PTR [rsp+0x5b0],0x0
    e224:	movups XMMWORD PTR [rsp+0x5c0],xmm0
    e22c:	mov    QWORD PTR [rsp+0x5d0],0x0
    e238:	movups XMMWORD PTR [rsp+0x5e0],xmm0
    e240:	mov    QWORD PTR [rsp+0x5f0],0x0
    e24c:	movups XMMWORD PTR [rsp+0x600],xmm0
    e254:	mov    QWORD PTR [rsp+0x610],0x0
    e260:	movups XMMWORD PTR [rsp+0x620],xmm0
    e268:	mov    QWORD PTR [rsp+0x630],0x0
    e274:	mov    QWORD PTR [rsp+0x238],0xffffffffffffffff
    e280:	mov    QWORD PTR [rsp+0x258],0xffffffffffffffff
    e28c:	mov    QWORD PTR [rsp+0x278],0xffffffffffffffff
    e298:	mov    QWORD PTR [rsp+0x298],0xffffffffffffffff
    e2a4:	mov    QWORD PTR [rsp+0x2b8],0xffffffffffffffff
    e2b0:	mov    QWORD PTR [rsp+0x2d8],0xffffffffffffffff
    e2bc:	mov    QWORD PTR [rsp+0x2f8],0xffffffffffffffff
    e2c8:	mov    QWORD PTR [rsp+0x318],0xffffffffffffffff
    e2d4:	mov    QWORD PTR [rsp+0x338],0xffffffffffffffff
    e2e0:	mov    QWORD PTR [rsp+0x358],0xffffffffffffffff
    e2ec:	mov    QWORD PTR [rsp+0x378],0xffffffffffffffff
    e2f8:	mov    QWORD PTR [rsp+0x398],0xffffffffffffffff
    e304:	mov    QWORD PTR [rsp+0x3b8],0xffffffffffffffff
    e310:	mov    QWORD PTR [rsp+0x3d8],0xffffffffffffffff
    e31c:	mov    QWORD PTR [rsp+0x3f8],0xffffffffffffffff
    e328:	mov    QWORD PTR [rsp+0x418],0xffffffffffffffff
    e334:	mov    QWORD PTR [rsp+0x438],0xffffffffffffffff
    e340:	mov    QWORD PTR [rsp+0x458],0xffffffffffffffff
    e34c:	mov    QWORD PTR [rsp+0x478],0xffffffffffffffff
    e358:	mov    QWORD PTR [rsp+0x498],0xffffffffffffffff
    e364:	mov    QWORD PTR [rsp+0x4b8],0xffffffffffffffff
    e370:	mov    QWORD PTR [rsp+0x4d8],0xffffffffffffffff
    e37c:	mov    QWORD PTR [rsp+0x4f8],0xffffffffffffffff
    e388:	mov    QWORD PTR [rsp+0x518],0xffffffffffffffff
    e394:	mov    QWORD PTR [rsp+0x538],0xffffffffffffffff
    e3a0:	mov    QWORD PTR [rsp+0x558],0xffffffffffffffff
    e3ac:	mov    QWORD PTR [rsp+0x578],0xffffffffffffffff
    e3b8:	mov    QWORD PTR [rsp+0x598],0xffffffffffffffff
    e3c4:	mov    QWORD PTR [rsp+0x5b8],0xffffffffffffffff
    e3d0:	mov    QWORD PTR [rsp+0x5d8],0xffffffffffffffff
    e3dc:	mov    QWORD PTR [rsp+0x5f8],0xffffffffffffffff
    e3e8:	mov    QWORD PTR [rsp+0x618],0xffffffffffffffff
    e3f4:	mov    eax,0x2
    e3f9:	xor    edi,edi
    e3fb:	xor    r9d,r9d
    e3fe:	xchg   ax,ax
    e400:	mov    rsi,QWORD PTR [rbx+0x58]
    e404:	cmp    rdi,rsi
    e407:	jae    fae7 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1f47>
    e40d:	mov    rsi,QWORD PTR [rbx+0xb0]
    e414:	cmp    rdi,rsi
    e417:	jae    fadb <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1f3b>
    e41d:	mov    rcx,QWORD PTR [rbx+0x50]
    e421:	mov    rdx,QWORD PTR [rbx+0xa8]
    e428:	mov    rsi,QWORD PTR [rcx+rax*4]
    e42c:	movzx  r8d,BYTE PTR [rdx+rdi*4]
    e431:	mov    BYTE PTR [rsi],r8b
    e434:	mov    edx,DWORD PTR [rdx+rdi*4]
    e437:	shr    edx,0x8
    e43a:	lea    r8,[rsi+0x1]
    e43e:	add    rsi,QWORD PTR [rcx+rax*4-0x8]
    e443:	mov    QWORD PTR [rsp+r9*1+0x238],rdi
    e44b:	mov    QWORD PTR [rsp+r9*1+0x240],r8
    e453:	mov    QWORD PTR [rsp+r9*1+0x248],rsi
    e45b:	mov    DWORD PTR [rsp+r9*1+0x250],edx
    e463:	mov    DWORD PTR [rsp+r9*1+0x254],0x0
    e46f:	prefetcht0 BYTE PTR [r14+rdx*2]
    e474:	lea    rsi,[rdi+0x1]
    e478:	add    r9,0x20
    e47c:	cmp    rdi,0x1e
    e480:	ja     e492 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x8f2>
    e482:	add    rax,0x6
    e486:	mov    rdi,rsi
    e489:	cmp    rsi,r12
    e48c:	jb     e400 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x860>
    e492:	cmp    rsi,0x20
    e496:	jne    f472 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x18d2>
    e49c:	mov    QWORD PTR [rsp+0x170],rsi
    e4a4:	add    rbp,0x3f
    e4a8:	mov    eax,0x20
    e4ad:	mov    QWORD PTR [rsp+0x8],rax
    e4b2:	mov    QWORD PTR [rsp+0x230],rbp
    e4ba:	jmp    e84d <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0xcad>
    e4bf:	nop
    e4c0:	mov    rbp,QWORD PTR [rsp+0x48]
    e4c5:	mov    r12,QWORD PTR [rsp+0x50]
    e4ca:	mov    rax,QWORD PTR [rsp+0x58]
    e4cf:	mov    QWORD PTR [rsp+0x10],rax
    e4d4:	mov    rax,QWORD PTR [rsp+0x60]
    e4d9:	mov    QWORD PTR [rsp+0x1b8],rax
    e4e1:	mov    rax,QWORD PTR [rsp+0x68]
    e4e6:	mov    QWORD PTR [rsp+0x1c0],rax
    e4ee:	mov    rax,QWORD PTR [rsp+0x70]
    e4f3:	mov    QWORD PTR [rsp+0x1c8],rax
    e4fb:	mov    rax,QWORD PTR [rsp+0x78]
    e500:	mov    QWORD PTR [rsp+0x1d0],rax
    e508:	mov    rax,QWORD PTR [rsp+0x80]
    e510:	mov    QWORD PTR [rsp+0x1d8],rax
    e518:	mov    rax,QWORD PTR [rsp+0x88]
    e520:	mov    QWORD PTR [rsp+0x1e0],rax
    e528:	mov    rax,QWORD PTR [rsp+0x90]
    e530:	mov    QWORD PTR [rsp+0x1e8],rax
    e538:	mov    rax,QWORD PTR [rsp+0x98]
    e540:	mov    QWORD PTR [rsp+0x1f0],rax
    e548:	mov    rax,QWORD PTR [rsp+0xa0]
    e550:	mov    QWORD PTR [rsp+0x1f8],rax
    e558:	mov    rax,QWORD PTR [rsp+0xa8]
    e560:	mov    QWORD PTR [rsp+0x200],rax
    e568:	mov    rax,QWORD PTR [rsp+0xb0]
    e570:	mov    QWORD PTR [rsp+0x208],rax
    e578:	mov    rax,QWORD PTR [rsp+0xb8]
    e580:	mov    QWORD PTR [rsp],rax
    e584:	mov    rax,QWORD PTR [rsp+0xc0]
    e58c:	mov    QWORD PTR [rsp+0x190],rax
    e594:	mov    rax,QWORD PTR [rsp+0xc8]
    e59c:	mov    QWORD PTR [rsp+0x198],rax
    e5a4:	mov    rax,QWORD PTR [rsp+0xd0]
    e5ac:	mov    QWORD PTR [rsp+0x1a0],rax
    e5b4:	mov    rax,QWORD PTR [rsp+0xd8]
    e5bc:	mov    QWORD PTR [rsp+0x1a8],rax
    e5c4:	mov    rax,QWORD PTR [rsp+0xe0]
    e5cc:	mov    QWORD PTR [rsp+0x1b0],rax
    e5d4:	mov    rax,QWORD PTR [rsp+0xe8]
    e5dc:	mov    QWORD PTR [rsp+0x180],rax
    e5e4:	mov    rax,QWORD PTR [rsp+0xf0]
    e5ec:	mov    QWORD PTR [rsp+0x188],rax
    e5f4:	mov    rdi,QWORD PTR [rsp+0xf8]
    e5fc:	mov    rsi,QWORD PTR [rsp+0x100]
    e604:	mov    rdx,QWORD PTR [rsp+0x108]
    e60c:	mov    rcx,QWORD PTR [rsp+0x110]
    e614:	mov    rax,QWORD PTR [rsp+0x118]
    e61c:	mov    r13,QWORD PTR [rsp+0x120]
    e624:	mov    r11,QWORD PTR [rsp+0x128]
    e62c:	mov    r10,QWORD PTR [rsp+0x130]
    e634:	mov    r9,QWORD PTR [rsp+0x138]
    e63c:	mov    r8,QWORD PTR [rsp+0x140]
    e644:	add    rbp,r15
    e647:	mov    QWORD PTR [rsp+0x240],rbp
    e64f:	add    r12,r15
    e652:	mov    QWORD PTR [rsp+0x260],r12
    e65a:	mov    r12,QWORD PTR [rsp+0x10]
    e65f:	add    r12,r15
    e662:	mov    QWORD PTR [rsp+0x280],r12
    e66a:	mov    r12,QWORD PTR [rsp+0x1b8]
    e672:	add    r12,r15
    e675:	mov    QWORD PTR [rsp+0x2a0],r12
    e67d:	mov    r12,QWORD PTR [rsp+0x1c0]
    e685:	add    r12,r15
    e688:	mov    QWORD PTR [rsp+0x2c0],r12
    e690:	mov    r12,QWORD PTR [rsp+0x1c8]
    e698:	add    r12,r15
    e69b:	mov    QWORD PTR [rsp+0x2e0],r12
    e6a3:	mov    r12,QWORD PTR [rsp+0x1d0]
    e6ab:	add    r12,r15
    e6ae:	mov    QWORD PTR [rsp+0x300],r12
    e6b6:	mov    r12,QWORD PTR [rsp+0x1d8]
    e6be:	add    r12,r15
    e6c1:	mov    QWORD PTR [rsp+0x320],r12
    e6c9:	mov    r12,QWORD PTR [rsp+0x1e0]
    e6d1:	add    r12,r15
    e6d4:	mov    QWORD PTR [rsp+0x340],r12
    e6dc:	mov    r12,QWORD PTR [rsp+0x1e8]
    e6e4:	add    r12,r15
    e6e7:	mov    QWORD PTR [rsp+0x360],r12
    e6ef:	mov    r12,QWORD PTR [rsp+0x1f0]
    e6f7:	add    r12,r15
    e6fa:	mov    QWORD PTR [rsp+0x380],r12
    e702:	mov    r12,QWORD PTR [rsp+0x1f8]
    e70a:	add    r12,r15
    e70d:	mov    QWORD PTR [rsp+0x3a0],r12
    e715:	mov    r12,QWORD PTR [rsp+0x200]
    e71d:	add    r12,r15
    e720:	mov    QWORD PTR [rsp+0x3c0],r12
    e728:	mov    r12,QWORD PTR [rsp+0x208]
    e730:	add    r12,r15
    e733:	mov    QWORD PTR [rsp+0x3e0],r12
    e73b:	mov    r12,QWORD PTR [rsp]
    e73f:	add    r12,r15
    e742:	mov    QWORD PTR [rsp+0x400],r12
    e74a:	mov    r12,QWORD PTR [rsp+0x190]
    e752:	add    r12,r15
    e755:	mov    QWORD PTR [rsp+0x420],r12
    e75d:	mov    r12,QWORD PTR [rsp+0x198]
    e765:	add    r12,r15
    e768:	mov    QWORD PTR [rsp+0x440],r12
    e770:	mov    r12,QWORD PTR [rsp+0x1a0]
    e778:	add    r12,r15
    e77b:	mov    QWORD PTR [rsp+0x460],r12
    e783:	mov    r12,QWORD PTR [rsp+0x1a8]
    e78b:	add    r12,r15
    e78e:	mov    QWORD PTR [rsp+0x480],r12
    e796:	mov    r12,QWORD PTR [rsp+0x1b0]
    e79e:	add    r12,r15
    e7a1:	mov    QWORD PTR [rsp+0x4a0],r12
    e7a9:	mov    r12,QWORD PTR [rsp+0x180]
    e7b1:	add    r12,r15
    e7b4:	mov    QWORD PTR [rsp+0x4c0],r12
    e7bc:	mov    r12,QWORD PTR [rsp+0x188]
    e7c4:	add    r12,r15
    e7c7:	mov    QWORD PTR [rsp+0x4e0],r12
    e7cf:	add    rdi,r15
    e7d2:	mov    QWORD PTR [rsp+0x500],rdi
    e7da:	add    rsi,r15
    e7dd:	mov    QWORD PTR [rsp+0x520],rsi
    e7e5:	add    rdx,r15
    e7e8:	mov    QWORD PTR [rsp+0x540],rdx
    e7f0:	add    rcx,r15
    e7f3:	mov    QWORD PTR [rsp+0x560],rcx
    e7fb:	add    rax,r15
    e7fe:	mov    QWORD PTR [rsp+0x580],rax
    e806:	add    r13,r15
    e809:	mov    QWORD PTR [rsp+0x5a0],r13
    e811:	add    r11,r15
    e814:	mov    QWORD PTR [rsp+0x5c0],r11
    e81c:	add    r10,r15
    e81f:	mov    QWORD PTR [rsp+0x5e0],r10
    e827:	add    r9,r15
    e82a:	mov    QWORD PTR [rsp+0x600],r9
    e832:	add    r8,r15
    e835:	mov    QWORD PTR [rsp+0x620],r8
    e83d:	mov    r9,QWORD PTR [rsp+0x148]
    e845:	mov    rbp,QWORD PTR [rsp+0x230]
    e84d:	mov    r15,rbp
    e850:	xor    r12d,r12d
    e853:	jmp    e891 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0xcf1>
    e855:	data16 cs nop WORD PTR [rax+rax*1+0x0]
    e860:	add    r13,rax
    e863:	mov    QWORD PTR [rsp+r12*1+0x240],r13
    e86b:	add    rdx,rax
    e86e:	mov    QWORD PTR [rsp+r12*1+0x248],rdx
    e876:	sub    rdx,r13
    e879:	add    r12,0x20
    e87d:	cmp    rdx,r15
    e880:	cmovb  r15,rdx
    e884:	cmp    r12,0x400
    e88b:	je     e910 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0xd70>
    e891:	mov    r13,QWORD PTR [rsp+r12*1+0x240]
    e899:	mov    rdx,QWORD PTR [rsp+r12*1+0x248]
    e8a1:	cmp    r13,rdx
    e8a4:	jne    e876 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0xcd6>
    e8a6:	mov    rsi,QWORD PTR [rbx+0x58]
    e8aa:	mov    rdi,QWORD PTR [rsp+r12*1+0x238]
    e8b2:	cmp    rdi,rsi
    e8b5:	jae    fb1a <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1f7a>
    e8bb:	mov    rcx,QWORD PTR [rbx+0x50]
    e8bf:	lea    rsi,[rdi+rdi*2]
    e8c3:	mov    rdx,QWORD PTR [rcx+rsi*8]
    e8c7:	mov    rax,QWORD PTR [rcx+rsi*8+0x8]
    e8cc:	sub    r13,rax
    e8cf:	mov    QWORD PTR [rcx+rsi*8+0x10],r13
    e8d4:	mov    rdi,rdx
    e8d7:	sub    rdi,r13
    e8da:	cmp    rdx,rdi
    e8dd:	jbe    e860 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0xcc0>
    e8df:	lea    rdi,[rcx+rsi*8]
    e8e3:	mov    QWORD PTR [rsp],rdi
    e8e7:	mov    ecx,0x1
    e8ec:	mov    r8d,0x1
    e8f2:	mov    rsi,r13
    e8f5:	mov    rbp,r9
    e8f8:	call   6100 <_RINvNvMs2_NtCs40k4W9msRzi_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs3AlRknvjqqN_7c30walk>
    e8fd:	mov    r9,rbp
    e900:	mov    rax,QWORD PTR [rsp]
    e904:	mov    rdx,QWORD PTR [rax]
    e907:	mov    rax,QWORD PTR [rax+0x8]
    e90b:	jmp    e860 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0xcc0>
    e910:	mov    QWORD PTR [rsp+0x148],r9
    e918:	mov    rax,QWORD PTR [rsp+0x240]
    e920:	mov    QWORD PTR [rsp+0x30],rax
    e925:	mov    rax,QWORD PTR [rsp+0x260]
    e92d:	mov    QWORD PTR [rsp+0x40],rax
    e932:	mov    rcx,QWORD PTR [rsp+0x280]
    e93a:	mov    QWORD PTR [rsp+0x10],rcx
    e93f:	mov    r12,QWORD PTR [rsp+0x2a0]
    e947:	mov    rbp,QWORD PTR [rsp+0x2c0]
    e94f:	mov    r13,QWORD PTR [rsp+0x2e0]
    e957:	mov    r11,QWORD PTR [rsp+0x300]
    e95f:	mov    r10,QWORD PTR [rsp+0x320]
    e967:	mov    r9,QWORD PTR [rsp+0x340]
    e96f:	mov    r8,QWORD PTR [rsp+0x360]
    e977:	mov    rdi,QWORD PTR [rsp+0x380]
    e97f:	mov    rsi,QWORD PTR [rsp+0x3a0]
    e987:	mov    rdx,QWORD PTR [rsp+0x3c0]
    e98f:	mov    rcx,QWORD PTR [rsp+0x3e0]
    e997:	mov    rax,QWORD PTR [rsp+0x400]
    e99f:	mov    QWORD PTR [rsp],rax
    e9a3:	mov    rax,QWORD PTR [rsp+0x30]
    e9a8:	mov    QWORD PTR [rsp+0x48],rax
    e9ad:	mov    rax,QWORD PTR [rsp+0x40]
    e9b2:	mov    QWORD PTR [rsp+0x50],rax
    e9b7:	mov    rax,QWORD PTR [rsp+0x10]
    e9bc:	mov    QWORD PTR [rsp+0x58],rax
    e9c1:	mov    QWORD PTR [rsp+0x1b8],r12
    e9c9:	mov    QWORD PTR [rsp+0x60],r12
    e9ce:	mov    QWORD PTR [rsp+0x1c0],rbp
    e9d6:	mov    QWORD PTR [rsp+0x68],rbp
    e9db:	mov    QWORD PTR [rsp+0x1c8],r13
    e9e3:	mov    QWORD PTR [rsp+0x70],r13
    e9e8:	mov    QWORD PTR [rsp+0x1d0],r11
    e9f0:	mov    QWORD PTR [rsp+0x78],r11
    e9f5:	mov    QWORD PTR [rsp+0x1d8],r10
    e9fd:	mov    QWORD PTR [rsp+0x80],r10
    ea05:	mov    QWORD PTR [rsp+0x1e0],r9
    ea0d:	mov    QWORD PTR [rsp+0x88],r9
    ea15:	mov    QWORD PTR [rsp+0x1e8],r8
    ea1d:	mov    QWORD PTR [rsp+0x90],r8
    ea25:	mov    QWORD PTR [rsp+0x1f0],rdi
    ea2d:	mov    QWORD PTR [rsp+0x98],rdi
    ea35:	mov    QWORD PTR [rsp+0x1f8],rsi
    ea3d:	mov    QWORD PTR [rsp+0xa0],rsi
    ea45:	mov    QWORD PTR [rsp+0x200],rdx
    ea4d:	mov    QWORD PTR [rsp+0xa8],rdx
    ea55:	mov    QWORD PTR [rsp+0x208],rcx
    ea5d:	mov    QWORD PTR [rsp+0xb0],rcx
    ea65:	mov    rax,QWORD PTR [rsp]
    ea69:	mov    QWORD PTR [rsp+0xb8],rax
    ea71:	mov    rax,QWORD PTR [rsp+0x420]
    ea79:	mov    QWORD PTR [rsp+0x190],rax
    ea81:	mov    QWORD PTR [rsp+0xc0],rax
    ea89:	mov    rax,QWORD PTR [rsp+0x440]
    ea91:	mov    QWORD PTR [rsp+0x198],rax
    ea99:	mov    QWORD PTR [rsp+0xc8],rax
    eaa1:	mov    rax,QWORD PTR [rsp+0x460]
    eaa9:	mov    QWORD PTR [rsp+0x1a0],rax
    eab1:	mov    QWORD PTR [rsp+0xd0],rax
    eab9:	mov    rax,QWORD PTR [rsp+0x480]
    eac1:	mov    QWORD PTR [rsp+0x1a8],rax
    eac9:	mov    QWORD PTR [rsp+0xd8],rax
    ead1:	mov    rax,QWORD PTR [rsp+0x4a0]
    ead9:	mov    QWORD PTR [rsp+0x1b0],rax
    eae1:	mov    QWORD PTR [rsp+0xe0],rax
    eae9:	mov    rbp,QWORD PTR [rsp+0x4c0]
    eaf1:	mov    QWORD PTR [rsp+0xe8],rbp
    eaf9:	mov    r12,QWORD PTR [rsp+0x4e0]
    eb01:	mov    QWORD PTR [rsp+0xf0],r12
    eb09:	mov    rdi,QWORD PTR [rsp+0x500]
    eb11:	mov    QWORD PTR [rsp+0xf8],rdi
    eb19:	mov    rsi,QWORD PTR [rsp+0x520]
    eb21:	mov    QWORD PTR [rsp+0x100],rsi
    eb29:	mov    rdx,QWORD PTR [rsp+0x540]
    eb31:	mov    QWORD PTR [rsp+0x108],rdx
    eb39:	mov    rcx,QWORD PTR [rsp+0x560]
    eb41:	mov    QWORD PTR [rsp+0x110],rcx
    eb49:	mov    rax,QWORD PTR [rsp+0x580]
    eb51:	mov    QWORD PTR [rsp+0x118],rax
    eb59:	mov    r13,QWORD PTR [rsp+0x5a0]
    eb61:	mov    QWORD PTR [rsp+0x120],r13
    eb69:	mov    r11,QWORD PTR [rsp+0x5c0]
    eb71:	mov    QWORD PTR [rsp+0x128],r11
    eb79:	mov    r10,QWORD PTR [rsp+0x5e0]
    eb81:	mov    QWORD PTR [rsp+0x130],r10
    eb89:	mov    r9,QWORD PTR [rsp+0x600]
    eb91:	mov    QWORD PTR [rsp+0x138],r9
    eb99:	mov    r8,QWORD PTR [rsp+0x620]
    eba1:	mov    QWORD PTR [rsp+0x140],r8
    eba9:	test   r15,r15
    ebac:	je     ee30 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1290>
    ebb2:	xor    eax,eax
    ebb4:	mov    ebp,DWORD PTR [rsp+0x24]
    ebb8:	mov    r13,QWORD PTR [rsp+0x38]
    ebbd:	lea    r12,[rsp+0x250]
    ebc5:	jmp    ebdd <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x103d>
    ebc7:	nop    WORD PTR [rax+rax*1+0x0]
    ebd0:	mov    rax,QWORD PTR [rsp]
    ebd4:	cmp    rax,r15
    ebd7:	je     e4c0 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x920>
    ebdd:	lea    rcx,[rax+0x1]
    ebe1:	mov    QWORD PTR [rsp],rcx
    ebe5:	mov    r8,rax
    ebe8:	not    r8
    ebeb:	xor    r9d,r9d
    ebee:	mov    r10,r9
    ebf1:	shl    r10,0x5
    ebf5:	add    r10,r12
    ebf8:	mov    rdx,r9
    ebfb:	jmp    ec2b <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x108b>
    ebfd:	nop    DWORD PTR [rax]
    ec00:	mov    ecx,esi
    ec02:	shr    ecx,0x8
    ec05:	add    ecx,edi
    ec07:	mov    DWORD PTR [r10],ecx
    ec0a:	mov    ecx,ecx
    ec0c:	prefetcht0 BYTE PTR [r14+rcx*2]
    ec11:	mov    rcx,QWORD PTR [rsp+rdx*8+0x48]
    ec16:	mov    BYTE PTR [rcx+rax*1],sil
    ec1a:	lea    rcx,[r9-0x1]
    ec1e:	add    r10,0x20
    ec22:	mov    rdx,r9
    ec25:	cmp    rcx,0x1f
    ec29:	jae    ebd0 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1030>
    ec2b:	lea    r9,[rdx+0x1]
    ec2f:	mov    r11d,DWORD PTR [r10]
    ec32:	movzx  edi,WORD PTR [r14+r11*2]
    ec37:	mov    ecx,r11d
    ec3a:	and    ecx,0xffffffe0
    ec3d:	mov    esi,DWORD PTR [r14+rcx*2+0x3c]
    ec42:	cmp    edi,0xfffe
    ec48:	jb     ec00 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1060>
    ec4a:	je     ec70 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x10d0>
    ec4c:	cmp    r11d,ebp
    ec4f:	jne    ed30 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1190>
    ec55:	mov    ecx,DWORD PTR [r10+0x4]
    ec59:	mov    esi,DWORD PTR [r13+rcx*4+0x0]
    ec5e:	mov    ecx,esi
    ec60:	shr    ecx,0x8
    ec63:	jmp    ec07 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1067>
    ec65:	data16 cs nop WORD PTR [rax+rax*1+0x0]
    ec70:	mov    rcx,QWORD PTR [rsp+rdx*8+0x48]
    ec75:	add    rcx,rax
    ec78:	mov    QWORD PTR [r10-0x10],rcx
    ec7c:	mov    rsi,QWORD PTR [rbx+0x58]
    ec80:	mov    rdi,QWORD PTR [r10-0x18]
    ec84:	cmp    rdi,rsi
    ec87:	jae    fb41 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1fa1>
    ec8d:	mov    rsi,QWORD PTR [rsp+0x18]
    ec92:	mov    rbx,QWORD PTR [rsi+0x50]
    ec96:	mov    rsi,QWORD PTR [rsp+0x18]
    ec9b:	mov    r13,QWORD PTR [rsi+0x68]
    ec9f:	lea    r12,[rdi+rdi*2]
    eca3:	sub    rcx,QWORD PTR [rbx+r12*8+0x8]
    eca8:	mov    rsi,QWORD PTR [rsp+0x18]
    ecad:	mov    rsi,QWORD PTR [rsi+0x70]
    ecb1:	mov    QWORD PTR [rbx+r12*8+0x10],rcx
    ecb6:	mov    rbx,QWORD PTR [rsp+0x18]
    ecbb:	mov    rbp,QWORD PTR [rbx+0x40]
    ecbf:	test   rbp,rbp
    ecc2:	mov    QWORD PTR [rsp+0x10],r13
    ecc7:	je     ed61 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x11c1>
    eccd:	mov    rcx,QWORD PTR [rbx+0x38]
    ecd1:	xor    r13d,r13d
    ecd4:	cmp    rbp,0x1
    ecd8:	je     ecfd <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x115d>
    ecda:	nop    WORD PTR [rax+rax*1+0x0]
    ece0:	mov    rbx,r13
    ece3:	mov    r12,rbp
    ece6:	shr    r12,1
    ece9:	add    r13,r12
    ecec:	cmp    DWORD PTR [rcx+r13*4],r11d
    ecf0:	cmova  r13,rbx
    ecf4:	sub    rbp,r12
    ecf7:	cmp    rbp,0x1
    ecfb:	ja     ece0 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1140>
    ecfd:	cmp    DWORD PTR [rcx+r13*4],r11d
    ed01:	mov    rcx,0xffffffffffffffff
    ed08:	cmovne r13,rcx
    ed0c:	mov    rbx,QWORD PTR [rsp+0x18]
    ed11:	cmp    rdi,rsi
    ed14:	mov    rcx,QWORD PTR [rsp+0x28]
    ed19:	mov    rbp,QWORD PTR [rsp+0x8]
    ed1e:	jb     ed7b <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x11db>
    ed20:	jmp    fb35 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1f95>
    ed25:	data16 cs nop WORD PTR [rax+rax*1+0x0]
    ed30:	shl    esi,0x5
    ed33:	and    esi,0x1ffffe0
    ed39:	and    r11d,0x1f
    ed3d:	or     r11d,esi
    ed40:	mov    DWORD PTR [r10+0x4],r11d
    ed44:	prefetcht0 BYTE PTR [r13+r11*4+0x0]
    ed4a:	mov    DWORD PTR [r10],ebp
    ed4d:	dec    QWORD PTR [rsp+rdx*8+0x48]
    ed52:	cmp    rdx,0x1f
    ed56:	jb     ebee <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x104e>
    ed5c:	jmp    ebd0 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1030>
    ed61:	mov    r13,0xffffffffffffffff
    ed68:	cmp    rdi,rsi
    ed6b:	mov    rcx,QWORD PTR [rsp+0x28]
    ed70:	mov    rbp,QWORD PTR [rsp+0x8]
    ed75:	jae    fb35 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1f95>
    ed7b:	mov    rsi,QWORD PTR [rsp+0x10]
    ed80:	mov    QWORD PTR [rsi+rdi*8],r13
    ed84:	cmp    rbp,rcx
    ed87:	je     ee4f <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x12af>
    ed8d:	mov    rsi,QWORD PTR [rbx+0x58]
    ed91:	cmp    rbp,rsi
    ed94:	mov    r13,QWORD PTR [rsp+0x38]
    ed99:	jae    fb5c <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1fbc>
    ed9f:	mov    rsi,QWORD PTR [rbx+0xb0]
    eda6:	cmp    rbp,rsi
    eda9:	jae    fb4d <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1fad>
    edaf:	mov    rcx,QWORD PTR [rbx+0x50]
    edb3:	mov    rsi,QWORD PTR [rbx+0xa8]
    edba:	lea    rdi,[rbp*2+0x0]
    edc2:	add    rdi,rbp
    edc5:	mov    r11,QWORD PTR [rcx+rdi*8+0x8]
    edca:	movzx  ebx,BYTE PTR [rsi+rbp*4]
    edce:	mov    BYTE PTR [r11],bl
    edd1:	mov    esi,DWORD PTR [rsi+rbp*4]
    edd4:	shr    esi,0x8
    edd7:	lea    rbx,[r11+0x1]
    eddb:	lea    r12,[r11+r8*1]
    eddf:	inc    r12
    ede2:	add    r11,QWORD PTR [rcx+rdi*8]
    ede6:	mov    QWORD PTR [r10-0x18],rbp
    edea:	mov    QWORD PTR [r10-0x10],rbx
    edee:	mov    rbx,QWORD PTR [rsp+0x18]
    edf3:	mov    QWORD PTR [r10-0x8],r11
    edf7:	mov    DWORD PTR [r10],esi
    edfa:	mov    DWORD PTR [r10+0x4],0x0
    ee02:	prefetcht0 BYTE PTR [r14+rsi*2]
    ee07:	inc    rbp
    ee0a:	mov    QWORD PTR [rsp+0x8],rbp
    ee0f:	mov    QWORD PTR [rsp+rdx*8+0x48],r12
    ee14:	mov    ebp,DWORD PTR [rsp+0x24]
    ee18:	lea    r12,[rsp+0x250]
    ee20:	cmp    rdx,0x1f
    ee24:	jb     ebee <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x104e>
    ee2a:	jmp    ebd0 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1030>
    ee2f:	nop
    ee30:	mov    QWORD PTR [rsp+0x188],r12
    ee38:	mov    r12,QWORD PTR [rsp+0x40]
    ee3d:	mov    QWORD PTR [rsp+0x180],rbp
    ee45:	mov    rbp,QWORD PTR [rsp+0x30]
    ee4a:	jmp    e644 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0xaa4>
    ee4f:	test   rdx,rdx
    ee52:	je     f22a <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x168a>
    ee58:	mov    rcx,QWORD PTR [rsp+0x48]
    ee5d:	lea    rdi,[rax+0x1]
    ee61:	add    rcx,rdi
    ee64:	mov    QWORD PTR [rsp+0x240],rcx
    ee6c:	cmp    rdx,0x2
    ee70:	mov    r9,QWORD PTR [rsp+0x148]
    ee78:	mov    rsi,QWORD PTR [rsp+0x170]
    ee80:	jb     f24a <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x16aa>
    ee86:	mov    rcx,QWORD PTR [rsp+0x50]
    ee8b:	add    rcx,rdi
    ee8e:	mov    QWORD PTR [rsp+0x260],rcx
    ee96:	cmp    rdx,0x2
    ee9a:	jbe    f25a <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x16ba>
    eea0:	mov    rcx,QWORD PTR [rsp+0x58]
    eea5:	add    rcx,rdi
    eea8:	mov    QWORD PTR [rsp+0x280],rcx
    eeb0:	cmp    rdx,0x3
    eeb4:	jbe    f26a <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x16ca>
    eeba:	mov    rcx,QWORD PTR [rsp+0x60]
    eebf:	add    rcx,rdi
    eec2:	mov    QWORD PTR [rsp+0x2a0],rcx
    eeca:	cmp    rdx,0x4
    eece:	jbe    f27a <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x16da>
    eed4:	mov    rcx,QWORD PTR [rsp+0x68]
    eed9:	add    rcx,rdi
    eedc:	mov    QWORD PTR [rsp+0x2c0],rcx
    eee4:	cmp    rdx,0x5
    eee8:	jbe    f28a <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x16ea>
    eeee:	mov    rcx,QWORD PTR [rsp+0x70]
    eef3:	add    rcx,rdi
    eef6:	mov    QWORD PTR [rsp+0x2e0],rcx
    eefe:	cmp    rdx,0x6
    ef02:	jbe    f29a <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x16fa>
    ef08:	mov    rcx,QWORD PTR [rsp+0x78]
    ef0d:	add    rcx,rdi
    ef10:	mov    QWORD PTR [rsp+0x300],rcx
    ef18:	cmp    rdx,0x7
    ef1c:	jbe    f2ad <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x170d>
    ef22:	mov    rcx,QWORD PTR [rsp+0x80]
    ef2a:	add    rcx,rdi
    ef2d:	mov    QWORD PTR [rsp+0x320],rcx
    ef35:	cmp    rdx,0x8
    ef39:	jbe    f2c0 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1720>
    ef3f:	mov    rcx,QWORD PTR [rsp+0x88]
    ef47:	add    rcx,rdi
    ef4a:	mov    QWORD PTR [rsp+0x340],rcx
    ef52:	cmp    rdx,0x9
    ef56:	jbe    f2d3 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1733>
    ef5c:	mov    rcx,QWORD PTR [rsp+0x90]
    ef64:	add    rcx,rdi
    ef67:	mov    QWORD PTR [rsp+0x360],rcx
    ef6f:	cmp    rdx,0xa
    ef73:	jbe    f2e6 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1746>
    ef79:	mov    rcx,QWORD PTR [rsp+0x98]
    ef81:	add    rcx,rdi
    ef84:	mov    QWORD PTR [rsp+0x380],rcx
    ef8c:	cmp    rdx,0xb
    ef90:	jbe    f2f9 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1759>
    ef96:	mov    rcx,QWORD PTR [rsp+0xa0]
    ef9e:	add    rcx,rdi
    efa1:	mov    QWORD PTR [rsp+0x3a0],rcx
    efa9:	cmp    rdx,0xc
    efad:	jbe    f30c <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x176c>
    efb3:	mov    rcx,QWORD PTR [rsp+0xa8]
    efbb:	add    rcx,rdi
    efbe:	mov    QWORD PTR [rsp+0x3c0],rcx
    efc6:	cmp    rdx,0xd
    efca:	jbe    f31f <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x177f>
    efd0:	mov    rcx,QWORD PTR [rsp+0xb0]
    efd8:	lea    rdi,[rax+0x1]
    efdc:	add    rcx,rdi
    efdf:	mov    QWORD PTR [rsp+0x3e0],rcx
    efe7:	cmp    rdx,0xe
    efeb:	jbe    f332 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1792>
    eff1:	mov    rcx,QWORD PTR [rsp+0xb8]
    eff9:	lea    rdi,[rax+0x1]
    effd:	add    rcx,rdi
    f000:	mov    QWORD PTR [rsp+0x400],rcx
    f008:	cmp    rdx,0xf
    f00c:	jbe    f345 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x17a5>
    f012:	mov    rcx,QWORD PTR [rsp+0xc0]
    f01a:	lea    rdi,[rax+0x1]
    f01e:	add    rcx,rdi
    f021:	mov    QWORD PTR [rsp+0x420],rcx
    f029:	cmp    rdx,0x10
    f02d:	jbe    f358 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x17b8>
    f033:	mov    rcx,QWORD PTR [rsp+0xc8]
    f03b:	lea    rdi,[rax+0x1]
    f03f:	add    rcx,rdi
    f042:	mov    QWORD PTR [rsp+0x440],rcx
    f04a:	cmp    rdx,0x11
    f04e:	jbe    f36b <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x17cb>
    f054:	mov    rcx,QWORD PTR [rsp+0xd0]
    f05c:	lea    rdi,[rax+0x1]
    f060:	add    rcx,rdi
    f063:	mov    QWORD PTR [rsp+0x460],rcx
    f06b:	cmp    rdx,0x12
    f06f:	jbe    f37e <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x17de>
    f075:	mov    rcx,QWORD PTR [rsp+0xd8]
    f07d:	lea    rdi,[rax+0x1]
    f081:	add    rcx,rdi
    f084:	mov    QWORD PTR [rsp+0x480],rcx
    f08c:	cmp    rdx,0x13
    f090:	jbe    f391 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x17f1>
    f096:	mov    rcx,QWORD PTR [rsp+0xe0]
    f09e:	lea    rdi,[rax+0x1]
    f0a2:	add    rcx,rdi
    f0a5:	mov    QWORD PTR [rsp+0x4a0],rcx
    f0ad:	cmp    rdx,0x14
    f0b1:	jbe    f3a4 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1804>
    f0b7:	mov    rcx,QWORD PTR [rsp+0xe8]
    f0bf:	lea    rdi,[rax+0x1]
    f0c3:	add    rcx,rdi
    f0c6:	mov    QWORD PTR [rsp+0x4c0],rcx
    f0ce:	cmp    rdx,0x15
    f0d2:	jbe    f3b7 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1817>
    f0d8:	mov    rcx,QWORD PTR [rsp+0xf0]
    f0e0:	lea    rdi,[rax+0x1]
    f0e4:	add    rcx,rdi
    f0e7:	mov    QWORD PTR [rsp+0x4e0],rcx
    f0ef:	cmp    rdx,0x16
    f0f3:	jbe    f3ca <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x182a>
    f0f9:	mov    rcx,QWORD PTR [rsp+0xf8]
    f101:	lea    rdi,[rax+0x1]
    f105:	add    rcx,rdi
    f108:	mov    QWORD PTR [rsp+0x500],rcx
    f110:	cmp    rdx,0x17
    f114:	jbe    f3dd <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x183d>
    f11a:	mov    rcx,QWORD PTR [rsp+0x100]
    f122:	lea    rdi,[rax+0x1]
    f126:	add    rcx,rdi
    f129:	mov    QWORD PTR [rsp+0x520],rcx
    f131:	cmp    rdx,0x18
    f135:	jbe    f3f0 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1850>
    f13b:	mov    rcx,QWORD PTR [rsp+0x108]
    f143:	lea    rdi,[rax+0x1]
    f147:	add    rcx,rdi
    f14a:	mov    QWORD PTR [rsp+0x540],rcx
    f152:	cmp    rdx,0x19
    f156:	jbe    f403 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1863>
    f15c:	mov    rcx,QWORD PTR [rsp+0x110]
    f164:	lea    rdi,[rax+0x1]
    f168:	add    rcx,rdi
    f16b:	mov    QWORD PTR [rsp+0x560],rcx
    f173:	cmp    rdx,0x1a
    f177:	jbe    f416 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1876>
    f17d:	mov    rcx,QWORD PTR [rsp+0x118]
    f185:	lea    rdi,[rax+0x1]
    f189:	add    rcx,rdi
    f18c:	mov    QWORD PTR [rsp+0x580],rcx
    f194:	cmp    rdx,0x1b
    f198:	jbe    f429 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1889>
    f19e:	mov    rcx,QWORD PTR [rsp+0x120]
    f1a6:	lea    rdi,[rax+0x1]
    f1aa:	add    rcx,rdi
    f1ad:	mov    QWORD PTR [rsp+0x5a0],rcx
    f1b5:	cmp    rdx,0x1c
    f1b9:	jbe    f43c <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x189c>
    f1bf:	mov    rcx,QWORD PTR [rsp+0x128]
    f1c7:	lea    rdi,[rax+0x1]
    f1cb:	add    rcx,rdi
    f1ce:	mov    QWORD PTR [rsp+0x5c0],rcx
    f1d6:	cmp    rdx,0x1d
    f1da:	jbe    f44f <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x18af>
    f1e0:	mov    rcx,QWORD PTR [rsp+0x130]
    f1e8:	lea    rdi,[rax+0x1]
    f1ec:	add    rcx,rdi
    f1ef:	mov    QWORD PTR [rsp+0x5e0],rcx
    f1f7:	cmp    rdx,0x1e
    f1fb:	jbe    f462 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x18c2>
    f201:	mov    rax,QWORD PTR [rsp+0x138]
    f209:	mov    rcx,QWORD PTR [rsp]
    f20d:	add    rax,rcx
    f210:	mov    QWORD PTR [rsp+0x600],rax
    f218:	mov    rax,rcx
    f21b:	cmp    rdx,0x20
    f21f:	jae    f462 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x18c2>
    f225:	jmp    f472 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x18d2>
    f22a:	mov    rcx,QWORD PTR [rsp+0x50]
    f22f:	add    rcx,rax
    f232:	mov    QWORD PTR [rsp+0x260],rcx
    f23a:	mov    r9,QWORD PTR [rsp+0x148]
    f242:	mov    rsi,QWORD PTR [rsp+0x170]
    f24a:	mov    rcx,QWORD PTR [rsp+0x58]
    f24f:	add    rcx,rax
    f252:	mov    QWORD PTR [rsp+0x280],rcx
    f25a:	mov    rcx,QWORD PTR [rsp+0x60]
    f25f:	add    rcx,rax
    f262:	mov    QWORD PTR [rsp+0x2a0],rcx
    f26a:	mov    rcx,QWORD PTR [rsp+0x68]
    f26f:	add    rcx,rax
    f272:	mov    QWORD PTR [rsp+0x2c0],rcx
    f27a:	mov    rcx,QWORD PTR [rsp+0x70]
    f27f:	add    rcx,rax
    f282:	mov    QWORD PTR [rsp+0x2e0],rcx
    f28a:	mov    rcx,QWORD PTR [rsp+0x78]
    f28f:	add    rcx,rax
    f292:	mov    QWORD PTR [rsp+0x300],rcx
    f29a:	mov    rcx,QWORD PTR [rsp+0x80]
    f2a2:	add    rcx,rax
    f2a5:	mov    QWORD PTR [rsp+0x320],rcx
    f2ad:	mov    rcx,QWORD PTR [rsp+0x88]
    f2b5:	add    rcx,rax
    f2b8:	mov    QWORD PTR [rsp+0x340],rcx
    f2c0:	mov    rcx,QWORD PTR [rsp+0x90]
    f2c8:	add    rcx,rax
    f2cb:	mov    QWORD PTR [rsp+0x360],rcx
    f2d3:	mov    rcx,QWORD PTR [rsp+0x98]
    f2db:	add    rcx,rax
    f2de:	mov    QWORD PTR [rsp+0x380],rcx
    f2e6:	mov    rcx,QWORD PTR [rsp+0xa0]
    f2ee:	add    rcx,rax
    f2f1:	mov    QWORD PTR [rsp+0x3a0],rcx
    f2f9:	mov    rcx,QWORD PTR [rsp+0xa8]
    f301:	add    rcx,rax
    f304:	mov    QWORD PTR [rsp+0x3c0],rcx
    f30c:	mov    rcx,QWORD PTR [rsp+0xb0]
    f314:	add    rcx,rax
    f317:	mov    QWORD PTR [rsp+0x3e0],rcx
    f31f:	mov    rcx,QWORD PTR [rsp+0xb8]
    f327:	add    rcx,rax
    f32a:	mov    QWORD PTR [rsp+0x400],rcx
    f332:	mov    rcx,QWORD PTR [rsp+0xc0]
    f33a:	add    rcx,rax
    f33d:	mov    QWORD PTR [rsp+0x420],rcx
    f345:	mov    rcx,QWORD PTR [rsp+0xc8]
    f34d:	add    rcx,rax
    f350:	mov    QWORD PTR [rsp+0x440],rcx
    f358:	mov    rcx,QWORD PTR [rsp+0xd0]
    f360:	add    rcx,rax
    f363:	mov    QWORD PTR [rsp+0x460],rcx
    f36b:	mov    rcx,QWORD PTR [rsp+0xd8]
    f373:	add    rcx,rax
    f376:	mov    QWORD PTR [rsp+0x480],rcx
    f37e:	mov    rcx,QWORD PTR [rsp+0xe0]
    f386:	add    rcx,rax
    f389:	mov    QWORD PTR [rsp+0x4a0],rcx
    f391:	mov    rcx,QWORD PTR [rsp+0xe8]
    f399:	add    rcx,rax
    f39c:	mov    QWORD PTR [rsp+0x4c0],rcx
    f3a4:	mov    rcx,QWORD PTR [rsp+0xf0]
    f3ac:	add    rcx,rax
    f3af:	mov    QWORD PTR [rsp+0x4e0],rcx
    f3b7:	mov    rcx,QWORD PTR [rsp+0xf8]
    f3bf:	add    rcx,rax
    f3c2:	mov    QWORD PTR [rsp+0x500],rcx
    f3ca:	mov    rcx,QWORD PTR [rsp+0x100]
    f3d2:	add    rcx,rax
    f3d5:	mov    QWORD PTR [rsp+0x520],rcx
    f3dd:	mov    rcx,QWORD PTR [rsp+0x108]
    f3e5:	add    rcx,rax
    f3e8:	mov    QWORD PTR [rsp+0x540],rcx
    f3f0:	mov    rcx,QWORD PTR [rsp+0x110]
    f3f8:	add    rcx,rax
    f3fb:	mov    QWORD PTR [rsp+0x560],rcx
    f403:	mov    rcx,QWORD PTR [rsp+0x118]
    f40b:	add    rcx,rax
    f40e:	mov    QWORD PTR [rsp+0x580],rcx
    f416:	mov    rcx,QWORD PTR [rsp+0x120]
    f41e:	add    rcx,rax
    f421:	mov    QWORD PTR [rsp+0x5a0],rcx
    f429:	mov    rcx,QWORD PTR [rsp+0x128]
    f431:	add    rcx,rax
    f434:	mov    QWORD PTR [rsp+0x5c0],rcx
    f43c:	mov    rcx,QWORD PTR [rsp+0x130]
    f444:	add    rcx,rax
    f447:	mov    QWORD PTR [rsp+0x5e0],rcx
    f44f:	mov    rcx,QWORD PTR [rsp+0x138]
    f457:	add    rcx,rax
    f45a:	mov    QWORD PTR [rsp+0x600],rcx
    f462:	add    rax,QWORD PTR [rsp+0x140]
    f46a:	mov    QWORD PTR [rsp+0x620],rax
    f472:	shl    rsi,0x5
    f476:	lea    rax,[rsp+rsi*1]
    f47a:	add    rax,0x238
    f480:	mov    QWORD PTR [rsp],rax
    f484:	mov    rax,QWORD PTR [rbx+0x68]
    f488:	mov    rsi,QWORD PTR [rbx+0x70]
    f48c:	lea    r12,[rsp+0x238]
    f494:	jmp    f4ad <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x190d>
    f496:	cs nop WORD PTR [rax+rax*1+0x0]
    f4a0:	mov    r12,r13
    f4a3:	add    r9,0xffffffffffffffe0
    f4a7:	je     f5eb <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1a4b>
    f4ad:	lea    r13,[r12+0x20]
    f4b2:	mov    r15,QWORD PTR [r12]
    f4b6:	cmp    r15,0xffffffffffffffff
    f4ba:	je     f4a0 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1900>
    f4bc:	cmp    r15,rsi
    f4bf:	jae    fb91 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1ff1>
    f4c5:	cmp    QWORD PTR [rax+r15*8],0xffffffffffffffff
    f4ca:	jne    f4a0 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1900>
    f4cc:	mov    edi,0x80
    f4d1:	call   QWORD PTR [rip+0x86a29]        # 95f00 <malloc@GLIBC_2.2.5>
    f4d7:	test   rax,rax
    f4da:	je     fbf5 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x2055>
    f4e0:	mov    rcx,QWORD PTR [r12+0x18]
    f4e5:	mov    QWORD PTR [rax+0x18],rcx
    f4e9:	movups xmm0,XMMWORD PTR [r12+0x8]
    f4ef:	movups XMMWORD PTR [rax+0x8],xmm0
    f4f3:	mov    QWORD PTR [rax],r15
    f4f6:	mov    QWORD PTR [rsp+0x158],0x4
    f502:	mov    QWORD PTR [rsp+0x160],rax
    f50a:	mov    QWORD PTR [rsp+0x168],0x1
    f516:	cmp    r13,QWORD PTR [rsp]
    f51a:	je     f5fd <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1a5d>
    f520:	mov    r12d,0x1
    f526:	lea    r15,[rsp+0x158]
    f52e:	mov    rcx,QWORD PTR [rbx+0x68]
    f532:	mov    rsi,QWORD PTR [rbx+0x70]
    f536:	mov    rdx,r13
    f539:	jmp    f54d <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x19ad>
    f53b:	nop    DWORD PTR [rax+rax*1+0x0]
    f540:	mov    rdx,r13
    f543:	cmp    r13,QWORD PTR [rsp]
    f547:	je     f603 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1a63>
    f54d:	lea    r13,[rdx+0x20]
    f551:	mov    rbp,QWORD PTR [rdx]
    f554:	cmp    rbp,0xffffffffffffffff
    f558:	je     f540 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x19a0>
    f55a:	cmp    rbp,rsi
    f55d:	jae    fba0 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x2000>
    f563:	cmp    QWORD PTR [rcx+rbp*8],0xffffffffffffffff
    f568:	jne    f540 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x19a0>
    f56a:	mov    rcx,QWORD PTR [rdx+0x18]
    f56e:	mov    QWORD PTR [rsp+0x220],rcx
    f576:	movups xmm0,XMMWORD PTR [rdx+0x8]
    f57a:	movaps XMMWORD PTR [rsp+0x210],xmm0
    f582:	cmp    r12,QWORD PTR [rsp+0x158]
    f58a:	jne    f5af <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1a0f>
    f58c:	mov    edx,0x1
    f591:	mov    ecx,0x8
    f596:	mov    r8d,0x20
    f59c:	mov    rdi,r15
    f59f:	mov    rsi,r12
    f5a2:	call   6100 <_RINvNvMs2_NtCs40k4W9msRzi_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs3AlRknvjqqN_7c30walk>
    f5a7:	mov    rax,QWORD PTR [rsp+0x160]
    f5af:	mov    rcx,r12
    f5b2:	shl    rcx,0x5
    f5b6:	mov    QWORD PTR [rax+rcx*1],rbp
    f5ba:	movaps xmm0,XMMWORD PTR [rsp+0x210]
    f5c2:	movups XMMWORD PTR [rax+rcx*1+0x8],xmm0
    f5c7:	mov    rdx,QWORD PTR [rsp+0x220]
    f5cf:	mov    QWORD PTR [rax+rcx*1+0x18],rdx
    f5d4:	inc    r12
    f5d7:	mov    QWORD PTR [rsp+0x168],r12
    f5df:	cmp    r13,QWORD PTR [rsp]
    f5e3:	jne    f52e <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x198e>
    f5e9:	jmp    f603 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1a63>
    f5eb:	mov    eax,0x8
    f5f0:	mov    QWORD PTR [rsp+0x8],rax
    f5f5:	xor    r14d,r14d
    f5f8:	jmp    f911 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1d71>
    f5fd:	mov    r12d,0x1
    f603:	mov    rax,QWORD PTR [rsp+0x158]
    f60b:	mov    QWORD PTR [rsp+0x10],rax
    f610:	mov    rax,QWORD PTR [rsp+0x160]
    f618:	mov    QWORD PTR [rsp+0x8],rax
    f61d:	mov    r15,r12
    f620:	shl    r15,0x5
    f624:	xor    r13d,r13d
    f627:	lea    rax,[rip+0x8387a]        # 92ea8 <__do_global_dtors_aux_fini_array_entry+0x368>
    f62e:	mov    QWORD PTR [rsp+0x30],rax
    f633:	jmp    f65e <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1abe>
    f635:	data16 cs nop WORD PTR [rax+rax*1+0x0]
    f640:	add    rbp,rax
    f643:	mov    rcx,QWORD PTR [rsp+0x8]
    f648:	mov    QWORD PTR [rcx+r13*1+0x8],rbp
    f64d:	add    rdx,rax
    f650:	mov    QWORD PTR [rcx+r13*1+0x10],rdx
    f655:	add    r13,0x20
    f659:	cmp    r15,r13
    f65c:	je     f6d4 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1b34>
    f65e:	mov    rax,QWORD PTR [rsp+0x8]
    f663:	mov    rbp,QWORD PTR [rax+r13*1+0x8]
    f668:	cmp    rbp,QWORD PTR [rax+r13*1+0x10]
    f66d:	jne    f655 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1ab5>
    f66f:	mov    rsi,QWORD PTR [rbx+0x58]
    f673:	mov    rax,QWORD PTR [rsp+0x8]
    f678:	mov    rdi,QWORD PTR [rax+r13*1]
    f67c:	cmp    rdi,rsi
    f67f:	jae    fb80 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1fe0>
    f685:	mov    rcx,QWORD PTR [rbx+0x50]
    f689:	lea    rsi,[rdi+rdi*2]
    f68d:	mov    rdx,QWORD PTR [rcx+rsi*8]
    f691:	mov    rax,QWORD PTR [rcx+rsi*8+0x8]
    f696:	sub    rbp,rax
    f699:	mov    QWORD PTR [rcx+rsi*8+0x10],rbp
    f69e:	mov    rdi,rdx
    f6a1:	sub    rdi,rbp
    f6a4:	cmp    rdx,rdi
    f6a7:	jbe    f640 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1aa0>
    f6a9:	lea    rdi,[rcx+rsi*8]
    f6ad:	mov    ecx,0x1
    f6b2:	mov    r8d,0x1
    f6b8:	mov    QWORD PTR [rsp],rdi
    f6bc:	mov    rsi,rbp
    f6bf:	call   6100 <_RINvNvMs2_NtCs40k4W9msRzi_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs3AlRknvjqqN_7c30walk>
    f6c4:	mov    rax,QWORD PTR [rsp]
    f6c8:	mov    rdx,QWORD PTR [rax]
    f6cb:	mov    rax,QWORD PTR [rax+0x8]
    f6cf:	jmp    f640 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1aa0>
    f6d4:	mov    rax,QWORD PTR [rsp+0x8]
    f6d9:	add    rax,0x18
    f6dd:	mov    QWORD PTR [rsp],rax
    f6e1:	xor    r15d,r15d
    f6e4:	jmp    f6f3 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1b53>
    f6e6:	cs nop WORD PTR [rax+rax*1+0x0]
    f6f0:	xor    r15d,r15d
    f6f3:	mov    r13,r15
    f6f6:	shl    r13,0x5
    f6fa:	add    r13,QWORD PTR [rsp]
    f6fe:	jmp    f71a <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1b7a>
    f700:	add    rbp,rax
    f703:	mov    QWORD PTR [r13-0x10],rbp
    f707:	add    rdx,rax
    f70a:	mov    QWORD PTR [r13-0x8],rdx
    f70e:	inc    r15
    f711:	add    r13,0x20
    f715:	cmp    r15,r12
    f718:	jae    f6f0 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1b50>
    f71a:	lea    rax,[r13-0x18]
    f71e:	mov    ecx,DWORD PTR [r13+0x0]
    f722:	movzx  esi,WORD PTR [r14+rcx*2]
    f727:	mov    edx,ecx
    f729:	and    edx,0xffffffe0
    f72c:	mov    edx,DWORD PTR [r14+rdx*2+0x3c]
    f731:	cmp    esi,0xfffe
    f737:	jae    f750 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1bb0>
    f739:	mov    ecx,edx
    f73b:	shr    ecx,0x8
    f73e:	add    ecx,esi
    f740:	jmp    f771 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1bd1>
    f742:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
    f750:	je     f800 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1c60>
    f756:	cmp    ecx,DWORD PTR [rsp+0x24]
    f75a:	jne    f890 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1cf0>
    f760:	mov    ecx,DWORD PTR [r13+0x4]
    f764:	mov    rdx,QWORD PTR [rsp+0x38]
    f769:	mov    edx,DWORD PTR [rdx+rcx*4]
    f76c:	mov    ecx,edx
    f76e:	shr    ecx,0x8
    f771:	mov    DWORD PTR [r13+0x0],ecx
    f775:	mov    ecx,ecx
    f777:	prefetcht0 BYTE PTR [r14+rcx*2]
    f77c:	mov    rcx,QWORD PTR [r13-0x10]
    f780:	mov    BYTE PTR [rcx],dl
    f782:	mov    rbp,QWORD PTR [r13-0x10]
    f786:	inc    rbp
    f789:	mov    QWORD PTR [r13-0x10],rbp
    f78d:	cmp    rbp,QWORD PTR [r13-0x8]
    f791:	jne    f70e <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1b6e>
    f797:	mov    rsi,QWORD PTR [rbx+0x58]
    f79b:	mov    rdi,QWORD PTR [rax]
    f79e:	cmp    rdi,rsi
    f7a1:	jae    fb80 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1fe0>
    f7a7:	mov    rcx,QWORD PTR [rbx+0x50]
    f7ab:	lea    rsi,[rdi+rdi*2]
    f7af:	mov    rdx,QWORD PTR [rcx+rsi*8]
    f7b3:	mov    rax,QWORD PTR [rcx+rsi*8+0x8]
    f7b8:	sub    rbp,rax
    f7bb:	mov    QWORD PTR [rcx+rsi*8+0x10],rbp
    f7c0:	mov    rdi,rdx
    f7c3:	sub    rdi,rbp
    f7c6:	cmp    rdx,rdi
    f7c9:	jbe    f700 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1b60>
    f7cf:	lea    rdi,[rcx+rsi*8]
    f7d3:	mov    ecx,0x1
    f7d8:	mov    r8d,0x1
    f7de:	mov    QWORD PTR [rsp+0x40],rdi
    f7e3:	mov    rsi,rbp
    f7e6:	call   6100 <_RINvNvMs2_NtCs40k4W9msRzi_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs3AlRknvjqqN_7c30walk>
    f7eb:	mov    rax,QWORD PTR [rsp+0x40]
    f7f0:	mov    rdx,QWORD PTR [rax]
    f7f3:	mov    rax,QWORD PTR [rax+0x8]
    f7f7:	jmp    f700 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1b60>
    f7fc:	nop    DWORD PTR [rax+0x0]
    f800:	mov    rsi,QWORD PTR [rbx+0x58]
    f804:	mov    rdi,QWORD PTR [rax]
    f807:	cmp    rdi,rsi
    f80a:	jae    fb74 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1fd4>
    f810:	mov    r8,QWORD PTR [rbx+0x50]
    f814:	mov    rdx,QWORD PTR [rbx+0x68]
    f818:	lea    r9,[rdi+rdi*2]
    f81c:	mov    r10,QWORD PTR [rax+0x8]
    f820:	sub    r10,QWORD PTR [r8+r9*8+0x8]
    f825:	mov    rsi,QWORD PTR [rbx+0x70]
    f829:	mov    QWORD PTR [r8+r9*8+0x10],r10
    f82e:	mov    r10,QWORD PTR [rbx+0x40]
    f832:	test   r10,r10
    f835:	je     f8c1 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1d21>
    f83b:	mov    r9,QWORD PTR [rbx+0x38]
    f83f:	xor    r8d,r8d
    f842:	cmp    r10,0x1
    f846:	je     f86d <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1ccd>
    f848:	nop    DWORD PTR [rax+rax*1+0x0]
    f850:	mov    r11,r8
    f853:	mov    rbx,r10
    f856:	shr    rbx,1
    f859:	add    r8,rbx
    f85c:	cmp    DWORD PTR [r9+r8*4],ecx
    f860:	cmova  r8,r11
    f864:	sub    r10,rbx
    f867:	cmp    r10,0x1
    f86b:	ja     f850 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1cb0>
    f86d:	cmp    DWORD PTR [r9+r8*4],ecx
    f871:	mov    rcx,0xffffffffffffffff
    f878:	cmovne r8,rcx
    f87c:	mov    rbx,QWORD PTR [rsp+0x18]
    f881:	cmp    rdi,rsi
    f884:	jb     f8d1 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1d31>
    f886:	jmp    fb6b <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1fcb>
    f88b:	nop    DWORD PTR [rax+rax*1+0x0]
    f890:	shl    edx,0x5
    f893:	and    edx,0x1ffffe0
    f899:	and    ecx,0x1f
    f89c:	or     ecx,edx
    f89e:	mov    DWORD PTR [r13+0x4],ecx
    f8a2:	mov    rax,QWORD PTR [rsp+0x38]
    f8a7:	prefetcht0 BYTE PTR [rax+rcx*4]
    f8ab:	mov    eax,DWORD PTR [rsp+0x24]
    f8af:	mov    DWORD PTR [r13+0x0],eax
    f8b3:	inc    r15
    f8b6:	cmp    r15,r12
    f8b9:	jb     f6f3 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1b53>
    f8bf:	jmp    f8fd <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1d5d>
    f8c1:	mov    r8,0xffffffffffffffff
    f8c8:	cmp    rdi,rsi
    f8cb:	jae    fb6b <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1fcb>
    f8d1:	mov    QWORD PTR [rdx+rdi*8],r8
    f8d5:	dec    r12
    f8d8:	mov    rcx,r12
    f8db:	shl    rcx,0x5
    f8df:	mov    rdx,QWORD PTR [rsp+0x8]
    f8e4:	movups xmm0,XMMWORD PTR [rdx+rcx*1]
    f8e8:	movups xmm1,XMMWORD PTR [rdx+rcx*1+0x10]
    f8ed:	movups XMMWORD PTR [rax+0x10],xmm1
    f8f1:	movups XMMWORD PTR [rax],xmm0
    f8f4:	cmp    r15,r12
    f8f7:	jb     f6f3 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1b53>
    f8fd:	mov    r15d,0x0
    f903:	test   r12,r12
    f906:	jne    f6f3 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1b53>
    f90c:	mov    r14,QWORD PTR [rsp+0x10]
    f911:	xor    eax,eax
    f913:	lea    rcx,[rip+0x8325e]        # 92b78 <__do_global_dtors_aux_fini_array_entry+0x38>
    f91a:	lea    r8,[rip+0x8326f]        # 92b90 <__do_global_dtors_aux_fini_array_entry+0x50>
    f921:	lea    r9,[rip+0x83280]        # 92ba8 <__do_global_dtors_aux_fini_array_entry+0x68>
    f928:	lea    rdx,[rip+0x83291]        # 92bc0 <__do_global_dtors_aux_fini_array_entry+0x80>
    f92f:	mov    r11,QWORD PTR [rsp+0x28]
    f934:	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
    f940:	mov    rsi,QWORD PTR [rbx+0x40]
    f944:	cmp    rax,rsi
    f947:	jae    fb0a <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1f6a>
    f94d:	mov    rsi,QWORD PTR [rbx+0x98]
    f954:	cmp    rax,rsi
    f957:	jae    fb02 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1f62>
    f95d:	mov    rsi,QWORD PTR [rbx+0x38]
    f961:	mov    edi,DWORD PTR [rsi+rax*4]
    f964:	mov    rsi,QWORD PTR [rbx+0x10]
    f968:	mov    r10d,edi
    f96b:	shr    r10d,0x5
    f96f:	cmp    rsi,r10
    f972:	jbe    fafa <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1f5a>
    f978:	and    edi,0x1f
    f97b:	cmp    edi,0x1d
    f97e:	ja     faf3 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1f53>
    f984:	mov    rsi,QWORD PTR [rbx+0x90]
    f98b:	movzx  esi,WORD PTR [rsi+rax*2]
    f98f:	inc    rax
    f992:	shl    r10,0x6
    f996:	add    r10,QWORD PTR [rbx+0x8]
    f99a:	mov    WORD PTR [r10+rdi*2],si
    f99f:	cmp    r11,rax
    f9a2:	jne    f940 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1da0>
    f9a4:	mov    rax,QWORD PTR [rbx+0x38]
    f9a8:	mov    rcx,QWORD PTR [rbx+0x40]
    f9ac:	mov    edi,DWORD PTR [rsp+0x154]
    f9b3:	mov    esi,edi
    f9b5:	mov    edx,0x88888889
    f9ba:	imul   rdx,rsi
    f9be:	shr    rdx,0x23
    f9c2:	and    edx,0xfffffffe
    f9c5:	add    edx,edi
    f9c7:	cmp    rcx,0x1
    f9cb:	je     f9fe <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1e5e>
    f9cd:	test   rcx,rcx
    f9d0:	je     fbc4 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x2024>
    f9d6:	xor    esi,esi
    f9d8:	nop    DWORD PTR [rax+rax*1+0x0]
    f9e0:	mov    rdi,rsi
    f9e3:	mov    r8,rcx
    f9e6:	shr    r8,1
    f9e9:	add    rsi,r8
    f9ec:	cmp    DWORD PTR [rax+rsi*4],edx
    f9ef:	cmova  rsi,rdi
    f9f3:	sub    rcx,r8
    f9f6:	cmp    rcx,0x1
    f9fa:	ja     f9e0 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1e40>
    f9fc:	jmp    fa00 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1e60>
    f9fe:	xor    esi,esi
    fa00:	cmp    DWORD PTR [rax+rsi*4],edx
    fa03:	jne    fbbd <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x201d>
    fa09:	mov    QWORD PTR [rbx+0x80],rsi
    fa10:	mov    rax,QWORD PTR [rsp+0x178]
    fa18:	mov    QWORD PTR [rbx+0x78],rax
    fa1c:	test   r14,r14
    fa1f:	je     fa2c <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1e8c>
    fa21:	mov    rdi,QWORD PTR [rsp+0x8]
    fa26:	call   QWORD PTR [rip+0x8635c]        # 95d88 <free@GLIBC_2.2.5>
    fa2c:	add    rsp,0x638
    fa33:	pop    rbx
    fa34:	pop    r12
    fa36:	pop    r13
    fa38:	pop    r14
    fa3a:	pop    r15
    fa3c:	pop    rbp
    fa3d:	ret
    fa3e:	lea    rcx,[rip+0x83193]        # 92bd8 <__do_global_dtors_aux_fini_array_entry+0x98>
    fa45:	xor    edi,edi
    fa47:	call   7a70 <_RNvNtNtCscI6d9CVNmLh_4core5slice5index16slice_index_fail>
    fa4c:	lea    rdi,[rbx+0x60]
    fa50:	mov    ecx,0x8
    fa55:	mov    r8d,0x8
    fa5b:	xor    esi,esi
    fa5d:	mov    rdx,r12
    fa60:	call   6100 <_RINvNvMs2_NtCs40k4W9msRzi_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs3AlRknvjqqN_7c30walk>
    fa65:	mov    r15,QWORD PTR [rbx+0x70]
    fa69:	jmp    dfa6 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x406>
    fa6e:	lea    rdx,[rip+0x831db]        # 92c50 <__do_global_dtors_aux_fini_array_entry+0x110>
    fa75:	mov    rdi,r12
    fa78:	call   79fb <_RNvNtCscI6d9CVNmLh_4core9panicking18panic_bounds_check>
    fa7d:	lea    rdx,[rip+0x83f1c]        # 939a0 <__do_global_dtors_aux_fini_array_entry+0xe60>
    fa84:	mov    esi,0x1e
    fa89:	mov    rdi,rbp
    fa8c:	call   79fb <_RNvNtCscI6d9CVNmLh_4core9panicking18panic_bounds_check>
    fa91:	lea    rdx,[rip+0x83ef0]        # 93988 <__do_global_dtors_aux_fini_array_entry+0xe48>
    fa98:	mov    rdi,r12
    fa9b:	call   79fb <_RNvNtCscI6d9CVNmLh_4core9panicking18panic_bounds_check>
    faa0:	lea    rdx,[rip+0x83191]        # 92c38 <__do_global_dtors_aux_fini_array_entry+0xf8>
    faa7:	call   79fb <_RNvNtCscI6d9CVNmLh_4core9panicking18panic_bounds_check>
    faac:	lea    rdx,[rip+0x8316d]        # 92c20 <__do_global_dtors_aux_fini_array_entry+0xe0>
    fab3:	mov    esi,0x1e
    fab8:	mov    rdi,rax
    fabb:	call   79fb <_RNvNtCscI6d9CVNmLh_4core9panicking18panic_bounds_check>
    fac0:	lea    rdx,[rip+0x83141]        # 92c08 <__do_global_dtors_aux_fini_array_entry+0xc8>
    fac7:	mov    rdi,rcx
    faca:	call   79fb <_RNvNtCscI6d9CVNmLh_4core9panicking18panic_bounds_check>
    facf:	lea    rdx,[rip+0x8311a]        # 92bf0 <__do_global_dtors_aux_fini_array_entry+0xb0>
    fad6:	call   79fb <_RNvNtCscI6d9CVNmLh_4core9panicking18panic_bounds_check>
    fadb:	lea    rdx,[rip+0x8337e]        # 92e60 <__do_global_dtors_aux_fini_array_entry+0x320>
    fae2:	call   79fb <_RNvNtCscI6d9CVNmLh_4core9panicking18panic_bounds_check>
    fae7:	lea    rdx,[rip+0x8335a]        # 92e48 <__do_global_dtors_aux_fini_array_entry+0x308>
    faee:	call   79fb <_RNvNtCscI6d9CVNmLh_4core9panicking18panic_bounds_check>
    faf3:	mov    esi,0x1e
    faf8:	jmp    fb10 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1f70>
    fafa:	mov    rdi,r10
    fafd:	mov    rdx,r9
    fb00:	jmp    fb10 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1f70>
    fb02:	mov    rdi,rax
    fb05:	mov    rdx,r8
    fb08:	jmp    fb10 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1f70>
    fb0a:	mov    rdi,rax
    fb0d:	mov    rdx,rcx
    fb10:	call   79fb <_RNvNtCscI6d9CVNmLh_4core9panicking18panic_bounds_check>
    fb15:	jmp    fbf3 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x2053>
    fb1a:	lea    rdx,[rip+0x83387]        # 92ea8 <__do_global_dtors_aux_fini_array_entry+0x368>
    fb21:	call   79fb <_RNvNtCscI6d9CVNmLh_4core9panicking18panic_bounds_check>
    fb26:	lea    rdx,[rip+0x83e8b]        # 939b8 <__do_global_dtors_aux_fini_array_entry+0xe78>
    fb2d:	mov    rdi,r13
    fb30:	call   79fb <_RNvNtCscI6d9CVNmLh_4core9panicking18panic_bounds_check>
    fb35:	lea    rdx,[rip+0x83354]        # 92e90 <__do_global_dtors_aux_fini_array_entry+0x350>
    fb3c:	call   79fb <_RNvNtCscI6d9CVNmLh_4core9panicking18panic_bounds_check>
    fb41:	lea    rdx,[rip+0x83330]        # 92e78 <__do_global_dtors_aux_fini_array_entry+0x338>
    fb48:	call   79fb <_RNvNtCscI6d9CVNmLh_4core9panicking18panic_bounds_check>
    fb4d:	lea    rdx,[rip+0x8330c]        # 92e60 <__do_global_dtors_aux_fini_array_entry+0x320>
    fb54:	mov    rdi,rbp
    fb57:	call   79fb <_RNvNtCscI6d9CVNmLh_4core9panicking18panic_bounds_check>
    fb5c:	lea    rdx,[rip+0x832e5]        # 92e48 <__do_global_dtors_aux_fini_array_entry+0x308>
    fb63:	mov    rdi,rbp
    fb66:	call   79fb <_RNvNtCscI6d9CVNmLh_4core9panicking18panic_bounds_check>
    fb6b:	lea    rax,[rip+0x8331e]        # 92e90 <__do_global_dtors_aux_fini_array_entry+0x350>
    fb72:	jmp    fb7b <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x1fdb>
    fb74:	lea    rax,[rip+0x832fd]        # 92e78 <__do_global_dtors_aux_fini_array_entry+0x338>
    fb7b:	mov    QWORD PTR [rsp+0x30],rax
    fb80:	mov    rdx,QWORD PTR [rsp+0x30]
    fb85:	mov    r14,QWORD PTR [rsp+0x10]
    fb8a:	call   79fb <_RNvNtCscI6d9CVNmLh_4core9panicking18panic_bounds_check>
    fb8f:	jmp    fbf3 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x2053>
    fb91:	lea    rdx,[rip+0x83328]        # 92ec0 <__do_global_dtors_aux_fini_array_entry+0x380>
    fb98:	mov    rdi,r15
    fb9b:	call   79fb <_RNvNtCscI6d9CVNmLh_4core9panicking18panic_bounds_check>
    fba0:	lea    rdx,[rip+0x83319]        # 92ec0 <__do_global_dtors_aux_fini_array_entry+0x380>
    fba7:	mov    rdi,rbp
    fbaa:	call   79fb <_RNvNtCscI6d9CVNmLh_4core9panicking18panic_bounds_check>
    fbaf:	jmp    fbf3 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x2053>
    fbb1:	lea    rdi,[rip+0x82f90]        # 92b48 <__do_global_dtors_aux_fini_array_entry+0x8>
    fbb8:	call   7d00 <_RNvNtNtCscI6d9CVNmLh_4core9panicking11panic_const23panic_const_div_by_zero>
    fbbd:	adc    rsi,0x0
    fbc1:	mov    rcx,rsi
    fbc4:	mov    QWORD PTR [rsp+0x210],rcx
    fbcc:	lea    rdi,[rip+0x72d20]        # 828f3 <_fini+0x4b57>
    fbd3:	lea    rcx,[rip+0x83d4e]        # 93928 <__do_global_dtors_aux_fini_array_entry+0xde8>
    fbda:	lea    r8,[rip+0x82f7f]        # 92b60 <__do_global_dtors_aux_fini_array_entry+0x20>
    fbe1:	lea    rdx,[rsp+0x210]
    fbe9:	mov    esi,0x19
    fbee:	call   7c00 <_RNvNtCscI6d9CVNmLh_4core6result13unwrap_failed>
    fbf3:	ud2
    fbf5:	mov    edi,0x8
    fbfa:	mov    esi,0x80
    fbff:	call   7715 <_RNvNtCs40k4W9msRzi_5alloc7raw_vec12handle_error>
    fc04:	jmp    fc08 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x2068>
    fc06:	jmp    fc12 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x2072>
    fc08:	mov    rbx,rax
    fc0b:	mov    r14,QWORD PTR [rsp+0x10]
    fc10:	jmp    fc32 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x2092>
    fc12:	mov    rbx,rax
    fc15:	cmp    QWORD PTR [rsp+0x158],0x0
    fc1e:	je     fc42 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x20a2>
    fc20:	mov    rax,QWORD PTR [rsp+0x160]
    fc28:	mov    QWORD PTR [rsp+0x8],rax
    fc2d:	jmp    fc37 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x2097>
    fc2f:	mov    rbx,rax
    fc32:	test   r14,r14
    fc35:	je     fc42 <_RINvMs0_Cs3AlRknvjqqN_7c30walkNtB6_3C304roomKb0_EB6_+0x20a2>
    fc37:	mov    rdi,QWORD PTR [rsp+0x8]
    fc3c:	call   QWORD PTR [rip+0x86146]        # 95d88 <free@GLIBC_2.2.5>
    fc42:	mov    rdi,rbx
    fc45:	call   6040 <_Unwind_Resume@plt>
    fc4a:	nop    WORD PTR [rax+rax*1+0x0]
