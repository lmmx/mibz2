"""Step 4. Counts against the BWT's induction; what the ABWT's grammar is.

Run: python3 step4_compare.py [seed]

(a) for every primitive word over 2 letters to length 12 and 3 letters to length 8, by
    length: runs r and steps S of the right-end induction, for the BWT and the ABWT, and
    the steps by kind (top wins / bottom wins / equal).
(b) on the same words and on 5,000 random primitive words (2 to 8 letters, length to 60):
    B1. the derivation tree of the ABWT's grammar == the min-Cartesian tree of
        key(j) = the alternating-order rank of the rotation that starts at G[j], 0 < j < n,
        over G = the least rotation in the alternating order;
    B2. the rule of step [m', m) sits at exactly the nodes with key in [m', m);
    B3. every rule N -> X Y: exp(Y) is the least proper suffix of exp(N) in the order of
        Definition 6.1 (the alternating order extended to words of different lengths);
    B4. every rule's expansion classed: 'G' a Galois word (Definition 7.1), 'GG' the
        square of a Galois word of odd length, 'other';
    B5. for comparison, two other readings of "standard factorisation": exp(Y) is the
        longest proper suffix that is a Galois word; exp(Y) is the longest proper suffix
        that is 'G' or 'GG'. Counted, not asserted;
    B6. the suffixes of G in the order of Definition 6.1 are in the order of the
        rotations (Proposition 7.5 of arXiv:1907.02308v1), as a check of this code's
        Definition 6.1.
    The same B1, B2 with the usual order for the BWT, and "every rule's expansion is a
    Lyndon word", as a control (the entry's Theorems 1 and 2).
"""
import random
import sys
from collections import Counter

from abwt import (all_words, primitive, transform, lf_formula, induce, cartesian, flatten,
                  alt_less, is_galois, is_lyndon, classify_alt)


def tree_checks(T, c, gal_cache):
    n = len(T)
    TT = T + T
    for alt in (True, False):
        name = 'abwt' if alt else 'bwt'
        L, I, SA, ISA = transform(T, alt)
        res = induce(L, alt)
        g = res['g']
        root = res['closed'][0][0]
        G = TT[SA[0]:SA[0] + n]
        key = [ISA[(SA[0] + j) % n] for j in range(n)]
        ct, at = cartesian(G, key)
        # B1
        assert g.tree(root) == ct, (T, alt)
        c[name, 'B1 trees equal'] += 1
        # B2
        covered = 0
        for (m2, m, kind, N) in res['steps']:
            t = g.tree(N)
            for y in range(m2, m):
                assert at[y] == t, (T, alt, y)
                covered += 1
        assert covered == n - 1
        c[name, 'B2 nodes'] += covered
        for (m2, m, kind, N) in res['steps']:
            x, y = g.rules[N - g.BASE]
            w = g.expand(N)
            wy = g.expand(y)
            c[name, 'rules'] += 1
            if not alt:
                assert is_lyndon(w), (T, w)
                assert all(wy <= w[d:] for d in range(1, len(w)))
                c[name, 'rule is Lyndon, right child the least proper suffix'] += 1
                continue
            # B3
            sufs = [w[d:] for d in range(1, len(w))]
            least = sufs[0]
            for s in sufs[1:]:
                if alt_less(s, least):
                    least = s
            assert least == wy, (T, w, wy, least)
            c[name, 'B3 right child is the least proper suffix (Def. 6.1)'] += 1
            # B4
            if w not in gal_cache:
                gal_cache[w] = classify_alt(w)
            cl = gal_cache[w]
            c[name, 'B4 rule expansion class ' + cl] += 1
            if cl == 'other':
                c['first other'] = c.get('first other') or 0
                raise AssertionError(("a word that is neither G nor GG", T, w))
            # B5
            def cls(s):
                if s not in gal_cache:
                    gal_cache[s] = classify_alt(s)
                return gal_cache[s]
            longest_G = next(s for s in sufs if cls(s) == 'G')
            longest_GGG = next(s for s in sufs if cls(s) in ('G', 'GG'))
            c[name, 'B5 right child == longest Galois proper suffix: ' + str(longest_G == wy)] += 1
            c[name, 'B5 right child == longest G-or-GG proper suffix: ' + str(longest_GGG == wy)] += 1
            if longest_G != wy and ('ex', 'G') not in c:
                c['ex', 'G'] = 1
                print("   first rule whose right child is not the longest Galois proper suffix:",
                      "text", T, "rule word", w, "right child", wy, "longest Galois suffix", longest_G)
            if longest_GGG != wy and ('ex', 'GGG') not in c:
                c['ex', 'GGG'] = 1
                print("   first rule whose right child is not the longest G-or-GG proper suffix:",
                      "text", T, "rule word", w, "right child", wy, "longest", longest_GGG)
        if alt:
            # B6
            order = sorted(range(n), key=lambda p: key[p])
            for a, b in zip(order, order[1:]):
                assert alt_less(G[a:], G[b:]), (T, G, a, b)
            c[name, 'B6 suffix order == rotation order'] += 1


def main():
    seed = int(sys.argv[1]) if len(sys.argv) > 1 else 20261110
    rng = random.Random(seed)
    print("(a) sums over all primitive words of each length")
    print("sigma  n  words |  r_bwt  r_abwt |  S_bwt (T/B/E)            | S_abwt (T/B/E)"
          "            | S_abwt<S_bwt  =  >  | r_abwt<r_bwt  =  >")
    tot = Counter()
    for sigma, nmax in ((2, 12), (3, 8)):
        for n in range(1, nmax + 1):
            c = Counter()
            for T in all_words(sigma, n):
                if not primitive(T):
                    continue
                c['w'] += 1
                out = {}
                for alt in (True, False):
                    L, I, SA, ISA = transform(T, alt)
                    res = induce(L, alt)
                    assert res['cnt']['E'] == res['r'] - 1
                    out[alt] = res
                    nm = 'a' if alt else 'b'
                    c['r' + nm] += res['r']
                    c['S' + nm] += res['S']
                    for k in 'TBE':
                        c[k + nm] += res['cnt'][k]
                sa, sb = out[True]['S'], out[False]['S']
                c['S<' if sa < sb else 'S=' if sa == sb else 'S>'] += 1
                ra, rb = out[True]['r'], out[False]['r']
                c['r<' if ra < rb else 'r=' if ra == rb else 'r>'] += 1
            print(f"{sigma:5d} {n:2d} {c['w']:6d} | {c['rb']:6d} {c['ra']:6d} | "
                  f"{c['Sb']:6d} ({c['Tb']}/{c['Bb']}/{c['Eb']}) | "
                  f"{c['Sa']:6d} ({c['Ta']}/{c['Ba']}/{c['Ea']}) | "
                  f"{c['S<']:6d} {c['S=']:6d} {c['S>']:6d} | {c['r<']:6d} {c['r=']:6d} {c['r>']:6d}")
            tot.update(c)
    print("TOTAL", dict(sorted(tot.items())))
    print("(b) trees")
    c = Counter()
    cache = {}
    for sigma, nmax in ((2, 12), (3, 8)):
        for n in range(1, nmax + 1):
            for T in all_words(sigma, n):
                if primitive(T):
                    tree_checks(T, c, cache)
                    c['words'] += 1
    for k in sorted(c, key=str):
        print("   exhaustive", k, c[k])
    c = Counter()
    done = 0
    while done < 5000:
        sigma = rng.randint(2, 8)
        n = rng.randint(1, 60)
        T = tuple(rng.randrange(sigma) for _ in range(n))
        if not primitive(T):
            continue
        tree_checks(T, c, cache)
        c['words'] += 1
        done += 1
    for k in sorted(c, key=str):
        print("   random", k, c[k])
    print("all assertions passed; seed", seed)


if __name__ == '__main__':
    main()
