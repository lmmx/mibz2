"""Step 3. The Rauzy induction with flips inverts the ABWT.

Run: python3 step3_induction.py [seed]

(a) every primitive word over 2 letters to length 12 and 3 letters to length 8;
(b) 20,000 random primitive words over 2 to 8 letters of length 1 to 60 (a draw that is not
    primitive is counted and drawn again: the ABWT is defined for primitive words);
(c) 20,000 random COLUMNS (any letters, any row), length 1 to 40, 2 to 5 letters: LF by
    eq. (3) has several cycles; the induction closes a letter at a time (README, "A = B").
Asserted on each word of (a), (b):
  1. the induction ends on one letter of one row; its word's expansion E is the least
     rotation in the alternating order (row 0 of the sorted matrix);
  2. with the row I followed as (alpha, o, v): T[k] = E[(k - v) mod n] for all k;
  3. f_alpha = |w_alpha| mod 2 for every letter at the end of every step;
  4. the linked-orders form makes the same rules in the same order;
  5. (a) to length 10 / 7, and every 20th word of (b): Invariant I' by brute force after
     every step (first return of every point of every letter: image, time, word read).
Asserted on each column of (c):
  6. the n bytes T[k] = L[LF^{-(k+1)}(ptr)] equal w[(k - v) mod |w|], w the closing letter
     that holds ptr;
  7. Invariant I' after every step and every drop;
  8. letters closed before the walk's: (word, lam, f) accounts for cycles of LF exactly:
     f = 0 -> lam cycles spelling w; f = 1 -> lam // 2 cycles spelling ww and, if lam is
     odd, one spelling w. The closed cycles are distinct cycles of LF (multiset inclusion).
The same (1, 2, 4, 5) is asserted for the BWT with alt=False, as a control of the code.
"""
import random
import sys
from collections import Counter

from abwt import (all_words, primitive, transform, lf_formula, runs_of, walk_arbitrary,
                  induce, induce_linked, make_checker, expand_rules, alt_key)


def necklace(w):
    return min(w[d:] + w[:d] for d in range(len(w)))


def cycles_of(L, LF):
    """Multiset of necklaces: each cycle of LF read as L[x], L[LF x], ... reversed."""
    n = len(L)
    seen = [False] * n
    out = Counter()
    for s in range(n):
        if seen[s]:
            continue
        read, x = [], s
        while not seen[x]:
            seen[x] = True
            read.append(L[x])
            x = LF[x]
        out[necklace(tuple(reversed(read)))] += 1
    return out


def one_word(T, alt, c, deep):
    n = len(T)
    L, I, SA, ISA = transform(T, alt)
    LF = lf_formula(L, alt)
    res = induce(L, alt, ptr=I, check=make_checker(L, LF) if deep else None)
    g = res['g']
    assert len(res['closed']) == 1, (T, alt)
    sym, lam, f, m = res['closed'][0]
    assert lam == 1 and m == 1, (T, alt)
    E = g.expand(sym)
    TT = T + T
    assert E == TT[SA[0]:SA[0] + n], (T, alt, E)
    sym2, v = res['result']
    assert sym2 == sym
    assert all(T[k] == E[(k - v) % n] for k in range(n)), (T, alt, E, v)
    if alt:
        assert f == n % 2
    rules, root, cnt = induce_linked(L, alt)
    assert rules == g.rules and cnt == res['cnt'], (T, alt)
    assert tuple(expand_rules(rules, root)) == E
    name = 'abwt' if alt else 'bwt'
    c[name, 'words'] += 1
    c[name, 'steps'] += res['S']
    c[name, 'runs'] += res['r']
    if deep:
        c[name, 'deep'] += 1
    return res


def main():
    seed = int(sys.argv[1]) if len(sys.argv) > 1 else 20261110
    rng = random.Random(seed)
    c = Counter()
    # (a)
    for sigma, nmax, deepmax in ((2, 12, 10), (3, 8, 7)):
        for n in range(1, nmax + 1):
            for T in all_words(sigma, n):
                if primitive(T):
                    for alt in (True, False):
                        one_word(T, alt, c, n <= deepmax)
    print("(a) exhaustive:", {k: v for k, v in sorted(c.items())})
    # (b)
    c = Counter()
    done = rejected = 0
    while done < 20000:
        sigma = rng.randint(2, 8)
        n = rng.randint(1, 60)
        T = tuple(rng.randrange(sigma) for _ in range(n))
        if not primitive(T):
            rejected += 1
            continue
        for alt in (True, False):
            one_word(T, alt, c, done % 20 == 0)
        done += 1
    print(f"(b) random primitive words: {done} (rejected as not primitive: {rejected}):",
          {k: v for k, v in sorted(c.items())})
    # (c)
    c = Counter()
    for t in range(20000):
        sigma = rng.randint(2, 5)
        n = rng.randint(1, 40)
        L = tuple(rng.randrange(sigma) for _ in range(n))
        ptr = rng.randrange(n)
        for alt in (True, False):
            name = 'abwt' if alt else 'bwt'
            LF = lf_formula(L, alt)
            res = induce(L, alt, ptr=ptr, check=make_checker(L, LF))
            g = res['g']
            sym, v = res['result']
            w = g.expand(sym)
            want = walk_arbitrary(L, LF, ptr)
            got = tuple(w[(k - v) % len(w)] for k in range(n))
            assert got == want, (L, ptr, alt)
            cyc = cycles_of(L, LF)
            closed = Counter()
            for (s, lam, f, m) in res['closed']:
                u = g.expand(s)
                if alt:
                    assert f == len(u) % 2
                if f == 0:
                    closed[necklace(u)] += lam
                else:
                    if lam // 2:
                        closed[necklace(u + u)] += lam // 2
                    if lam % 2:
                        closed[necklace(u)] += 1
                    if lam >= 2:
                        c[name, 'closed flipped letter with lam >= 2'] += 1
            for k, mlt in closed.items():
                assert cyc[k] >= mlt, (L, ptr, alt, k)
            c[name, 'columns'] += 1
            c[name, 'steps'] += res['S']
            if len(cyc) > 1 or sum(cyc.values()) > 1:
                c[name, 'columns with several cycles'] += 1
            if len(res['closed']) > 1:
                c[name, 'columns with a letter dropped'] += 1
            c[name, 'letters closed'] += len(res['closed'])
    print("(c) random columns:", {k: v for k, v in sorted(c.items())})
    print("all assertions passed; seed", seed)


if __name__ == '__main__':
    main()
