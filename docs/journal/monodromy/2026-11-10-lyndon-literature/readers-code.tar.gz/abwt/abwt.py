"""Alternating BWT (ABWT), its LF map, and Rauzy induction with flips at the right endpoint.

Definitions implemented (locators in README):
  * alternating order on words of one length: first difference at index i (0-based);
    i even -> the smaller letter is smaller, i odd -> the larger letter is smaller
    (Giancarlo-Manzini-Restivo-Rosone-Sciortino, arXiv:1907.02308v1, Section 2).
  * ABWT of a primitive word: last column of the rotations sorted in that order, and the
    row I of the word (same paper, Section 3).
  * LF for the ABWT: LF(i) = sum_{c <= L[i]} P[c] - rank_{L[i]}(L, i-1) - 1 (eq. (3)),
    and w[n-1-j] = L[LF^j(I)] (eq. (1)).
  * alternating order on words of different lengths (Definition 6.1), Galois word
    (Definition 7.1).

Nothing here is timed. Words are tuples of small ints.
"""
import itertools
import random
import sys
from collections import Counter

sys.setrecursionlimit(1000000)


# ---------------------------------------------------------------- words and orders

def primitive(T):
    n = len(T)
    return all(n % d or T[d:] + T[:d] != T for d in range(1, n))


def alt_key(seq):
    """Sort key realising the alternating order on words of one length."""
    return tuple(c if i % 2 == 0 else -c for i, c in enumerate(seq))


def alt_less(x, y):
    """x strictly below y in the alternating order extended to different lengths
    (arXiv:1907.02308v1, Definition 6.1). x != y."""
    k = min(len(x), len(y))
    for i in range(k):
        if x[i] != y[i]:
            return (x[i] < y[i]) if i % 2 == 0 else (x[i] > y[i])
    assert len(x) != len(y)
    if len(x) < len(y):          # x a proper prefix of y: x below y iff |x| even
        return len(x) % 2 == 0
    return len(y) % 2 == 1       # y a proper prefix of x: y below x iff |y| even


def lex_less(x, y):
    return x < y


def is_galois(w):
    """Definition 7.1: primitive, and below (or equal to) each of its rotations in the
    alternating order."""
    if not primitive(w):
        return False
    k = alt_key(w)
    return all(k <= alt_key(w[d:] + w[:d]) for d in range(1, len(w)))


def is_lyndon(w):
    return primitive(w) and all(w <= w[d:] + w[:d] for d in range(1, len(w)))


def classify_alt(w):
    """'G' Galois; 'GG' the square of a Galois word of odd length; 'other'."""
    if is_galois(w):
        return 'G'
    n = len(w)
    if n % 2 == 0:
        h = n // 2
        if w[:h] == w[h:] and h % 2 == 1 and is_galois(w[:h]):
            return 'GG'
    return 'other'


# ---------------------------------------------------------------- the two transforms

def transform(T, alt):
    """(L, I, SA, ISA): rotations of the primitive word T sorted in the alternating (alt)
    or the usual order; L the last column; I the row of T."""
    n = len(T)
    TT = T + T
    if alt:
        SA = sorted(range(n), key=lambda s: alt_key(TT[s:s + n]))
    else:
        SA = sorted(range(n), key=lambda s: TT[s:s + n])
    ISA = [0] * n
    for x, p in enumerate(SA):
        ISA[p] = x
    L = tuple(T[(p - 1) % n] for p in SA)
    return L, ISA[0], SA, ISA


def lf_formula(L, alt):
    """LF from the column alone: eq. (2) (BWT) or eq. (3) (ABWT) of arXiv:1907.02308v1."""
    cnt = Counter(L)
    C, s = {}, 0
    for c in sorted(cnt):
        C[c] = s
        s += cnt[c]
    seen = Counter()
    LF = [0] * len(L)
    for i, c in enumerate(L):
        if alt:
            LF[i] = C[c] + cnt[c] - seen[c] - 1
        else:
            LF[i] = C[c] + seen[c]
        seen[c] += 1
    return LF


def lf_matrix(SA, ISA):
    """LF from the sorted matrix: row i (rotation at SA[i]) -> the row of the rotation that
    starts one place earlier."""
    n = len(SA)
    return [ISA[(SA[i] - 1) % n] for i in range(n)]


def runs_of(L):
    """[(byte, start, length)] of the maximal equal-letter runs."""
    out = []
    i, n = 0, len(L)
    while i < n:
        j = i
        while j < n and L[j] == L[i]:
            j += 1
        out.append((L[i], i, j - i))
        i = j
    return out


def walk(L, LF, I):
    """Eq. (1): w[n-1-j] = L[LF^j(I)]."""
    n = len(L)
    out = [None] * n
    x = I
    for j in range(n):
        out[n - 1 - j] = L[x]
        x = LF[x]
    return tuple(out)


def walk_arbitrary(L, LF, ptr):
    """The entry's definition for any column and row: T[k] = L[LF^{-(k+1)}(ptr)], n bytes."""
    n = len(L)
    FL = [0] * n
    for i, j in enumerate(LF):
        FL[j] = i
    out = []
    x = ptr
    for _ in range(n):
        x = FL[x]
        out.append(L[x])
    return tuple(out)


# ---------------------------------------------------------------- the induction (Python lists)

class Grammar:
    """Terminals are the letters themselves (ints < BASE); rule k is the symbol BASE + k."""
    BASE = 1 << 20

    def __init__(self):
        self.rules = []

    def new(self, x, y):
        self.rules.append((x, y))
        return self.BASE + len(self.rules) - 1

    def expand(self, s):
        out, st = [], [s]
        while st:
            t = st.pop()
            if t < self.BASE:
                out.append(t)
            else:
                x, y = self.rules[t - self.BASE]
                st.append(y)
                st.append(x)
        return tuple(out)

    def tree(self, s):
        """Nested tuples: a leaf is its letter, a node (left, right)."""
        if s < self.BASE:
            return s
        x, y = self.rules[s - self.BASE]
        return (self.tree(x), self.tree(y))


def induce(L, alt, ptr=None, check=None):
    """Right-end Rauzy induction on the exchange of the runs of L by LF.

    alt=False: the entry's section 2 (every letter a translation, bottom = runs stably
    sorted by byte). alt=True: every run is a flip, bottom = runs sorted by byte and,
    inside a byte, in reverse order of position; one orientation bit f a letter.

    State: top, bot (lists of letters, in order), lam, w (grammar symbol), wl = |w|, f.
    Step (A = top[-1], B = bot[-1], A != B; N -> w_A w_B):
      top wins    (lam_A > lam_B): lam_A -= lam_B; w_B := N; f_B ^= f_A;
                  bottom: B is taken off the end and put just after A if f_A = 0,
                  just before A if f_A = 1 (f_A as before the step).
      bottom wins (lam_A < lam_B): lam_B -= lam_A; w_A := N; f_A ^= f_B;
                  top: A is taken off the end and put just after B if f_B = 0,
                  just before B if f_B = 1.
      equal: w_B := N; f_B ^= f_A; A deleted; bottom: B takes A's place.
    A = B: the letter closes (see README); it is dropped from both orders unless the
    tracked row lies on it or it is the last.

    ptr: a row to follow as (alpha, o, v): ptr = pi^v(start(I_alpha) + o), 0 <= v < |w_alpha|.
    check: None or a callable(state) run after every step (Invariant I' by brute force).

    Returns a dict: g (Grammar), closed [(symbol, lam, f, m_before)], steps [(m', m, kind,
    symbol)], counts, and for ptr: (symbol of its cycle's letter, v).
    """
    rs = runs_of(L)
    r = len(rs)
    g = Grammar()
    top = list(range(r))
    if alt:
        bot = sorted(range(r), key=lambda i: (rs[i][0], -i))
    else:
        bot = sorted(range(r), key=lambda i: (rs[i][0], i))
    lam = [x[2] for x in rs]
    w = [x[0] for x in rs]
    wl = [1] * r
    f = [1 if alt else 0] * r
    m = len(L)
    steps, closed = [], []
    cnt = {'T': 0, 'B': 0, 'E': 0}
    trk = None
    if ptr is not None:
        for a, (_, s, ln) in enumerate(rs):
            if s <= ptr < s + ln:
                trk = [a, ptr - s, 0]
    result = None
    st = dict(top=top, bot=bot, lam=lam, w=w, wl=wl, f=f, g=g)
    if check:
        check(st, m)
    while top:
        A, B = top[-1], bot[-1]
        if A == B:
            closed.append((w[A], lam[A], f[A], m))
            if trk is not None and trk[0] == A:
                result = (w[A], trk[2])
                break
            top.pop()
            bot.pop()
            m -= lam[A]
            if check:
                check(st, m)
            continue
        la, lb = lam[A], lam[B]
        fa, fb = f[A], f[B]
        N = g.new(w[A], w[B])
        if la > lb:                                   # top wins
            kind = 'T'
            if trk is not None and trk[0] == A and trk[1] >= la - lb:
                o = trk[1] - (la - lb)                # place in J_B
                trk[0] = B
                trk[1] = o if fb == 0 else lb - 1 - o
                trk[2] += wl[B]
            lam[A] = la - lb
            bot.pop()
            j = bot.index(A)
            bot.insert(j + 1 if fa == 0 else j, B)
            w[B] = N
            wl[B] += wl[A]
            f[B] ^= fa
        elif la < lb:                                 # bottom wins
            kind = 'B'
            if trk is not None:
                if trk[0] == A:
                    trk[1] = trk[1] if fb == 0 else la - 1 - trk[1]
                    trk[2] += wl[B]
                elif trk[0] == B:
                    if fb == 0:
                        if trk[1] >= lb - la:
                            trk[0] = A
                            trk[1] -= lb - la
                    else:
                        if trk[1] < la:
                            trk[0] = A
                        else:
                            trk[1] -= la
            lam[B] = lb - la
            top.pop()
            j = top.index(B)
            top.insert(j + 1 if fb == 0 else j, A)
            w[A] = N
            wl[A] += wl[B]
            f[A] ^= fb
        else:                                         # equal
            kind = 'E'
            if trk is not None and trk[0] == A:
                trk[0] = B
                trk[1] = trk[1] if fb == 0 else lb - 1 - trk[1]
                trk[2] += wl[B]
            top.pop()
            bot.pop()
            bot[bot.index(A)] = B
            w[B] = N
            wl[B] += wl[A]
            f[B] ^= fa
        m2 = m - min(la, lb)
        steps.append((m2, m, kind, N))
        cnt[kind] += 1
        m = m2
        if check:
            check(st, m)
    return dict(g=g, closed=closed, steps=steps, cnt=cnt, r=r, S=len(steps), result=result,
                wl=wl, f=f)


def make_checker(L, LF):
    """Invariant I' by brute force: with the letters' intervals laid out from the two
    orders, the first return of every x of I_alpha to [0, m) is the isometry onto J_alpha
    (order kept if f = 0, reversed if f = 1), after |w_alpha| steps, reading w_alpha
    reversed; and f_alpha = (number of flipped original letters in w_alpha) mod 2."""
    def check(st, m):
        top, bot, lam, w, wl, f, g = (st[k] for k in ('top', 'bot', 'lam', 'w', 'wl', 'f', 'g'))
        assert sorted(top) == sorted(bot)
        assert sum(lam[a] for a in top) == m
        I0, J0, s = {}, {}, 0
        for a in top:
            I0[a] = s
            s += lam[a]
        s = 0
        for a in bot:
            J0[a] = s
            s += lam[a]
        for a in top:
            word = g.expand(w[a])
            assert len(word) == wl[a]
            for o in range(lam[a]):
                x = I0[a] + o
                read = []
                y = x
                while True:
                    read.append(L[y])
                    y = LF[y]
                    if y < m:
                        break
                assert tuple(reversed(read)) == word, (L, m, a)
                want = J0[a] + o if f[a] == 0 else J0[a] + lam[a] - 1 - o
                assert y == want, (L, m, a, o, y, want)
    return check


# ---------------------------------------------------------------- the same on linked orders

def induce_linked(L, alt):
    """The same steps with both orders as doubly linked lists (O(1) a step), for long
    columns. One cycle only (asserted). Returns (rules, root symbol, counts)."""
    rs = runs_of(L)
    r = len(rs)
    BASE = Grammar.BASE
    rules = []
    if alt:
        boto = sorted(range(r), key=lambda i: (rs[i][0], -i))
    else:
        boto = sorted(range(r), key=lambda i: (rs[i][0], i))
    HEAD = r                                    # sentinel in both orders
    tp = [i - 1 for i in range(r)] + [r - 1]
    tn = [i + 1 for i in range(r)] + [0]
    tp[0] = HEAD
    tn[r - 1] = HEAD
    bp = [0] * (r + 1)
    bn = [0] * (r + 1)
    prev = HEAD
    for a in boto:
        bp[a] = prev
        bn[prev] = a
        prev = a
    bn[prev] = HEAD
    bp[HEAD] = prev
    lam = [x[2] for x in rs]
    w = [x[0] for x in rs]
    f = [1 if alt else 0] * r
    cnt = {'T': 0, 'B': 0, 'E': 0}
    while True:
        A, B = tp[HEAD], bp[HEAD]
        if A == B:
            assert tn[HEAD] == A and bn[HEAD] == A and lam[A] == 1, "not one cycle"
            return rules, w[A], cnt
        la, lb = lam[A], lam[B]
        rules.append((w[A], w[B]))
        N = BASE + len(rules) - 1
        if la > lb:
            cnt['T'] += 1
            lam[A] = la - lb
            p = bp[B]                           # unlink B from the bottom's end
            bn[p] = HEAD
            bp[HEAD] = p
            if f[A] == 0:                       # just after A
                q = bn[A]
                bn[A] = B; bp[B] = A; bn[B] = q; bp[q] = B
            else:                               # just before A
                q = bp[A]
                bn[q] = B; bp[B] = q; bn[B] = A; bp[A] = B
            w[B] = N
            f[B] ^= f[A]
        elif la < lb:
            cnt['B'] += 1
            lam[B] = lb - la
            p = tp[A]
            tn[p] = HEAD
            tp[HEAD] = p
            if f[B] == 0:
                q = tn[B]
                tn[B] = A; tp[A] = B; tn[A] = q; tp[q] = A
            else:
                q = tp[B]
                tn[q] = A; tp[A] = q; tn[A] = B; tp[B] = A
            w[A] = N
            f[A] ^= f[B]
        else:
            cnt['E'] += 1
            p = tp[A]                           # A off the top
            tn[p] = HEAD
            tp[HEAD] = p
            p = bp[B]                           # B off the bottom's end
            bn[p] = HEAD
            bp[HEAD] = p
            p, q = bp[A], bn[A]                 # B into A's bottom place
            bn[p] = B; bp[B] = p; bn[B] = q; bp[q] = B
            w[B] = N
            f[B] ^= f[A]


def expand_rules(rules, s, BASE=Grammar.BASE):
    out, st = [], [s]
    while st:
        t = st.pop()
        if t < BASE:
            out.append(t)
        else:
            x, y = rules[t - BASE]
            st.append(y)
            st.append(x)
    return out


# ---------------------------------------------------------------- Cartesian tree

def cartesian(G, key):
    """Min-Cartesian tree of key[1..n-1] over the word G: the node of span [lo, hi) splits
    at the j in (lo, hi) of least key. Returns nested tuples and {key value: subtree}."""
    at = {}

    def build(lo, hi):
        if hi - lo == 1:
            return G[lo]
        j = min(range(lo + 1, hi), key=lambda t: key[t])
        node = (build(lo, j), build(j, hi))
        at[key[j]] = node
        return node

    return build(0, len(G)), at


def flatten(t):
    out, st = [], [t]
    while st:
        x = st.pop()
        if isinstance(x, tuple):
            st.append(x[1])
            st.append(x[0])
        else:
            out.append(x)
    return tuple(out)


def all_words(sigma, n):
    return itertools.product(range(sigma), repeat=n)
