"""Step 2. What does the ABWT's LF do on each run of the transform?

Run: python3 step2_runs.py
For every primitive word over 2 letters to length 12 and 3 letters to length 8:
  * the two forms of LF agree: eq. (3) from the column alone, and "the row of the rotation
    that starts one place earlier" from the sorted matrix; eq. (1) gives the word back;
  * every run [s, s+len) of L is classed: LF(s+k) = LF(s)+k for all k (translation),
    LF(s+k) = LF(s)-k for all k (flip), or neither. A run of one row is both.
The same is counted for the BWT, as a control, and split by the parity of the run's length,
of its first row, of n, and of the run's byte.
"""
import sys
from collections import Counter

from abwt import all_words, primitive, transform, lf_formula, lf_matrix, runs_of, walk


def classify(LF, s, ln):
    tr = all(LF[s + k] == LF[s] + k for k in range(ln))
    fl = all(LF[s + k] == LF[s] - k for k in range(ln))
    return tr, fl


def main():
    grids = [(2, 12), (3, 8)]
    total = Counter()
    by = Counter()
    for sigma, nmax in grids:
        for n in range(1, nmax + 1):
            c = Counter()
            for T in all_words(sigma, n):
                if not primitive(T):
                    continue
                c['words'] += 1
                for alt in (True, False):
                    name = 'abwt' if alt else 'bwt'
                    L, I, SA, ISA = transform(T, alt)
                    LF = lf_formula(L, alt)
                    assert LF == lf_matrix(SA, ISA), (T, alt)
                    assert sorted(LF) == list(range(n))
                    assert walk(L, LF, I) == T, (T, alt)
                    # one cycle
                    x, seen = 0, 0
                    while True:
                        x = LF[x]
                        seen += 1
                        if x == 0:
                            break
                    assert seen == n
                    for b, s, ln in runs_of(L):
                        tr, fl = classify(LF, s, ln)
                        if ln == 1:
                            c[name, 'single'] += 1
                        else:
                            kind = 'translation' if tr else 'flip' if fl else 'neither'
                            assert not (tr and fl)
                            c[name, kind] += 1
                            by[name, kind, 'len%2', ln % 2] += 1
                            by[name, kind, 'start%2', s % 2] += 1
                            by[name, kind, 'n%2', n % 2] += 1
                            by[name, kind, 'byte', b] += 1
            print(f"sigma={sigma} n={n:2d} primitive={c['words']:6d}  "
                  f"ABWT runs: single={c['abwt','single']} flip={c['abwt','flip']} "
                  f"translation={c['abwt','translation']} neither={c['abwt','neither']}  |  "
                  f"BWT runs: single={c['bwt','single']} translation={c['bwt','translation']} "
                  f"flip={c['bwt','flip']} neither={c['bwt','neither']}")
            total.update(c)
    print("TOTAL", dict(total))
    print("runs of length >= 2 by class and by parity:")
    for k in sorted(by, key=str):
        print("  ", k, by[k])


if __name__ == '__main__':
    main()
