"""Step 5. Runs and steps for the BWT and the ABWT of real text. Counts only, no clock.

Run: python3 -I step5_block.py text/repo_markdown.txt
The file is the repository's own Markdown (docs/*.md then docs/team/*.md, concatenated;
text/FILES.txt lists them). Blocks: bytes [0, 100000) and [100000, 200000).

For each block and each transform:
  * rotations sorted by prefix doubling (numpy). Alternating order: the pair
    (T[i], -T[i+1]) ranks the prefixes of length 2; from then on the prefix of length 2k is
    the pair of two prefixes of length k, both at an even offset, so plain doubling;
  * checked on 300 random short words against the brute-force sort of abwt.py;
  * L, its runs r, LF by eq. (2) / eq. (3), LF checked to be one cycle that spells the
    block (eq. (1));
  * the induction on linked orders (abwt.induce_linked, the same steps as the lists form):
    S and the steps by kind; the root's expansion asserted equal to the least rotation;
  * r2 = |run starts  U  image starts|, the cells of the common refinement (the entry's
    floor is r2 - 1); distinct rules as (left symbol, right symbol) after hash-consing by
    expansion identity (equal rules shared).
"""
import random
import sys

import numpy as np

sys.path.insert(0, __file__.rsplit('/', 1)[0])
from abwt import (transform, lf_formula, runs_of, induce_linked, expand_rules, Grammar,
                  primitive)


def sort_rotations(T, alt):
    """SA of the rotations of the primitive byte string T (numpy uint8)."""
    n = len(T)
    idx = np.arange(n, dtype=np.int64)
    rank = T.astype(np.int64)
    k = 1
    while True:
        second = rank[(idx + k) % n]
        if alt and k == 1:
            second = -second
        order = np.lexsort((second, rank))
        r1 = rank[order]
        r2 = second[order]
        change = np.empty(n, dtype=np.int64)
        change[0] = 0
        change[1:] = (r1[1:] != r1[:-1]) | (r2[1:] != r2[:-1])
        newrank_sorted = np.cumsum(change)
        rank = np.empty(n, dtype=np.int64)
        rank[order] = newrank_sorted
        k *= 2
        if newrank_sorted[-1] == n - 1:
            return order, rank
        if k >= 2 * n:
            raise ValueError("not primitive")


def selftest():
    rng = random.Random(5)
    done = 0
    while done < 300:
        sigma = rng.randint(2, 5)
        n = rng.randint(1, 40)
        T = tuple(rng.randrange(sigma) for _ in range(n))
        if not primitive(T):
            continue
        for alt in (True, False):
            L, I, SA, ISA = transform(T, alt)
            order, rank = sort_rotations(np.array(T, dtype=np.uint8), alt)
            assert list(order) == SA, (T, alt)
        done += 1
    print("prefix-doubling sort == brute-force sort on 300 random primitive words, both orders")


def one(block, alt):
    n = len(block)
    T = np.frombuffer(block, dtype=np.uint8)
    SA, ISA = sort_rotations(T, alt)
    Larr = T[(SA - 1) % n]
    L = Larr.tolist()
    I = int(ISA[0])
    LF = lf_formula(L, alt)
    # eq. (1): one cycle, and it spells the block
    out = bytearray(n)
    x = I
    for j in range(n):
        out[n - 1 - j] = L[x]
        x = LF[x]
    assert x == I and bytes(out) == block
    rs = runs_of(L)
    r = len(rs)
    tops = set(s for (_, s, _) in rs)
    if alt:
        bots = set(LF[s + ln - 1] for (_, s, ln) in rs)     # a flipped run's image starts at its last row's image
    else:
        bots = set(LF[s] for (_, s, _) in rs)
    r2 = len(tops | bots)
    rules, root, cnt = induce_linked(L, alt)
    S = len(rules)
    E = bytes(expand_rules(rules, root))
    s0 = int(SA[0])
    G = block[s0:] + block[:s0]
    assert E == G, "the grammar does not expand to the least rotation"
    assert cnt['E'] == r - 1
    assert S >= r2 - 1
    # equal rules shared: canonical id of a symbol = id of its (canon left, canon right)
    BASE = Grammar.BASE
    canon = {}
    cid = [0] * S
    for k, (a, b) in enumerate(rules):
        ca = a if a < BASE else cid[a - BASE]
        cb = b if b < BASE else cid[b - BASE]
        cid[k] = canon.setdefault((ca, cb), BASE + len(canon))
    D = len(canon)
    # orientation: how many rules have a word of odd length (flipped letters, ABWT)
    ln = [0] * S
    odd = 0
    for k, (a, b) in enumerate(rules):
        la = 1 if a < BASE else ln[a - BASE]
        lb = 1 if b < BASE else ln[b - BASE]
        ln[k] = la + lb
        odd += ln[k] & 1
    return dict(n=n, r=r, r2=r2, S=S, T=cnt['T'], B=cnt['B'], E=cnt['E'], D=D, odd=odd)


def main():
    path = sys.argv[1]
    data = open(path, 'rb').read()
    selftest()
    tot = {}
    for lo in (0, 100000):
        block = data[lo:lo + 100000]
        assert len(block) == 100000
        for alt in (False, True):
            name = 'ABWT' if alt else 'BWT '
            d = one(block, alt)
            print(f"bytes [{lo},{lo + 100000}) {name}: n={d['n']} r={d['r']} (r/n={d['r'] / d['n']:.4f}) "
                  f"S={d['S']} (S/r={d['S'] / d['r']:.4f}, S/n={d['S'] / d['n']:.4f}) "
                  f"top/bottom/equal={d['T']}/{d['B']}/{d['E']} "
                  f"r2-1={d['r2'] - 1} ((r2-1)/r={(d['r2'] - 1) / d['r']:.4f}) "
                  f"distinct rules={d['D']} ({d['D'] / d['S']:.4f} S) rules of odd length={d['odd']}")
            tot[lo, alt] = d
    for lo in (0, 100000):
        a, b = tot[lo, True], tot[lo, False]
        print(f"bytes [{lo},{lo + 100000}) ABWT/BWT: r {a['r'] / b['r']:.4f}  S {a['S'] / b['S']:.4f}  "
              f"r2-1 {(a['r2'] - 1) / (b['r2'] - 1):.4f}  distinct rules {a['D'] / b['D']:.4f}")
    print("the root's expansion equals the least rotation on every run above")


if __name__ == '__main__':
    main()
