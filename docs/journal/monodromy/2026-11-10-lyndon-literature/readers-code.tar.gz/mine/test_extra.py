"""T6: every right-end step is a legal rise of the Schutzenberger-Melancon rewriting (the
right word is a largest current word, the left word is smaller). T7: on a two-run column
b^k a^l the right end is Euclid's subtractive algorithm on (k, l)."""
import sys
from math import gcd
exec(open('lyndon_induction_tests.py').read().split('if __name__')[0])


def legal_rises(maxlen2, maxlen3):
    words = steps = 0
    for alphabet, maxlen in (((0, 1), maxlen2), ((0, 1, 2), maxlen3)):
        for T in words_over(alphabet, maxlen, 2):
            if not is_primitive(T):
                continue
            top, bot, lam, word = lf_runs(bwt(T))
            words += 1
            while len(top) > 1:
                a, b = top[-1], bot[-1]
                wa, wb = tuple(flat(word[a])), tuple(flat(word[b]))
                cur = [tuple(flat(word[x])) for x in top]
                assert wa < wb, T                       # a rise
                assert all(w <= wb for w in cur), T      # the right word is a largest word present
                assert all(is_lyndon(w) for w in cur), T
                steps += 1
                n = (word[a], word[b])
                if lam[a] > lam[b]:
                    lam[a] -= lam[b]; word[b] = n; bot.pop(); bot.insert(bot.index(a) + 1, b)
                elif lam[a] < lam[b]:
                    lam[b] -= lam[a]; word[a] = n; top.pop(); top.insert(top.index(b) + 1, a)
                else:
                    word[b] = n; top.pop(); bot.pop(); bot[bot.index(a)] = b
    print(f"T6: {words} primitive words, {steps} right-end steps: at every step every letter's word is a "
          f"Lyndon word, w_A < w_B, and w_B is a largest of the words present")


def two_runs(maxk):
    cols = 0
    for k in range(1, maxk + 1):
        for l in range(1, maxk + 1):
            closed, steps = right_end([1] * k + [0] * l)
            # Euclid by subtraction on (k, l): the number of subtractions is the sum of the
            # partial quotients of k/l
            a, b, subs, quotients = k, l, 0, 0
            while b:
                subs += a // b; quotients += 1
                a, b = b, a % b
            g = gcd(k, l)
            assert len(closed) == 1 and closed[0][1] == g, (k, l, closed)
            assert steps == subs, (k, l, steps, subs)
            assert len(flat(closed[0][0])) == (k + l) // g
            cols += 1
    print(f"T7: {cols} columns b^k a^l (1 <= k, l <= {maxk}): one closed letter of gcd(k, l) points, its word of "
          f"length (k + l)/gcd; steps = the sum of the partial quotients of k/l (Euclid by subtraction)")


legal_rises(12, 8)
two_runs(40)
