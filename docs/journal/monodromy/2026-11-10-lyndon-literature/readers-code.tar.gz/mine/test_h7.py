"""H7: is the number of steps a function of the tree an order of steps leaves? Candidate:
the tree's inner nodes that lie above a hinge (the text positions whose bytes the run-start
rows emit; entry, Theorem 3). Tested for every tree every order leaves."""
from induce import *
from test_h123 import all_schedule_trees


def hinges_and_ends(V):
    """text positions (in V) emitted by the run-start rows, and by the run-end rows."""
    n = len(V)
    rows = sorted(range(n), key=lambda i: V[i:] + V[:i])
    L = [V[(i - 1) % n] for i in rows]
    starts = {(rows[x] - 1) % n for x in range(n) if x == 0 or L[x] != L[x - 1]}
    ends = {(rows[x] - 1) % n for x in range(n) if x == n - 1 or L[x] != L[x + 1]}
    return starts, ends


def marked_nodes(tree, marks, offset, n):
    """inner nodes with a marked leaf below; leaves are numbered offset, offset+1, ... mod n"""
    count = 0
    def rec(t, i):
        nonlocal count
        if not isinstance(t, tuple):
            return 1, ((offset + i) % n) in marks
        l1, m1 = rec(t[0], i)
        l2, m2 = rec(t[1], i + l1)
        if m1 or m2:
            count += 1
        return l1 + l2, m1 or m2
    rec(tree, 0)
    return count


def run(two_sided, maxlen2, maxlen3):
    tot = trees_n = ok_s = ok_e = ok_min = ok_max = 0
    bad = []
    for alphabet, maxlen in (((0, 1), maxlen2), ((0, 1, 2), maxlen3)):
        for V in words_over(alphabet, maxlen, 3):
            if not is_lyndon(V):
                continue
            n = len(V)
            starts, ends = hinges_and_ends(V)
            trees = all_schedule_trees(bwt(V), two_sided)
            tot += 1
            for t, steps in trees.items():
                w = tuple(flat(t))
                offs = [s for s in range(n) if V[s:] + V[:s] == w]
                assert len(offs) == 1
                a = marked_nodes(t, starts, offs[0], n)
                b = marked_nodes(t, ends, offs[0], n)
                trees_n += 1
                ok_s += a == steps
                ok_e += b == steps
                ok_min += min(a, b) == steps
                ok_max += max(a, b) == steps
                if a != steps and len(bad) < 3:
                    bad.append((V, t, steps, a, b))
    side = "either end" if two_sided else "right-handed"
    print(f"H7 ({side}): {tot} Lyndon words, {trees_n} (word, tree) pairs; fewest steps == inner nodes above a "
          f"run-start hinge on {ok_s}; above a run-end hinge on {ok_e}; == min of the two on {ok_min}; max on {ok_max}")
    for V, t, s, a, b in bad:
        print("   e.g.", "".join("abc"[c] for c in V), t, "steps", s, "start-hinge nodes", a, "end-hinge nodes", b)


run(False, 10, 7)
run(True, 9, 6)
