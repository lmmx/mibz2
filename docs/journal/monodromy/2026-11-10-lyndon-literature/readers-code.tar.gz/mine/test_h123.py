"""Brute-force tests of three statements (scratch; MONODROMY's second record).

H1  The right-end induction on ANY column, with the drop rule, returns the multiset of
    Lyndon words whose extended BWT the column is (Gessel-Reutenauer), largest first, each
    with its Lyndon tree; on the bijective BWT of T that is T's Lyndon factorization.
H2  The left-end induction on the BWT of a primitive T returns the Lyndon tree, for the
    inverse order of the alphabet, of T's greatest rotation.
H3  Is the LEFT Lyndon tree of the least rotation the tree of some order of steps?
"""
import sys
from induce import (bwt, duval, ebwt, flat, is_lyndon, is_primitive, least_rotation, left_tree,
                    lf_runs, right_end, right_tree, words_over)


def omega_key(w, k):
    return tuple(w[i % len(w)] for i in range(k))


def h1(maxlen2, maxlen3):
    cols = closed_total = multi = powers = 0
    for alphabet, maxlen in (((0, 1), maxlen2), ((0, 1, 2), maxlen3)):
        for L in words_over(alphabet, maxlen):
            closed, _ = right_end(list(L))
            cols += 1
            words = []
            assert sum(lam * len(flat(t)) for t, lam in closed) == len(L)
            for t, lam in closed:
                w = tuple(flat(t))
                assert is_lyndon(w), (L, w)  # primitive and least among its rotations
                assert t == right_tree(w), (L, w)  # its tree is the Lyndon tree
                words.extend([w] * lam)
                closed_total += 1
                powers += lam > 1
            multi += len(words) > 1
            k = 2 * len(L)
            # largest first, in the infinite order and in the lexicographic order alike
            assert all(omega_key(a, k) >= omega_key(b, k) for a, b in zip(words, words[1:])), L
            assert all(a >= b for a, b in zip(words, words[1:])), L
            # the column is the extended BWT of that multiset (the bijection, both ways)
            assert ebwt(words) == list(L), (L, words)
    print(f"H1a: {cols} columns ({multi} with more than one word; {closed_total} closed "
          f"letters, {powers} of them of several points): every closed word a Lyndon word "
          f"with its Lyndon tree, largest first, and the column their extended BWT")
    texts = 0
    for alphabet, maxlen in (((0, 1), maxlen2), ((0, 1, 2), maxlen3)):
        for T in words_over(alphabet, maxlen):
            f = duval(T)
            closed, _ = right_end(ebwt(f))
            got = []
            for t, lam in closed:
                got.extend([tuple(flat(t))] * lam)
            assert got == f, (T, f, got)
            texts += 1
    print(f"H1b: {texts} texts: the induction on the bijective BWT returns the Lyndon "
          f"factorization, in its order")


def h2(maxlen2, maxlen3):
    n = 0
    for alphabet, maxlen in (((0, 1), maxlen2), ((0, 1, 2), maxlen3)):
        top_sym = alphabet[-1]
        comp = lambda w: tuple(top_sym - c for c in w)
        for T in words_over(alphabet, maxlen, 2):
            if not is_primitive(T):
                continue
            L = bwt(T)
            mirror = [top_sym - c for c in reversed(L)]
            assert mirror == bwt(comp(T)), T  # the mirrored column is the BWT for the inverse order
            closed, steps_mirror = right_end(mirror)
            assert len(closed) == 1
            t = closed[0][0]
            assert t == right_tree(least_rotation(comp(T))), T
            # and the left-end induction written directly agrees with the mirror
            direct, steps_direct = left_end(L)
            assert comp_tree(direct, top_sym) == t and steps_direct == steps_mirror, T
            n += 1
    print(f"H2: {n} primitive words: the left-end induction is the right-end induction of "
          f"the BWT for the inverse alphabet order; its tree is the Lyndon tree (inverse "
          f"order) of the greatest rotation")


def comp_tree(t, top_sym):
    if isinstance(t, tuple):
        return (comp_tree(t[0], top_sym), comp_tree(t[1], top_sym))
    return top_sym - t


def left_end(L):
    """The induction at the left endpoint, for one cycle: the mirror of the entry's table."""
    top, bot, lam, word = lf_runs(L)
    steps = 0
    while len(top) > 1:
        a, b = top[0], bot[0]
        assert a != b
        steps += 1
        n = (word[a], word[b])
        if lam[a] > lam[b]:  # B takes the word, moves on the bottom to just before A
            lam[a] -= lam[b]
            word[b] = n
            bot.pop(0)
            bot.insert(bot.index(a), b)
        elif lam[a] < lam[b]:  # A takes the word, moves on top to just before B
            lam[b] -= lam[a]
            word[a] = n
            top.pop(0)
            top.insert(top.index(b), a)
        else:
            word[b] = n
            top.pop(0)
            bot.pop(0)
            bot[bot.index(a)] = b
    return word[top[0]], steps


def all_schedule_trees(L, two_sided=True):
    """Every tree that some order of steps leaves, steps taken at any coincidence, at the
    end of two intervals (right-handed) and, if two_sided, at their start (left-handed).
    Returns {tree: fewest steps}."""
    top, bot, lam, word = lf_runs(L)
    start = (tuple(top), tuple(bot), tuple(lam), tuple(word))
    best = {}
    seen = {}
    stack = [(start, 0)]
    while stack:
        state, steps = stack.pop()
        if seen.get(state, 1 << 30) <= steps:
            continue
        seen[state] = steps
        top, bot, lam, word = state
        if len(top) == 1:
            t = word[top[0]]
            best[t] = min(best.get(t, 1 << 30), steps)
            continue
        ends_t, starts_t, pos = {}, {}, 0
        for x in top:
            starts_t[pos] = x
            pos += lam[x]
            ends_t[pos] = x
        pos = 0
        moves = []
        for x in bot:
            if two_sided and pos in starts_t and starts_t[pos] != x:
                moves.append((starts_t[pos], x, False))
            pos += lam[x]
            if pos in ends_t and ends_t[pos] != x:
                moves.append((ends_t[pos], x, True))
        for a, b, right in moves:
            t2, b2, l2, w2 = list(top), list(bot), list(lam), list(word)
            n = (word[a], word[b])
            if lam[a] > lam[b]:
                l2[a] -= lam[b]
                w2[b] = n
                b2.remove(b)
                b2.insert(b2.index(a) + (1 if right else 0), b)
            elif lam[a] < lam[b]:
                l2[b] -= lam[a]
                w2[a] = n
                t2.remove(a)
                t2.insert(t2.index(b) + (1 if right else 0), a)
            else:
                w2[b] = n
                t2.remove(a)
                i = b2.index(a)
                b2.remove(b)
                b2[b2.index(a)] = b
            stack.append(((tuple(t2), tuple(b2), tuple(l2), tuple(w2)), steps + 1))
    return best


def h3(maxlen2, maxlen3):
    for two_sided in (False, True):
        tot = differ = left_in = right_in = anti_in = 0
        fewer = []
        counts = []
        for alphabet, maxlen in (((0, 1), maxlen2), ((0, 1, 2), maxlen3)):
            top_sym = alphabet[-1]
            for V in words_over(alphabet, maxlen, 3):
                if not is_lyndon(V):
                    continue
                L = bwt(V)
                trees = all_schedule_trees(L, two_sided)
                # every tree spells a rotation of V
                assert all(tuple(flat(t)) in {V[i:] + V[:i] for i in range(len(V))} for t in trees)
                rt, lt = right_tree(V), left_tree(V)
                anti = comp_tree(right_tree(least_rotation(tuple(top_sym - c for c in V))), top_sym)
                tot += 1
                right_in += rt in trees
                anti_in += anti in trees
                counts.append(len(trees))
                if lt != rt:
                    differ += 1
                    if lt in trees:
                        left_in += 1
                        _, s_right = right_end(L)
                        if trees[lt] < s_right:
                            fewer.append((V, trees[lt], s_right))
        side = "either end of an interval" if two_sided else "right-handed steps only"
        print(f"H3 ({side}): {tot} Lyndon words; the right tree is some order's tree on "
              f"{right_in}, the anti-Lyndon tree on {anti_in}; the left tree differs from "
              f"the right on {differ} and is some order's tree on {left_in} of those; "
              f"trees a word: max {max(counts)}, mean {sum(counts) / len(counts):.1f}")
        if fewer:
            print(f"   left tree reached in fewer steps than the right end on {len(fewer)}: "
                  f"first {fewer[:3]}")


if __name__ == "__main__":
    a = int(sys.argv[1]) if len(sys.argv) > 1 else 10
    b = int(sys.argv[2]) if len(sys.argv) > 2 else 7
    h1(a, b)
    h2(a, b)
    h3(min(a, 9), min(b, 6))
