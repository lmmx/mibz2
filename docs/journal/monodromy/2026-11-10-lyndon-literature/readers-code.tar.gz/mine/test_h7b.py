"""H7, the full statement: for EVERY sequence of right-handed steps (not only the shortest to
each tree) the number of steps equals the inner nodes of the final tree above a run-start
hinge; and every letter, at every moment, has exactly one occurrence holding a hinge: the
one at its first row. Walks every path of steps (memo on the state, which holds the words),
so a state reached with two different step counts would be caught."""
from induce import *
from test_h7 import hinges_and_ends, marked_nodes


def check(V):
    n = len(V)
    starts, _ = hinges_and_ends(V)
    rows = sorted(range(n), key=lambda i: V[i:] + V[:i])   # row -> text position of its rotation
    L = [V[(i - 1) % n] for i in rows]
    top, bot, lam, word = lf_runs(L)
    seen = {}
    finals = 0
    stack = [((tuple(top), tuple(bot), tuple(lam), tuple(word)), 0)]
    while stack:
        state, steps = stack.pop()
        if state in seen:
            assert seen[state] == steps, (V, state, seen[state], steps)   # steps is a function of the state
            continue
        seen[state] = steps
        top, bot, lam, word = state
        if len(top) == 1:
            t = word[top[0]]
            w = tuple(flat(t))
            off = [s for s in range(n) if V[s:] + V[:s] == w][0]
            assert marked_nodes(t, starts, off, n) == steps, (V, t, steps)
            finals += 1
            continue
        ends_t, pos = {}, 0
        for x in top:
            pos += lam[x]
            ends_t[pos] = x
        pos = 0
        for b in bot:
            pos += lam[b]
            a = ends_t.get(pos)
            if a is None or a == b:
                continue
            t2, b2, l2, w2 = list(top), list(bot), list(lam), list(word)
            nw = (word[a], word[b])
            if lam[a] > lam[b]:
                l2[a] -= lam[b]; w2[b] = nw; b2.remove(b); b2.insert(b2.index(a) + 1, b)
            elif lam[a] < lam[b]:
                l2[b] -= lam[a]; w2[a] = nw; t2.remove(a); t2.insert(t2.index(b) + 1, a)
            else:
                w2[b] = nw; t2.remove(a); b2.remove(b); b2[b2.index(a)] = b
            stack.append(((tuple(t2), tuple(b2), tuple(l2), tuple(w2)), steps + 1))
    return len(seen), finals


tot = states = finals = 0
for alphabet, maxlen in (((0, 1), 11), ((0, 1, 2), 7), ((0, 1, 2, 3), 6)):
    for V in words_over(alphabet, maxlen, 3):
        if is_lyndon(V):
            s, f = check(V)
            tot += 1; states += s; finals += f
print(f"H7 (every path of right-handed steps): {tot} Lyndon words, {states} states, {finals} final states: "
      f"the steps taken are a function of the state, and equal the final tree's inner nodes above a run-start hinge")
