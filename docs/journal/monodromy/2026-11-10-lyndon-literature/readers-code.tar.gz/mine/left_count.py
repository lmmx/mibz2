import sys, random
sys.setrecursionlimit(100000)
exec(open('lyndon_induction_tests.py').read().split('if __name__')[0])

def left_tree_fast(w):
    # longest proper Lyndon prefix by Duval-style scan: p is Lyndon iff unbordered-and-least; use direct test but memo-free, fine for n <= 400
    w = tuple(w)
    if len(w) == 1: return w[0]
    k = max(i for i in range(1, len(w)) if is_lyndon(w[:i]))
    return (left_tree_fast(w[:k]), left_tree_fast(w[k:]))

def report(name, T):
    T = tuple(T)
    if not is_primitive(T): print(name, 'not primitive'); return
    V = least_rotation(T); n = len(V)
    starts, ends = hinges_and_ends(V)
    rt, lt = right_tree(V), left_tree_fast(V)
    a = marked_nodes(rt, starts, 0, n); b = marked_nodes(lt, starts, 0, n)
    r = len(starts)
    _, s = right_end(bwt(V))
    print(f"{name}: n {n} r {r} | right tree: {a} nodes over the hinges (= S {s}: {a == s}), {a/r:.2f} r | left tree: {b}, {b/r:.2f} r, {b/n:.2f} n")

random.seed(7)
report('random 4 letters, n 300', [random.choice('acgt') for _ in range(300)])
words = ['the','of','and','to','in','is','that','it','was','for','on','with','as','be','at','by','this','have','from','or']
txt = ' '.join(random.choice(words) for _ in range(90))[:400]
report('random words, n 400', txt)
js = ''.join('{"id":%d,"name":"n%d","ok":true},' % (i, i % 7) for i in range(18))[:400]
report('JSON-like, n 400', js)
src = open('induce.py').read()[:400]
report('python source, n 400', src)
