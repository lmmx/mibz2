"""Rauzy induction on LF's exchange, on Python lists: the entry's section 2, with steps at
either end, at any coincidence, and the drop rule. Words are kept as trees (nested pairs of
bytes) in text order. Scratch code of MONODROMY's second record; brute force only."""
from itertools import product


def lf_runs(L):
    """letters of the exchange: (byte, length) per maximal run; top = as they lie; bottom =
    stable sort by byte."""
    runs = []
    for c in L:
        if runs and runs[-1][0] == c:
            runs[-1][1] += 1
        else:
            runs.append([c, 1])
    top = list(range(len(runs)))
    bot = sorted(top, key=lambda i: runs[i][0])  # stable
    lam = [r[1] for r in runs]
    word = [r[0] for r in runs]  # a leaf is a byte (int or str)
    return top, bot, lam, word


def flat(t, out=None):
    if out is None:
        out = []
    stack = [t]
    while stack:
        x = stack.pop()
        if isinstance(x, tuple):
            stack.append(x[1])
            stack.append(x[0])
        else:
            out.append(x)
    return out


def right_end(L):
    """The right-end induction with the drop rule. Returns the closed letters in the order
    they close: [(tree, number of points)], and the number of steps."""
    top, bot, lam, word = lf_runs(L)
    closed, steps = [], 0
    while top:
        a, b = top[-1], bot[-1]
        if a == b:
            closed.append((word[a], lam[a]))
            top.pop()
            bot.pop()
            continue
        steps += 1
        n = (word[a], word[b])
        if lam[a] > lam[b]:  # top wins: B takes the word, moves on the bottom to just after A
            lam[a] -= lam[b]
            word[b] = n
            bot.pop()
            bot.insert(bot.index(a) + 1, b)
        elif lam[a] < lam[b]:  # bottom wins: A takes the word, moves on top to just after B
            lam[b] -= lam[a]
            word[a] = n
            top.pop()
            top.insert(top.index(b) + 1, a)
        else:  # equal: B takes the word and A's bottom place; A is deleted
            word[b] = n
            top.pop()
            bot.pop()
            bot[bot.index(a)] = b
    return closed, steps


# ---- Lyndon tools ------------------------------------------------------------------------
def duval(s):
    """Lyndon factorization (Chen-Fox-Lyndon), by Duval's algorithm: list of factors."""
    out, i, n = [], 0, len(s)
    while i < n:
        j, k = i + 1, i
        while j < n and s[k] <= s[j]:
            k = i if s[k] < s[j] else k + 1
            j += 1
        while i <= k:
            out.append(tuple(s[i : i + j - k]))
            i += j - k
    return out


def is_lyndon(w):
    w = tuple(w)
    return all(w < w[i:] + w[:i] for i in range(1, len(w)))


def least_rotation(w):
    w = tuple(w)
    return min(w[i:] + w[:i] for i in range(len(w)))


def is_primitive(w):
    w = tuple(w)
    n = len(w)
    return not any(n % d == 0 and w == w[:d] * (n // d) for d in range(1, n))


def right_tree(w):
    """The (right) Lyndon tree of a Lyndon word: w = uv, v its least proper suffix."""
    w = tuple(w)
    if len(w) == 1:
        return w[0]
    k = min(range(1, len(w)), key=lambda i: w[i:])
    return (right_tree(w[:k]), right_tree(w[k:]))


def left_tree(w):
    """The left Lyndon tree of a Lyndon word: w = uv, u its longest proper prefix that is a
    Lyndon word (then v is a Lyndon word too)."""
    w = tuple(w)
    if len(w) == 1:
        return w[0]
    k = max(i for i in range(1, len(w)) if is_lyndon(w[:i]))
    assert is_lyndon(w[k:]), w
    return (left_tree(w[:k]), left_tree(w[k:]))


def bwt(T):
    """bzip2's transform: the rotations of T sorted, last column (ties in any order)."""
    T = tuple(T)
    n = len(T)
    rows = sorted(range(n), key=lambda i: T[i:] + T[:i])
    return [T[(i - 1) % n] for i in rows]


def ebwt(words):
    """Extended BWT of a multiset of words (Mantaci et al.): every rotation of every word,
    sorted by the infinite order (u^omega), last letters."""
    rots = []
    tot = sum(len(w) for w in words)
    for wi, w in enumerate(words):
        w = tuple(w)
        for i in range(len(w)):
            r = w[i:] + w[:i]
            key = tuple(r[k % len(r)] for k in range(2 * tot))
            rots.append((key, wi, r[-1]))
    rots.sort(key=lambda x: x[0])
    return [x[2] for x in rots]


def words_over(alphabet, maxlen, minlen=1):
    for n in range(minlen, maxlen + 1):
        for w in product(alphabet, repeat=n):
            yield w
