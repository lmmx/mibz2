"""H5: the right Lyndon tree by iterated Lazard elimination of the largest letter.
H6: over all orders of steps, the fewest steps that still leave the Lyndon tree, against the
right end's count and against the fewest steps of any order."""
import sys
from induce import *
from test_h123 import all_schedule_trees


def lazard_largest(V):
    """V a Lyndon word. Letters are (expansion, tree). Repeatedly take the largest letter z
    (expansions compared as words) and merge every maximal block x z^i, x != z, into one
    letter ((x z) z)... Returns (tree, eliminations, merges)."""
    seq = [((c,), c) for c in V]
    rounds = merges = 0
    while len(seq) > 1:
        z = max(e for e, _ in seq)
        assert seq[0][0] != z, V  # a Lyndon word does not begin with its largest letter
        out = []
        for e, t in seq:
            if e == z:
                pe, pt = out[-1]
                out[-1] = (pe + e, (pt, t))
                merges += 1
            else:
                out.append((e, t))
        seq = out
        rounds += 1
    return seq[0][1], rounds, merges


def h5(maxlen2, maxlen3):
    n = 0
    for alphabet, maxlen in (((0, 1), maxlen2), ((0, 1, 2), maxlen3), ((0, 1, 2, 3), 7)):
        for V in words_over(alphabet, maxlen, 2):
            if is_lyndon(V):
                t, rounds, merges = lazard_largest(V)
                assert t == right_tree(V), V
                n += 1
    print(f"H5: {n} Lyndon words: eliminating the largest letter again and again (every block x z^i "
          f"merged as ((x z) z)...) leaves the right Lyndon tree")


def h6(maxlen2, maxlen3):
    for two_sided in (False, True):
        tot = s_right = s_same = s_any = less = 0
        ex = []
        for alphabet, maxlen in (((0, 1), maxlen2), ((0, 1, 2), maxlen3)):
            for V in words_over(alphabet, maxlen, 3):
                if not is_lyndon(V):
                    continue
                L = bwt(V)
                trees = all_schedule_trees(L, two_sided)
                _, sr = right_end(L)
                rt = right_tree(V)
                tot += 1
                s_right += sr
                s_same += trees[rt]
                s_any += min(trees.values())
                if trees[rt] < sr:
                    less += 1
                    ex.append((len(V), V, sr, trees[rt], min(trees.values())))
        side = "either end" if two_sided else "right-handed"
        print(f"H6 ({side}): {tot} Lyndon words; steps summed: right end {s_right}, fewest that leave "
              f"the Lyndon tree {s_same}, fewest of any order {s_any}; the Lyndon tree is reached in "
              f"fewer steps than the right end's on {less} words")
        ex.sort()
        for n, V, sr, st, sm in ex[:3]:
            print("   e.g.", "".join("abc"[c] for c in V), "right end", sr, "Lyndon tree in", st, "any tree in", sm)


if __name__ == "__main__":
    h5(14, 9)
    h6(10, 7)
