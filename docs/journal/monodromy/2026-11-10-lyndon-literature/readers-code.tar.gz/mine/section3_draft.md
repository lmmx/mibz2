## 3. Derived while reading (P + C; `lyndon_induction_tests.py.txt`, about two minutes)

Notation is entry 1's (§1, §2): π = LF on a column L; letters with a top interval I_α, an
image J_α, a length λ_α and a word w_α; a right-handed step at a coincidence takes A (the
top interval ending there) and B (the image ending there) and names N → w_A w_B. A *hinge*
is a text position whose byte a run-start row of L emits (entry 1, Theorem 3).

**3.1 Theorem 5 (P; C): the steps are the tree's, not the order's.** In any sequence of
right-handed steps, from any column:

- **(a)** every letter, at every moment, has exactly one row whose occurrence of the
  letter's word holds a hinge: its first row;
- **(b)** so each step makes exactly one inner node above a hinge, and
  **steps = the inner nodes of the derivation forest that have a hinge leaf below them.**

*Proof.* A row x of a letter α stands for one occurrence of w_α in the text: the bytes the
rows x, πx, …, π^{|w_α|−1}x emit. At the start a letter is a run and its word one byte: the
occurrence at x holds a hinge iff x is the run's start, its first row. A step, with the
cell's rows read as rows of I_B: the occurrence of w_A w_B at x is B's at x and then A's at
π_m x.
- Top wins (λ_A > λ_B). The new letter is all of I_B, carried onto the last λ_B rows of
  I_A, which do not include A's first row. Its occurrence at x holds a hinge iff x is B's
  first row: one row, the first. A keeps its first rows, its first among them.
- Bottom wins (λ_A < λ_B). The new letter is the last λ_A rows of I_B, which do not include
  B's first row, carried in order onto all of I_A. Its occurrence at x holds a hinge iff
  π_m x is A's first row, iff x is the cell's first row. B keeps its first row.
- Equal. The new letter is I_B carried in order onto I_A: B's first row goes to A's first
  row. One row holds a hinge (two of them).
A step makes one new inner node an occurrence, that is, a row of its cell; by (a) one of
them is above a hinge. Nothing in this used where the coincidence lies. ∎

- **C:** every path of right-handed steps on the BWT of every Lyndon word over 2 letters to
  length 11, 3 to 7 and 4 to 6: 1,865 words, 5,255,519 states, 2,792,616 final states. The
  number of steps is a function of the state, and equals the final tree's inner nodes above
  a hinge on every one.
- **It contains entry 1's Theorem 3** (the right end: S = the Lyndon-tree nodes on the
  hinges' paths), with a proof that needs neither §5.5's count nor Theorem 1.
- **Equal steps are the nodes with a hinge on both sides; a cut step has its hinges on one
  side.** r hinges need r − 1 of the first kind in any tree of one cycle. So the freedom of
  entry 1's Theorem 4 (steps = r₂ − 1 + U) is all in the second kind: U + (r₂ − r) nodes
  that hang hinge-free text onto a hinge's path. r₂ − r is the number of stretches of more
  than one row (entry 1, §5.5: 0.220 r on Wikidata): the floor is one such node a stretch,
  and it is met when a stretch's inside is bracketed whole, as the other occurrences of
  steps whose hinged occurrence lies elsewhere, before it is hung on.
- **Corollary (P): the Lyndon tree costs S whatever the order.** No order of right-handed
  steps that leaves the Lyndon tree takes fewer steps than the right end. So every saving
  entry 1 counted (1.279 r against 1.812 r) changes the grammar: it is not the Lyndon tree
  any more, and nothing that relies on Lyndon words (Theorem 2's corollary, the Lyndon SLP)
  carries over to it. **C:** on 725 Lyndon words (binary to 10, ternary to 7) the fewest
  steps over all orders that leave the Lyndon tree is the right end's count on each; the
  fewest over all orders is 2.7% less in sum (4,087 against 4,201; 4,071 with left-handed
  steps allowed too).
- **Mixed hands have no such formula (C).** With steps at the start of an interval allowed
  too, the count is neither tree's-nodes-above-run-starts nor above-run-ends (249,156
  (word, tree) pairs: 227,286 and 227,286; the larger of the two on 246,384). Left-handed
  steps alone are the mirror: the hinges are the bytes the run-END rows emit.

**3.2 Corollary A (P; C): the induction inverts the extended and the bijective BWT.**
Entry 1's §2 runs the induction on "a column that is no BWT" and drops what closes
unmarked. What it drops:

- Every column L is the extended BWT of exactly one multiset M of primitive necklaces
  (**K:** Gessel–Reutenauer; Mantaci et al.; §2 below): row x is a rotation ρ_x of a word of
  M, the rows in the order of the infinite words ρ_x^ω, and π carries a row to the row of
  the rotation one place earlier. The cycles of π are the necklaces.
- A letter closes (A = B) when it is the last on both orders: I_A = J_A = [m − λ_A, m). Each
  of its rows is then the only row of its cycle left in [0, m), so it is the least row of
  that cycle: ρ_x is the least rotation of its necklace, a Lyndon word, and by Invariant I
  w_A is that word. Cycles close by decreasing least row.
- **So the closed letters, in the order they close, are the Lyndon words of M, largest
  first, each once with λ = its multiplicity; and the tree of each is its Lyndon tree.**
- **On the bijective BWT of T** (**K:** the extended BWT of T's Lyndon factors) **the closed
  words, in order, with their multiplicities, are the Lyndon factorization of T:** the
  induction inverts the BBWT, and writes T front to back as it closes.
- **C:** all 18,030 columns over 2 letters to length 12 and 3 to 8 (15,965 with more than
  one word; 44,674 closed letters, 8,767 of several points): every closed word a Lyndon
  word with its Lyndon tree, non-increasing in the infinite order and in the lexicographic
  order alike, and the column the extended BWT of what closed. The same 18,030 words as
  texts: the induction on the BBWT returns Duval's factorization, in its order.
- For the decoder this says what a corrupt stream decodes to: the n bytes round the Lyndon
  word of the cycle the stream's row lies on. For the kernel it says that `write_cells`
  with every closed letter written, not only the marked one, is a BBWT inverter in S
  cells. Not built; no clock.

**3.3 Corollary B (P; C): the left end is the Lyndon tree for the inverse order.** Turn the
rows over (x ↦ n − 1 − x) and the alphabet with them: L' = the complement of L reversed is
the BWT, for the inverse order, of the same primitive T, and π' is π turned over. The
left-end induction on L is the right-end induction on L'. By Theorem 1 its tree is the
Lyndon tree, for the inverse order, of the greatest rotation of T. **C:** 17,732 primitive
words. So entry 1's 2.137 r against 1.812 r (§5.6) is a fact about Wikidata's text under an
order and its inverse, not about the two ends: for the inverse order the ends change
places.

**3.4 The left Lyndon tree is not an order of steps (C).** The left standard factorization
(the longest proper prefix that is a Lyndon word) gives another tree of the same Lyndon
word. Over every order of steps, at either end of an interval, on the BWT of every Lyndon
word over 2 letters to length 10 and 3 to 7 (725 words): the left tree differs from the
right on 613, and no order leaves it on 77 of those. Smallest: `aabbc` (L = `caabb`), left
tree (((a(ab))b)c). Where an order does leave it, it takes fewer steps than the right end
on one word of 314. Its bracketing follows what lies to the left of a factor; a cell is a
set of rows, and rows are sorted by what lies to the right.

**3.5 The right end is Lazard's elimination of the largest letter (K + C).** Take the
largest letter z of the cyclic word and replace every block x zⁱ (x ≠ z) by one new letter
bracketed ((x z) z)…; repeat on the new alphabet, the new letters compared as words. What
is left is the right Lyndon tree (**C:** 9,335 Lyndon words over 2 letters to length 14, 3
to 9, 4 to 7). The induction does the same eliminations a cell at a time: the rows of the
largest letter are the last rows, and a step removes the largest of them.
