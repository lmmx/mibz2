import sys
from induce import *
from test_h123 import h1, h2, all_schedule_trees, comp_tree
h1(12, 8)
h2(12, 8)
# H3: smallest Lyndon words whose left tree is no order's tree (steps at either end of an interval)
miss = []
tot = differ = 0
for alphabet, maxlen in (((0, 1), 10), ((0, 1, 2), 7)):
    for V in words_over(alphabet, maxlen, 3):
        if not is_lyndon(V):
            continue
        lt, rt = left_tree(V), right_tree(V)
        tot += 1
        if lt == rt:
            continue
        differ += 1
        trees = all_schedule_trees(bwt(V), True)
        if lt not in trees:
            miss.append(V)
print(f"H3: {tot} Lyndon words (binary to 10, ternary to 7); left tree differs from the right on {differ}; no order of steps gives it on {len(miss)}")
miss.sort(key=lambda v: (len(v), v))
for V in miss[:4]:
    print("   e.g.", "".join("abc"[c] for c in V), "BWT", "".join("abc"[c] for c in bwt(V)), "left tree", left_tree(V))
