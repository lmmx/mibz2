**4.6 Every right-end step is a legal rise (C).** On the BWT of all 17,732 primitive words
over 2 letters to length 12 and 3 to 8, at each of the 133,817 right-end steps: every
letter's word is a Lyndon word, w_A < w_B, and w_B is a largest of the words present. So
the right end is §3.2's rewriting with LF's row order choosing the rise: the one at the
largest row. A reader adds (its simulator, not here): w_B never increases along the
induction, and a maximal stretch of steps with one w_B = z is one Lazard elimination of z,
cut into a step for each pair of letters it joins.

**4.7 Two runs: Euclid (C).** On the column `b^k a^l`, 1 ≤ k, l ≤ 40 (1,600 columns): one
letter closes, of gcd(k, l) points, its word of length (k + l)/gcd(k, l); the steps are the
sum of the partial quotients of k/l, Euclid's algorithm by subtraction. With entry 1's
division rule (§8 item 5) it must be the number of partial quotients, and the word the
Lyndon rotation of a standard word ([BKL] Theorem 24): a unit test for that rule with a
closed form on both sides. A reader notes that the rule would not change what the grammar
is: one elimination of z makes the letters y z^k for every k at once, and y z^k bracketed
((y z) z)… is already a node chain of the Lyndon tree.

**4.8 What the readers counted beyond the papers** (their programs, in the session's record
only; each is one sub-agent's, checked here only where §4.1 to §4.7 say so).
- **The left tree at size.** Its nodes over the hinges against the right tree's: 2,518
  against 1,944 on a JSON-like text of 6,000 bytes (r = 804) by one reader; 29,011 against
  8,581 on one of 30,000 by another (0.97 n against 1.9 r), who gives the reason: every
  unbordered prefix of the least rotation is a node of the left spine, and most prefixes are
  unbordered. Mine, on four inputs of 300 to 400 bytes: 294 / 291, 260 / 262, 178 / 146,
  399 / 386. Not smaller in sum anywhere; larger as n/r grows.
- **By steps on any cell, not only at a coincidence, the left tree is reachable** (the left
  Lazard order: least piece first; 8,730 words, one reader), and the count over the hinges
  holds there too. About one step in twenty of that order is away from a coincidence.
- **The Hall orders the literature names, as orders of steps** (Lyndon right and left, the
  inverse order's two, Nyldon and Nyldon for the inverse alphabet; 3,600 short words, one
  reader): 31,686 to 32,053 steps in sum against a floor of 27,325. None is 1% under the
  right end.
- **The alternating BWT.** LF reverses every run ([GMRRS20] says so as a formula; three
  readers checked it, 89,502 runs in one count). The induction with a flip bit a letter (the
  loser lands before the winner when the winner is flipped; the loser's flip is XORed with
  the winner's) ends on the least rotation in the alternating order on every word tried
  (67,319 in the largest count), and on any column gives back the multiset of the
  alternating bijection, a flipped closed letter of k points standing for squares. Its tree
  is the Cartesian tree of the alternating rotation ranks, which is the Galois words'
  standard tree on 7 of 1,375 binary Galois words: `abb` gives a(bb), and bb is no Galois
  word. The Hall order compares pieces by their own infinite powers; the induction compares
  the rotations that begin at them; for the lexicographic order the two agree on the
  largest cut, for the alternating order they do not. On five Wikidata chunks of 900,000
  bytes the alternating transform has the BWT's runs to 0.1% and 1 to 5% more steps.
- **Another order of the first letter** (the F-buckets as blocks of rows in another order,
  the runs cut at the seams: at most σ − 1 letters more; a generalized order in §3.6's
  sense with only the first position changed). Entry 1 counted bucket orders on 8 blocks
  and found them worse (§5.6). Two readers recounted: on two Wikidata chunks, byte order
  1.811 r and 1.810 r; reversed, by frequency, random, buckets reversed in place: 1.80 r to
  2.20 r, the best gain 0.4% on one chunk; on three small inputs 0.945 to 1.29 of the byte
  order's count. Closed at depth one.
