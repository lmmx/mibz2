#!/usr/bin/env python3
"""H4, first two clauses, and a named-free form of the third.

Alternating order on rotations of one word (as described in Bannai et al.,
Inf. Comput. 2024, section 1.2.1): first letter by <, second by >, third by <, ...
ABWT = last letters of the rotations so sorted.

Tested here:
 (1) the ABWT's LF (row of rotation R -> row of the rotation one place back)
     is, on each run of the column, an order-REVERSING translation: an
     interval exchange with flips on the runs;
 (2) right-end Rauzy induction with flips, run on the column alone, ends on
     one letter whose word is the least rotation in the alternating order;
 (3) its derivation tree is the min-Cartesian tree of the alternating
     rotation ranks over that rotation (the analogue of the entry's Theorem 1).
 (4) any column: the closed letters give exactly the cycles of the flipped LF
     (a flipped closed letter of length k: k//2 cycles spelling w w, k%2 spelling w).
Whether (3) is 'the standard factorization tree for the alternating order'
is a matter of that literature's definitions and is not decided here.
"""
import itertools
import random
import sys
from collections import Counter

from h1_h2_induction import expand


def alt_key(w):
    return tuple(c if i % 2 == 0 else -c for i, c in enumerate(w))


def primitive(w):
    n = len(w)
    return not any(n % d == 0 and w[:d] * (n // d) == w for d in range(1, n))


def abwt(w):
    n = len(w)
    rots = sorted(range(n), key=lambda i: alt_key(w[i:] + w[:i]))
    return tuple(w[(i - 1) % n] for i in rots), rots


def lf_flip(L):
    """rows with equal letters go to that letter's bucket in reversed order"""
    n = len(L)
    order = sorted(range(n), key=lambda i: (L[i], -i))
    pi = [0] * n
    for rank, i in enumerate(order):
        pi[i] = rank
    return pi


def induce_flips(L):
    n = len(L)
    starts = [i for i in range(n) if i == 0 or L[i] != L[i - 1]]
    r = len(starts)
    lam = [(starts[k + 1] if k + 1 < r else n) - starts[k] for k in range(r)]
    word = [L[s] for s in starts]
    flip = [True] * r
    top = list(range(r))
    # bottom: by letter, and inside a letter's bucket the runs in reversed order
    bot = sorted(range(r), key=lambda k: (L[starts[k]], -k))
    closed, steps = [], 0
    while top:
        A, B = top[-1], bot[-1]
        if A == B:
            closed.append((word[A], lam[A], flip[A]))
            top.pop()
            bot.pop()
            continue
        steps += 1
        N = (word[A], word[B])
        if lam[A] > lam[B]:
            # J_B is the end of I_A; B's points go on through A
            lam[A] -= lam[B]
            word[B] = N
            bot.pop()
            i = bot.index(A)
            bot.insert(i if flip[A] else i + 1, B)   # A flipped: the end of I_A lands at the START of J_A
            flip[B] ^= flip[A]
        elif lam[A] < lam[B]:
            # I_A is the end of J_B; its preimage is the end of I_B, or its start if B is flipped
            lam[B] -= lam[A]
            word[A] = N
            top.pop()
            i = top.index(B)
            top.insert(i if flip[B] else i + 1, A)
            flip[A] ^= flip[B]
        else:
            word[B] = N
            top.pop()
            bot.pop()
            bot[bot.index(A)] = B
            flip[B] ^= flip[A]
    return closed, steps


def cartesian(key, a, b, V):
    if b - a == 1:
        return V[a]
    m = min(range(a + 1, b), key=lambda j: key[j])
    return (cartesian(key, a, m, V), cartesian(key, m, b, V))


def necklace(w):
    return min(w[i:] + w[:i] for i in range(len(w)))


def main():
    st = dict(prim=0, flip_runs_ok=0, word_ok=0, tree_ok=0, steps=0)
    for sigma, maxn in ((2, 13), (3, 9), (4, 7)):
        for n in range(1, maxn + 1):
            for w in itertools.product(range(sigma), repeat=n):
                if not primitive(w):
                    continue
                L, rots = abwt(w)
                rank = [0] * n
                for rk, i in enumerate(rots):
                    rank[i] = rk
                # (1) true LF from the sorted rotations
                true_lf = [rank[(rots[x] - 1) % n] for x in range(n)]
                assert true_lf == lf_flip(L), ('lf', w)
                st['flip_runs_ok'] += 1
                closed, steps = induce_flips(L)
                assert len(closed) == 1 and closed[0][1] == 1, ('one letter', w, closed)
                V = w[rots[0]:] + w[:rots[0]]          # least rotation, alternating order
                assert expand(closed[0][0]) == V, ('word', w, closed)
                st['word_ok'] += 1
                keyV = [rank[(rots[0] + j) % n] for j in range(n)]
                assert closed[0][0] == cartesian(keyV, 0, n, V), ('tree', w)
                st['tree_ok'] += 1
                st['prim'] += 1
                st['steps'] += steps
        print('primitive words, sigma', sigma, 'n <=', maxn, dict(st))
        sys.stdout.flush()
    # (4) arbitrary columns
    cols = multi = flipped_closed = 0
    rng = random.Random(4)
    def columns():
        for sigma, maxn in ((2, 12), (3, 8)):
            for n in range(1, maxn + 1):
                yield from itertools.product(range(sigma), repeat=n)
        for _ in range(3000):
            sigma = rng.choice((2, 3, 5, 26))
            L = []
            n = rng.randint(13, 90)
            while len(L) < n:
                L += [rng.randrange(sigma)] * rng.choice((1, 1, 2, 3, 6))
            yield tuple(L[:n])
    for L in columns():
        n, pi = len(L), lf_flip(L)
        seen, ref = [False] * n, Counter()
        for x in range(n):
            if seen[x]:
                continue
            wd, y = [], x
            while not seen[y]:
                seen[y] = True
                wd.append(L[y])
                y = pi[y]
            ref[necklace(tuple(reversed(wd)))] += 1
        got = Counter()
        closed, _ = induce_flips(L)
        for t, k, f in closed:
            wd = expand(t)
            if f:
                got[necklace(wd + wd)] += k // 2
                got[necklace(wd)] += k % 2
                flipped_closed += k > 1
            else:
                got[necklace(wd)] += k
        got = +got
        assert got == ref, ('cycles', L, got, ref)
        cols += 1
        multi += sum(ref.values()) > 1
    print('arbitrary columns', cols, 'with several cycles', multi,
          'with a flipped closed letter of length > 1', flipped_closed)


if __name__ == '__main__':
    main()
