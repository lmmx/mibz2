#!/usr/bin/env python3
"""Tests for H1 and H2 (MONODROMY entry 2026-11-10, sections 2 and 5.6).

Right-end and left-end Rauzy-Veech induction on LF of an ARBITRARY column L,
with the entry's drop rule (a closed letter is recorded and removed).

H1: closed words, in closing order, are the Lyndon factorization of the
    unique T with BBWT(T) = L (Gil-Scott / Kufleitner Thm 8), each with
    multiplicity = its length lambda, and each tree is the right Lyndon tree.
H2: left end = the same statement for the inverse alphabet order
    (greatest rotations; 'anti-Lyndon').

Light, exhaustive on small alphabets; no timing.
"""
import itertools
import random
import sys


# ---------- words ----------
def is_lyndon(w):
    return all(w < w[i:] for i in range(1, len(w)))


def duval(s):
    """Lyndon factorization, list of factors (tuples), non-increasing."""
    n, i, out = len(s), 0, []
    while i < n:
        j, k = i + 1, i
        while j < n and s[k] <= s[j]:
            k = i if s[k] < s[j] else k + 1
            j += 1
        while i <= k:
            out.append(tuple(s[i:i + j - k]))
            i += j - k
    return out


def right_tree(w):
    """Right standard factorization, recursively: v = longest proper Lyndon suffix."""
    if len(w) == 1:
        return w[0]
    for i in range(1, len(w)):
        if is_lyndon(w[i:]):
            return (right_tree(w[:i]), right_tree(w[i:]))
    raise AssertionError


def left_tree(w):
    """Left standard factorization: u = longest proper Lyndon prefix."""
    if len(w) == 1:
        return w[0]
    for i in range(len(w) - 1, 0, -1):
        if is_lyndon(w[:i]):
            assert is_lyndon(w[i:])
            return (left_tree(w[:i]), left_tree(w[i:]))
    raise AssertionError


def expand(t):
    if isinstance(t, tuple):
        return expand(t[0]) + expand(t[1])
    return (t,)


def bbwt(t):
    """Brute force: last letters of the rotations of the Lyndon factors, omega-sorted."""
    fs = duval(t)
    m = max(len(f) for f in fs)
    rows = []
    for f in fs:
        for i in range(len(f)):
            r = f[i:] + f[:i]
            key = (r * (2 * m // len(r) + 1))[:2 * m]
            rows.append((key, r[-1]))
    rows.sort(key=lambda x: x[0])
    return tuple(c for _, c in rows)


# ---------- LF ----------
def lf(L):
    order = sorted(range(len(L)), key=lambda i: (L[i], i))  # stable
    pi = [0] * len(L)
    for rank, i in enumerate(order):
        pi[i] = rank
    return pi


def cycles_reference(L, end):
    """Cycle words by walking LF (Kufleitner 2009 Thm 8 / Gil-Scott Alg. 5.2).
    end='right': cycles by decreasing minimal row, word = rotation at that row.
    end='left' : cycles by increasing maximal row, word = rotation at that row."""
    n, pi = len(L), lf(L)
    seen, out = [False] * n, []
    rows = range(n - 1, -1, -1) if end == 'left' else range(n)
    cyc = []
    for x in rows:
        if seen[x]:
            continue
        w, y = [], x
        while not seen[y]:
            seen[y] = True
            w.append(L[y])
            y = pi[y]
        cyc.append((x, tuple(reversed(w))))
    cyc.sort(key=lambda c: -c[0] if end == 'right' else c[0])
    return cyc


# ---------- the induction (entry section 2, with the drop rule) ----------
def induce(L, end='right'):
    """Returns (closed, steps): closed = [(tree, lam)] in closing order."""
    n = len(L)
    starts = [i for i in range(n) if i == 0 or L[i] != L[i - 1]]
    r = len(starts)
    lam = [(starts[k + 1] if k + 1 < r else n) - starts[k] for k in range(r)]
    word = [L[s] for s in starts]
    top = list(range(r))
    bot = sorted(range(r), key=lambda k: (L[starts[k]], k))
    closed, steps = [], 0
    e = -1 if end == 'right' else 0
    while top:
        A, B = top[e], bot[e]
        if A == B:
            closed.append((word[A], lam[A]))
            top.pop(e)
            bot.pop(e)
            continue
        steps += 1
        N = (word[A], word[B])
        if lam[A] > lam[B]:            # top wins
            lam[A] -= lam[B]
            word[B] = N
            bot.pop(e)
            i = bot.index(A)
            bot.insert(i + 1 if end == 'right' else i, B)
        elif lam[A] < lam[B]:          # bottom wins
            lam[B] -= lam[A]
            word[A] = N
            top.pop(e)
            i = top.index(B)
            top.insert(i + 1 if end == 'right' else i, A)
        else:                          # equal: A deleted, B takes A's bottom place
            word[B] = N
            top.pop(e)
            bot.pop(e)
            bot[bot.index(A)] = B
    return closed, steps


def check(L, sigma, stats):
    L = tuple(L)
    n = len(L)
    # ---- right end / H1 ----
    closed, steps = induce(L, 'right')
    ref = cycles_reference(L, 'right')
    words = [expand(t) for t, _ in closed]
    T = tuple(c for w, (_, k) in zip(words, closed) for c in w * k)
    assert len(T) == n, (L, closed)
    # (a) T is the BBWT preimage
    assert bbwt(T) == L, ('bbwt', L, T)
    # (b) closed words = Lyndon factorization of T, distinct factors with exponents
    fs = duval(T)
    comp = [(f, len(list(g))) for f, g in itertools.groupby(fs)]
    assert comp == [(w, k) for w, (_, k) in zip(words, closed)], ('fact', L, comp, closed)
    # (c) = cycles of LF by decreasing minimal row
    assert [w for _, w in ref] == [w for w, (_, k) in zip(words, closed) for _ in range(k)], ('cyc', L)
    # (d) every tree is the right Lyndon tree
    for (t, _), w in zip(closed, words):
        assert t == right_tree(w), ('tree', L, t)
    stats['cols'] += 1
    stats['multi'] += len(ref) > 1
    stats['pow'] += any(k > 1 for _, k in closed)
    stats['closed'] += len(closed)
    stats['nodes'] += steps
    # ---- left end / H2 ----
    closedL, stepsL = induce(L, 'left')
    inv = lambda w: tuple(sigma - 1 - c for c in w)
    refL = cycles_reference(L, 'left')
    wordsL = [expand(t) for t, _ in closedL]
    assert [w for _, w in refL] == [w for w, (_, k) in zip(wordsL, closedL) for _ in range(k)], ('cycL', L)
    for (t, _), w in zip(closedL, wordsL):
        # greatest rotation of its class
        assert all(w >= w[i:] + w[:i] for i in range(len(w))), ('greatest', L, w)
        # Lyndon for the inverse alphabet order, tree = right Lyndon tree there
        wi = inv(w)
        assert is_lyndon(wi), ('antiLyndon', L, w)
        ti = right_tree(wi)
        back = lambda x: (back(x[0]), back(x[1])) if isinstance(x, tuple) else sigma - 1 - x
        assert t == back(ti), ('treeL', L, t)
    # closed words in order = Lyndon factorization, inverse order, of their concatenation
    TL = tuple(c for w, (_, k) in zip(wordsL, closedL) for c in w * k)
    fsL = duval(inv(TL))
    assert [inv(f) for f in fsL] == [w for w, (_, k) in zip(wordsL, closedL) for _ in range(k)], ('factL', L)
    # and L reversed, letters inverted, is the BBWT (inverse order) of that text
    assert bbwt(inv(TL)) == inv(L[::-1]), ('bbwtL', L)
    stats['nodesL'] += stepsL
    stats['trees_differ'] += sorted(map(str, closed)) != sorted(map(str, closedL))


def main():
    stats = dict(cols=0, multi=0, pow=0, closed=0, nodes=0, nodesL=0, trees_differ=0)
    # sanity against the entry (section 5.6): abacb, L = bbcaa: right end 4 steps, left end 3
    L = (1, 1, 2, 0, 0)
    assert bbwt((0, 1, 0, 2, 1)) == L
    assert induce(L, 'right')[1] == 4 and induce(L, 'left')[1] == 3
    print('sanity abacb: right', induce(L, 'right')[1], 'left', induce(L, 'left')[1])
    for sigma, maxn in ((2, 14), (3, 9), (4, 7)):
        for n in range(1, maxn + 1):
            for L in itertools.product(range(sigma), repeat=n):
                check(L, sigma, stats)
        print('exhaustive sigma', sigma, 'n <=', maxn, dict(stats))
        sys.stdout.flush()
    rng = random.Random(20261110)
    for _ in range(4000):
        sigma = rng.choice((2, 3, 5, 8, 26))
        n = rng.randint(15, 120)
        # runs make the exchange non-trivial
        L = []
        while len(L) < n:
            L += [rng.randrange(sigma)] * rng.choice((1, 1, 1, 2, 3, 5, 9))
        check(L[:n], sigma, stats)
    print('all (with 4000 random, n 15..120):', stats)


if __name__ == '__main__':
    main()
