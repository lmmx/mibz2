#!/usr/bin/env python3
"""H3: (i) is the LEFT Lyndon tree (left standard factorization) the derivation
tree of some schedule of Rauzy steps taken at coincidences of LF's exchange?
(ii) nodes over the hinges (entry, Theorem 3): left tree against right tree.

A step is taken at any coincidence, on the two letters that END there
(the entry's kind) or on the two that BEGIN there (its mirror).
Light, exhaustive on short Lyndon words; no timing.
"""
import itertools
import random
import sys

sys.setrecursionlimit(100000)
from h1_h2_induction import is_lyndon, right_tree, left_tree, expand, induce, lf  # noqa: E402


def bwt_of_lyndon(V):
    n = len(V)
    rots = sorted(range(n), key=lambda i: V[i:] + V[:i])
    return tuple(V[(i - 1) % n] for i in rots), rots


# ---------- all schedules ----------
def all_trees(L, kinds=('end', 'begin')):
    n = len(L)
    starts = [i for i in range(n) if i == 0 or L[i] != L[i - 1]]
    r = len(starts)
    lam0 = tuple((starts[k + 1] if k + 1 < r else n) - starts[k] for k in range(r))
    word0 = tuple(L[s] for s in starts)
    top0 = tuple(range(r))
    bot0 = tuple(sorted(range(r), key=lambda k: (L[starts[k]], k)))
    # state: top = tuple of (word, lam) ; bot = tuple of indices into top
    def canon(top, bot, lam, word):
        pos = {a: i for i, a in enumerate(top)}
        return (tuple((word[a], lam[a]) for a in top), tuple(pos[b] for b in bot))

    start = canon(top0, bot0, dict(zip(top0, lam0)), dict(zip(top0, word0)))
    seen, finals, stack = {start}, set(), [start]
    while stack:
        items, botp = stack.pop()
        k = len(items)
        if k == 1:
            finals.add(items[0][0])
            continue
        lam = [x[1] for x in items]
        word = [x[0] for x in items]
        top = list(range(k))
        bot = list(botp)
        tsum = list(itertools.accumulate(lam))
        bsum = list(itertools.accumulate(lam[b] for b in bot))
        tend = {s: i for i, s in enumerate(tsum)}
        tbeg = {s - lam[i]: i for i, s in enumerate(tsum)}
        for j, s in enumerate(bsum):
            for kind in kinds:
                if kind == 'end':
                    if s not in tend:
                        continue
                    A, B = tend[s], bot[j]
                else:
                    b0 = s - lam[bot[j]]
                    if b0 not in tbeg:
                        continue
                    A, B = tbeg[b0], bot[j]
                if A == B:
                    continue
                lam2, word2, top2, bot2 = lam[:], word[:], top[:], bot[:]
                N = (word[A], word[B])
                off = 1 if kind == 'end' else 0
                if lam[A] > lam[B]:
                    lam2[A] -= lam[B]
                    word2[B] = N
                    bot2.remove(B)
                    bot2.insert(bot2.index(A) + off, B)
                elif lam[A] < lam[B]:
                    lam2[B] -= lam[A]
                    word2[A] = N
                    top2.remove(A)
                    top2.insert(top2.index(B) + off, A)
                else:
                    # equal: A is deleted; on the bottom B leaves its place and takes A's
                    word2[B] = N
                    top2.remove(A)
                    bot2 = [x for x in bot if x != B]
                    bot2[bot2.index(A)] = B
                st = canon(top2, bot2, dict(enumerate(lam2)), dict(enumerate(word2)))
                if st not in seen:
                    seen.add(st)
                    stack.append(st)
    return finals, len(seen)


def lyndon_words(sigma, n):
    for w in itertools.product(range(sigma), repeat=n):
        if is_lyndon(w):
            yield w


def part_i():
    tot = dict(words=0, right_in=0, left_in=0, left_ne_right=0, left_in_when_ne=0,
               left_in_end_only=0, states=0, trees=0)
    first_miss = None
    for sigma, maxn in ((2, 11), (3, 8)):
        for n in range(2, maxn + 1):
            for V in lyndon_words(sigma, n):
                L, _ = bwt_of_lyndon(V)
                finals, ns = all_trees(L)
                finals_end, _ = all_trees(L, kinds=('end',))
                rt, lt = right_tree(V), left_tree(V)
                assert all(len(expand(t)) == n for t in finals)
                tot['words'] += 1
                tot['states'] += ns
                tot['trees'] += len(finals)
                tot['right_in'] += rt in finals
                tot['left_in'] += lt in finals
                tot['left_in_end_only'] += lt in finals_end
                if lt != rt:
                    tot['left_ne_right'] += 1
                    tot['left_in_when_ne'] += lt in finals
                    if lt not in finals and first_miss is None:
                        first_miss = (V, L, lt, rt)
        print('part (i), sigma', sigma, 'n <=', maxn, dict(tot))
        sys.stdout.flush()
    print('first Lyndon word whose left tree is no schedule tree:', first_miss)


# ---------- (ii) nodes over the hinges ----------
def cartesian_nodes(key, lo, hi, hinge_prefix):
    """internal nodes of the min-Cartesian tree of key over cut positions lo+1..hi-1
    of leaves lo..hi-1; count those whose leaf span holds a hinge."""
    cnt, stack = 0, [(lo, hi)]
    while stack:
        a, b = stack.pop()
        if b - a < 2:
            continue
        if hinge_prefix[b] - hinge_prefix[a] > 0:
            cnt += 1
        m = min(range(a + 1, b), key=lambda j: key[j])
        stack.append((a, m))
        stack.append((m, b))
    return cnt


def left_nodes(V, hinge_prefix):
    cnt, stack = 0, [(0, len(V))]
    while stack:
        a, b = stack.pop()
        if b - a < 2:
            continue
        if hinge_prefix[b] - hinge_prefix[a] > 0:
            cnt += 1
        # longest proper Lyndon prefix of the Lyndon word V[a:b] (Duval scan)
        k, best = a, a + 1
        for j in range(a + 1, b - 1):
            if V[k] < V[j]:
                k, best = a, j + 1
            else:
                assert V[k] == V[j]
                k += 1
        stack.append((a, best))
        stack.append((best, b))
    return cnt


def hinge_counts(V):
    n = len(V)
    L, rots = bwt_of_lyndon(V)
    rank = [0] * n
    for rk, i in enumerate(rots):
        rank[i] = rk
    res = {}
    for name, rows in (('run starts', [t for t in range(n) if t == 0 or L[t] != L[t - 1]]),
                       ('run ends', [t for t in range(n) if t == n - 1 or L[t] != L[t + 1]])):
        h = [0] * n
        for t in rows:
            h[(rots[t] - 1) % n] = 1
        pre = [0] + list(itertools.accumulate(h))
        res[name] = (cartesian_nodes(rank, 0, n, pre), left_nodes(V, pre))
    r = sum(1 for t in range(n) if t == 0 or L[t] != L[t - 1])
    S_right = induce(L, 'right')[1]
    S_left = induce(L, 'left')[1]
    return r, S_right, S_left, res


def random_lyndon(rng, n, sigma, style):
    while True:
        if style == 'uniform':
            w = [rng.randrange(sigma) for _ in range(n)]
        else:  # repetitive: copies of a few phrases with edits
            phrases = [[rng.randrange(sigma) for _ in range(rng.randint(3, 12))] for _ in range(6)]
            w = []
            while len(w) < n:
                p = list(rng.choice(phrases))
                if rng.random() < 0.15:
                    p[rng.randrange(len(p))] = rng.randrange(sigma)
                w += p
            w = w[:n]
        w = tuple(w)
        i = min(range(n), key=lambda i: w[i:] + w[:i])
        V = w[i:] + w[:i]
        if is_lyndon(V):
            return V


def part_ii():
    # Theorem 3 as read here: S(right end) = internal nodes of the right Lyndon tree
    # over a run-start hinge. Check on all short Lyndon words first.
    ok = bad = 0
    for sigma, maxn in ((2, 12), (3, 8)):
        for n in range(2, maxn + 1):
            for V in lyndon_words(sigma, n):
                r, S, SL, res = hinge_counts(V)
                if res['run starts'][0] == S:
                    ok += 1
                else:
                    bad += 1
    print('part (ii) Theorem 3 reading, short Lyndon words: equal', ok, 'different', bad)
    rng = random.Random(7)
    for style, sigma, n in (('uniform', 2, 600), ('uniform', 4, 600), ('uniform', 26, 600),
                            ('repetitive', 4, 1500), ('repetitive', 26, 1500)):
        agg = dict(words=0, r=0, S_right=0, S_left=0, R_start=0, Lt_start=0, R_end=0, Lt_end=0,
                   left_smaller=0, thm3_ok=0)
        for _ in range(40):
            V = random_lyndon(rng, n, sigma, style)
            r, S, SL, res = hinge_counts(V)
            agg['words'] += 1
            agg['r'] += r
            agg['S_right'] += S
            agg['S_left'] += SL
            agg['R_start'] += res['run starts'][0]
            agg['Lt_start'] += res['run starts'][1]
            agg['R_end'] += res['run ends'][0]
            agg['Lt_end'] += res['run ends'][1]
            agg['left_smaller'] += res['run starts'][1] < res['run starts'][0]
            agg['thm3_ok'] += res['run starts'][0] == S
        rr = agg['r']
        print(f"part (ii) {style} sigma={sigma} n={n}: words {agg['words']}, r {rr}, "
              f"right-end steps/r {agg['S_right']/rr:.3f}, left-end steps/r {agg['S_left']/rr:.3f}, "
              f"right tree nodes over run-start hinges/r {agg['R_start']/rr:.3f} (equal to S on {agg['thm3_ok']}), "
              f"left tree same hinges/r {agg['Lt_start']/rr:.3f}, "
              f"right tree over run-end hinges/r {agg['R_end']/rr:.3f}, left tree over run-end hinges/r {agg['Lt_end']/rr:.3f}, "
              f"left<right on {agg['left_smaller']}")
        sys.stdout.flush()


if __name__ == '__main__':
    part_i()
    part_ii()
