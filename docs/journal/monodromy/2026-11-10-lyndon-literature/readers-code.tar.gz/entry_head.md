# 2026-11-10 · MONODROMY 2 · The generalized-Lyndon literature read against the induction: 32 Scholar lines, a bibliography, what was already in print, and the steps as the tree's own count

Labels: **P** proved here · **C** counted (exact for its input) · **M** measured · **Conj**
conjecture · **K** known, cited with its place. "Entry 1" is
`2026-11-10-rauzy-veech.md`; its notation is used without restating it. No clock in this
entry: nothing here was timed.

## 0. Result

- **Asked (Louis, 10 Nov):** two Google Scholar result lists, reached from the references of
  Crochemore–Russo's *Cartesian and Lyndon trees* through Dolce–Restivo–Reutenauer's *On
  generalized Lyndon words*, to be recorded verbatim, made an itemised bibliography, and
  mined.
- **Verbatim:** `2026-11-10-lyndon-literature/scholar-results.txt`, 32 result lines as pasted.
- **Bibliography (§2):** the 32 lines are **23 works** (§1 maps each line); 30 more works
  were fetched to state things exactly. Every field is from a page fetched on 10 November;
  what could not be fetched is said, item by item.
- **For the decoder's speed: nothing.** No paper of the lists inverts a transform in fewer
  than n steps of LF, builds a Lyndon tree, array or grammar from a column, or works from
  the run-length form in time that depends on r alone (§3.4, §3.1).
- **Already in print, narrowing entry 1's claims (§5):**
  - the right-end induction, read in the text, is the **Schützenberger–Melançon rewriting**
    on the circular word (Melançon 1992; Reutenauer 2006, §3.4): merge a rise u < v whose
    right word is a largest word present. Every right-end step is such a rise (**C**);
  - what entry 1's §2 does with "a column that is no BWT" is the inversion of the
    **extended / bijective BWT** by its cycles, largest first (Gil–Scott; Kufleitner 2009,
    Theorem 8);
  - that every letter's word is a Lyndon word follows from two lemmas on next and previous
    smaller suffixes (as Ellert 2022 states them).
  What stays entry 1's: the rewriting done on the run-length column, one rise at all its
  occurrences at once in O(1), in S steps; the counts; the cells form.
- **Derived while reading (§4; P + C, brute force, `lyndon_induction_tests.py.txt`):**
  - **Theorem 5: the steps are the tree's.** For every order of right-handed steps, steps =
    the inner nodes of the derivation tree that have a hinge below them. It contains entry
    1's Theorem 3, gives the floor r₂ − 1 a second proof, and says that **no order which
    leaves the Lyndon tree is cheaper than the right end**: every saving entry 1 counted
    (1.279 r against 1.812 r) changes the grammar;
  - **the induction inverts the extended and the bijective BWT in S steps**, with the Lyndon
    tree of every factor: the only run-length inversion in print takes n steps;
  - **the left end is the right end for the inverse alphabet order** (the Lyndon tree,
    inverse order, of the greatest rotation): entry 1's 2.137 r against 1.812 r is a fact
    about the text, not about the ends;
  - **the left Lyndon tree is no order of steps** (smallest case `aabbc`), and where it can
    be counted it costs about n nodes over the hinges, not 1.8 r;
  - **the alternating BWT is the same exchange with every interval flipped;** the induction
    with a flip bit inverts it, and its tree is not the Galois words' standard tree;
  - on a two-run column `b^k a^l` the right end is **Euclid by subtraction** on (k, l).
- **Usable by the production kernel (§6, ranked):** a proved refusal after the order stage
  (S ≥ r₂ − 1, and r₂ is free there); the two-run columns as the division rule's unit test;
  a validity criterion from the run lengths' gcd (Likhomanov–Shur) for telling a corrupt
  stream from a periodic one. None of them moves the clock on Wikidata.
