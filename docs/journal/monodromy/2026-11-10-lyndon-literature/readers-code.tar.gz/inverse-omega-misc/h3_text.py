#!/usr/bin/env python3
"""H3 (b) on text-like samples: nodes over the hinges, right Lyndon tree vs left Lyndon tree of V.
usage: h3_text.py <file> <offset> <nbytes>  (file only read)"""
import sys
sys.setrecursionlimit(1000000)
from tests import duval, cartesian, induce
from h3_left_tree import left_lyndon_tree, hinge_nodes
def run(name, data):
    t = data.decode('latin-1'); n = len(t); d = t + t
    order = sorted(range(n), key=lambda p: d[p:p + n])
    if any(d[order[i]:order[i]+n] == d[order[i+1]:order[i+1]+n] for i in range(n-1)): print(name, 'not primitive'); return
    s = order[0]; V = d[s:s + n]
    rank = [0] * n
    for x, p in enumerate(order): rank[(p - s) % n] = x          # rank of the rotation starting at V[j]
    L = ''.join(V[((p - s) % n) - 1] for p in order)
    hs = {(((order[x] - s) % n) - 1) % n for x in range(n) if x == 0 or L[x] != L[x - 1]}
    R = cartesian(V, rank, 0, n, min)
    Lt = left_lyndon_tree(V)
    a, b = hinge_nodes(R, hs), hinge_nodes(Lt, hs)
    S = induce(L)[1]
    assert a == S, (a, S)
    print(f'{name}: n={n} r={len(hs)} r/n={len(hs)/n:.3f}  right tree over hinges={a} ({a/len(hs):.3f} r) = induction steps  left Lyndon tree={b} ({b/len(hs):.3f} r)')
path, off, nb = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
data = open(path, 'rb').read()
for k in range(4):
    run(f'text sample {k}', data[off + k * nb: off + (k + 1) * nb])
