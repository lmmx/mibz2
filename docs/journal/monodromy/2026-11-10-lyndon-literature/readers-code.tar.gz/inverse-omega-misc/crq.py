import sys, json, urllib.request, urllib.parse, ssl, os
def q(query, rows=6):
    url='https://api.crossref.org/works?rows=%d&query.bibliographic=%s'%(rows, urllib.parse.quote(query))
    req=urllib.request.Request(url, headers={'User-Agent':'lit-check/1.0'})
    with urllib.request.urlopen(req, timeout=60) as r:
        d=json.load(r)
    for it in d['message']['items']:
        au='; '.join((a.get('given','')+' '+a.get('family','')).strip() for a in it.get('author',[]))
        print('DOI:',it.get('DOI'))
        print('  type:',it.get('type'),'| title:',(it.get('title') or [''])[0])
        print('  authors:',au)
        print('  container:',it.get('container-title'),'| vol',it.get('volume'),'| issue',it.get('issue'),'| pages',it.get('page'),'| art',it.get('article-number'))
        print('  issued:',it.get('issued',{}).get('date-parts'),'| published-online:',it.get('published-online',{}).get('date-parts'),'| print:',it.get('published-print',{}).get('date-parts'))
        print('  publisher:',it.get('publisher'),'| ISBN',it.get('ISBN'))
for a in sys.argv[1:]:
    print('=== ',a); q(a)
