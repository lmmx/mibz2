#!/usr/bin/env python3
"""T6: how large is the ICFL bound M (Bonizzoni et al. 2021: lcp of two factors <= M = max |m_i m_{i+1}|)
against the true longest repeat, on a block-like word?  M >= the longest factor of CFL_in(w), because each
ICFL factor is a concatenation of consecutive CFL_in factors (2018, Prop. 7.13; needs >= 2 ICFL factors,
which holds when w is a Lyndon word that is no letter, Prop. 4.3).  Input: least rotation V of a sample.
usage: t6_icfl_bound.py <file> <nbytes>   (the file is only read)"""
import sys, random

def duval(s):
    out, i, n = [], 0, len(s)
    while i < n:
        j, k = i + 1, i
        while j < n and s[k] <= s[j]:
            k = i if s[k] < s[j] else k + 1
            j += 1
        while i <= k:
            out.append(j - k); i += j - k
    return out

def least_rotation(s):
    n = len(s); d = s + s
    i = min(range(n), key=lambda k: d[k:k + n])
    return d[i:i + n]

def max_lcp(s):
    n = len(s)
    rank = list(s); sa = list(range(n)); k = 1
    while True:
        key = lambda i: (rank[i], rank[i + k] if i + k < n else -1)
        sa.sort(key=key)
        new = [0] * n
        for a in range(1, n):
            new[sa[a]] = new[sa[a - 1]] + (key(sa[a]) != key(sa[a - 1]))
        rank = new
        if rank[sa[-1]] == n - 1: break
        k *= 2
    h, best = 0, 0
    pos = [0] * n
    for a, i in enumerate(sa): pos[i] = a
    for i in range(n):
        if pos[i] == 0: h = 0; continue
        j = sa[pos[i] - 1]
        while i + h < n and j + h < n and s[i + h] == s[j + h]: h += 1
        best = max(best, h)
        if h: h -= 1
    return best

def report(name, s):
    v = least_rotation(s)
    n = len(v)
    cin = duval(bytes(255 - b for b in v))        # Lyndon factorisation for the inverse order
    cfl = duval(v)
    print(f'{name}: n={n}  CFL(V) factors={len(cfl)}  CFL_in(V) factors={len(cin)}  '
          f'longest CFL_in factor={max(cin)} ({max(cin) / n:.3f} n)  => M >= {max(cin)}; '
          f'longest repeat (max lcp of two suffixes)={max_lcp(v)}')

if __name__ == '__main__':
    path, nb = sys.argv[1], int(sys.argv[2])
    data = open(path, 'rb').read()[:nb]
    report('text sample', data)
    rng = random.Random(7)
    report('uniform 4 letters', bytes(rng.choice(b'acgt') for _ in range(nb)))
    f = [b'b', b'a']
    while len(f[-1]) < nb: f.append(f[-1] + f[-2])
    report('Fibonacci word', f[-1])
    report('period 37 x k + 5', bytes(rng.choice(b'abcd') for _ in range(37)) * (nb // 37) + b'abcda')
