import json,sys
d=json.load(open(sys.argv[1]))
objs=d['_embedded']['searchResult']['_embedded']['objects']
for o in objs:
    it=o['_embedded']['indexableObject']
    print('UUID',it.get('uuid'),'| handle',it.get('handle'),'| name',it.get('name'))
    md=it.get('metadata',{})
    for k,v in md.items():
        vals=[x['value'] for x in v]
        s=' || '.join(vals)
        print('  ',k,':',s[:700])
    print('  links:',{k:v['href'] for k,v in it.get('_links',{}).items() if k in('bundles','self')})
