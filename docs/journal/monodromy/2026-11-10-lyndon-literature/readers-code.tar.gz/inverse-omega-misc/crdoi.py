import sys, json, urllib.request, urllib.parse
def get(doi):
    url='https://api.crossref.org/works/'+urllib.parse.quote(doi)
    req=urllib.request.Request(url, headers={'User-Agent':'lit-check/1.0'})
    with urllib.request.urlopen(req, timeout=60) as r:
        it=json.load(r)['message']
    au='; '.join((a.get('given','')+' '+a.get('family','')).strip() for a in it.get('author',[]))
    ed='; '.join((a.get('given','')+' '+a.get('family','')).strip() for a in it.get('editor',[]))
    print('DOI:',it.get('DOI'))
    print('  type:',it.get('type'),'| title:',(it.get('title') or [''])[0])
    print('  authors:',au)
    if ed: print('  editors:',ed)
    print('  container:',it.get('container-title'),'| vol',it.get('volume'),'| issue',it.get('issue'),'| pages',it.get('page'),'| art',it.get('article-number'))
    print('  issued:',it.get('issued',{}).get('date-parts'),'| online:',it.get('published-online',{}).get('date-parts'),'| print:',it.get('published-print',{}).get('date-parts'))
    print('  publisher:',it.get('publisher'),'| ISBN',it.get('ISBN'),'| ISSN',it.get('ISSN'))
    print('  relation:',json.dumps(it.get('relation',{}))[:400])
    print('  update-to:',it.get('update-to'))
for d in sys.argv[1:]:
    try: get(d)
    except Exception as e: print('ERR',d,e)
