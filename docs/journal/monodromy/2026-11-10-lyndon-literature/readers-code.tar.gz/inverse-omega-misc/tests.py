#!/usr/bin/env python3
"""Light checks for the inverse-omega-misc literature cluster.
Reference (slow) implementations only; nothing is timed.

T1  right-end induction on BWT(T), T primitive  == Lyndon tree of least rotation   (entry, Thm 1-2; sanity)
T2  LEFT-end induction on BWT(T)                == Lyndon tree, for the INVERSE alphabet order, of the
                                                   GREATEST rotation == max-Cartesian tree of rotation ranks (H2)
T3  right-end induction with the drop rule on an ARBITRARY column: closed words = Lyndon conjugates of
    LF's cycles, closing order non-increasing; on BBWT(T): closed words in order = CFL(T), trees = Lyndon trees (H1)
T3b the same at the LEFT end: closed words = anti-Lyndon conjugates, in non-increasing order for <_in
T4  ICFL by its definition (Bonizzoni et al. 2018, Def. 4.2/4.3): paper's examples, grouping of CFL_in,
    and the bound lcp <= M of the 2021 paper, on all short words
T5  omega-order (Luo-Zhu-Jin): AB<BA <=> A^w<B^w; equals lex on Lyndon words; M_i reduction; CFL(T) is the
    lexicographically largest concatenation of its factors
"""
import sys, random, itertools
from functools import cmp_to_key

# ---------------------------------------------------------------- words
def rotations(t): return [t[i:] + t[:i] for i in range(len(t))]
def primitive(t):
    n = len(t)
    return all(t != t[i:] + t[:i] for i in range(1, n))
def inv(t, alpha):            # map a word to its image under the order-reversing relabelling
    m = {c: alpha[len(alpha) - 1 - i] for i, c in enumerate(alpha)}
    return ''.join(m[c] for c in t)
def is_lyndon(w): return all(w < w[i:] for i in range(1, len(w)))
def duval(s):
    out, i, n = [], 0, len(s)
    while i < n:
        j, k = i + 1, i
        while j < n and s[k] <= s[j]:
            k = i if s[k] < s[j] else k + 1
            j += 1
        while i <= k:
            out.append(s[i:i + j - k]); i += j - k
    return out

# ---------------------------------------------------------------- trees (leaf = 1-char str, node = (l, r))
def expand(t): return t if isinstance(t, str) else expand(t[0]) + expand(t[1])
def lyndon_tree(w):
    """right standard factorisation, recursively: w = uv, v the longest proper suffix that is Lyndon."""
    if len(w) == 1: return w
    for i in range(1, len(w)):
        if is_lyndon(w[i:]):
            return (lyndon_tree(w[:i]), lyndon_tree(w[i:]))
    raise ValueError('not Lyndon: ' + w)
def cartesian(w, key, lo, hi, pick):
    """tree over w[lo:hi]; internal boundaries j in (lo, hi) carry key[j]; root = pick(key) boundary."""
    if hi - lo == 1: return w[lo]
    j = pick(range(lo + 1, hi), key=lambda x: key[x])
    return (cartesian(w, key, lo, j, pick), cartesian(w, key, j, hi, pick))

# ---------------------------------------------------------------- columns
def bwt(t):
    rs = sorted(rotations(t))
    return ''.join(r[-1] for r in rs)
def omega_cmp(u, v):
    a, b = u * len(v), v * len(u)          # compare u^w and v^w on lcm-multiple length
    a, b = a + a, b + b
    return (a > b) - (a < b)
def ebwt(words):
    rows = [r for w in words for r in rotations(w)]
    rows.sort(key=cmp_to_key(omega_cmp))
    return ''.join(r[-1] for r in rows)
def lf_cycles(L):
    """cycles of LF as words: for row x the word c with reversed(c) = L[x], L[LF x], ...  (x = least row)."""
    n = len(L)
    order = sorted(range(n), key=lambda i: (L[i], i))
    lf = [0] * n
    for pos, i in enumerate(order): lf[i] = pos
    seen, out = [False] * n, []
    for x in range(n):
        if seen[x]: continue
        y, cs = x, []
        while not seen[y]:
            seen[y] = True; cs.append(L[y]); y = lf[y]
        out.append(''.join(reversed(cs)))
    return out          # in increasing order of least row

# ---------------------------------------------------------------- the induction (entry, section 2), reference form
def induce(L, left=False):
    """Rauzy-Veech induction of LF's exchange on the runs of L, at the right end (or the left end, by
    running the same step on both orders reversed). Returns the closed letters in closing order:
    (tree, multiplicity), and the number of steps."""
    runs = []
    for c in L:
        if runs and runs[-1][0] == c: runs[-1][1] += 1
        else: runs.append([c, 1])
    r = len(runs)
    top = list(range(r))
    bot = sorted(range(r), key=lambda i: (runs[i][0], i))
    if left: top.reverse(); bot.reverse()
    lam = {i: runs[i][1] for i in range(r)}
    word = {i: runs[i][0] for i in range(r)}
    closed, steps = [], 0
    while top:
        A, B = top[-1], bot[-1]
        if A == B:                                   # I_A = J_A: lam[A] cycles spelling word[A]; drop
            closed.append((word[A], lam[A])); top.pop(); bot.pop(); continue
        steps += 1
        N = (word[A], word[B])
        if lam[A] > lam[B]:                          # top wins
            lam[A] -= lam[B]; word[B] = N
            bot.pop(); bot.insert(bot.index(A) + 1, B)
        elif lam[A] < lam[B]:                        # bottom wins
            lam[B] -= lam[A]; word[A] = N
            top.pop(); top.insert(top.index(B) + 1, A)
        else:                                        # equal
            word[B] = N
            top.pop(); bot.pop(); bot[bot.index(A)] = B
            del lam[A], word[A]
    return closed, steps

# ---------------------------------------------------------------- inverse Lyndon words, ICFL by definition
def is_inv_lyndon(w): return all(w[i:] < w for i in range(1, len(w)))
def strongly_less(x, y): return x < y and not y.startswith(x)      # x << y
def pref_bre(w):
    out = []
    for i in range(1, len(w)):
        p, v = w[:i], w[i:]
        if not is_inv_lyndon(p): continue
        for j in range(1, len(v) + 1):
            q = v[:j]
            if (is_inv_lyndon(q) and all(is_inv_lyndon(p + q[:k]) for k in range(1, j))
                    and not is_inv_lyndon(p + q) and strongly_less(p, q)):
                out.append((p, q))
    return out
def icfl(w):
    if is_inv_lyndon(w): return [w]
    pb = pref_bre(w)
    assert len(pb) == 1, (w, pb)                     # Prop. 4.1
    p, q = pb[0]
    rest = icfl(w[len(p):])
    if rest[0].startswith(q): return [p] + rest      # rb <=_p m'_1
    assert q[:-1].startswith(rest[0]), (w, p, q, rest)   # m'_1 <=_p r
    return [p + rest[0]] + rest[1:]
def lcp(a, b):
    k = 0
    while k < len(a) and k < len(b) and a[k] == b[k]: k += 1
    return k

# ================================================================= tests
def rand_word(rng, alpha, n): return ''.join(rng.choice(alpha) for _ in range(n))

def t1_t2(rng, trials):
    n1 = n2 = n2c = 0; left_steps = right_steps = 0
    for _ in range(trials):
        alpha = 'ab' if rng.random() < .4 else ('abc' if rng.random() < .6 else 'abcde')
        t = rand_word(rng, alpha, rng.randint(2, 40))
        if not primitive(t): continue
        L = bwt(t)
        # --- right end
        closed, s = induce(L); right_steps += s
        assert len(closed) == 1 and closed[0][1] == 1, (t, closed)
        V = min(rotations(t))
        assert expand(closed[0][0]) == V, (t, expand(closed[0][0]), V)
        assert closed[0][0] == lyndon_tree(V), t
        n1 += 1
        # --- left end
        closed, s = induce(L, left=True); left_steps += s
        assert len(closed) == 1 and closed[0][1] == 1, (t, closed)
        W = max(rotations(t))
        assert expand(closed[0][0]) == W, (t, expand(closed[0][0]), W)
        full = ''.join(sorted(set(alpha)))
        Wi = inv(W, full)                            # W read in the inverse order: a Lyndon word
        assert is_lyndon(Wi), (t, W)
        ti = lyndon_tree(Wi)
        back = lambda x: inv(x, full) if isinstance(x, str) else (back(x[0]), back(x[1]))
        assert closed[0][0] == back(ti), ('H2 fails', t, closed[0][0], back(ti))
        n2 += 1
        # --- max-Cartesian tree of the rotation ranks (ordinary order) over W
        rs = sorted(rotations(t)); rank = {x: i for i, x in enumerate(rs)}
        key = [rank[W[j:] + W[:j]] for j in range(len(W))]
        assert closed[0][0] == cartesian(W, key, 0, len(W), max), ('max-Cartesian fails', t)
        n2c += 1
    return n1, n2, n2c, right_steps, left_steps

def t3(rng, trials):
    cols = multi = dropped = bb = 0
    for _ in range(trials):
        alpha = 'ab' if rng.random() < .5 else 'abc'
        L = rand_word(rng, alpha, rng.randint(1, 24))
        cyc = lf_cycles(L)                           # by increasing least row
        for left in (False, True):
            closed, _ = induce(L, left=left)
            words = [expand(w) for w, m in closed for _ in range(m)]
            if not left:
                assert words == list(reversed(cyc)), (L, words, cyc)   # decreasing least row
                assert all(is_lyndon(w) for w in words), (L, words)
                assert all(words[i] >= words[i + 1] for i in range(len(words) - 1)), (L, words)
                assert all(w == lyndon_tree(expand(w)) for w, m in closed), L
            else:
                full = ''.join(sorted(set(alpha)))
                wi = [inv(w, full) for w in words]
                assert all(is_lyndon(w) for w in wi), (L, words)       # anti-Lyndon conjugates
                assert all(wi[i] >= wi[i + 1] for i in range(len(wi) - 1)), (L, words)
                assert sorted(min(rotations(w)) for w in words) == sorted(cyc), (L, words, cyc)
        cols += 1; multi += len(cyc) > 1; dropped += len(induce(L)[0]) > 1
    for _ in range(trials):
        alpha = 'ab' if rng.random() < .5 else 'abc'
        t = rand_word(rng, alpha, rng.randint(1, 24))
        f = duval(t)
        L = ebwt(f)                                  # bijective BWT of t (Gil-Scott)
        closed, _ = induce(L)
        words = [expand(w) for w, m in closed for _ in range(m)]
        assert words == f, (t, words, f)
        assert all(w == lyndon_tree(expand(w)) for w, m in closed), t
        bb += 1
    return cols, multi, dropped, bb

def t4(maxlen):
    ex = {'dabadabdabdadac': ['daba', 'dabdab', 'dadac'], 'cbabacaacbabacbac': ['cbabacaacbaba', 'cbac'],
          'dabdadacddbdc': ['dab', 'dadac', 'ddbdc'], 'bab': ['bab'],
          'dabadabdabdabdadac': ['daba', 'dabdabdab', 'dadac'], 'babaababaababab': ['babaababaa', 'babab']}
    for w, f in ex.items(): assert icfl(w) == f, (w, icfl(w), f)
    words = grouped = bounded = tight = 0
    for alpha in ('ab', 'abc'):
        full = alpha
        for n in range(1, maxlen[alpha] + 1):
            for tup in itertools.product(alpha, repeat=n):
                w = ''.join(tup); f = icfl(w); words += 1
                assert ''.join(f) == w and all(is_inv_lyndon(m) for m in f)
                assert all(strongly_less(f[i], f[i + 1]) for i in range(len(f) - 1)), (w, f)
                # grouping of CFL_in (2018, Prop. 7.13): every ICFL cut is a CFL_in cut
                cin = [inv(x, full) for x in duval(inv(w, full))]
                cuts_in = set(itertools.accumulate(len(x) for x in cin))
                assert set(itertools.accumulate(len(x) for x in f)) <= cuts_in, (w, f, cin)
                grouped += 1
                if len(f) > 1:                       # 2021 paper, Prop. 9.2 (arXiv numbering)
                    M = max(len(f[i]) + len(f[i + 1]) for i in range(len(f) - 1))
                    worst = max((lcp(w[i:], w[j:]) for i in range(n) for j in range(i + 1, n)), default=0)
                    assert worst <= M, (w, f, M, worst)
                    bounded += 1; tight += worst == M
    return len(ex), words, grouped, bounded, tight

def t5(rng, trials):
    pairs = lyn = red = rearr = 0
    for _ in range(trials):
        a, b = rand_word(rng, 'ab', rng.randint(1, 7)), rand_word(rng, 'ab', rng.randint(1, 7))
        c = omega_cmp(a, b)
        assert c == ((a + b > b + a) - (a + b < b + a)), (a, b)      # Lemma 3 (Dolce et al. Cor. 11)
        pairs += 1
        if is_lyndon(a) and is_lyndon(b):
            assert c == ((a > b) - (a < b)), (a, b); lyn += 1        # FAW Lemma 7
    for _ in range(trials // 10):
        ws = list({w for w in (rand_word(rng, 'ab', rng.randint(1, 6)) for _ in range(6)) if primitive(w)})
        def deg(s, a):
            d = 0
            while a.startswith(s * (d + 1)): d += 1
            return d
        M = {w: w * (max(deg(w, a) for a in ws) + 2) for w in ws}     # M_i = A_i^(deg+2)
        assert sorted(ws, key=cmp_to_key(omega_cmp)) == sorted(ws, key=lambda w: M[w]), ws
        red += 1
    for _ in range(trials // 10):
        t = rand_word(rng, 'ab' if rng.random() < .5 else 'abc', rng.randint(1, 12))
        f = duval(t)
        if len(f) > 7: continue
        assert t == max(''.join(p) for p in itertools.permutations(f)), (t, f)   # largest concatenation
        rearr += 1
    return pairs, lyn, red, rearr

if __name__ == '__main__':
    rng = random.Random(20261110)
    print('T1/T2 (primitive words; right tree; left tree; max-Cartesian; right steps; left steps):',
          t1_t2(rng, 6000))
    print('T3 (arbitrary columns; with several cycles; with a dropped letter; BBWT texts):', t3(rng, 4000))
    print('T4 (paper examples; words; groupings checked; lcp<=M checked; lcp==M):',
          t4({'ab': 11, 'abc': 7}))
    print('T5 (omega pairs; Lyndon pairs; M_i reductions; largest-concatenation):', t5(rng, 20000))
