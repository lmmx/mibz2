import sys, xml.etree.ElementTree as ET
ns={'a':'http://www.w3.org/2005/Atom','x':'http://arxiv.org/schemas/atom'}
for f in sys.argv[1:]:
    r=ET.parse(f).getroot()
    for e in r.findall('a:entry',ns):
        print('ID:',e.find('a:id',ns).text)
        print('TITLE:',' '.join(e.find('a:title',ns).text.split()))
        print('AUTHORS:','; '.join(a.find('a:name',ns).text for a in e.findall('a:author',ns)))
        print('PUBLISHED:',e.find('a:published',ns).text,'UPDATED:',e.find('a:updated',ns).text)
        for t in ('x:journal_ref','x:doi','x:comment'):
            el=e.find(t,ns)
            if el is not None: print(t,':',' '.join(el.text.split()))
        print('ABS:',' '.join(e.find('a:summary',ns).text.split())[:1500])
        print('---')
