#!/usr/bin/env python3
"""H3, a light check (outside this cluster's papers; the induction code is tests.py's).
(a) Is the LEFT Lyndon tree of the least rotation V (w = uv, u the longest proper prefix that is Lyndon,
    recursively) the derivation tree of SOME order of Rauzy steps (a step at any coincidence, entry 5.3)?
    Exhaustive over all schedules, for all short primitive words.
(b) Nodes over the hinges (entry, Theorem 3): internal nodes with a hinge leaf below, right tree vs left tree.
"""
import sys, random, itertools
sys.setrecursionlimit(100000)
from tests import rotations, primitive, is_lyndon, duval, expand, lyndon_tree, bwt, induce, cartesian

def left_lyndon_tree(w):
    if len(w) == 1: return w
    u = duval(w[:-1])[0]                 # longest proper prefix of w that is a Lyndon word
    assert is_lyndon(w[len(u):]), w
    return (left_lyndon_tree(u), left_lyndon_tree(w[len(u):]))

def initial(L):
    runs = []
    for c in L:
        if runs and runs[-1][0] == c: runs[-1][1] += 1
        else: runs.append([c, 1])
    r = len(runs)
    top = tuple(range(r))
    bot = tuple(sorted(range(r), key=lambda i: (runs[i][0], i)))
    lam = tuple(runs[i][1] for i in range(r))
    word = tuple(runs[i][0] for i in range(r))
    return top, bot, lam, word

def moves(state):
    top, bot, lam, word = state
    ends_t, c = {}, 0
    for a in top: c += lam[a]; ends_t[c] = a
    c = 0
    for b in bot:
        c += lam[b]
        if c in ends_t and ends_t[c] != b: yield ends_t[c], b

def moves_left(state):
    top, bot, lam, word = state
    st, c = {}, 0
    for a in top: st[c] = a; c += lam[a]
    c = 0
    for b in bot:
        if c in st and st[c] != b: yield st[c], b
        c += lam[b]

def apply_left(state, A, B):
    top, bot, lam, word = list(state[0]), list(state[1]), list(state[2]), list(state[3])
    N = (word[A], word[B])
    if lam[A] > lam[B]:
        lam[A] -= lam[B]; word[B] = N
        bot.remove(B); bot.insert(bot.index(A), B)
    elif lam[A] < lam[B]:
        lam[B] -= lam[A]; word[A] = N
        top.remove(A); top.insert(top.index(B), A)
    else:
        word[B] = N; top.remove(A); bot.remove(B); bot[bot.index(A)] = B
        lam[A] = 0; word[A] = None
    return tuple(top), tuple(bot), tuple(lam), tuple(word)

def apply(state, A, B):
    top, bot, lam, word = list(state[0]), list(state[1]), list(state[2]), list(state[3])
    N = (word[A], word[B])
    if lam[A] > lam[B]:
        lam[A] -= lam[B]; word[B] = N
        bot.remove(B); bot.insert(bot.index(A) + 1, B)
    elif lam[A] < lam[B]:
        lam[B] -= lam[A]; word[A] = N
        top.remove(A); top.insert(top.index(B) + 1, A)
    else:
        word[B] = N; top.remove(A); bot.remove(B); bot[bot.index(A)] = B
        lam[A] = 0; word[A] = None
    return tuple(top), tuple(bot), tuple(lam), tuple(word)

def all_trees(L, budget=200000, both=False):
    seen, out, stack = set(), set(), [initial(L)]
    minsteps = {}
    while stack:
        s = stack.pop()
        if s in seen: continue
        seen.add(s)
        if len(seen) > budget: return None
        if len(s[0]) == 1:
            out.add(s[3][s[0][0]]); continue
        ms = list(moves(s))
        assert ms, ('stuck', L, s)
        for A, B in ms: stack.append(apply(s, A, B))
        if both:
            for A, B in moves_left(s): stack.append(apply_left(s, A, B))
    return out

def hinge_nodes(tree, hinges):
    """internal nodes with at least one hinge leaf below; leaves are text positions 0..n-1 of V."""
    cnt = 0
    def go(t, lo):
        nonlocal cnt
        if isinstance(t, str): return lo + 1, (lo in hinges)
        mid, hl = go(t[0], lo); hi, hr = go(t[1], mid)
        if hl or hr: cnt += 1
        return hi, hl or hr
    go(tree, 0)
    return cnt

def hinges_of(t):
    n = len(t); V = min(rotations(t))
    order = sorted(range(n), key=lambda p: V[p:] + V[:p])     # row -> start position in V
    L = ''.join(V[p - 1] for p in order)
    hs = {(order[x] - 1) % n for x in range(n) if x == 0 or L[x] != L[x - 1]}
    return V, L, hs

if __name__ == '__main__':
    # ---- (a) exhaustive reachability
    tot = reach_left = reach_right = reach_anti = skipped = 0
    reach_left2 = reach_anti2 = ntrees = ntrees2 = ntreesV = ntrees2V = 0
    first_fail = first_fail2 = None
    for alpha, maxn in (('ab', int(sys.argv[1]) if len(sys.argv) > 1 else 10), ('abc', int(sys.argv[2]) if len(sys.argv) > 2 else 6)):
        for n in range(2, maxn + 1):
            for tup in itertools.product(alpha, repeat=n):
                t = ''.join(tup)
                if not primitive(t) or t != min(rotations(t)): continue      # one word a necklace
                if len(set(t)) < 2: continue
                L = bwt(t)
                trees = all_trees(L)
                both = all_trees(L, both=True)
                if trees is None or both is None: skipped += 1; continue
                assert trees <= both and all(expand(x) in rotations(t) for x in both), t
                reach_left2 += left_lyndon_tree(t) in both
                reach_anti2 += induce(L, left=True)[0][0][0] in both
                ntrees += len(trees); ntrees2 += len(both)
                ntreesV += sum(expand(x) == t for x in trees); ntrees2V += sum(expand(x) == t for x in both)
                if left_lyndon_tree(t) not in both and first_fail2 is None: first_fail2 = (t, L)
                assert all(expand(x) in rotations(t) for x in trees), t
                tot += 1
                reach_right += lyndon_tree(t) in trees
                reach_anti += induce(L, left=True)[0][0][0] in trees
                ok = left_lyndon_tree(t) in trees
                reach_left += ok
                if not ok and first_fail is None: first_fail = (t, L, left_lyndon_tree(t))
    print('(a) necklaces:', tot, '| right Lyndon tree reachable:', reach_right, '| left-end (anti-Lyndon) tree reachable:',
          reach_anti, '| LEFT Lyndon tree reachable:', reach_left, '| over budget:', skipped)
    print('    first word whose left Lyndon tree no right-type schedule makes:', first_fail)
    print('    with left-type steps too: LEFT Lyndon tree reachable:', reach_left2, '| left-end tree reachable:', reach_anti2, '| first failure:', first_fail2)
    print('    distinct final trees: right-type', ntrees, '(spelling V:', ntreesV, ') both types', ntrees2, '(spelling V:', ntrees2V, ')')
    # ---- (b) nodes over the hinges
    rng = random.Random(3)
    rows = []
    for alpha, n, reps in (('ab', 300, 40), ('abcd', 300, 40), ('abcdefghijklmnop', 300, 40)):
        sr = sl = sh = 0; less = more = same = 0
        for _ in range(reps):
            t = ''.join(rng.choice(alpha) for _ in range(n))
            if not primitive(t): continue
            V, L, hs = hinges_of(t)
            R, Lt = lyndon_tree(V), left_lyndon_tree(V)
            a, b = hinge_nodes(R, hs), hinge_nodes(Lt, hs)
            assert a == induce(L)[1], (t, a, induce(L)[1])            # Theorem 3 of the entry, as counted here
            sr += a; sl += b; sh += len(hs)
            less += b < a; more += b > a; same += b == a
        print(f'(b) sigma={len(alpha)} n={n} words={less + more + same}: runs r={sh}  right-tree nodes over hinges={sr} '
              f'({sr / sh:.3f} r)  left-tree={sl} ({sl / sh:.3f} r)  left<right on {less}, > on {more}, = on {same}')
