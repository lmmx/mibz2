#!/usr/bin/env python3
"""T5: runs of the BWT and of the alternating BWT of the same real bytes, and
the number of right-end induction steps on each (translations for the BWT,
flips for the ABWT).  Counts only; no clock.

The chunks are raw decompressed bytes (not bzip2's blocks: no RLE1), sorted as
cyclic rotations.  Usage:
  python3 -I t5_real.py FILE.bz2 CHUNK_BYTES OFFSET [OFFSET ...]"""
import bz2
import sys

import numpy as np


def cyclic_ranks(t, alt):
    """Ranks of the rotations of t by prefix doubling.  In the alternating
    order the second half of a factor of length 2k is compared in the opposite
    sense iff k is odd, i.e. only at k = 1."""
    n = len(t)
    rank = t.astype(np.int64)
    idx = np.arange(n)
    k = 1
    while True:
        sec = rank[(idx + k) % n]
        if alt and k % 2 == 1:
            sec = -sec
        order = np.lexsort((sec, rank))
        r1 = rank[order]
        s1 = sec[order]
        diff = np.empty(n, dtype=bool)
        diff[0] = True
        diff[1:] = (r1[1:] != r1[:-1]) | (s1[1:] != s1[:-1])
        new = np.empty(n, dtype=np.int64)
        new[order] = np.cumsum(diff) - 1
        rank = new
        k *= 2
        if rank.max() == n - 1:
            return rank
        if k >= 2 * n:
            raise SystemExit("chunk is not primitive")


def induce_count(L, alt):
    """The induction of fiet.induce on linked orders, counting only."""
    n = len(L)
    starts = np.flatnonzero(np.r_[True, L[1:] != L[:-1]])
    byte = L[starts].astype(np.int64)
    lam = np.diff(np.r_[starts, n]).tolist()
    r = len(starts)
    ids = np.arange(r)
    order = np.lexsort((-ids if alt else ids, byte)).tolist()
    S = r  # sentinel
    tprev = list(range(-1, r))
    tprev[0] = S
    tnext = list(range(1, r + 1)) + [0]
    tprev[S] = r - 1
    bprev = [0] * (r + 1)
    bnext = [0] * (r + 1)
    p = S
    for a in order:
        bprev[a] = p
        bnext[p] = a
        p = a
    bnext[p] = S
    bprev[S] = p
    flip = [-1 if alt else 1] * r
    wlen = [1] * r
    steps = eq = tw = bw = 0
    closed = []
    while True:
        A = tprev[S]
        B = bprev[S]
        if A == S:
            break
        if A == B:
            closed.append((wlen[A], lam[A], flip[A]))
            q = tprev[A]
            tnext[q] = S
            tprev[S] = q
            q = bprev[A]
            bnext[q] = S
            bprev[S] = q
            continue
        steps += 1
        nl = wlen[A] + wlen[B]
        nf = flip[A] * flip[B]
        if lam[A] > lam[B]:
            tw += 1
            lam[A] -= lam[B]
            q = bprev[B]  # unlink B from the bottom's end
            bnext[q] = S
            bprev[S] = q
            if flip[A] == 1:  # B just after A
                x = bnext[A]
                bnext[A] = B
                bprev[B] = A
                bnext[B] = x
                bprev[x] = B
            else:  # B just before A
                x = bprev[A]
                bnext[x] = B
                bprev[B] = x
                bnext[B] = A
                bprev[A] = B
            wlen[B] = nl
            flip[B] = nf
        elif lam[A] < lam[B]:
            bw += 1
            lam[B] -= lam[A]
            q = tprev[A]
            tnext[q] = S
            tprev[S] = q
            if flip[B] == 1:
                x = tnext[B]
                tnext[B] = A
                tprev[A] = B
                tnext[A] = x
                tprev[x] = A
            else:
                x = tprev[B]
                tnext[x] = A
                tprev[A] = x
                tnext[A] = B
                tprev[B] = A
            wlen[A] = nl
            flip[A] = nf
        else:
            eq += 1
            q = tprev[A]  # A leaves the top
            tnext[q] = S
            tprev[S] = q
            q = bprev[B]  # B leaves the bottom's end ...
            bnext[q] = S
            bprev[S] = q
            x = bprev[A]  # ... and takes A's place
            y = bnext[A]
            bnext[x] = B
            bprev[B] = x
            bnext[B] = y
            bprev[y] = B
            wlen[B] = nl
            flip[B] = nf
    return r, steps, eq, tw, bw, closed


def main():
    path = sys.argv[1]
    chunk = int(sys.argv[2])
    offsets = sorted(int(x) for x in sys.argv[3:])
    f = bz2.open(path, 'rb')
    pos = 0
    print(f"{path}: chunks of {chunk} bytes")
    print(" offset        n   r_BWT  r_ABWT  ABWT/BWT   S_BWT  S/r   S_ABWT  S/r   S_ABWT/S_BWT  closed(BWT,ABWT)")
    for off in offsets:
        while pos < off:
            got = f.read(min(1 << 24, off - pos))
            if not got:
                break
            pos += len(got)
        data = f.read(chunk)
        pos += len(data)
        if len(data) < chunk:
            print(f" offset {off}: only {len(data)} bytes left, skipped")
            continue
        t = np.frombuffer(data, dtype=np.uint8)
        n = len(t)
        res = []
        for alt in (False, True):
            rank = cyclic_ranks(t, alt)
            sa = np.empty(n, dtype=np.int64)
            sa[rank] = np.arange(n)
            L = t[(sa - 1) % n]
            r, steps, eq, tw, bw, closed = induce_count(L, alt)
            assert sum(wl * lam for wl, lam, _ in closed) == n
            res.append((r, steps, len(closed), closed[-1]))
        (r0, s0, c0, last0), (r1, s1, c1, last1) = res
        assert last0[0] == n and last0[1] == 1, last0
        assert last1[0] == n and last1[1] == 1, last1
        print(f" {off:9d} {n:8d} {r0:7d} {r1:7d}   {r1 / r0:.4f} {s0:8d} {s0 / r0:.3f} {s1:8d} {s1 / r1:.3f}   {s1 / s0:.4f}        {c0},{c1}")


main()
