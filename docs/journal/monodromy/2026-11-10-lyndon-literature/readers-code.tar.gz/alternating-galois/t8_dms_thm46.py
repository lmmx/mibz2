#!/usr/bin/env python3
"""T8: Daykin-Mhaskar-Smyth, arXiv:2409.02757, Theorem 46: for Galois words
u, v with uv primitive, "u <alt v iff uv is a Galois word" (<alt on finite
words as their Definition 38).  Exhaustive check over 3 letters, |u|,|v| <= 5.
Hendrian et al. (arXiv:2403.02636, after Lemma 4) and Reutenauer (SLC B54h,
section 3.8) print the counterexample u = aba, v = c."""
import itertools
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fiet import is_gl, is_primitive


def alt_less(x, y):
    """Definition 38 (positions counted from 1: odd '<', even '>';
    a proper prefix x of y is smaller iff |x| is even)."""
    for i in range(min(len(x), len(y))):
        if x[i] != y[i]:
            return x[i] < y[i] if i % 2 == 0 else x[i] > y[i]
    if len(x) == len(y):
        return False
    return (len(x) % 2 == 0) if len(x) < len(y) else not (len(y) % 2 == 0)


def bordered(w):
    return any(w[:k] == w[-k:] for k in range(1, len(w)))


G = [list(w) for n in range(1, 6) for w in itertools.product(range(3), repeat=n) if is_gl(list(w), True)]
pairs = fail = fail_fwd = fail_bwd = 0
pairs_bf = fail_bf = 0
first = None
for u in G:
    for v in G:
        if u == v or not is_primitive(u + v):
            continue
        pairs += 1
        a = alt_less(u, v)
        b = is_gl(u + v, True)
        bf = not bordered(u) and not bordered(v)
        pairs_bf += bf
        if a != b:
            fail += 1
            fail_fwd += a and not b
            fail_bwd += b and not a
            fail_bf += bf
            if first is None:
                first = (u, v)
print(f"Galois words of length <= 5 over 3 letters: {len(G)}")
print(f"pairs (u, v), u != v, uv primitive: {pairs}; the equivalence fails on {fail}")
print(f"   u <alt v but uv not Galois: {fail_fwd};  uv Galois but not u <alt v: {fail_bwd}")
print(f"pairs with u and v both border-free: {pairs_bf}; fails on {fail_bf}")
print("first failing pair:", first)
print("u=aba, v=c:", alt_less([0, 1, 0], [2]), is_gl([0, 1, 0, 2], True), " acab Galois:", is_gl([0, 2, 0, 1], True))
