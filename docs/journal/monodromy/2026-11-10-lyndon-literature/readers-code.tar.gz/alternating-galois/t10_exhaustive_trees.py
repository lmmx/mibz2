#!/usr/bin/env python3
"""T10: all binary (and ternary) Galois words up to a length: the tree of the
right-end induction with flips on the word's ABWT against the iterated standard
factorisation (Reutenauer) and the Cartesian tree of the alternating ranks.
Usage: python3 -I t10_exhaustive_trees.py"""
import itertools
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fiet import cartesian, column, flatten, induce, is_gl, std_tree

for sigma, N in ((2, 14), (3, 9)):
    per = {}
    for n in range(2, N + 1):
        tot = agree_std = agree_cart = root = 0
        for t in itertools.product(range(sigma), repeat=n):
            w = list(t)
            if not is_gl(w, True):
                continue
            tot += 1
            sa, L, lf = column(w, True)
            closed, steps, r = induce(L, True)
            tr = closed[-1][0]
            assert flatten(tr) == w
            st = std_tree(w, True)
            agree_std += tr == st
            agree_cart += tr == cartesian(w, True)
            root += len(flatten(tr[0])) == len(flatten(st[0]))
        per[n] = (tot, agree_std, agree_cart, root)
    print(f"{sigma} letters: length: (Galois words, induction tree = standard tree, = Cartesian tree, same root split)")
    for n, v in per.items():
        print(f"   {n:2d}: {v}")
    print("   total:", tuple(sum(v[i] for v in per.values()) for i in range(4)))
