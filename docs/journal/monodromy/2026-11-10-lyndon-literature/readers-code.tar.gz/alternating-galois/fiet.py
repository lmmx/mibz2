#!/usr/bin/env python3
"""Shared routines for the alternating-BWT / Galois-word checks.

Words are lists of small ints. "alt" = alternating lexicographic order:
position 0 of a rotation is compared in the usual order, position 1 in the
opposite order, and so on (Giancarlo et al., arXiv:1907.02308, Section 2).

The induction below is the right-end Rauzy step of the journal entry
(section 2), extended with one flip bit per letter:
  flip = +1  the first-return map sends the letter's top interval onto its
             bottom interval by a translation,
  flip = -1  by an order-reversing isometry (a "flip").
For the BWT every run starts with +1; for the alternating BWT with -1.
"""
from collections import Counter


def key_of(r, alt):
    if not alt:
        return tuple(r)
    return tuple(c if k % 2 == 0 else -c for k, c in enumerate(r))


def rotations_sorted(w, alt):
    n = len(w)
    return sorted(range(n), key=lambda i: key_of(w[i:] + w[:i], alt))


def is_primitive(w):
    n = len(w)
    return all(w[i:] + w[:i] != w for i in range(1, n))


def column(w, alt):
    """Last column of the sorted rotation matrix, and LF by brute force."""
    sa = rotations_sorted(w, alt)
    n = len(w)
    inv = [0] * n
    for x, i in enumerate(sa):
        inv[i] = x
    L = [w[(i - 1) % n] for i in sa]
    lf_true = [inv[(i - 1) % n] for i in sa]
    return sa, L, lf_true


def lf_formula(L, alt):
    """LF from the column alone.
    BWT : C[c] + (occurrences of c before x)                     [eq. (2)]
    ABWT: C[c] + count[c] - 1 - (occurrences of c before x)      [eq. (3)]"""
    n = len(L)
    cnt = Counter(L)
    C = {}
    s = 0
    for c in sorted(cnt):
        C[c] = s
        s += cnt[c]
    seen = Counter()
    LF = [0] * n
    for x, c in enumerate(L):
        LF[x] = C[c] + cnt[c] - 1 - seen[c] if alt else C[c] + seen[c]
        seen[c] += 1
    return LF


def flatten(t):
    out = []
    stack = [t]
    while stack:
        x = stack.pop()
        if isinstance(x, tuple):
            stack.append(x[1])
            stack.append(x[0])
        else:
            out.append(x)
    return out


def induce(L, alt, record=None):
    """Right-end induction on the runs of L.  Returns (closed, steps, r).
    closed: list of (tree, word length, lambda, flip) in closing order.
    record: optional list that receives every word tree made by a step."""
    runs = []
    for c in L:
        if runs and runs[-1][0] == c:
            runs[-1][1] += 1
        else:
            runs.append([c, 1])
    r = len(runs)
    lam = [ln for _, ln in runs]
    word = [c for c, _ in runs]
    wlen = [1] * r
    flip = [-1 if alt else 1] * r
    top = list(range(r))
    if alt:
        bot = sorted(range(r), key=lambda a: (runs[a][0], -a))
    else:
        bot = sorted(range(r), key=lambda a: (runs[a][0], a))
    steps = 0
    closed = []
    while top:
        A = top[-1]
        B = bot[-1]
        if A == B:  # I_A = J_A: the drop rule
            closed.append((word[A], wlen[A], lam[A], flip[A]))
            top.pop()
            bot.pop()
            continue
        steps += 1
        N = (word[A], word[B])
        nl = wlen[A] + wlen[B]
        nf = flip[A] * flip[B]
        if record is not None:
            record.append(N)
        if lam[A] > lam[B]:  # top wins
            lam[A] -= lam[B]
            bot.pop()
            i = bot.index(A)
            bot.insert(i + 1 if flip[A] == 1 else i, B)
            word[B], wlen[B], flip[B] = N, nl, nf
        elif lam[A] < lam[B]:  # bottom wins
            lam[B] -= lam[A]
            top.pop()
            i = top.index(B)
            top.insert(i + 1 if flip[B] == 1 else i, A)
            word[A], wlen[A], flip[A] = N, nl, nf
        else:  # equal
            top.pop()
            bot.pop()
            bot[bot.index(A)] = B
            word[B], wlen[B], flip[B] = N, nl, nf
    return closed, steps, r


def least_rotation(w):
    return min(w[i:] + w[:i] for i in range(len(w)))


def necklaces_from_closed(closed):
    """Multiset of necklaces (each as its lexicographically least rotation,
    a tuple) that the closed letters stand for."""
    out = Counter()
    for tree, wl, lam, f in closed:
        w = flatten(tree)
        if f == 1:
            out[tuple(least_rotation(w))] += lam
        else:
            if lam // 2:
                out[tuple(least_rotation(w + w))] += lam // 2
            if lam % 2:
                out[tuple(least_rotation(w))] += 1
    return out


def necklaces_brute(L, alt):
    """Cycles of LF read as words: L[x], L[LF x], ... is the word reversed."""
    LF = lf_formula(L, alt)
    n = len(L)
    seen = [False] * n
    out = Counter()
    for x in range(n):
        if seen[x]:
            continue
        w = []
        y = x
        while not seen[y]:
            seen[y] = True
            w.append(L[y])
            y = LF[y]
        w.reverse()
        out[tuple(least_rotation(w))] += 1
    return out


def omega_less(u, v, alt):
    """u^omega < v^omega (strict) in the lexicographic / alternating order.
    Decided inside the prefix of length |u|+|v| (Fine and Wilf)."""
    N = len(u) + len(v)
    for k in range(N):
        a = u[k % len(u)]
        b = v[k % len(v)]
        if a != b:
            return (a < b) if (not alt or k % 2 == 0) else (a > b)
    return False


def is_gl(w, alt):
    """Generalized Lyndon word (Lyndon if not alt, Galois if alt):
    strictly least among its rotations."""
    k0 = key_of(w, alt)
    for i in range(1, len(w)):
        if key_of(w[i:] + w[:i], alt) <= k0:
            return False
    return True


def std_tree(w, alt, bad=None):
    """Standard factorisation iterated: w = uv, v the longest proper suffix
    that is a generalized Lyndon word (Reutenauer 2006, Remarque 2.2)."""
    if len(w) == 1:
        return w[0]
    for j in range(1, len(w)):
        if is_gl(w[j:], alt):
            if bad is not None and not is_gl(w[:j], alt):
                bad.append(list(w))
            return (std_tree(w[:j], alt, bad), std_tree(w[j:], alt, bad))
    raise AssertionError


def std_split_min_omega(w, alt):
    """Reutenauer's definition in the proof of Th. 2.2: v the proper suffix
    with v^omega least, the shortest such."""
    best = None
    for j in range(len(w) - 1, 0, -1):  # shortest suffix first
        v = w[j:]
        if best is None or omega_less(v, w[best:], alt):
            best = j
    return best


def cartesian(G, alt):
    """Min-Cartesian tree of the rotation ranks over G (G = least rotation)."""
    n = len(G)
    sa = rotations_sorted(G, alt)
    key = [0] * n
    for x, i in enumerate(sa):
        key[i] = x

    def build(l, r):
        if r - l == 1:
            return G[l]
        j = min(range(l + 1, r), key=lambda t: key[t])
        return (build(l, j), build(j, r))

    return build(0, n)


def duval(T):
    """Lyndon factorisation (usual order), non-increasing factors."""
    n = len(T)
    i = 0
    out = []
    while i < n:
        j = i + 1
        k = i
        while j < n and T[k] <= T[j]:
            k = i if T[k] < T[j] else k + 1
            j += 1
        while i <= k:
            out.append(T[i:i + j - k])
            i += j - k
    return out
