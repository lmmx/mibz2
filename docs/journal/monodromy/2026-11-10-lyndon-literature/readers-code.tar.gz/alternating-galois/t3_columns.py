#!/usr/bin/env python3
"""T3: the right-end induction on ANY column (no BWT of a primitive word needed).

 lex part (H1):
  a. random columns: the necklaces the closed letters stand for = the cycles
     of LF; every closed word a Lyndon word; closing order non-increasing in
     the order of u^omega.
  b. the bijective BWT of a random text T (rotations of the Lyndon factors,
     sorted by u^omega): the closed words in closing order, each lambda times,
     = the Lyndon factorisation of T; each tree = the Lyndon tree.
 alt part (H4, Gessel-Restivo-Reutenauer's alternating bijection as restated
 by Elizalde, arXiv:2503.09972, section 2.2):
  c. random columns with the ABWT's LF (order reversed inside a bucket) and
     flips: necklaces from the closed letters = cycles of LF; each necklace
     primitive or (uu) with u primitive of odd length; no necklace of odd
     length twice.
  d. all columns of length <= N over 2 (and 3) letters: distinct multisets.
Usage: python3 -I t3_columns.py [seed] [count]"""
import itertools
import os
import random
import sys
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fiet import (duval, flatten, induce, is_gl, is_primitive, key_of,
                  least_rotation, necklaces_brute, necklaces_from_closed,
                  omega_less, std_tree)

seed = int(sys.argv[1]) if len(sys.argv) > 1 else 1
count = int(sys.argv[2]) if len(sys.argv) > 2 else 20000
rng = random.Random(seed)


def rand_word(maxn=40):
    sigma = rng.choice([2, 2, 3, 4])
    n = rng.randint(1, maxn)
    geo = rng.random() < 0.5
    w = []
    while len(w) < n:
        w += [rng.randrange(sigma)] * (rng.randint(1, 4) if geo else 1)
    return w[:n]


# ---- a. lex, random columns
cols = several = neck_ok = all_lyndon = nonincr = trees_ok = 0
for _ in range(count):
    L = rand_word()
    cols += 1
    closed, steps, r = induce(L, False)
    several += len(closed) > 1 or closed[0][2] > 1
    neck_ok += necklaces_from_closed(closed) == necklaces_brute(L, False)
    ws = [flatten(t) for t, _, _, _ in closed]
    all_lyndon += all(is_gl(w, False) for w in ws)
    nonincr += all(not omega_less(ws[i], ws[i + 1], False) for i in range(len(ws) - 1))
    trees_ok += all(t == std_tree(flatten(t), False) for t, _, _, _ in closed)
print("a. lex, random columns")
print(f"   columns                                   {cols}")
print(f"   with several cycles                       {several}")
print(f"   necklaces of closed letters = LF's cycles {neck_ok}")
print(f"   every closed word a Lyndon word           {all_lyndon}")
print(f"   closing order non-increasing (u^omega)    {nonincr}")
print(f"   every closed tree = its Lyndon tree       {trees_ok}")

# ---- b. lex, bijective BWT
texts = fact_ok = tree_ok = 0
for _ in range(count):
    T = rand_word()
    fs = duval(T)
    rows = []
    N = 2 * len(T) + 2
    for f in fs:
        for i in range(len(f)):
            rot = f[i:] + f[:i]
            rows.append((tuple(rot[k % len(rot)] for k in range(N)), rot[-1]))
    rows.sort(key=lambda t: t[0])
    L = [c for _, c in rows]
    closed, steps, r = induce(L, False)
    got = []
    for t, wl, lam, f in closed:
        got += [flatten(t)] * lam
    texts += 1
    fact_ok += got == fs
    tree_ok += all(t == std_tree(flatten(t), False) for t, _, _, _ in closed)
print("b. lex, bijective BWT of random texts")
print(f"   texts                                     {texts}")
print(f"   closed words in order = Lyndon factorisation {fact_ok}")
print(f"   every closed tree = its Lyndon tree       {tree_ok}")

# ---- c. alt, random columns
cols = several = neck_ok = shape_ok = odd_once = closed_galois = nonincr = 0
closed_letters = closed_flip_minus_multi = 0
for _ in range(count):
    L = rand_word()
    cols += 1
    closed, steps, r = induce(L, True)
    several += len(closed) > 1 or closed[0][2] > 1
    nk = necklaces_from_closed(closed)
    neck_ok += nk == necklaces_brute(L, True)
    ok = True
    once = True
    for w, m in nk.items():
        w = list(w)
        if not is_primitive(w):
            h = len(w) // 2
            if not (len(w) % 2 == 0 and w[:h] == w[h:] and is_primitive(w[:h]) and h % 2 == 1):
                # (uu) is a rotation class: test the least rotation's halves
                ok = False
        if len(w) % 2 == 1 and m > 1:
            once = False
    shape_ok += ok
    odd_once += once
    ws = [flatten(t) for t, _, _, _ in closed]
    closed_galois += all(is_gl(w, True) for w in ws)
    nonincr += all(not omega_less(ws[i], ws[i + 1], True) for i in range(len(ws) - 1))
    for t, wl, lam, f in closed:
        closed_letters += 1
        closed_flip_minus_multi += (f == -1 and lam > 1)
print("c. alt (flips), random columns")
print(f"   columns                                   {cols}")
print(f"   with several cycles                       {several}")
print(f"   necklaces of closed letters = LF's cycles {neck_ok}")
print(f"   each necklace primitive or (uu), u primitive, |u| odd {shape_ok}")
print(f"   no necklace of odd length twice           {odd_once}")
print(f"   every closed word a Galois word           {closed_galois}")
print(f"   closing order non-increasing (alt u^omega) {nonincr}")
print(f"   closed letters {closed_letters}, of them flipped with lambda > 1 {closed_flip_minus_multi}")

# ---- d. alt, exhaustive: the map column -> multiset is injective
for sigma, N in ((2, 12), (3, 8)):
    tot = 0
    images = set()
    for n in range(1, N + 1):
        for L in itertools.product(range(sigma), repeat=n):
            closed, steps, r = induce(list(L), True)
            nk = necklaces_from_closed(closed)
            images.add(tuple(sorted(nk.items())))
            tot += 1
    print(f"d. alt, all columns of length <= {N} over {sigma} letters: {tot} columns, {len(images)} distinct multisets")
