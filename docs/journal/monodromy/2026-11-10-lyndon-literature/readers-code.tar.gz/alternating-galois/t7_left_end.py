#!/usr/bin/env python3
"""T7 (H2): the left-end induction is the right-end induction on the mirrored
rows.  For a primitive word the mirrored column is the BWT for the inverse
alphabet order, so by the entry's Theorems 1-2 it ends on the greatest rotation
with its Lyndon tree for the inverse order.  Checked here on random words.
Also: the powers that the flipped (alternating) induction makes on the way.
Usage: python3 -I t7_left_end.py [seed] [count]"""
import os
import random
import sys
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fiet import column, flatten, induce, is_gl, is_primitive, std_tree

seed = int(sys.argv[1]) if len(sys.argv) > 1 else 1
count = int(sys.argv[2]) if len(sys.argv) > 2 else 10000
rng = random.Random(seed)
words = mirror = greatest = tree = 0
powers = Counter()
odd_root = made_powers = 0
for _ in range(count):
    sigma = rng.choice([2, 3, 4])
    n = rng.randint(2, 36)
    w = []
    while len(w) < n:
        w += [rng.randrange(sigma)] * rng.randint(1, 3)
    w = w[:n]
    if not is_primitive(w):
        continue
    words += 1
    sa, L, _ = column(w, False)
    comp = [sigma - 1 - c for c in w]          # the inverse alphabet order
    sa2, L2, _ = column(comp, False)
    mirror += L2 == [sigma - 1 - c for c in L[::-1]]
    closed, steps, r = induce([sigma - 1 - c for c in L[::-1]], False)
    t = closed[-1][0]
    g = flatten(t)
    big = max(w[i:] + w[:i] for i in range(n))
    greatest += [sigma - 1 - c for c in g] == big
    tree += t == std_tree(g, False)
    # powers made by the alternating induction
    sa3, L3, _ = column(w, True)
    rec = []
    induce(L3, True, rec)
    for N in rec:
        f = flatten(N)
        if not is_primitive(f):
            made_powers += 1
            p = next(d for d in range(1, len(f)) if len(f) % d == 0 and f[:d] * (len(f) // d) == f)
            powers[len(f) // p] += 1
            odd_root += (p % 2 == 1) and is_gl(f[:p], True)
print(f"primitive words                                         {words}")
print(f"mirrored column = BWT for the inverse alphabet order    {mirror}")
print(f"mirrored induction ends on the greatest rotation        {greatest}")
print(f"its tree = the Lyndon tree for the inverse order        {tree}")
print(f"alternating induction: powers made {made_powers}; root a Galois word of odd length {odd_root}; exponents {dict(sorted(powers.items()))}")
