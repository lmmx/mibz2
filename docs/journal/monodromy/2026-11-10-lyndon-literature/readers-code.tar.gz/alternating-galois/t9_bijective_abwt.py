#!/usr/bin/env python3
"""T9: a "bijective ABWT" and its inversion by the induction with flips.

T is cut into its Galois factorisation g1 >= g2 >= ... (non-increasing in the
alternating order of u^omega; last factor = the shortest suffix v with least
v^omega, Reutenauer, SLC B54h, Cor. 2.2).  The column is the last letters of
all rotations of all factors, sorted by the alternating order of their
infinite powers.  The right-end induction with flips is run on that column;
its closed words, each lambda times, in closing order, are compared with the
Galois factorisation.  (Hendrian et al., arXiv:2403.02636, section 2, name
such a transform as future work.)
Usage: python3 -I t9_bijective_abwt.py [seed] [count]"""
import functools
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fiet import flatten, induce, is_gl, omega_less

seed = int(sys.argv[1]) if len(sys.argv) > 1 else 1
count = int(sys.argv[2]) if len(sys.argv) > 2 else 20000
rng = random.Random(seed)


def galois_factorisation(T):
    out = []
    w = list(T)
    while w:
        best = len(w) - 1
        for j in range(len(w) - 2, -1, -1):
            if omega_less(w[j:], w[best:], True):
                best = j
        out.append(w[best:])
        w = w[:best]
    out.reverse()
    return out


def cmp_rows(a, b):
    if omega_less(a[0], b[0], True):
        return -1
    if omega_less(b[0], a[0], True):
        return 1
    return 0


texts = fact_is_galois = col_defined = ok = repeated_odd = 0
for _ in range(count):
    sigma = rng.choice([2, 2, 3])
    n = rng.randint(1, 30)
    T = []
    while len(T) < n:
        T += [rng.randrange(sigma)] * rng.randint(1, 3)
    T = T[:n]
    fs = galois_factorisation(T)
    texts += 1
    fact_is_galois += all(is_gl(f, True) for f in fs) and all(
        not omega_less(fs[i], fs[i + 1], True) for i in range(len(fs) - 1))
    repeated_odd += any(fs[i] == fs[i + 1] and len(fs[i]) % 2 == 1 for i in range(len(fs) - 1))
    rows = [(f[i:] + f[:i], (f[i:] + f[:i])[-1]) for f in fs for i in range(len(f))]
    rows.sort(key=functools.cmp_to_key(cmp_rows))
    # tied rows (equal infinite powers) must end with the same letter
    col_defined += all(cmp_rows(rows[i], rows[i + 1]) != 0 or rows[i][1] == rows[i + 1][1]
                       for i in range(len(rows) - 1))
    L = [c for _, c in rows]
    closed, steps, r = induce(L, True)
    got = []
    for t, wl, lam, f in closed:
        got += [flatten(t)] * lam
    ok += got == fs
print(f"texts                                              {texts}")
print(f"factorisation is non-increasing Galois words       {fact_is_galois}")
print(f"with an odd-length factor repeated                 {repeated_odd}")
print(f"column well defined (ties end with one letter)     {col_defined}")
print(f"closed words in closing order = the factorisation  {ok}")
