#!/usr/bin/env python3
"""T11: what the alternating BWT suggests a DECODER could do with an ordinary
BWT column: keep the column, but lay the rows out in another order before the
induction.  The rows of one first letter (a bucket) stay together; the buckets
are permuted, and some buckets are reversed in place.  LF in that layout is an
interval exchange on the runs cut at the bucket boundaries, with a flip on a
piece iff exactly one of (its bucket, its byte's bucket) is reversed.  With
only the bucket order changed this is a "local ordering" with pi_empty changed
(Giancarlo et al., Inf. Comput. 2023, Section 4, Fig. 7 right).

Part 1 (small words): the induction in such a layout still ends on one letter,
one row, spelling a rotation of the word.
Part 2 (real bytes): number of steps S in several layouts, counts only.
Usage: python3 -I t11_conjugated.py [FILE.bz2 CHUNK OFFSET ...]"""
import bz2
import os
import random
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fiet import column, flatten, is_primitive


def layout(L, bucket_order, sign):
    """Pieces = runs of L cut at bucket boundaries.  Returns top order, bottom
    order (lists of piece ids), lengths, flips, bytes."""
    n = len(L)
    cnt = {}
    for c in L:
        cnt[c] = cnt.get(c, 0) + 1
    C = {}
    s = 0
    for c in sorted(cnt):
        C[c] = s
        s += cnt[c]
    bounds = set(C.values())
    pieces = []  # (bucket, byte, start)
    lam = []
    x = 0
    bucket_of_row = []
    for c in sorted(cnt):
        bucket_of_row += [c] * cnt[c]
    while x < n:
        y = x + 1
        while y < n and L[y] == L[x] and y not in bounds:
            y += 1
        pieces.append((bucket_of_row[x], L[x], x))
        lam.append(y - x)
        x = y
    ids = range(len(pieces))
    pos = {c: k for k, c in enumerate(bucket_order)}
    top = sorted(ids, key=lambda p: (pos[pieces[p][0]], sign[pieces[p][0]] * pieces[p][2]))
    bot = sorted(ids, key=lambda p: (pos[pieces[p][1]], sign[pieces[p][1]] * pieces[p][2]))
    flip = [sign[b] * sign[d] for b, d, _ in pieces]
    byte = [d for _, d, _ in pieces]
    return top, bot, lam, flip, byte


def induce_words(top, bot, lam, flip, byte):
    top = list(top)
    bot = list(bot)
    lam = list(lam)
    flip = list(flip)
    word = list(byte)
    steps = 0
    closed = []
    while top:
        A = top[-1]
        B = bot[-1]
        if A == B:
            closed.append((word[A], lam[A], flip[A]))
            top.pop()
            bot.pop()
            continue
        steps += 1
        N = (word[A], word[B])
        nf = flip[A] * flip[B]
        if lam[A] > lam[B]:
            lam[A] -= lam[B]
            bot.pop()
            i = bot.index(A)
            bot.insert(i + 1 if flip[A] == 1 else i, B)
            word[B], flip[B] = N, nf
        elif lam[A] < lam[B]:
            lam[B] -= lam[A]
            top.pop()
            i = top.index(B)
            top.insert(i + 1 if flip[B] == 1 else i, A)
            word[A], flip[A] = N, nf
        else:
            top.pop()
            bot.pop()
            bot[bot.index(A)] = B
            word[B], flip[B] = N, nf
    return closed, steps


def induce_count(top, bot, lam, flip):
    r = len(lam)
    lam = list(lam)
    flip = list(flip)
    S = r
    tprev = [0] * (r + 1)
    tnext = [0] * (r + 1)
    bprev = [0] * (r + 1)
    bnext = [0] * (r + 1)
    for prv, nxt, order in ((tprev, tnext, top), (bprev, bnext, bot)):
        p = S
        for a in order:
            prv[a] = p
            nxt[p] = a
            p = a
        nxt[p] = S
        prv[S] = p
    steps = 0
    closed = 0
    while True:
        A = tprev[S]
        B = bprev[S]
        if A == S:
            break
        if A == B:
            closed += 1
            q = tprev[A]; tnext[q] = S; tprev[S] = q
            q = bprev[A]; bnext[q] = S; bprev[S] = q
            continue
        steps += 1
        nf = flip[A] * flip[B]
        if lam[A] > lam[B]:
            lam[A] -= lam[B]
            q = bprev[B]; bnext[q] = S; bprev[S] = q
            if flip[A] == 1:
                x = bnext[A]; bnext[A] = B; bprev[B] = A; bnext[B] = x; bprev[x] = B
            else:
                x = bprev[A]; bnext[x] = B; bprev[B] = x; bnext[B] = A; bprev[A] = B
            flip[B] = nf
        elif lam[A] < lam[B]:
            lam[B] -= lam[A]
            q = tprev[A]; tnext[q] = S; tprev[S] = q
            if flip[B] == 1:
                x = tnext[B]; tnext[B] = A; tprev[A] = B; tnext[A] = x; tprev[x] = A
            else:
                x = tprev[B]; tnext[x] = A; tprev[A] = x; tnext[A] = B; tprev[B] = A
            flip[A] = nf
        else:
            q = tprev[A]; tnext[q] = S; tprev[S] = q
            q = bprev[B]; bnext[q] = S; bprev[S] = q
            x = bprev[A]; y = bnext[A]
            bnext[x] = B; bprev[B] = x; bnext[B] = y; bprev[y] = B
            flip[B] = nf
    return steps, closed


def part1(count=4000, seed=1):
    rng = random.Random(seed)
    words = ok = same = 0
    for _ in range(count):
        sigma = rng.choice([2, 3, 4])
        n = rng.randint(2, 30)
        w = []
        while len(w) < n:
            w += [rng.randrange(sigma)] * rng.randint(1, 3)
        w = w[:n]
        if not is_primitive(w):
            continue
        sa, L, _ = column(w, False)
        alpha = sorted(set(L))
        bo = alpha[:]
        rng.shuffle(bo)
        sign = {c: rng.choice([1, -1]) for c in alpha}
        top, bot, lam, flip, byte = layout(L, bo, sign)
        closed, steps = induce_words(top, bot, lam, flip, byte)
        words += 1
        g = flatten(closed[-1][0])
        good = len(closed) == 1 and closed[0][1] == 1 and any(g == w[i:] + w[:i] for i in range(n))
        ok += good
        s2, c2 = induce_count(top, bot, lam, flip)
        same += (s2, c2) == (steps, len(closed))
    print(f"part 1: {words} primitive words, random bucket order and random bucket reversals")
    print(f"   ends on one letter, one row, a rotation of the word: {ok}")
    print(f"   counting induction agrees with the word-carrying one: {same}")


def cyclic_L(t):
    n = len(t)
    rank = t.astype(np.int64)
    idx = np.arange(n)
    k = 1
    while True:
        sec = rank[(idx + k) % n]
        order = np.lexsort((sec, rank))
        r1 = rank[order]; s1 = sec[order]
        diff = np.empty(n, dtype=bool)
        diff[0] = True
        diff[1:] = (r1[1:] != r1[:-1]) | (s1[1:] != s1[:-1])
        new = np.empty(n, dtype=np.int64)
        new[order] = np.cumsum(diff) - 1
        rank = new
        k *= 2
        if rank.max() == n - 1:
            break
    sa = np.empty(n, dtype=np.int64)
    sa[rank] = np.arange(n)
    return t[(sa - 1) % n]


def part2(path, chunk, offsets):
    rng = random.Random(5)
    f = bz2.open(path, 'rb')
    pos = 0
    print(f"part 2: {path}, chunks of {chunk} bytes; S / (runs of the column, uncut) in each layout")
    for off in sorted(offsets):
        while pos < off:
            got = f.read(min(1 << 24, off - pos))
            if not got:
                break
            pos += len(got)
        data = f.read(chunk)
        pos += len(data)
        if len(data) < chunk:
            continue
        L = cyclic_L(np.frombuffer(data, dtype=np.uint8)).tolist()
        r = 1 + sum(1 for i in range(1, len(L)) if L[i] != L[i - 1])
        alpha = sorted(set(L))
        cnt = {c: 0 for c in alpha}
        for c in L:
            cnt[c] += 1
        plus = {c: 1 for c in alpha}
        minus = {c: -1 for c in alpha}
        shuf1 = alpha[:]; rng.shuffle(shuf1)
        shuf2 = alpha[:]; rng.shuffle(shuf2)
        rs1 = {c: rng.choice([1, -1]) for c in alpha}
        layouts = [
            ("byte order", alpha, plus),
            ("reversed byte order", alpha[::-1], plus),
            ("by count, rare first", sorted(alpha, key=lambda c: cnt[c]), plus),
            ("by count, common first", sorted(alpha, key=lambda c: -cnt[c]), plus),
            ("random order 1", shuf1, plus),
            ("random order 2", shuf2, plus),
            ("byte order, every bucket reversed", alpha, minus),
            ("reversed order, every bucket reversed (= left end)", alpha[::-1], minus),
            ("byte order, random buckets reversed", alpha, rs1),
        ]
        print(f"   offset {off}: n {len(L)}, r {r}")
        for name, bo, sg in layouts:
            top, bot, lam, flip, byte = layout(L, bo, sg)
            steps, closed = induce_count(top, bot, lam, flip)
            print(f"      {name:52s} pieces {len(lam):7d}  S {steps:8d}  S/r {steps / r:.3f}  closed {closed}")


part1()
if len(sys.argv) > 3:
    part2(sys.argv[1], int(sys.argv[2]), [int(x) for x in sys.argv[3:]])
