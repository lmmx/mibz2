#!/usr/bin/env python3
"""T4: on which generalized BWTs is LF an isometry on each run of the column?

 BWT_K (Giancarlo et al., DLT 2018 / TCS 2020, Def. 4.2): rotations sorted with
   the alphabet order pi_{i mod k} at position i.  K = (Id, pi).
 Local orderings, k = 1 (Giancarlo et al., Inf. Comput. 2023, Section 4): the
   order used at position i >= 1 depends on the symbol at position i - 1; the
   first column uses pi_empty.

For every maximal run of equal letters of the column (length >= 2) LF is
classed as a translation (+1 each row), a reversal (-1 each row), or neither.
For local orderings the runs are also cut where the first column changes.
Usage: python3 -I t4_generalized.py [seed] [count]"""
import itertools
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fiet import is_primitive

seed = int(sys.argv[1]) if len(sys.argv) > 1 else 1
count = int(sys.argv[2]) if len(sys.argv) > 2 else 4000
rng = random.Random(seed)
SIGMA = 3


def matrix(w, keyf):
    n = len(w)
    sa = sorted(range(n), key=lambda i: keyf(w[i:] + w[:i]))
    inv = [0] * n
    for x, i in enumerate(sa):
        inv[i] = x
    L = [w[(i - 1) % n] for i in sa]
    F = [w[i] for i in sa]
    LF = [inv[(i - 1) % n] for i in sa]
    return F, L, LF


def classify(F, L, LF, cut_at_F):
    tr = rev = neither = 0
    n = len(L)
    i = 0
    while i < n:
        j = i
        while j + 1 < n and L[j + 1] == L[i] and (not cut_at_F or F[j + 1] == F[i]):
            j += 1
        if j > i:
            d = {LF[x + 1] - LF[x] for x in range(i, j)}
            if d == {1}:
                tr += 1
            elif d == {-1}:
                rev += 1
            else:
                neither += 1
        i = j + 1
    return tr, rev, neither


def words():
    out = []
    while len(out) < count:
        n = rng.randint(4, 30)
        w = []
        while len(w) < n:
            w += [rng.randrange(SIGMA)] * rng.randint(1, 3)
        w = w[:n]
        if is_primitive(w):
            out.append(w)
    return out


W = words()
print(f"{len(W)} primitive words over {SIGMA} letters, length 4..30")
print("BWT_K, K = (Id, pi): runs of length >= 2 on which LF is a translation / a reversal / neither")
for pi in itertools.permutations(range(SIGMA)):
    rank = {c: k for k, c in enumerate(pi)}

    def keyf(r, rank=rank):
        return tuple(c if k % 2 == 0 else rank[c] for k, c in enumerate(r))

    tr = rev = ne = 0
    for w in W:
        a, b, c = classify(*matrix(w, keyf), False)
        tr += a
        rev += b
        ne += c
    name = "Id (BWT)" if pi == (0, 1, 2) else "Rev (ABWT)" if pi == (2, 1, 0) else ""
    print(f"   pi = {pi} {name:10s} {tr:7d} {rev:7d} {ne:7d}")

print("local orderings, k = 1 (pi_empty and one order per symbol, drawn at random for each word):")
tr = rev = ne = 0
trc = revc = nec = 0
perms = list(itertools.permutations(range(SIGMA)))
for w in W:
    p0 = rng.choice(perms)
    pc = [rng.choice(perms) for _ in range(SIGMA)]
    r0 = {c: k for k, c in enumerate(p0)}
    rc = [{c: k for k, c in enumerate(p)} for p in pc]

    def keyf(r):
        return tuple(r0[c] if k == 0 else rc[r[k - 1]][c] for k, c in enumerate(r))

    F, L, LF = matrix(w, keyf)
    a, b, c = classify(F, L, LF, False)
    tr += a
    rev += b
    ne += c
    a, b, c = classify(F, L, LF, True)
    trc += a
    revc += b
    nec += c
print(f"   whole runs of the column:            translation {tr}, reversal {rev}, neither {ne}")
print(f"   runs cut where the first column changes: translation {trc}, reversal {revc}, neither {nec}")
