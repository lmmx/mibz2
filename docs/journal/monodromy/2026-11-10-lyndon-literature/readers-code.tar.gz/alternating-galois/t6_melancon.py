#!/usr/bin/env python3
"""T6: the Schuetzenberger-Melancon rewriting as Reutenauer states it
(Mots de Lyndon generalises, SLC B54h, section 3.4):

  a circular sequence (h_1 ... h_n) of Hall words, at first the letters of w;
  a rise is a pair (h_i, h_{i+1}) with h_i < h_{i+1} (indices mod n); it is
  legal if h_{i+1} >= every h_j; replace a legal rise by the word h_i h_{i+1};
  repeat.  The order is u < v iff u^omega < v^omega.

Run with a legal rise chosen at random each time, for the lexicographic order
(Lyndon words) and the alternating order (Galois words), on primitive words.
Compared with: the word and tree of the right-end induction (flips for alt),
the standard-factorisation tree, the Cartesian tree of the rotation ranks.
Usage: python3 -I t6_melancon.py [seed] [count]"""
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fiet import (cartesian, column, flatten, induce, is_primitive, omega_less,
                  std_tree)

seed = int(sys.argv[1]) if len(sys.argv) > 1 else 1
count = int(sys.argv[2]) if len(sys.argv) > 2 else 5000
rng = random.Random(seed)


def melancon(w, alt):
    seq = [([c], c) for c in w]  # (word, tree)
    while len(seq) > 1:
        mx = seq[0][0]
        for u, _ in seq[1:]:
            if omega_less(mx, u, alt):
                mx = u
        n = len(seq)
        legal = [i for i in range(n)
                 if seq[(i + 1) % n][0] == mx and omega_less(seq[i][0], mx, alt)]
        if not legal:
            break  # all equal: w is a power
        i = rng.choice(legal)
        j = (i + 1) % n
        merged = (seq[i][0] + seq[j][0], (seq[i][1], seq[j][1]))
        if j == 0:
            seq = [merged] + seq[1:n - 1]
        else:
            seq = seq[:i] + [merged] + seq[j + 1:]
    return seq


for alt in (False, True):
    words = one = same_word = eq_ind = eq_std = eq_cart = 0
    for _ in range(count):
        sigma = rng.choice([2, 2, 3, 4])
        n = rng.randint(2, 32)
        w = []
        while len(w) < n:
            w += [rng.randrange(sigma)] * rng.randint(1, 3)
        w = w[:n]
        if not is_primitive(w):
            continue
        words += 1
        seq = melancon(w, alt)
        one += len(seq) == 1
        sa, L, _ = column(w, alt)
        G = w[sa[0]:] + w[:sa[0]]
        same_word += seq[0][0] == G
        closed, steps, r = induce(L, alt)
        t = seq[0][1]
        eq_ind += t == closed[-1][0]
        eq_std += t == std_tree(G, alt)
        eq_cart += t == cartesian(G, alt)
    print("order:", "alternating (Galois)" if alt else "lexicographic (Lyndon)")
    print(f"   primitive words                              {words}")
    print(f"   rewriting ends on one word                   {one}")
    print(f"   that word = the least rotation               {same_word}")
    print(f"   its tree = the right-end induction's tree    {eq_ind}")
    print(f"   its tree = the standard-factorisation tree   {eq_std}")
    print(f"   its tree = the Cartesian tree of the ranks   {eq_cart}")
