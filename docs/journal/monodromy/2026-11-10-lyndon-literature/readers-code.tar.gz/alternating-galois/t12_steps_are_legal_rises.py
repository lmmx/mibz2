#!/usr/bin/env python3
"""T12: is every step of the right-end induction (no flips, BWT of a primitive
word) a legal rise of the Schuetzenberger-Melancon rewriting?  At each step
with A = last on top, B = last on the bottom:
  (i)  w_B is a maximum, in the order of u^omega, of the words of all letters
       still present;
  (ii) w_A < w_B strictly in that order.
Same question for the alternating order with flips.
Usage: python3 -I t12_steps_are_legal_rises.py [seed] [count]"""
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fiet import column, flatten, is_primitive, omega_less

seed = int(sys.argv[1]) if len(sys.argv) > 1 else 1
count = int(sys.argv[2]) if len(sys.argv) > 2 else 3000
rng = random.Random(seed)


def run(L, alt):
    runs = []
    for c in L:
        if runs and runs[-1][0] == c:
            runs[-1][1] += 1
        else:
            runs.append([c, 1])
    r = len(runs)
    lam = [ln for _, ln in runs]
    word = [[c] for c, _ in runs]
    flip = [-1 if alt else 1] * r
    top = list(range(r))
    bot = sorted(range(r), key=lambda a: (runs[a][0], -a if alt else a))
    steps = bmax = rise = 0
    while top:
        A = top[-1]
        B = bot[-1]
        if A == B:
            top.pop()
            bot.pop()
            continue
        steps += 1
        bmax += not any(omega_less(word[B], word[x], alt) for x in top)
        rise += omega_less(word[A], word[B], alt)
        N = word[A] + word[B]
        nf = flip[A] * flip[B]
        if lam[A] > lam[B]:
            lam[A] -= lam[B]
            bot.pop()
            i = bot.index(A)
            bot.insert(i + 1 if flip[A] == 1 else i, B)
            word[B], flip[B] = N, nf
        elif lam[A] < lam[B]:
            lam[B] -= lam[A]
            top.pop()
            i = top.index(B)
            top.insert(i + 1 if flip[B] == 1 else i, A)
            word[A], flip[A] = N, nf
        else:
            top.pop()
            bot.pop()
            bot[bot.index(A)] = B
            word[B], flip[B] = N, nf
    return steps, bmax, rise


for alt in (False, True):
    words = S = M = R = 0
    for _ in range(count):
        sigma = rng.choice([2, 3, 4])
        n = rng.randint(2, 40)
        w = []
        while len(w) < n:
            w += [rng.randrange(sigma)] * rng.randint(1, 3)
        w = w[:n]
        if not is_primitive(w):
            continue
        words += 1
        sa, L, _ = column(w, alt)
        s, m, ri = run(L, alt)
        S += s
        M += m
        R += ri
    print("order:", "alternating, flips" if alt else "lexicographic")
    print(f"   words {words}, steps {S}; w_B a maximum of the present words: {M}; w_A < w_B: {R}")
