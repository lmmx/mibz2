#!/usr/bin/env python3
"""T1: the ABWT's LF map (formula (3) of arXiv:1907.02308) against brute force,
     and its shape on a run of equal letters.
T2: the right-end induction with flips on the ABWT of a primitive word:
     the word it ends on, and its tree against
       (i)  the min-Cartesian tree of the alternating rotation ranks,
       (ii) Reutenauer's standard factorisation of the Galois word, iterated.
     Also: is every word made on the way a Galois word?
Usage: python3 -I t1_t2_abwt.py [seed] [count] [alt|lex]
(lex runs the same harness on the ordinary BWT, as a control.)"""
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fiet import (cartesian, column, flatten, induce, is_gl, is_primitive,
                  lf_formula, std_split_min_omega, std_tree)

seed = int(sys.argv[1]) if len(sys.argv) > 1 else 1
count = int(sys.argv[2]) if len(sys.argv) > 2 else 20000
rng = random.Random(seed)
ALT = not (len(sys.argv) > 3 and sys.argv[3] == 'lex')

words = 0
lf_ok = 0
runs_total = runs_len2 = runs_reversing = runs_translating = 0
ends_on_galois = tree_cart = tree_std = 0
one_closed = 0
made = made_galois = made_nonprimitive = 0
root_split_same = 0
split_defs_agree = split_defs = 0
u_not_galois = 0
first_bad = None
for _ in range(count):
    sigma = rng.choice([2, 2, 3, 4])
    n = rng.randint(2, 40)
    geo = rng.random() < 0.5  # half the words have long runs
    w = []
    while len(w) < n:
        c = rng.randrange(sigma)
        w += [c] * (rng.randint(1, 4) if geo else 1)
    w = w[:n]
    if not is_primitive(w):
        continue
    words += 1
    sa, L, lf_true = column(w, ALT)
    LF = lf_formula(L, ALT)
    lf_ok += LF == lf_true
    # shape of LF on each maximal run of L
    i = 0
    while i < n:
        j = i
        while j + 1 < n and L[j + 1] == L[i]:
            j += 1
        runs_total += 1
        if j > i:
            runs_len2 += 1
            d = {lf_true[x + 1] - lf_true[x] for x in range(i, j)}
            runs_reversing += d == {-1}
            runs_translating += d == {1}
        i = j + 1
    G = w[sa[0]:] + w[:sa[0]]
    rec = []
    closed, steps, r = induce(L, ALT, rec)
    one_closed += len(closed) == 1 and closed[0][2] == 1
    t = closed[-1][0]
    ends_on_galois += flatten(t) == G
    c_ok = t == cartesian(G, ALT)
    bad = []
    s_ok = t == std_tree(G, ALT, bad)
    u_not_galois += bool(bad)
    tree_cart += c_ok
    tree_std += s_ok
    if not s_ok and first_bad is None:
        first_bad = (w, G, t, std_tree(G, ALT))
    for N in rec:
        made += 1
        fw = flatten(N)
        made_galois += is_gl(fw, ALT)
        made_nonprimitive += not is_primitive(fw)
    st = std_tree(G, ALT)
    if n >= 2:
        root_split_same += len(flatten(t[0])) == len(flatten(st[0]))
    # the two definitions of the standard factorisation (Remarque 2.2)
    if n >= 2:
        split_defs += 1
        j1 = std_split_min_omega(G, ALT)
        j2 = next(j for j in range(1, n) if is_gl(G[j:], ALT))
        split_defs_agree += j1 == j2

print("order:", "alternating (ABWT, flips)" if ALT else "lexicographic (BWT, no flips)")
print(f"primitive words                       {words}")
print(f"T1 LF by formula (3) = brute force    {lf_ok}")
print(f"T1 runs of L                          {runs_total}")
print(f"T1 runs of length >= 2                {runs_len2}")
print(f"T1   LF order-reversing on the run    {runs_reversing}")
print(f"T1   LF a translation on the run      {runs_translating}")
print(f"T2 induction closes one letter, 1 row {one_closed}")
print(f"T2 it spells the Galois rotation      {ends_on_galois}")
print(f"T2 tree = Cartesian tree of alt ranks {tree_cart}")
print(f"T2 tree = standard factorisation tree {tree_std}")
print(f"T2 words made by steps                {made}")
print(f"T2   of them Galois words             {made_galois}")
print(f"T2   of them not primitive (a power)  {made_nonprimitive}")
print(f"T2 root split = standard factorisation {root_split_same}")
print(f"T2 std fact.: min v^omega = longest Galois suffix  {split_defs_agree} of {split_defs}")
print(f"T2 words whose std tree met a non-Galois left part {u_not_galois}")
if first_bad:
    print("first word whose induction tree differs from the standard tree:")
    print("  w =", first_bad[0], " Galois rotation =", first_bad[1])
    print("  induction:", first_bad[2])
    print("  standard :", first_bad[3])
