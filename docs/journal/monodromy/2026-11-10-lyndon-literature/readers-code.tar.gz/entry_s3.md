## 3. In print (K), by what it bears on

Read by five sub-agents, one cluster each, every statement with the place it was read at.
Keys are §2's. "Not in print" means: not in the works read, which §7 bounds.

**3.1 The tree.**
- The tree of a Lyndon word, its standard bracketing, is the increasing tree of its suffix
  standard permutation: [HR] (its opening paragraphs; the body was not obtained). Restated
  with a proof from suffix ranks: [CR] Proposition 1 and §4 (the Lyndon factorization is the
  left-to-right minima of the ranks; the longest Lyndon factor at i ends at the next smaller
  rank).
- Always for the suffixes of a word. **No work read states it for rotation ranks or for
  the rows of a BWT, builds a Lyndon tree, array or grammar from a BWT or a run-length BWT,
  or builds one below linear time except from the packed text** (O(n / log_σ n): [BE23],
  abstract and introduction). [Koeppl20] §4.3 gets the Lyndon *factorization* from a
  run-length BWT by Duval's algorithm on n forward steps.
- [CR] §6: the tree labelled by ranks is "richer" than the Lyndon tree; the labels seem hard
  to recover without sorting the suffixes.
- The right Lyndon tree gives the Lyndon factorization of every suffix as the right
  children hanging off a leaf's path to the root: [BBIK] §4, Theorem 3 and its proof. So a
  stretch's forward minima (entry 1, §5.5) count Lyndon factors.

**3.2 The right end, read in the text, is the Schützenberger–Melançon rewriting.**
- [Reut06] §3.4, crediting [Mel92] and Schützenberger: take the letters of w as a circular
  sequence of Hall words. A *rise* is a pair of neighbours h_i < h_{i+1}; it is *legal* when
  h_{i+1} is at least every word of the sequence. Merge a legal rise; repeat. What is left
  is the Hall conjugate of w (a power of it if w is not primitive), with its tree. The same
  algorithm: [PR18] §8 (its left form), [CPS19] §12 and Algorithm 3, [Garg21] Theorem 3.18.
  [Mel92] itself was not obtained.
- Lyndon words are the Hall set in question: the right Lazard set that removes the greatest
  element, in decreasing order, and the left Lazard set that removes the least ([CPS19]
  Definition 47, Examples 48–49; "the choice of the words … determines the total order",
  Remark 50). Hall sets and Lazard sets coincide (Viennot; [Reut93] Theorem 4.18, as cited).
- The tree is the standard bracketing, a basis of the free Lie algebra: [GR-Hopf] Theorem
  6.1.30, Definition 6.1.38; [Reut06] Corollaire 2.3 for every generalized order.
- Steps of such rewritings are counted in print only as: k − 1 eliminations for the k Lyndon
  words of length ≤ n; Algorithm 3's worst case O(n²) ([CPS19] Remark 58, Open Problem 59,
  §12). **No work read takes all occurrences of a rise at once, relates a count to the runs
  of a BWT, or gives a fewest-steps form.**

**3.3 Every piece is a Lyndon word.** With next[i] and prev[i] the nearest smaller suffixes
to the right and left of i: x[i .. next[i]) is the longest Lyndon prefix of the suffix at i,
and x[prev[i] .. i) is a Lyndon word ([Ellert22] §2, Lemmas 3 and 4, credited there to
Hohlweg–Reutenauer, Franek et al. and Bille et al.). Entry 1's pieces at prefix m are of one
or the other kind.

**3.4 Any column: the extended and the bijective BWT.**
- Every word is the image of exactly one multiset of aperiodic necklaces: sort all rotations
  of all necklaces by their infinite powers, take last letters; the cycles of the inverse
  standard permutation spell the necklaces ([GR-Hopf] Definitions 6.6.12, 6.6.26, Theorem
  6.6.29, Remark 6.6.31, crediting [GR93] and [Reut93] Theorem 7.20; [CDP05] §4). The BWT is
  the one-necklace case; the bijective BWT is the multiset of T's Lyndon factors ([BKL] §2.1;
  [Kuf09]).
- **Inversion by cycles, in print:** the cycles taken by increasing smallest row spell the
  Lyndon factors last to first ([GilScott] §5, Algorithms 5.1–5.2; [Kuf09] Lemma 7 and
  Theorem 8, whose proof deletes a cycle and finds a valid transform left; [BKKP] §4.6). All
  of them walk LF or FL for n steps. Run-length to run-length: [Koeppl20] Theorem 3, n
  backward steps, O(n lg r / lg lg r). **Neither the survey (2025) nor the journal article
  (2024) has an inversion in fewer than n steps.**
- A column is the BWT of some word iff the number of cycles of its standard permutation
  equals the gcd of its run lengths (Likhomanov–Shur, as [BKL] p. 2:4 states it).
- Runs: r_B is "roughly equal" to r on the standard corpora ([BKKP] Table 6); r_B = O(r log⁴
  n) and r = O(r_B log⁴ n), with families a factor log n apart both ways ([BIN25]; [BBIK]
  Theorem 2).
- The bijective BWT has two runs iff T = b^k a^l or T is a power of the Lyndon rotation of
  a standard word ([BKL] Theorem 24).
- The survey's open problems ([BKL] p. 2:22; six, unnumbered) and the journal article's
  ([BKKP] §7): construction in O(n / log_σ n); matching in O(m) rank operations; which
  rotation has the fewest runs; a bijective BWT on other factorizations (generalized Lyndon,
  Galois, inverse Lyndon, Nyldon). None asks for a faster inversion.

**3.5 The left tree.** The left standard factorization (the longest proper prefix that is a
Lyndon word) is Viennot's and Širšov's ([DRR-var] Proposition 26; [PR18] Example 1). Its
tree is the decreasing Cartesian tree of the proper prefixes ranked by their infinite powers
([DRR-var] Theorem 36), built in O(n) letter comparisons, the ranks being the left-to-right
postorder ([BC] Proposition 4, Theorem 6). [BC] §7 asks: "Is there a tight relation between
the left Lyndon trees and the right Lyndon trees?" (Entry 1's §5.6 credited "another tree" to
Dolce–Restivo–Reutenauer: the factorization is Viennot's; theirs is the Cartesian form.)

**3.6 Other orders.**
- A generalized lexicographic order takes an alphabet order for each position; its Lyndon
  words are a Hall set, with standard factorization "v the proper suffix of least v^∞"
  ([Reut06] Théorème 2.2; [DRR-gen] Definitions 4 and 12, Theorem 14). Galois words are the
  alternating case. They can be bordered and are not closed under ordered product (121, 3,
  1213: [Reut06] §3.8), so they are no Viennot factorization.
- Of the transforms that sort by a periodic sequence of alphabet orders, **only the BWT and
  the alternating BWT are inverted from ranks alone** ([GMRRS20] Definition 5.2, Theorem 5.9). In the alternating BWT
  equal letters lie in L in the reverse of their order in F ([GMRRS20] Proposition 3.2(3b),
  equation (3)). A second family that works: orders that depend on the last k symbols of
  the common prefix ([GMRRS23] §4, Lemma 17).
- Galois words: detection, factorization and rotation in O(n) time ([HKYS24]). Circ-UMFFs
  hold one rotation of every primitive word, all border-free ([DMS] Theorem 22); Galois
  words are not one ([DMS] §7). A reader's caution: [DMS] Theorem 46 ("for Galois u, v with
  uv primitive, u < v iff uv is Galois") is contradicted by aba, c (the example [Reut06] and
  [HKYS24] print), 80 pairs over three letters to length 5.
- ω-Lyndon words for any order on infinite words with a lexicographic-like condition
  ([PZ20]); generalized Lyndon factorizations of infinite words ([BW19]); Nyldon words, a
  right Hall set for the other extremal Lazard choice ([CPS19]); generalised Nyldon words
  ([FHN25], abstract only). No tree, transform or algorithm in them.
- Formalized in Isabelle/HOL: the basics, the factorization's existence and uniqueness, the
  existence of a factorization into two Lyndon words; no tree ([HS21], from the AFP
  outline).
