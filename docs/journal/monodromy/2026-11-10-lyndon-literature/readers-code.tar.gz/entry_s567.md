## 5. What this changes in entry 1

Entry 1 stays as merged, with one dated paragraph added to its §10 that points here. The
corrections:

| entry 1 says | it should say |
|---|---|
| §10, new: "§5.6's: that this SLP is the Lyndon tree above the run starts" | the bottom-up making of the Lyndon tree of the least rotation, by merging on the circular word a largest word into its left neighbour, is the Schützenberger–Melançon rewriting (§3.2). New: its run on the run-length column, LF's row order choosing the rise, a rise taken at all its occurrences at once in O(1), and the count |
| §2, "A column that is no BWT … drop it from both orders and go on" | that is the inversion of the extended BWT by its cycles, largest first; in print with n steps (§3.4). New: in S steps, with each factor's tree (§4.2) |
| §5.6 Theorem 2, "every letter's word at every moment is a Lyndon word" as its own count | it follows from two lemmas in print (§3.3) |
| §5.6, "The left standard factorisation gives another tree (Dolce–Restivo–Reutenauer 2019)" | the factorization is Viennot's and Širšov's; DRR give its Cartesian form (§3.5). It is no order of steps at coincidences (§4.4) |
| §5.6, "left end 2.137 r" as an order of steps of its own | the right end for the inverse alphabet order (§4.3) |
| §5.6 Theorem 3, "P from §5.5 and Theorem 1" | a case of Theorem 5 (§4.1), which needs neither |
| §8 item 9, "Whether another order of the alphabet makes fewer cells" | counted for the first letter by entry 1 and two readers: no (§4.8) |

Nothing in the works read anticipates steps = r₂ − 1 + U, the count over the hinges, a
count of S on any corpus, or the cells form.

## 6. Ideas, ranked by what they are worth to the decoder

**To use in the production kernel** (entry 1, §8 items 3 to 5):
1. **A proved refusal after the order stage.** S ≥ r₂ − 1 (entry 1, Theorem 4), and r₂ = 2r
   less the coincidences, which the order stage can count as it lays the two orders out (not built). So
   a block whose r₂ − 1 exceeds the cells budget is refused before any cell, soundly. On
   Wikidata r₂/n tracks S/n a little better than r/n does (correlation over the 233 blocks
   0.991 against 0.983; S/r₂ 1.14 to 1.62 a block, S/r 1.29 to 2.08; **C**). Neither sees a
   periodic block (S/r₂ in the hundreds). Cost: a counter. *Kind: new, from Theorem 4.*
2. **The two-run columns as the division rule's unit test** (§4.7): steps must fall from
   the sum of the partial quotients of k/l to their number. Cost: the rule (not built) and
   thirty lines. *Kind: a known characterization ([BKL] Theorem 24) put to use.*
3. **A validity criterion for free** (§3.4): with g the gcd of the run lengths, a column is
   a BWT iff LF has exactly g cycles. So when g = 1, the first letter that closes unmarked
   proves the stream corrupt; when g > 1 a periodic block is told from a corrupt one by
   counting what closes. The decoder must still write what the walk would. Falsifier: a
   valid block that closes a letter early with g = 1. Cost: a gcd over the records. *Kind:
   known result to implement (Likhomanov–Shur), as a diagnostic only.*

**To record, not to build:**
4. **The kernel as an inverter of the bijective and the extended BWT** (§4.2): write every
   closed letter, not only the marked one. The literature has no run-length inversion under
   n steps. Not bzip2's format. Falsifier: a published inversion in o(n) steps. Cost: a
   writer loop and a census of S on bijective transforms of real text. *Kind: new idea.*
5. **Run-length bijective BWT to run-length BWT without n steps:** the factors' Lyndon
   grammars from the run list, then a Lyndon grammar → run-length BWT construction (entry
   1, §10: Olbrich, ESA 2025). Falsifier: that construction needing a reduced grammar the
   induction does not give. Cost: days. *Kind: new idea, a reader's.*
6. **The division rule in Lazard's form** (§4.7): N → w_A (w_B)^q is a run-length coding of
   nodes the Lyndon tree already has, so Theorems 1 and 2 survive it. A reader counted the
   steps it would take away on small inputs: 40 of 1,944 on a JSON-like text, 81 of 5,267
   on prose, 499 of 501 on `(ab)^500 a`. Entry 1 counted 94 steps of 27.4 million in such
   streaks on Wikidata (its §6.4). *Kind: related approach; it bears on periodic blocks only.*
7. **The run-minimization yardstick** ([GMRRS23] Theorem 27: the fewest runs any
   context-adaptive order gives, in O(n) for a constant alphabet): how far a block's r is
   from the least any sort order could give. A decoder cannot choose the order. *Kind:
   known algorithm; of use to an encoder.*

**Closed by this reading:**
8. The left Lyndon tree as an order of steps (§4.4, §4.8): not at coincidences, and not
   cheaper.
9. Other Hall orders, Nyldon included, as orders of steps (§4.8): within 1% of the right
   end.
10. Another order of the first letter, or buckets reversed in place (§4.8): at most 0.4%.
    The untried variant is depth two (the σ² pair buckets); a reader prices it at forty
    lines and expects nothing.
11. The alternating order (§4.8): the same runs, more steps, and a tree that is no Hall
    tree.
12. A machine-checked Theorem 2 on top of [HS21]: weeks; the standard factorization is not
    in the formal development yet.
13. From the works on inverse Lyndon words, ω-order sorting and Lyndon subsequences: §3.7.

**What no work read offers:** a way to make the Lyndon tree cheaper than by the induction.
Theorem 5 says where the cost is: one node above a hinge a step, whatever the order.

## 7. Limits

- **Not obtained** (publisher walls; each is cited only through the works that restate it):
  the body of Hohlweg–Reutenauer 2003; Melançon 1992; Reutenauer's *Free Lie Algebras*;
  Viennot 1978; Gessel–Reutenauer 1993; Gessel–Restivo–Reutenauer 2012; Mantaci et al.
  2007; the journal texts of the Elsevier and Springer versions (the arXiv or author
  versions were read, and locators are theirs); Fleischmann–Huch–Nowotka beyond its
  abstract; Postic's thesis; the paper of Holub–Starosta (its formal outline was read).
  Melançon 1992 should be read before §3.2 is leaned on: whether it already merges all
  equal rises at once, with a cost, is not known here.
- **The readers' tests are theirs.** §4.8 reports them with their sizes; only §4.1 to §4.7
  were run here, and only those are in the file beside this entry.
- **The brute force is small:** words to length 14 at most; nothing in §4 was run on a
  bzip2 block. Theorem 5 and its corollaries are proved; §4.4 and §4.8 are counts.
- **"Not in print" is five readers on one day**, on the two lists and what they cite. It is
  not a search of the field.
