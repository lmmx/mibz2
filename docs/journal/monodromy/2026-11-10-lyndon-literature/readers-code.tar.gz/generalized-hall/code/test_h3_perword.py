import sys, itertools, random
sys.path.insert(0,'.')
from iet import *
from cells import *
rnd = random.Random(5)
small = [''.join(t) for n in range(2, 12) for t in itertools.product('ab', repeat=n)]
small += [''.join(t) for n in range(2, 8) for t in itertools.product('abc', repeat=n)]
small += [''.join(rnd.choice('abcd') for _ in range(rnd.randint(5, 40))) for _ in range(1500)]
nw=d_r=d_l=0; ex=None; exl=None
for w in small:
    if not is_primitive(w): continue
    V=least_rotation(w)
    if len(set(V))<2: continue
    nw+=1
    L=bwt(V); closed,S=induce(L,'right')
    sr,cr,tr=lazard(V,'right'); sl,cl,tl=lazard(V,'left')
    hr=hinge_nodes(V,tr); hl=hinge_nodes(V,tl)
    if sr!=S or sr!=hr: d_r+=1
    if sl!=hl: d_l+=1
    if hl<hr and (ex is None or len(V)<len(ex[0])): ex=(V,L,hr,hl)
    if hl>hr and (exl is None or len(V)<len(exl[0])): exl=(V,L,hr,hl)
print("words",nw,"right Lazard cell steps != S or != hinge nodes:",d_r,"; left Lazard cell steps != hinge nodes of left tree:",d_l)
print("smallest with left<right:",ex,"; smallest with left>right:",exl)
