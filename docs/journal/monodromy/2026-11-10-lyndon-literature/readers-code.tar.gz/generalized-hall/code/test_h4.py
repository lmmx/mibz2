#!/usr/bin/env python3
"""H4: the alternating BWT, its LF as an exchange with flips, the induction with flips,
and the Galois standard-factorisation tree (Reutenauer 2006, Th. 2.2 and Rem. 2.2).
Usage: python3 test_h4.py
"""
import sys, itertools, random
sys.path.insert(0, '.')
from iet import runs, flat, is_primitive

def altkey(u, N, rank):
    """Key of u^infinity for the alternating order: position i even -> order, odd -> reversed."""
    s = (u * (N // len(u) + 2))[:N]
    return tuple(rank[c] if i % 2 == 0 else -rank[c] for i, c in enumerate(s))

def alt_lt(u, v, rank):
    N = len(u) + len(v)
    return altkey(u, N, rank) < altkey(v, N, rank)

def is_galois(w, rank):
    return all(alt_lt(w, w[i:], rank) for i in range(1, len(w)))      # Prop. 2.1: w^oo < v^oo

def galois_tree(w, rank):
    """Reutenauer's standard factorisation: v = shortest proper suffix with least v^oo."""
    if len(w) == 1: return w
    best = None
    for i in range(len(w) - 1, 0, -1):           # shortest first
        v = w[i:]
        if best is None or alt_lt(v, w[best:], rank): best = i
    return (galois_tree(w[:best], rank), galois_tree(w[best:], rank))

def abwt(w, rank):
    n = len(w)
    rots = sorted(range(n), key=lambda i: altkey(w[i:] + w[:i], 2 * n, rank))
    return ''.join(w[(i - 1) % n] for i in rots), rots

def lf_alt(L):
    """LF with the order reversed inside each letter's bucket."""
    n = len(L)
    order = sorted(range(n), key=lambda i: (L[i], -i))
    pi = [0]*n
    for r, i in enumerate(order): pi[i] = r
    return pi

def induce_flips(L, stats, rank):
    """Right-end induction for an exchange whose letters are all flipped at the start."""
    rs = runs(L); r = len(rs)
    lam = [e - s for s, e in rs]; tree = [L[s] for s, e in rs]; flip = [True]*r
    top = list(range(r)); bot = sorted(range(r), key=lambda a: (L[rs[a][0]], -a))
    closed = []
    while top:
        A, B = top[-1], bot[-1]
        if A == B:
            closed.append((tree[A], lam[A], flip[A])); top.pop(); bot.pop(); continue
        stats['steps'] += 1
        N = (tree[A], tree[B])
        wa, wb = flat(tree[A]), flat(tree[B])
        if not (is_galois(wa, rank) and is_galois(wb, rank)): stats['piece_not_galois'] += 1
        if not alt_lt(wa, wb, rank): stats['not_rise'] += 1
        if any(alt_lt(wb, flat(tree[x]), rank) for x in top): stats['not_legal'] += 1
        if lam[A] > lam[B]:
            lam[A] -= lam[B]; tree[B] = N
            bot.pop(); i = bot.index(A)
            bot.insert(i if flip[A] else i + 1, B)       # flipped winner: loser lands before it
            flip[B] ^= flip[A]
        elif lam[A] < lam[B]:
            lam[B] -= lam[A]; tree[A] = N
            top.pop(); i = top.index(B)
            top.insert(i if flip[B] else i + 1, A)
            flip[A] ^= flip[B]
        else:
            tree[B] = N; flip[B] ^= flip[A]
            top.pop(); bot.pop(); bot[bot.index(A)] = B
    return closed

def main():
    rnd = random.Random(3)
    words = [''.join(t) for n in range(2, 13) for t in itertools.product('ab', repeat=n)]
    words += [''.join(t) for n in range(2, 9) for t in itertools.product('abc', repeat=n)]
    words += [''.join(rnd.choice('abcd') for _ in range(rnd.randint(5, 40))) for _ in range(4000)]
    st = dict(steps=0, piece_not_galois=0, not_rise=0, not_legal=0)
    nw = bad_lf = bad_flip = bad_word = bad_tree = bad_closed = 0
    for w in words:
        if not is_primitive(w): continue
        nw += 1
        rank = {c: i for i, c in enumerate(sorted(set(w)))}
        L, rots = abwt(w, rank)
        n = len(w)
        # LF as text: row of rotation i  ->  row of rotation i-1
        row = [0]*n
        for x, i in enumerate(rots): row[i] = x
        true_lf = [row[(rots[x] - 1) % n] for x in range(n)]
        if true_lf != lf_alt(L): bad_lf += 1
        for s, e in runs(L):                       # a flip on every run
            if any(true_lf[x + 1] != true_lf[x] - 1 for x in range(s, e - 1)): bad_flip += 1
        closed = induce_flips(L, st, rank)
        g = min((w[i:] + w[:i] for i in range(n)), key=lambda u: altkey(u, 2 * n, rank))
        if len(closed) != 1 or closed[0][1] != 1: bad_closed += 1; continue
        if flat(closed[0][0]) != g: bad_word += 1
        elif closed[0][0] != galois_tree(g, rank): bad_tree += 1
    print("H4 primitive words", nw)
    print("  LF of the alternating BWT != bucket-reversed LF:", bad_lf, " runs on which LF is not a flip:", bad_flip)
    print("  induction with flips: not one closed point:", bad_closed, " word != Galois conjugate:", bad_word,
          " tree != Galois standard tree:", bad_tree)
    print("  steps", st['steps'], "piece not Galois", st['piece_not_galois'], "not a rise", st['not_rise'], "not a legal rise", st['not_legal'])
    # the two printed counter-examples to closure under product
    r2 = {'a': 0, 'b': 1}
    print("  Postic-Zamboni Rem.3: abba Galois", is_galois('abba', r2), "b Galois", is_galois('b', r2),
          "abba<b", alt_lt('abba', 'b', r2), "abbab Galois", is_galois('abbab', r2))
    r3 = {'1': 0, '2': 1, '3': 2}
    print("  Reutenauer s.3.8: 121 Galois", is_galois('121', r3), "3 Galois", is_galois('3', r3),
          "121<3", alt_lt('121', '3', r3), "1213 Galois", is_galois('1213', r3), "1312 Galois", is_galois('1312', r3))

main()
