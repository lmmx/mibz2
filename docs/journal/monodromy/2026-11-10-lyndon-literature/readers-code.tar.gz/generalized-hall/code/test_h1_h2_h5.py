#!/usr/bin/env python3
"""Tests for H1, H2 and the Melancon reading of a right-end step (H5).
Usage: python3 test_h1_h2_h5.py
"""
import sys, itertools, random
sys.path.insert(0, '.')
from iet import *

def induce_checked(L, stats):
    """Right-end induction (section 2) with, at every step, the checks:
       (i)  both words are Lyndon, w_A < w_B          (a rise)
       (ii) w_B >= every current letter's word         (a legal rise, Reutenauer 2006 s.3.4)
       (iii) every current letter is a letter or (t',t'') with t'' >= every current word
             (the sequence is circularly standard)
    """
    rs = runs(L); r = len(rs)
    lam = [e - s for s, e in rs]
    tree = [L[s] for s, e in rs]
    word = [L[s] for s, e in rs]
    top = list(range(r)); bot = sorted(range(r), key=lambda a: (L[rs[a][0]], a))
    closed = []
    while top:
        A, B = top[-1], bot[-1]
        live = set(top)
        mx = max(word[x] for x in live)
        # (iii)
        for x in live:
            if not isinstance(tree[x], str) and flat(tree[x][1]) < mx:
                stats['not_standard'] += 1
        if A == B:
            closed.append((tree[A], lam[A])); top.pop(); bot.pop(); continue
        stats['steps'] += 1
        if not (word[A] < word[B]): stats['not_rise'] += 1
        if word[B] != mx: stats['not_legal'] += 1
        N = (tree[A], tree[B]); W = word[A] + word[B]
        if not is_lyndon(W): stats['not_lyndon'] += 1
        if lam[A] > lam[B]:
            lam[A] -= lam[B]; tree[B] = N; word[B] = W
            bot.pop(); bot.insert(bot.index(A) + 1, B)
        elif lam[A] < lam[B]:
            lam[B] -= lam[A]; tree[A] = N; word[A] = W
            top.pop(); top.insert(top.index(B) + 1, A)
        else:
            tree[B] = N; word[B] = W
            top.pop(); bot.pop(); bot[bot.index(A)] = B
    return closed

def gr_multiset(L):
    """Cycles of LF read as necklaces (Gessel-Reutenauer), as {Lyndon conjugate: multiplicity}."""
    pi = lf(L); n = len(L); seen = [False]*n; out = {}
    for x in range(n):
        if seen[x]: continue
        cyc = []; y = x
        while not seen[y]:
            seen[y] = True; cyc.append(L[y]); y = pi[y]
        w = ''.join(reversed(cyc))        # L[x], L[pi x], ... is the word reversed
        out[least_rotation(w)] = out.get(least_rotation(w), 0) + 1
    return out

def omega_less_eq(u, v):
    return u + v <= v + u

def columns():
    for n in range(1, 13):
        for t in itertools.product('ab', repeat=n): yield ''.join(t)
    for n in range(1, 9):
        for t in itertools.product('abc', repeat=n): yield ''.join(t)
    rnd = random.Random(1)
    for _ in range(20000):
        n = rnd.randint(1, 40); k = rnd.randint(2, 5)
        yield ''.join(rnd.choice('abcde'[:k]) for _ in range(n))

def main():
    # ---- H1 and H5 (legal rise) on arbitrary columns
    st = dict(steps=0, not_rise=0, not_legal=0, not_lyndon=0, not_standard=0)
    ncol = multi = bad_set = bad_order = bad_tree = bad_prim = 0
    for L in columns():
        ncol += 1
        closed = induce_checked(L, st)
        got = {}
        for t, m in closed:
            w = flat(t)
            if not is_lyndon(w): bad_prim += 1
            got[w] = got.get(w, 0) + m
            if right_tree(w) != t: bad_tree += 1
        if got != gr_multiset(L): bad_set += 1
        if len(closed) > 1: multi += 1
        ws = [flat(t) for t, m in closed]
        for u, v in zip(ws, ws[1:]):
            if not (omega_less_eq(v, u) and u != v): bad_order += 1
    print("H1/H5 columns", ncol, "with several closed letters", multi)
    print("  closed-letter multiset != Gessel-Reutenauer multiset:", bad_set)
    print("  closed word not Lyndon:", bad_prim, " tree != right standard tree:", bad_tree)
    print("  closing order not strictly omega-decreasing:", bad_order)
    print("  steps", st['steps'], "not a rise", st['not_rise'], "not a legal rise", st['not_legal'],
          "merged word not Lyndon", st['not_lyndon'], "sequence not circularly standard", st['not_standard'])
    # ---- H1(c): bijective BWT
    rnd = random.Random(2); nb = badb = 0
    texts = [''.join(t) for n in range(1, 11) for t in itertools.product('ab', repeat=n)]
    texts += [''.join(rnd.choice('abcd'[:rnd.randint(2, 4)]) for _ in range(rnd.randint(1, 60))) for _ in range(20000)]
    for T in texts:
        nb += 1
        f = duval(T)
        L = ebwt(f)                         # Kufleitner / Gil-Scott: eBWT of the Lyndon factors
        closed = induce_checked(L, dict(steps=0, not_rise=0, not_legal=0, not_lyndon=0, not_standard=0))
        seq = []
        for t, m in closed: seq += [flat(t)] * m
        if seq != f or any(right_tree(flat(t)) != t for t, m in closed): badb += 1
    print("H1(c) texts", nb, "closed words in order != Lyndon factorisation (or tree differs):", badb)
    # ---- H2: left end on BWTs of primitive words
    key = None
    nw = bad2 = 0; sl = sr = 0
    words = [''.join(t) for n in range(2, 13) for t in itertools.product('ab', repeat=n)]
    words += [''.join(t) for n in range(2, 9) for t in itertools.product('abc', repeat=n)]
    words += [''.join(rnd.choice('abcd') for _ in range(rnd.randint(5, 60))) for _ in range(5000)]
    for w in words:
        if not is_primitive(w): continue
        nw += 1
        L = bwt(w)
        closed, steps = induce(L, 'left')
        _, stepsr = induce(L, 'right')
        sl += steps; sr += stepsr
        alpha = sorted(set(w)); inv = {c: -i for i, c in enumerate(alpha)}
        g = max(w[i:] + w[:i] for i in range(len(w)))
        if len(closed) != 1 or flat(closed[0][0]) != g or closed[0][0] != right_tree(g, inv): bad2 += 1
    print("H2 primitive words", nw, "left-end tree != right standard tree of the greatest rotation for the inverse order:", bad2,
          " steps left/right", sl, sr)

main()
