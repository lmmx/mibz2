import sys, itertools, random, io, contextlib
sys.path.insert(0,'.')
from iet import *
with contextlib.redirect_stdout(io.StringIO()):
    from test_h4 import *
def cart_tree(g, rank):
    n=len(g)
    key={i:altkey(g[i:]+g[:i],2*n,rank) for i in range(1,n)}
    def rec(lo,hi):
        if hi-lo==1: return g[lo]
        m=min(range(lo+1,hi), key=lambda i:key[i])
        return (rec(lo,m),rec(m,hi))
    return rec(0,n)
rnd=random.Random(3)
words=[''.join(t) for n in range(2,12) for t in itertools.product('ab',repeat=n)]
words+=[''.join(t) for n in range(2,8) for t in itertools.product('abc',repeat=n)]
words+=[''.join(rnd.choice('abcd') for _ in range(rnd.randint(5,40))) for _ in range(2000)]
nw=bad=0
for w in words:
    if not is_primitive(w): continue
    nw+=1
    rank={c:i for i,c in enumerate(sorted(set(w)))}
    L,rots=abwt(w,rank); n=len(w)
    g=min((w[i:]+w[:i] for i in range(n)), key=lambda u: altkey(u,2*n,rank))
    cl=induce_flips(L,dict(steps=0,piece_not_galois=0,not_rise=0,not_legal=0),rank)
    if cl[0][0]!=cart_tree(g,rank): bad+=1
print("primitive words",nw,"flipped induction tree != min-Cartesian tree of alternating rotation ranks:",bad)
