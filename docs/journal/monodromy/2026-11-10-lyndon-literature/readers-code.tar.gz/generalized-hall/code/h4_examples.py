import sys, itertools
sys.path.insert(0,'.')
from iet import *
from test_h4 import *
def cart_tree(g, rank):
    n=len(g)
    key={i:altkey(g[i:]+g[:i],2*n,rank) for i in range(1,n)}
    def rec(lo,hi):
        if hi-lo==1: return g[lo]
        m=min(range(lo+1,hi), key=lambda i:key[i])
        return (rec(lo,m),rec(m,hi))
    return rec(0,n)
shown=0
for n in range(2,8):
    for t in itertools.product('ab',repeat=n):
        w=''.join(t)
        if not is_primitive(w): continue
        rank={'a':0,'b':1}
        g=min((w[i:]+w[:i] for i in range(n)), key=lambda u: altkey(u,2*n,rank))
        if g!=w: continue
        L,rots=abwt(w,rank)
        st=dict(steps=0,piece_not_galois=0,not_rise=0,not_legal=0)
        cl=induce_flips(L,st,rank)
        t1=cl[0][0]; t2=galois_tree(g,rank); t3=cart_tree(g,rank)
        if t1!=t2 and shown<6:
            shown+=1
            print(g,"ABWT",L,"\n  induction:",t1,"\n  cartesian(alt rotation ranks):",t3,"\n  Galois standard:",t2, "\n  ", st)
