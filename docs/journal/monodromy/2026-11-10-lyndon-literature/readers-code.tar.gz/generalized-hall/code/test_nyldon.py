import sys, itertools, functools
sys.path.insert(0,'.')
from iet import *
from test_hall_orders import run
@functools.lru_cache(maxsize=None)
def nyldon(w):
    if len(w)==1: return True
    for i in range(1,len(w)):          # longest Nyldon proper suffix
        if nyldon(w[i:]):
            p=w[:i]; s=w[i:]
            return nyldon(p) and p>s   # Charlier-Philibert-Stipulanti, Theorem 20
    raise ValueError
# sanity: binary Nyldon words up to length 5 as listed in their Table 6
print(sorted(w for n in range(1,6) for w in map(''.join,itertools.product('01',repeat=n)) if nyldon(w)))
nw=bad=0
for n in range(2,11):
    for t in itertools.product('01',repeat=n):
        w=''.join(t)
        if not is_primitive(w) or len(set(w))<2: continue
        V=least_rotation(w); nw+=1
        steps,r2,root=run(V,'right','revlex')
        if not nyldon(root) or least_rotation(root)!=V: bad+=1
print("binary primitive words",nw,"Nyldon schedule does not end on the Nyldon conjugate:",bad)
