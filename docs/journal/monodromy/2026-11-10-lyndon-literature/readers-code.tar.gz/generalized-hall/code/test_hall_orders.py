#!/usr/bin/env python3
"""Cell-step counts of the one-sided Lazard (Hall) orders the literature names
(Charlier-Philibert-Stipulanti 2019, s.11.3 and Table 8), run on the cyclic word of run letters.
  right: z = greatest piece for the Hall order, absorbed by its left neighbour  ((Y\\z) z*)
  left : z = least piece for the Hall order, absorbs its right neighbour        (z* (Y\\z))
Usage: python3 test_hall_orders.py [prose file]
"""
import sys, itertools, random
sys.path.insert(0, '.')
sys.setrecursionlimit(100000)
from iet import *
from cells import State

def run(V, side, order):
    alpha = sorted(set(V)); inv = {c: chr(255 - i) for i, c in enumerate(alpha)}
    tr = (lambda w: w) if order in ('lex', 'revlex') else (lambda w: ''.join(inv[c] for c in w))
    S = State(V); steps = 0
    kcache = {}
    def key(w):
        if w not in kcache: kcache[w] = tr(w)
        return kcache[w]
    r2 = len(S.cells())
    while S.ncuts > 1:
        ws = set(S.word.values())
        if order in ('lex', 'invlex'):
            z = max(ws, key=key) if side == 'right' else min(ws, key=key)
        else:                                   # Hall order is the reverse of the word order
            z = min(ws, key=key) if side == 'right' else max(ws, key=key)
        did = False
        for cuts, c in S.cells():
            p = cuts[0]; a = S.prev[p]
            wl, wr = S.word[a], S.word[p]
            ok = (wr == z and wl != z) if side == 'right' else (wl == z and wr != z)
            if not ok: continue
            assert all(S.word[S.prev[q]] == wl and S.word[q] == wr for q in cuts)
            for q in cuts: S.merge(q)
            steps += 1; did = True
            break
        assert did
    (root,) = S.tree.values()
    return steps, r2, flat(root)

def fib(k):
    a, b = 'a', 'ab'
    for _ in range(k): a, b = b, b + a
    return b

SCHED = [('right', 'lex'), ('left', 'lex'), ('right', 'invlex'), ('left', 'invlex'), ('right', 'revlex'), ('right', 'revinvlex')]
NAMES = ['Lyn-right', 'Lyn-left', 'anti-right', 'anti-left', 'Nyldon', 'Nyldon-inv']

def main():
    rnd = random.Random(5)
    small = [''.join(t) for n in range(2, 11) for t in itertools.product('ab', repeat=n)]
    small += [''.join(t) for n in range(2, 7) for t in itertools.product('abc', repeat=n)]
    small += [''.join(rnd.choice('abcd') for _ in range(rnd.randint(5, 40))) for _ in range(600)]
    tot = [0]*6; nw = 0; R = 0; R2 = 0; bad = 0; best = [0]*6
    for w in small:
        if not is_primitive(w) or len(set(w)) < 2: continue
        V = least_rotation(w); nw += 1
        L = bwt(V); R += len(runs(L))
        res = [run(V, s, o) for s, o in SCHED]
        _, Sr = induce(L, 'right'); _, Sl = induce(L, 'left')
        if res[0][0] != Sr or res[2][0] != Sl: bad += 1
        if res[2][2] != max(V[i:] + V[:i] for i in range(len(V))): bad += 1
        R2 += res[0][1]
        m = min(x[0] for x in res)
        for i, x in enumerate(res):
            tot[i] += x[0]; best[i] += (x[0] == m)
    print("small primitive words", nw, " sum r", R, " sum (r2-1)", R2 - nw, " mismatches with the endpoint inductions:", bad)
    print("  cell steps  ", "  ".join("%s %d" % (n, t) for n, t in zip(NAMES, tot)))
    print("  words where the schedule is (one of) the fewest:", "  ".join("%s %d" % (n, t) for n, t in zip(NAMES, best)))
    big = {}
    big['fibonacci(13)'] = fib(13)
    big['json ids x150'] = ''.join('{"id":%d,"name":"user%d","ok":true},' % (1000 + i, i % 17) for i in range(150))[:3000]
    big['random abcd runs'] = ''.join(rnd.choice('abcd') * rnd.randint(1, 6) for _ in range(600))
    big['period 37 x40 +1'] = ''.join(rnd.choice('abcdef') for _ in range(37)) * 40 + 'g'
    if len(sys.argv) > 1:
        big['prose'] = open(sys.argv[1], encoding='latin-1').read()[2000:5000]
    print("%-18s %5s %5s %6s " % ("input", "n", "r", "r2-1") + " ".join("%10s" % n for n in NAMES))
    for name, w in big.items():
        if not is_primitive(w): w += '\x01'
        V = least_rotation(w); L = bwt(V)
        res = [run(V, s, o) for s, o in SCHED]
        _, Sr = induce(L, 'right'); _, Sl = induce(L, 'left')
        assert res[0][0] == Sr and res[2][0] == Sl
        print("%-18s %5d %5d %6d " % (name, len(V), len(runs(L)), res[0][1] - 1) + " ".join("%10d" % x[0] for x in res), flush=True)

main()
