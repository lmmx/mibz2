#!/usr/bin/env python3
"""Reference simulators written from sections 2, 5.5, 5.6 of the entry (not from its code).

 - lf(L): LF of an arbitrary column (stable sort by byte).
 - induce(L, end): endpoint induction with the drop rule; returns the closed letters
   in closing order as (tree, multiplicity), and the number of steps.
   tree = nested tuples (left, right) over single characters.
 - lyndon helpers: least rotation, Duval factorisation, right/left standard trees.
"""
import sys, itertools, random

def lf(L):
    n = len(L)
    order = sorted(range(n), key=lambda i: (L[i], i))   # stable
    pi = [0]*n
    for rank, i in enumerate(order):
        pi[i] = rank
    return pi

def runs(L):
    out = []; i = 0
    while i < len(L):
        j = i
        while j < len(L) and L[j] == L[i]: j += 1
        out.append((i, j)); i = j
    return out

def flat(t):
    return t if isinstance(t, str) else flat(t[0]) + flat(t[1])

def induce(L, end='right'):
    """Section 2's table, at the right end (or its mirror at the left end)."""
    rs = runs(L)
    r = len(rs)
    lam = [e - s for s, e in rs]
    tree = [L[s] for s, e in rs]
    top = list(range(r))
    bot = sorted(range(r), key=lambda a: (L[rs[a][0]], a))
    closed = []; steps = 0
    if end == 'left':
        top.reverse(); bot.reverse()      # work at the list tail in both cases
    while top:
        A, B = top[-1], bot[-1]
        if A == B:
            closed.append((tree[A], lam[A]))
            top.pop(); bot.pop()
            continue
        steps += 1
        N = (tree[A], tree[B])
        if lam[A] > lam[B]:               # top wins
            lam[A] -= lam[B]; tree[B] = N
            bot.pop(); bot.insert(bot.index(A) + 1, B) if end == 'right' else bot.insert(bot.index(A) + 1, B)
        elif lam[A] < lam[B]:             # bottom wins
            lam[B] -= lam[A]; tree[A] = N
            top.pop(); top.insert(top.index(B) + 1, A)
        else:                             # equal
            tree[B] = N
            top.pop(); bot.pop(); bot[bot.index(A)] = B
            top  # A deleted from top already
    return closed, steps

# NB on the left end: with both lists reversed, "just after X" at the right end becomes
# "just before X" in the original order, which is "just after X" in the reversed list:
# the same list operation. So one code path serves both ends.

def least_rotation(w):
    return min(w[i:] + w[:i] for i in range(len(w)))

def is_primitive(w):
    n = len(w)
    return all(w != w[:d] * (n // d) for d in range(1, n) if n % d == 0)

def is_lyndon(w, key=None):
    if key: w2 = [key[c] for c in w]
    else: w2 = list(w)
    return all(w2 < w2[i:] for i in range(1, len(w2)))

def duval(w):
    """Chen-Fox-Lyndon factorisation (Duval)."""
    n = len(w); i = 0; out = []
    while i < n:
        j, k = i + 1, i
        while j < n and w[k] <= w[j]:
            k = i if w[k] < w[j] else k + 1
            j += 1
        while i <= k:
            out.append(w[i:i + j - k]); i += j - k
    return out

def right_tree(w, key=None):
    """Iterated right standard factorisation: v = longest proper Lyndon suffix."""
    if len(w) == 1: return w
    for i in range(1, len(w)):
        if is_lyndon(w[i:], key):
            return (right_tree(w[:i], key), right_tree(w[i:], key))
    raise ValueError(w)

def left_tree(w):
    """Iterated left standard factorisation: u = longest proper Lyndon prefix."""
    if len(w) == 1: return w
    for i in range(len(w) - 1, 0, -1):
        if is_lyndon(w[:i]):
            return (left_tree(w[:i]), left_tree(w[i:]))
    raise ValueError(w)

def bwt(w):
    n = len(w)
    rots = sorted(range(n), key=lambda i: w[i:] + w[:i])
    return ''.join(w[(i - 1) % n] for i in rots)

def omega_key(u, N):
    return (u * (N // len(u) + 2))[:N]

def ebwt(words):
    """Extended BWT of a multiset of primitive words (omega order of all conjugates)."""
    conj = []
    N = 2 * max(len(u) for u in words) + 2
    for u in words:
        for i in range(len(u)):
            c = u[i:] + u[:i]
            conj.append((omega_key(c, N), c[-1]))
    conj.sort(key=lambda t: t[0])
    return ''.join(c for _, c in conj)
