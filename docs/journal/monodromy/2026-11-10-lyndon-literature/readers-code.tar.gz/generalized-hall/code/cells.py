#!/usr/bin/env python3
"""Cell steps in the text picture (entry, sections 5.5 and 5.6), for a primitive word.

V = least rotation, n rows. Row x <-> the rotation of V starting at SA[x] <-> the cut at
text position SA[x]. State = the set C of remaining cuts. ret(c) = the row of the previous
remaining cut in text order (first return of LF to C). Top letters = maximal runs of
C-consecutive rows on which ret is a translation of C-ranks; bottom letters = their images.
A cell = a maximal run of C-consecutive rows inside one top letter and one bottom letter
= every occurrence of one digram of refined letters. A cell step removes all cuts of a cell.

Schedules:
  right_lazard : z = the largest piece; cells (alpha, beta) with word(beta) = z != word(alpha)
                 (merge z with its left neighbour: Melancon / right Lazard elimination)
  left_lazard  : z = the least piece; cells (alpha, beta) with word(alpha) = z != word(beta)
                 (merge z with its right neighbour: left Lazard elimination, Perrin-Reutenauer s.8)
Each returns (number of cell steps, number of steps whose cell is at a coincidence
 = ends where a top letter and a bottom letter both end, tree).
"""
import sys
sys.path.insert(0, '.')
from iet import *

class State:
    def __init__(self, V):
        n = len(V); self.V = V; self.n = n
        sa = sorted(range(n), key=lambda i: V[i:] + V[:i])
        self.sa = sa
        self.row = [0]*n
        for x, p in enumerate(sa): self.row[p] = x
        self.alive = [True]*n               # by text position
        self.prev = [(p - 1) % n for p in range(n)]   # previous remaining cut (text order)
        self.next = [(p + 1) % n for p in range(n)]
        self.tree = {p: V[p] for p in range(n)}        # piece starting at cut p
        self.word = {p: V[p] for p in range(n)}
        self.ncuts = n
        # letter identity: the run of L that emits the byte, then the pair of identities merged
        L = ''.join(V[(p - 1) % n] for p in sa)
        runid = [0]*n; rid = 0
        for x in range(n):
            if x and L[x] != L[x - 1]: rid += 1
            runid[x] = rid
        # the byte V[p] is emitted by the row of the rotation starting at p+1
        self.ident = {p: runid[self.row[(p + 1) % n]] for p in range(n)}
        self.intern = {}
        self.nid = rid + 1

    def cells(self):
        """List of cells; each = (list of text positions of its cuts, is_coincidence_end)."""
        rows = [x for x in range(self.n) if self.alive[self.sa[x]]]
        k = len(rows)
        crank = {x: i for i, x in enumerate(rows)}
        ret = [crank[self.row[self.prev[self.sa[x]]]] for x in rows]   # C-rank of ret
        fwd = [crank[self.row[self.next[self.sa[x]]]] for x in rows]
        idl = [self.ident[self.prev[self.sa[x]]] for x in rows]    # piece ending at the cut
        idr = [self.ident[self.sa[x]] for x in rows]               # piece starting at the cut
        topb = [True] + [ret[i + 1] != ret[i] + 1 or idl[i + 1] != idl[i] for i in range(k - 1)]
        botb = [True] + [fwd[i + 1] != fwd[i] + 1 or idr[i + 1] != idr[i] for i in range(k - 1)]
        out = []; i = 0
        while i < k:
            j = i + 1
            while j < k and not topb[j] and not botb[j]: j += 1
            end_top = (j == k) or topb[j]; end_bot = (j == k) or botb[j]
            beg_top = topb[i]; beg_bot = botb[i]
            coin = (end_top and end_bot) or (beg_top and beg_bot)
            out.append(([self.sa[rows[t]] for t in range(i, j)], coin))
            i = j
        return out

    def merge(self, p):
        """Remove the cut at text position p."""
        a = self.prev[p]
        self.tree[a] = (self.tree[a], self.tree[p]); self.word[a] = self.word[a] + self.word[p]
        del self.tree[p]; del self.word[p]
        key = (self.ident[a], self.ident[p])
        if key not in self.intern:
            self.intern[key] = self.nid; self.nid += 1
        self.ident[a] = self.intern[key]; del self.ident[p]
        self.alive[p] = False
        nx = self.next[p]; self.next[a] = nx; self.prev[nx] = a
        self.ncuts -= 1

def lazard(V, side):
    S = State(V); steps = coin = 0
    while S.ncuts > 1:
        z = max(S.word.values()) if side == 'right' else min(S.word.values())
        did = False
        for cuts, c in S.cells():
            p = cuts[0]; a = S.prev[p]
            wl, wr = S.word[a], S.word[p]          # pieces ending / starting at the cut
            ok = (wr == z and wl != z) if side == 'right' else (wl == z and wr != z)
            if not ok: continue
            # every cut of the cell carries the same two words (same refined digram)
            assert all(S.word[S.prev[q]] == wl and S.word[q] == wr for q in cuts)
            for q in cuts: S.merge(q)
            steps += 1; coin += c; did = True
            break                                   # cells change: recompute
        assert did, (V, side)
    (root,) = S.tree.values()
    return steps, coin, root

def hinge_nodes(V, tree):
    """Nodes of the tree on the leaf-to-root paths of the hinges (entry, Theorem 3)."""
    n = len(V)
    L = bwt(V)
    sa = sorted(range(n), key=lambda i: V[i:] + V[:i])
    hinge = set()
    for x in range(n):
        if x == 0 or L[x] != L[x - 1]: hinge.add((sa[x] - 1) % n)
    cnt = 0
    def rec(t, lo):
        nonlocal cnt
        if isinstance(t, str): return lo + 1, (lo in hinge)
        mid, hl = rec(t[0], lo); hi, hr = rec(t[1], mid)
        if hl or hr: cnt += 1
        return hi, (hl or hr)
    rec(tree, 0)
    return cnt

def nruns(L):
    return len(runs(L))
