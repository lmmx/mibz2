#!/usr/bin/env python3
"""The right-end induction as right Lazard eliminations in decreasing order, refined:
phases = maximal stretches of steps with one word w_B; within the run the words w_B never increase.
Usage: python3 test_phases.py [prose file]
"""
import sys, random
sys.path.insert(0, '.')
from iet import *

def phases(L):
    rs = runs(L); r = len(rs)
    lam = [e - s for s, e in rs]; word = [L[s] for s, e in rs]
    top = list(range(r)); bot = sorted(range(r), key=lambda a: (L[rs[a][0]], a))
    S = 0; seq = []; rules = set(); streak = 0; powers = 0; lastA = None; lastz = None
    while top:
        A, B = top[-1], bot[-1]
        if A == B: top.pop(); bot.pop(); continue
        S += 1; z = word[B]
        if seq and z > seq[-1]: raise AssertionError("w_B increased")
        if not seq or z != seq[-1]: seq.append(z)
        rules.add((word[A], z))
        # y z^k : the left word is itself (y' z) made in this phase
        if word[A].endswith(z) and (word[A][:-len(z)], z) in rules: powers += 1
        W = word[A] + word[B]
        if lam[A] > lam[B]:
            lam[A] -= lam[B]; word[B] = W; bot.pop(); bot.insert(bot.index(A) + 1, B)
        elif lam[A] < lam[B]:
            lam[B] -= lam[A]; word[A] = W; top.pop(); top.insert(top.index(B) + 1, A)
        else:
            word[B] = W; top.pop(); bot.pop(); bot[bot.index(A)] = B
    return r, S, len(seq), len(rules), powers

def fib(k):
    a, b = 'a', 'ab'
    for _ in range(k): a, b = b, b + a
    return b
rnd = random.Random(5)
big = {}
big['fibonacci(15)'] = fib(15)
big['json ids x300'] = ''.join('{"id":%d,"name":"user%d","ok":true},' % (1000 + i, i % 17) for i in range(300))[:6000]
big['random abcd runs'] = ''.join(rnd.choice('abcd') * rnd.randint(1, 6) for _ in range(900))
big['period 37 x60 +1'] = ''.join(rnd.choice('abcdef') for _ in range(37)) * 60 + 'g'
big['(ab)^500 a'] = 'ab' * 500 + 'a'
if len(sys.argv) > 1: big['prose'] = open(sys.argv[1], encoding='latin-1').read()[:6000]
print("%-18s %6s %6s %7s %8s %9s %12s" % ("input", "n", "r", "S", "phases", "distinct", "steps y.z^k,"))
print("%-18s %6s %6s %7s %8s %9s %12s" % ("", "", "", "", "(words z)", "(y,z)", "k>=2"))
for name, w in big.items():
    if not is_primitive(w): w += '\x01'
    V = least_rotation(w); L = bwt(V)
    r, S, E, D, P = phases(L)
    print("%-18s %6d %6d %7d %8d %9d %12d" % (name, len(V), r, S, E, D, P))
