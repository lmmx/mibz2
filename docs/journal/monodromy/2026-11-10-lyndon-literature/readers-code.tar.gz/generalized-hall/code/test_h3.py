#!/usr/bin/env python3
"""H3: the left Lyndon tree as a schedule of cell steps, and its count over the hinges.
Usage: python3 test_h3.py [path of a text file used as prose, optional]
"""
import sys, itertools, random
sys.path.insert(0, '.')
sys.setrecursionlimit(100000)
from iet import *
from cells import *

def fib(k):
    a, b = 'a', 'ab'
    for _ in range(k): a, b = b, b + a
    return b

def main():
    rnd = random.Random(5)
    small = [''.join(t) for n in range(2, 12) for t in itertools.product('ab', repeat=n)]
    small += [''.join(t) for n in range(2, 8) for t in itertools.product('abc', repeat=n)]
    small += [''.join(rnd.choice('abcd') for _ in range(rnd.randint(5, 40))) for _ in range(1500)]
    nw = 0; bad_l = bad_r = bad_th3 = 0
    tot = dict(r=0, S=0, Sleft_end=0, hr=0, hl=0, cr=0, cl=0, coin_r=0, coin_l=0)
    less = more = same = 0
    for w in small:
        if not is_primitive(w): continue
        V = least_rotation(w)
        if len(set(V)) < 2: continue
        nw += 1
        L = bwt(V)
        closed, S = induce(L, 'right'); _, Sl = induce(L, 'left')
        rt = closed[0][0]; lt = left_tree(V)
        sr, cr, tr = lazard(V, 'right'); sl, cl, tl = lazard(V, 'left')
        if tr != rt: bad_r += 1
        if tl != lt: bad_l += 1
        hr = hinge_nodes(V, rt); hl = hinge_nodes(V, lt)
        if hr != S: bad_th3 += 1
        tot['r'] += nruns(L); tot['S'] += S; tot['Sleft_end'] += Sl; tot['hr'] += hr; tot['hl'] += hl
        tot['cr'] += sr; tot['cl'] += sl; tot['coin_r'] += cr; tot['coin_l'] += cl
        less += hl < hr; more += hl > hr; same += hl == hr
    print("small primitive words", nw)
    print("  right Lazard schedule tree != right-end induction's tree:", bad_r)
    print("  left Lazard schedule tree != left standard (left Lyndon) tree:", bad_l)
    print("  Theorem 3 check, hinge nodes of the right tree != S:", bad_th3)
    print("  sums: r", tot['r'], " S right end", tot['S'], " S left end", tot['Sleft_end'])
    print("        hinge nodes right tree", tot['hr'], " left tree", tot['hl'], " (left<right on", less, "words, >", more, ", =", same, ")")
    print("        cell steps right Lazard", tot['cr'], "(at a coincidence:", tot['coin_r'], ")  left Lazard", tot['cl'], "(at a coincidence:", tot['coin_l'], ")")
    # larger inputs
    big = {}
    big['fibonacci(15)'] = fib(15)
    big['json ids x300'] = ''.join('{"id":%d,"name":"user%d","ok":true},' % (1000 + i, i % 17) for i in range(300))[:6000]
    big['random abcd runs'] = ''.join(rnd.choice('abcd') * rnd.randint(1, 6) for _ in range(900))
    big['period 37 x60 +1'] = ''.join(rnd.choice('abcdef') for _ in range(37)) * 60 + 'g'
    if len(sys.argv) > 1:
        big['prose ' + sys.argv[1].split('/')[-1]] = open(sys.argv[1], encoding='latin-1').read()[:6000]
    print("%-22s %6s %6s %7s %7s %7s %7s %9s %9s %9s %9s" % ("input", "n", "r", "S_right", "S_left", "hingeR", "hingeL", "cellsRLaz", "coinR", "cellsLLaz", "coinL"))
    for name, w in big.items():
        w = w.replace('\x00', ' ')
        if not is_primitive(w): w += '\x01'
        V = least_rotation(w)
        L = bwt(V)
        closed, S = induce(L, 'right'); _, Sl = induce(L, 'left')
        rt = closed[0][0]; lt = left_tree_fast(V)
        hr = hinge_nodes(V, rt); hl = hinge_nodes(V, lt)
        sr, cr, tr = lazard(V, 'right'); sl, cl, tl = lazard(V, 'left')
        assert tr == rt and tl == lt and hr == S
        print("%-22s %6d %6d %7d %7d %7d %7d %9d %9d %9d %9d" % (name, len(V), nruns(L), S, Sl, hr, hl, sr, cr, sl, cl))

def left_tree_fast(V):
    """Left Lyndon tree by the left Lazard / Melancon rule on a linear word (stack)."""
    # A Lyndon word's left standard tree: scan left to right; keep a stack of Lyndon pieces;
    # a new letter c is pushed; while the stack has >= 2 pieces and the piece below the top
    # is smaller than the top ... (Viennot's left factorisation is not a simple stack rule),
    # so fall back on the definition with a Lyndon-prefix table.
    n = len(V)
    # lyn[i] = set of j such that V[i:j] is Lyndon : compute per start by Duval-like extension
    import functools
    @functools.lru_cache(maxsize=None)
    def lynpref(i, j):
        """lengths l in increasing order with V[i:i+l] Lyndon and i+l <= j."""
        out = []; k = i; p = 1        # standard: longest Lyndon prefix tracking
        # w[i:m] is a Lyndon word iff period of it is its whole length under the Duval scan
        m = i + 1; per = 1; out.append(1)
        while m < j:
            c = V[m]; d = V[m - per]
            if c < d: break
            if c > d: per = m - i + 1; out.append(per)
            m += 1
        return tuple(out)
    def rec(i, j):
        if j - i == 1: return V[i]
        ls = [l for l in lynpref(i, j) if l < j - i]
        l = ls[-1]
        return (rec(i, i + l), rec(i + l, j))
    return rec(0, n)

main()
