import sys,urllib.request,urllib.parse,time,re
import xml.etree.ElementTree as ET
ns={'a':'http://www.w3.org/2005/Atom','x':'http://arxiv.org/schemas/atom'}
def q(query,n=6):
    url="https://export.arxiv.org/api/query?max_results=%d&search_query=%s"%(n,urllib.parse.quote(query))
    req=urllib.request.Request(url,headers={"User-Agent":"bibliography-check/1.0"})
    for attempt in range(4):
        try:
            with urllib.request.urlopen(req,timeout=60) as r:
                d=r.read()
            break
        except Exception as e:
            print("  retry",e); time.sleep(6*(attempt+1))
    else: return
    root=ET.fromstring(d)
    for e in root.findall('a:entry',ns):
        au="; ".join(x.find('a:name',ns).text for x in e.findall('a:author',ns))
        t=re.sub(r'\s+',' ',e.find('a:title',ns).text)
        jr=e.find('x:journal_ref',ns); doi=e.find('x:doi',ns); com=e.find('x:comment',ns)
        print("-",e.find('a:id',ns).text,"|",au,"|",t,"| published",e.find('a:published',ns).text,"| updated",e.find('a:updated',ns).text,"| jref",None if jr is None else jr.text,"| doi",None if doi is None else doi.text,"| comment",None if com is None else com.text)
for a in sys.argv[1:]:
    print("==",a); q(a); time.sleep(4)
