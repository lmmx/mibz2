import json,sys,urllib.request,urllib.parse,time
for doi in sys.argv[1:]:
    url="https://api.crossref.org/works/"+urllib.parse.quote(doi,safe='/')
    for attempt in range(4):
        try:
            with urllib.request.urlopen(urllib.request.Request(url,headers={"User-Agent":"bibliography-check/1.0"}),timeout=60) as r:
                d=json.load(r)["message"]; break
        except Exception as e:
            print("retry",doi,e); time.sleep(6*(attempt+1))
    else: continue
    keys=["type","title","subtitle","container-title","short-container-title","volume","issue","page","article-number","publisher","ISBN","ISSN","issued","published-print","published-online","event","editor","author","assertion","relation","license","update-to","abstract"]
    print("==",doi)
    for k in keys:
        v=d.get(k)
        if v is None: continue
        if k in("author","editor"): v="; ".join((a.get("given","")+" "+a.get("family","")).strip() for a in v)
        if k=="assertion": v=[(a.get("name"),a.get("value")) for a in v]
        if k=="license": v=[(a.get("URL"),a.get("content-version")) for a in v]
        s=str(v); print("  ",k,":",s[:900])
    time.sleep(3)
