import json,sys,urllib.request,urllib.parse,time
def q(query, rows=6):
    url="https://api.crossref.org/works?rows=%d&query.bibliographic=%s"%(rows,urllib.parse.quote(query))
    req=urllib.request.Request(url,headers={"User-Agent":"bibliography-check/1.0"})
    for attempt in range(5):
        try:
            with urllib.request.urlopen(req,timeout=60) as r:
                d=json.load(r)
            break
        except Exception as e:
            print("  retry",e); time.sleep(8*(attempt+1))
    else:
        return
    for it in d["message"]["items"]:
        au="; ".join((a.get("given","")+" "+a.get("family","")).strip() for a in it.get("author",[]))
        print("-",au,"|",(it.get("title") or [""])[0],"|",(it.get("container-title") or [""]),"| vol",it.get("volume"),"| issue",it.get("issue"),"| pp",it.get("page"),"| art",it.get("article-number"),"|",it.get("issued",{}).get("date-parts"),"| print",it.get("published-print",{}).get("date-parts"),"| online",it.get("published-online",{}).get("date-parts"),"|",it.get("DOI"),"|",it.get("type"))
for a in sys.argv[1:]:
    print("==",a); q(a); time.sleep(4)
