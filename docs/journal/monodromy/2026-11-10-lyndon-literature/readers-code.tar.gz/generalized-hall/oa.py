import json,sys,urllib.request,time
for doi in sys.argv[1:]:
    url="https://api.openalex.org/works/doi:"+doi
    try:
        with urllib.request.urlopen(urllib.request.Request(url,headers={"User-Agent":"bibliography-check/1.0"}),timeout=60) as r:
            d=json.load(r)
    except Exception as e:
        print(doi,"ERR",e); continue
    print("==",doi)
    print(" title:",d.get("title")); print(" year:",d.get("publication_year"),"date:",d.get("publication_date"))
    print(" authors:","; ".join(a["author"]["display_name"] for a in d.get("authorships",[])))
    b=d.get("biblio",{}); print(" biblio:",b)
    pl=d.get("primary_location") or {}; print(" venue:",(pl.get("source") or {}).get("display_name"))
    print(" oa:",d.get("open_access"))
    for l in d.get("locations",[]): print("  loc:",(l.get("source") or {}).get("display_name"),l.get("landing_page_url"),l.get("pdf_url"),l.get("version"),l.get("license"))
    inv=d.get("abstract_inverted_index")
    if inv:
        pos={}
        for w,ps in inv.items():
            for p in ps: pos[p]=w
        print(" abstract:"," ".join(pos[i] for i in sorted(pos)))
    time.sleep(1)
