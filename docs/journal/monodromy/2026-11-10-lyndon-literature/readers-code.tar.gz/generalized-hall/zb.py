import json,sys,urllib.request,urllib.parse,time
def q(s,n=3):
    url="https://api.zbmath.org/v1/document/_search?results_per_page=%d&search_string=%s"%(n,urllib.parse.quote(s))
    for attempt in range(3):
        try:
            with urllib.request.urlopen(urllib.request.Request(url,headers={"User-Agent":"bibliography-check/1.0"}),timeout=60) as r:
                return json.load(r).get("result",[])
        except Exception as e:
            err=e; time.sleep(4)
    print("ERR",s,err); return []
for s in sys.argv[1:]:
    print("==",s)
    for d in q(s):
        au="; ".join(a.get("name","") for a in d.get("contributors",{}).get("authors",[]))
        t=d.get("title",{}); src=d.get("source",{})
        print("-",au,"|",t.get("title"),"|",t.get("original_title"),"|",src.get("source"),"| year",d.get("year"),"| Zbl",d.get("identifier"),"|",[l.get("identifier") for l in d.get("links",[])])
        for ec in d.get("editorial_contributions",[]):
            print("   ",ec.get("contribution_type"),"by",(ec.get("reviewer") or {}).get("name"),":",(ec.get("text") or "")[:2500])
    time.sleep(2)
