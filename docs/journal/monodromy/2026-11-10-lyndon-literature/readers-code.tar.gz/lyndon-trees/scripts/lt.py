#!/usr/bin/env python3
"""Light checks for the lyndon-trees literature cluster (MONODROMY).

Nothing here is a timing benchmark.  Everything is counted.

Sub-commands (see main):
  h1   right-end induction with the drop rule on eBWT / BBWT / arbitrary columns
  h2   left-end induction against the Lyndon tree, inverse order, of the greatest rotation
  h3   is the LEFT Lyndon tree a tree of digram steps?  hinge counts left vs right
  h4   Galois words: Cartesian tree of alternating rotation ranks vs standard factorisation
  h5   first-letter order permuted (a generalized order): step counts
"""
import sys, random, itertools, functools

sys.setrecursionlimit(1 << 20)

# ----------------------------------------------------------------------------
# words
# ----------------------------------------------------------------------------

def is_lyndon(s, lt=None):
    """s (tuple) strictly smaller than all its proper non-empty suffixes."""
    if lt is None:
        return all(s < s[k:] for k in range(1, len(s)))
    return all(lt(s, s[k:]) for k in range(1, len(s)))


def lex_lt_factory(rank):
    """finite lexicographic order (prefix is smaller) for the letter order `rank`."""
    def lt(a, b):
        for x, y in zip(a, b):
            if x != y:
                return rank[x] < rank[y]
        return len(a) < len(b)
    return lt


def is_primitive(s):
    n = len(s)
    return not any(n % d == 0 and s == s[:d] * (n // d) for d in range(1, n))


def duval(s):
    """Lyndon factorisation (list of tuples), usual order."""
    n, i, out = len(s), 0, []
    while i < n:
        j, k = i + 1, i
        while j < n and s[k] <= s[j]:
            k = i if s[k] < s[j] else k + 1
            j += 1
        while i <= k:
            out.append(tuple(s[i:i + j - k]))
            i += j - k
    return out


def right_tree_naive(w, lt=None):
    """spans (lo, mid, hi) of the right Lyndon tree: v = longest proper Lyndon suffix."""
    spans = []
    def rec(lo, hi):
        if hi - lo < 2:
            return
        for mid in range(lo + 1, hi):
            if is_lyndon(w[mid:hi], lt):
                break
        assert is_lyndon(w[lo:mid], lt), (w, lo, mid, hi)
        spans.append((lo, mid, hi))
        rec(lo, mid); rec(mid, hi)
    rec(0, len(w))
    return sorted(spans)


def left_tree_naive(w):
    """spans of the left Lyndon tree: u = longest proper Lyndon prefix (Viennot)."""
    spans = []
    def rec(lo, hi):
        if hi - lo < 2:
            return
        for mid in range(hi - 1, lo, -1):
            if is_lyndon(w[lo:mid]):
                break
        assert is_lyndon(w[mid:hi]), (w, lo, mid, hi)
        spans.append((lo, mid, hi))
        rec(lo, mid); rec(mid, hi)
    rec(0, len(w))
    return sorted(spans)


def left_tree_bc(y):
    """Badkobeh-Crochemore LeftLyndonTree (arXiv:2011.12742 section 3), spans (lo, mid, hi)."""
    n = len(y)
    lyns = [1] * n
    spans = []
    per, i = 1, 0
    for j in range(1, n):
        if y[j] != y[i]:
            lyns[j] = j + 1
            per, i = j + 1, 0
        else:
            lyns[j] = lyns[i]
            i = (i + 1) % per
        l, k = 1, j - 1
        while l < lyns[j]:
            # left child: tree of width lyns[k] ending at k; right: current tree ending at j
            spans.append((k - lyns[k] + 1, k + 1, j + 1))
            l, k = l + lyns[k], k - lyns[k]
    return sorted(spans)


def cartesian_spans(key, lo, hi, smallest=True):
    """Cartesian tree of key[j], j in (lo, hi) junctions; returns spans (a, j, b)."""
    spans = []
    stack = [(lo, hi)]
    while stack:
        a, b = stack.pop()
        if b - a < 2:
            continue
        js = range(a + 1, b)
        j = min(js, key=lambda t: key[t]) if smallest else max(js, key=lambda t: key[t])
        spans.append((a, j, b))
        stack.append((a, j)); stack.append((j, b))
    return sorted(spans)


def cartesian_spans_fast(key, n, smallest=True):
    """Same for junctions 1..n-1 in O(n) by a stack."""
    sgn = 1 if smallest else -1
    lo = [0] * (n + 1); hi = [n] * (n + 1)
    st = []
    for j in range(1, n):
        while st and sgn * key[st[-1]] > sgn * key[j]:
            hi[st.pop()] = j
        lo[j] = st[-1] if st else 0
        st.append(j)
    return sorted((lo[j], j, hi[j]) for j in range(1, n))


# ----------------------------------------------------------------------------
# rotations
# ----------------------------------------------------------------------------

def rot_order(t):
    """start positions of the rotations of t in increasing order (t primitive)."""
    n = len(t)
    if n <= 4000:
        tt = t + t
        return sorted(range(n), key=lambda i: tt[i:i + n])
    # prefix doubling on the cyclic word
    vals = sorted(set(t)); r0 = {v: k for k, v in enumerate(vals)}
    rank = [r0[c] for c in t]
    k = 1
    sa = list(range(n))
    while True:
        keyf = lambda i: (rank[i], rank[(i + k) % n])
        sa.sort(key=keyf)
        new = [0] * n
        for a in range(1, n):
            new[sa[a]] = new[sa[a - 1]] + (keyf(sa[a]) != keyf(sa[a - 1]))
        rank = new
        if rank[sa[-1]] == n - 1 or k >= n:
            break
        k *= 2
    return sa


# ----------------------------------------------------------------------------
# hash-consed trees
# ----------------------------------------------------------------------------

class Cons:
    def __init__(self):
        self.tab = {}
        self.node = []          # ('L', sym) or ('P', a, b)
        self.size = []
    def leaf(self, sym):
        k = ('L', sym)
        if k not in self.tab:
            self.tab[k] = len(self.node); self.node.append(k); self.size.append(1)
        return self.tab[k]
    def pair(self, a, b):
        k = ('P', a, b)
        if k not in self.tab:
            self.tab[k] = len(self.node); self.node.append(k)
            self.size.append(self.size[a] + self.size[b])
        return self.tab[k]
    def expand(self, t):
        """(leaves, spans) of tree t; spans are (lo, mid, hi)."""
        leaves, spans = [], []
        def rec(x, off):
            nd = self.node[x]
            if nd[0] == 'L':
                leaves.append(nd[1]); return
            a, b = nd[1], nd[2]
            spans.append((off, off + self.size[a], off + self.size[x]))
            rec(a, off); rec(b, off + self.size[a])
        rec(t, 0)
        return leaves, sorted(spans)


# ----------------------------------------------------------------------------
# the induction, as the entry's section 2 states it (generic exchange)
# ----------------------------------------------------------------------------

def pieces_of_column(L):
    """LF of column L as an exchange: list of (length, image start, run byte), top order."""
    cnt = {}
    for c in L:
        cnt[c] = cnt.get(c, 0) + 1
    C, tot = {}, 0
    for c in sorted(cnt):
        C[c] = tot; tot += cnt[c]
    seen = dict.fromkeys(cnt, 0)
    pcs, i, n = [], 0, len(L)
    while i < n:
        j = i
        while j < n and L[j] == L[i]:
            j += 1
        pcs.append((j - i, C[L[i]] + seen[L[i]], L[i]))
        seen[L[i]] += j - i
        i = j
    return pcs


def induce(pcs, cons, end='right', leaf=lambda idx, sym: idx):
    """Endpoint induction with the drop rule.

    pcs: (length, image start, symbol) in top order.
    Returns (closed, steps, kinds): closed = [(tree, multiplicity)] in closing order,
    steps = number of rules made, kinds = [top wins, bottom wins, equal].
    """
    r = len(pcs)
    H, T = r, r + 1
    lam = [p[0] for p in pcs]
    w = [cons.leaf(leaf(i, p[2])) for i, p in enumerate(pcs)]
    tn = [0] * (r + 2); tp = [0] * (r + 2); bn = [0] * (r + 2); bp = [0] * (r + 2)
    def build(order, nx, pv):
        prev = H
        for x in order:
            nx[prev] = x; pv[x] = prev; prev = x
        nx[prev] = T; pv[T] = prev
    build(range(r), tn, tp)
    build(sorted(range(r), key=lambda i: pcs[i][1]), bn, bp)
    def unlink(x, nx, pv):
        nx[pv[x]] = nx[x]; pv[nx[x]] = pv[x]
    def ins_after(x, y, nx, pv):      # x just after y
        nx[x] = nx[y]; pv[x] = y; pv[nx[y]] = x; nx[y] = x
    def ins_before(x, y, nx, pv):
        ins_after(x, pv[y], nx, pv)
    right = end == 'right'
    closed, steps, kinds = [], 0, [0, 0, 0]
    while True:
        A = tp[T] if right else tn[H]
        B = bp[T] if right else bn[H]
        if A == H or A == T:
            break
        if A == B:
            closed.append((w[A], lam[A]))
            unlink(A, tn, tp); unlink(A, bn, bp)
            continue
        N = cons.pair(w[A], w[B]); steps += 1
        if lam[A] > lam[B]:
            kinds[0] += 1
            lam[A] -= lam[B]; w[B] = N
            unlink(B, bn, bp)
            (ins_after if right else ins_before)(B, A, bn, bp)
        elif lam[A] < lam[B]:
            kinds[1] += 1
            lam[B] -= lam[A]; w[A] = N
            unlink(A, tn, tp)
            (ins_after if right else ins_before)(A, B, tn, tp)
        else:
            kinds[2] += 1
            w[B] = N
            unlink(B, bn, bp)
            ins_after(B, A, bn, bp); unlink(A, bn, bp)   # B takes A's place
            unlink(A, tn, tp)
    return closed, steps, kinds


# ----------------------------------------------------------------------------
# H1
# ----------------------------------------------------------------------------

def omega_cmp(u, v):
    a, b = u * len(v), v * len(u)
    return (a > b) - (a < b)


def ebwt(words):
    """extended BWT (Mantaci et al.) of a list of primitive words: rows = all rotations,
    sorted by the omega order."""
    rows = []
    for wd in words:
        for i in range(len(wd)):
            rows.append(wd[i:] + wd[:i])
    rows.sort(key=functools.cmp_to_key(omega_cmp))
    return tuple(r[-1] for r in rows)


def least_rotation(t):
    return min(t[i:] + t[:i] for i in range(len(t)))


def cmd_h1(seed=1, trials=20000):
    rnd = random.Random(seed)
    n_bbwt = n_fact_ok = n_tree_ok = n_trees = 0
    n_multi = 0
    for _ in range(trials):
        n = rnd.randint(1, 14); sig = rnd.randint(1, 4)
        t = tuple(rnd.randrange(sig) for _ in range(n))
        fac = duval(t)
        L = ebwt(fac)
        cons = Cons()
        closed, steps, _ = induce(pieces_of_column(L), cons, 'right', leaf=lambda i, s: s)
        got = []
        ok_tree = True
        for tree, mult in closed:
            leaves, spans = cons.expand(tree)
            got.extend([tuple(leaves)] * mult)
            n_trees += 1
            if spans == right_tree_naive(tuple(leaves)):
                n_tree_ok += 1
        n_bbwt += 1
        n_multi += len(fac) > 1
        n_fact_ok += got == fac
    print(f"H1a BBWT columns: {n_bbwt} (with >1 Lyndon factor: {n_multi}); closed words in closing order == Lyndon factorisation: {n_fact_ok}; "
          f"closed trees == right Lyndon tree (naive): {n_tree_ok} of {n_trees}")
    # arbitrary columns
    n_cols = n_lyn = n_noninc = n_inv = 0; n_closed = 0; n_several = 0
    for _ in range(trials):
        n = rnd.randint(1, 14); sig = rnd.randint(1, 4)
        L = tuple(rnd.randrange(sig) for _ in range(n))
        cons = Cons()
        closed, steps, _ = induce(pieces_of_column(L), cons, 'right', leaf=lambda i, s: s)
        words = []
        all_lyn = True
        for tree, mult in closed:
            leaves, spans = cons.expand(tree)
            wd = tuple(leaves)
            n_closed += 1
            lyn = is_lyndon(wd) and spans == right_tree_naive(wd) if is_lyndon(wd) else False
            all_lyn &= lyn
            words.extend([wd] * mult)
        n_cols += 1
        n_several += len(words) > 1
        n_lyn += all_lyn
        n_noninc += all(words[i] >= words[i + 1] for i in range(len(words) - 1))
        n_inv += (sum(map(len, words)) == n and ebwt(words) == L)
    print(f"H1b arbitrary columns: {n_cols} (several cycles: {n_several}); every closed word Lyndon with its right Lyndon tree: {n_lyn}; "
          f"closing order non-increasing: {n_noninc}; eBWT(closed multiset) == column: {n_inv}; closed letters: {n_closed}")


# ----------------------------------------------------------------------------
# H2
# ----------------------------------------------------------------------------

def bwt_col(t):
    sa = rot_order(t)
    n = len(t)
    return tuple(t[(i - 1) % n] for i in sa), sa


def cmd_h2(seed=2, trials=20000):
    rnd = random.Random(seed)
    tot = okw = okt = okr = 0
    steps_l = steps_r = 0
    for _ in range(trials):
        n = rnd.randint(2, 16); sig = rnd.randint(2, 4)
        t = tuple(rnd.randrange(sig) for _ in range(n))
        if not is_primitive(t):
            continue
        L, sa = bwt_col(t)
        cons = Cons()
        closed, sl, _ = induce(pieces_of_column(L), cons, 'left', leaf=lambda i, s: s)
        assert len(closed) == 1 and closed[0][1] == 1
        leaves, spans = cons.expand(closed[0][0])
        greatest = max(t[i:] + t[:i] for i in range(n))
        inv = lex_lt_factory({c: -c for c in range(sig)})
        tot += 1
        okw += tuple(leaves) == greatest
        if tuple(leaves) == greatest:
            okt += spans == right_tree_naive(greatest, inv)
        cons2 = Cons()
        closed2, sr, _ = induce(pieces_of_column(L), cons2, 'right', leaf=lambda i, s: s)
        leaves2, spans2 = cons2.expand(closed2[0][0])
        okr += (tuple(leaves2) == least_rotation(t) and spans2 == right_tree_naive(tuple(leaves2)))
        steps_l += sl; steps_r += sr
    print(f"H2 primitive words: {tot}; left-end word == greatest rotation: {okw}; left-end tree == right Lyndon tree "
          f"(inverse order) of it: {okt}; [control] right-end tree == Lyndon tree of least rotation: {okr}; "
          f"steps left {steps_l}, right {steps_r}")


# ----------------------------------------------------------------------------
# H3
# ----------------------------------------------------------------------------

def setting(t):
    """V = least rotation of t, the run letter of each position of V, hinges."""
    n = len(t)
    sa_t = rot_order(t)
    st = sa_t[0]
    v = t[st:] + t[:st]
    sa = [(i - st) % n for i in sa_t]     # sa[x] = start of the x-th rotation of v; sa[0] == 0
    assert sa[0] == 0
    L = [v[(i - 1) % n] for i in sa]
    runid = [0] * n; starts = [False] * n
    rid = -1
    for x in range(n):
        if x == 0 or L[x] != L[x - 1]:
            rid += 1; starts[x] = True
        runid[x] = rid
    R = [0] * n
    for x, i in enumerate(sa):
        R[i] = x
    letter = [runid[R[(p + 1) % n]] for p in range(n)]    # the row that emits V[p]
    hinge = [starts[R[(p + 1) % n]] for p in range(n)]
    return v, L, R, letter, hinge, rid + 1


def digram_realizable(n, spans, letter, one_sided=False):
    """Can the tree `spans` over the cyclic word of run letters be built by steps that
    each replace ALL occurrences of one digram of current letters?  Greedy (monotone).
    one_sided: additionally one of the two letters must occur only inside the digram
    (what a step at a coincidence does; necessary, not sufficient, for such a step)."""
    cons = Cons()
    left_of = {}; right_of = {}; node = {}
    for (lo, mid, hi) in spans:
        node[(lo, hi)] = mid
    parent_pair = {}
    for (lo, mid, hi) in spans:
        parent_pair[((lo, mid), (mid, hi))] = (lo, hi)
    pieces = [(p, p + 1) for p in range(n)]
    typ = {(p, p + 1): cons.leaf(letter[p]) for p in range(n)}
    rounds = 0
    while len(pieces) > 1:
        occ = {}
        m = len(pieces)
        count = {}
        for pc in pieces:
            count[typ[pc]] = count.get(typ[pc], 0) + 1
        for i in range(m):
            P, Q = pieces[i], pieces[(i + 1) % m]
            d = (typ[P], typ[Q])
            good = (P, Q) in parent_pair and i + 1 < m
            o = occ.setdefault(d, [0, True, []])
            o[0] += 1; o[1] &= good; o[2].append(i)
        ready = [d for d, o in occ.items() if o[1]]
        if one_sided:
            ready = [d for d in ready if d[0] != d[1] and
                     (occ[d][0] == count[d[0]] or occ[d][0] == count[d[1]])]
        if not ready:
            return False, len(pieces), rounds
        rounds += 1
        # take every ready digram at once (they never share a piece: a piece has one parent)
        merge_at = set()
        for d in ready:
            merge_at.update(occ[d][2])
        newp = []
        i = 0
        while i < m:
            if i in merge_at:
                P, Q = pieces[i], pieces[i + 1]
                N = parent_pair[(P, Q)]
                typ[N] = cons.pair(typ[P], typ[Q])
                newp.append(N); i += 2
            else:
                newp.append(pieces[i]); i += 1
        pieces = newp
    return True, 1, rounds


def hinge_nodes(spans, hinge):
    n = len(hinge)
    pre = [0] * (n + 1)
    for p in range(n):
        pre[p + 1] = pre[p] + hinge[p]
    return sum(1 for (lo, mid, hi) in spans if pre[hi] > pre[lo])


def necklaces(n, sig):
    """Lyndon words of length n over range(sig) (one per primitive necklace)."""
    for t in itertools.product(range(sig), repeat=n):
        if is_lyndon(t):
            yield t


def cmd_h3(maxn2=14, maxn3=9):
    # exhaustive part
    for sig, maxn in ((2, maxn2), (3, maxn3), (4, 7)):
        tot = diff = real_l = real_l1 = real_r = real_r1 = 0
        first_fail = None; first_fail1 = None
        hl = hr = 0; less = more = same = 0
        s_mis = 0
        for n in range(2, maxn + 1):
            for t in necklaces(n, sig):
                v, L, R, letter, hinge, r = setting(t)
                rt = right_tree_naive(v); lt = left_tree_naive(v)
                assert lt == left_tree_bc(v)
                key = [R[j] for j in range(n)]
                assert rt == cartesian_spans(key, 0, n)
                tot += 1
                diff += rt != lt
                a = digram_realizable(n, lt, letter)[0]
                a1 = digram_realizable(n, lt, letter, one_sided=True)[0]
                b = digram_realizable(n, rt, letter)[0]
                b1 = digram_realizable(n, rt, letter, one_sided=True)[0]
                real_l += a; real_l1 += a1; real_r += b; real_r1 += b1
                if not a and first_fail is None:
                    first_fail = v
                if not a1 and first_fail1 is None:
                    first_fail1 = v
                cons = Cons()
                closed, S, _ = induce(pieces_of_column(tuple(L)), cons, 'right')
                x, y = hinge_nodes(lt, hinge), hinge_nodes(rt, hinge)
                s_mis += y != S
                hl += x; hr += y
                less += x < y; more += x > y; same += x == y
        print(f"H3 sigma={sig} n<={maxn}: Lyndon words {tot}; left tree != right tree: {diff}; "
              f"right tree digram-realizable {real_r} (one-sided {real_r1}); "
              f"LEFT tree digram-realizable {real_l} (one-sided {real_l1}); "
              f"first left failure {first_fail}; first one-sided failure {first_fail1}; "
              f"hinge nodes left {hl} right {hr} (left<right {less}, = {same}, > {more}); "
              f"right hinge nodes != S: {s_mis}")


def synth_texts(seed=7):
    rnd = random.Random(seed)
    out = {}
    # JSON-like records
    recs = []
    for i in range(1500):
        recs.append('{"id":"Q%d","type":"item","labels":{"en":{"language":"en","value":"%s"}},"claims":{"P31":[{"rank":"normal","id":"Q%d"}]}}\n'
                    % (rnd.randrange(10 ** 6), ''.join(rnd.choice('abcdefghij ') for _ in range(rnd.randint(4, 14))), rnd.randrange(5000)))
    out['json-like'] = ''.join(recs).encode()[:60000]
    # prose-like: a Markov chain of words
    words = [''.join(rnd.choice('etaoinshrdlu') for _ in range(rnd.randint(2, 8))) for _ in range(400)]
    out['words'] = ' '.join(rnd.choice(words) for _ in range(12000)).encode()[:60000]
    # this very script, repeated material
    try:
        out['python-source'] = open(__file__, 'rb').read()[:60000]
    except OSError:
        pass
    # Fibonacci word
    a, b = b'b', b'a'
    while len(b) < 20000:
        a, b = b, b + a
    out['fibonacci'] = b[:17711]
    return out


def cmd_h3big():
    for name, data in synth_texts().items():
        t = tuple(data)
        if not is_primitive(t[:1] * 1) or len(set(t)) < 2:
            pass
        v, L, R, letter, hinge, r = setting(t)
        n = len(v)
        lt = left_tree_bc(v)
        rt = cartesian_spans_fast(R, n)
        cons = Cons()
        closed, S, kinds = induce(pieces_of_column(tuple(L)), cons, 'right')
        x, y = hinge_nodes(lt, hinge), hinge_nodes(rt, hinge)
        a = digram_realizable(n, lt, letter)
        b = digram_realizable(n, rt, letter)
        same = len(set(lt) & set(rt))
        print(f"H3big {name}: n={n} r={r} r/n={r/n:.3f}; S(right-end induction)={S} ({S/r:.3f} r); "
              f"right-tree hinge nodes={y}; LEFT-tree hinge nodes={x} ({x/r:.3f} r); nodes shared by both trees={same} of {n-1}; "
              f"right tree digram-realizable={b[0]} (rounds {b[2]}); left tree digram-realizable={a[0]} (pieces left {a[1]}, rounds {a[2]})")


# ----------------------------------------------------------------------------
# H4: alternating order
# ----------------------------------------------------------------------------

def alt_omega_cmp(u, v):
    """u^omega against v^omega in the alternating order (odd positions usual, even reversed)."""
    lu, lv = len(u), len(v)
    for k in range(lu + lv):
        a, b = u[k % lu], v[k % lv]
        if a != b:
            lt = a < b
            if k % 2 == 1:        # position k+1 even: reversed
                lt = not lt
            return -1 if lt else 1
    return 0


def gen_omega_cmp_factory(rank_at):
    """generalized order: rank_at(k)(letter) is the letter's rank at position k (0-based)."""
    def cmp(u, v):
        lu, lv = len(u), len(v)
        for k in range(lu + lv):
            a, b = u[k % lu], v[k % lv]
            if a != b:
                return -1 if rank_at(k)[a] < rank_at(k)[b] else 1
        return 0
    return cmp


def is_gen_lyndon(w, cmp):
    return all(cmp(w, w[k:] + w[:k]) < 0 for k in range(1, len(w)))


def std_tree_gen(w, cmp):
    """recursive factorisation w = uv, v the longest proper suffix that is a generalized
    Lyndon word; returns (spans, ok) where ok is False if some u is not generalized Lyndon."""
    spans = []; ok = True
    def rec(lo, hi):
        nonlocal ok
        if hi - lo < 2:
            return
        for mid in range(lo + 1, hi):
            if is_gen_lyndon(w[mid:hi], cmp):
                break
        if not is_gen_lyndon(w[lo:mid], cmp):
            ok = False
        spans.append((lo, mid, hi))
        rec(lo, mid); rec(mid, hi)
    rec(0, len(w))
    return sorted(spans), ok


def cmd_h4(maxn2=13, maxn3=8):
    for sig, maxn in ((2, maxn2), (3, maxn3)):
        tot = flips = cart_all_galois = rec_ok = equal = equal_suf = 0
        first_bad = None; first_notgal = None; first_recbad = None
        for n in range(2, maxn + 1):
            for t in itertools.product(range(sig), repeat=n):
                if not is_gen_lyndon(t, alt_omega_cmp):
                    continue
                tot += 1
                rots = sorted(range(n), key=functools.cmp_to_key(
                    lambda i, j: alt_omega_cmp(t[i:] + t[:i], t[j:] + t[:j])))
                assert rots[0] == 0
                R = [0] * n
                for x, i in enumerate(rots):
                    R[i] = x
                # the alternating BWT's LF: translation with a flip on every run?
                Lc = [t[(i - 1) % n] for i in rots]
                pi = [R[(i - 1) % n] for i in rots]
                fl = True
                for x in range(1, n):
                    if Lc[x] == Lc[x - 1] and pi[x] != pi[x - 1] - 1:
                        fl = False
                flips += fl
                ct = cartesian_spans(R, 0, n)
                allg = all(is_gen_lyndon(t[lo:hi], alt_omega_cmp) for lo, mid, hi in ct)
                cart_all_galois += allg
                if not allg and first_notgal is None:
                    first_notgal = t
                st, ok = std_tree_gen(t, alt_omega_cmp)
                rec_ok += ok
                if not ok and first_recbad is None:
                    first_recbad = t
                equal += ct == st
                if ct != st and first_bad is None:
                    first_bad = (t, ct, st)
                # Cartesian tree of the ranks of the suffixes s by s^omega (shorter first on ties)
                sufs = sorted(range(1, n), key=functools.cmp_to_key(
                    lambda i, j: alt_omega_cmp(t[i:], t[j:]) or (j - i)))
                key = [0] * n
                for x, i in enumerate(sufs):
                    key[i] = x
                equal_suf += cartesian_spans(key, 0, n) == st
        print(f"H4 sigma={sig} n<={maxn}: Galois words {tot}; ABWT's LF reverses order on every run: {flips}; "
              f"Cartesian tree of alternating rotation ranks: every node a Galois word {cart_all_galois}, "
              f"== tree of 'longest proper Galois suffix' {equal}; that recursion well defined (prefix Galois) {rec_ok}; "
              f"Cartesian tree of suffix s^omega ranks == it {equal_suf}; "
              f"first Cartesian node not Galois: {first_notgal}; first recursion failure: {first_recbad}; first mismatch: {first_bad}")


# ----------------------------------------------------------------------------
# H5: the first letter's order permuted: still an exchange of the given LF
# ----------------------------------------------------------------------------

def exchange_in_order(t, order_rows):
    """LF of t's rotations with the rows listed in `order_rows` (start positions):
    pieces (length, image start, symbol) of the maximal translated intervals."""
    n = len(t)
    R = [0] * n
    for x, i in enumerate(order_rows):
        R[i] = x
    pi = [R[(i - 1) % n] for i in order_rows]
    pcs = []
    x = 0
    while x < n:
        y = x
        while (y + 1 < n and pi[y + 1] == pi[y] + 1 and
               t[(order_rows[y + 1] - 1) % n] == t[(order_rows[x] - 1) % n]):
            y += 1
        pcs.append((y - x + 1, pi[x], t[(order_rows[x] - 1) % n]))
        x = y + 1
    return pcs, R


def cmd_h5():
    rnd = random.Random(11)
    # (a) small: is the tree for the order (sigma at position 1, usual after) the
    #     standard-factorisation tree of the generalized Lyndon conjugate?
    tot = same_word = eq = recok = 0
    for _ in range(4000):
        n = rnd.randint(3, 12); sig = rnd.randint(2, 4)
        t = tuple(rnd.randrange(sig) for _ in range(n))
        if not is_primitive(t):
            continue
        perm = list(range(sig)); rnd.shuffle(perm)
        ident = list(range(sig))
        cmp = gen_omega_cmp_factory(lambda k: perm if k == 0 else ident)
        sa = rot_order(t)
        Rstd = [0] * n
        for x, i in enumerate(sa):
            Rstd[i] = x
        rows = sorted(range(n), key=lambda i: (perm[t[i]], Rstd[i]))
        rows2 = sorted(range(n), key=functools.cmp_to_key(lambda i, j: cmp(t[i:] + t[:i], t[j:] + t[:j])))
        assert rows == rows2
        pcs, R = exchange_in_order(t, rows)
        cons = Cons()
        closed, S, _ = induce(pcs, cons, 'right', leaf=lambda i, s: s)
        assert len(closed) == 1
        leaves, spans = cons.expand(closed[0][0])
        g = t[rows[0]:] + t[:rows[0]]
        tot += 1
        same_word += tuple(leaves) == g
        st, ok = std_tree_gen(g, cmp)
        recok += ok
        eq += spans == st
    print(f"H5a random primitive words {tot}, first letter's order permuted: induction's word == the generalized Lyndon conjugate {same_word}; "
          f"its tree == 'longest proper generalized-Lyndon suffix' tree {eq}; that recursion well defined {recok}")
    # (b) counts on larger inputs: usual order against a few first-letter orders
    for name, data in synth_texts().items():
        t = tuple(data); n = len(t)
        sa = rot_order(t)
        Rstd = [0] * n
        for x, i in enumerate(sa):
            Rstd[i] = x
        alph = sorted(set(t))
        freq = {c: 0 for c in alph}
        for c in t:
            freq[c] += 1
        orders = {
            'usual': {c: k for k, c in enumerate(alph)},
            'reversed': {c: -k for k, c in enumerate(alph)},
            'by frequency, rare first': {c: k for k, c in enumerate(sorted(alph, key=lambda c: freq[c]))},
            'by frequency, common first': {c: k for k, c in enumerate(sorted(alph, key=lambda c: -freq[c]))},
        }
        rr = random.Random(5)
        for k in range(3):
            sh = alph[:]; rr.shuffle(sh)
            orders[f'random {k}'] = {c: i for i, c in enumerate(sh)}
        res = []
        for oname, rank in orders.items():
            rows = sorted(range(n), key=lambda i: (rank[t[i]], Rstd[i]))
            pcs, R = exchange_in_order(t, rows)
            cons = Cons()
            closed, S, kinds = induce(pcs, cons, 'right', leaf=lambda i, s: s)
            assert len(closed) == 1 and cons.size[closed[0][0]] == n
            res.append((oname, len(pcs), S))
        r0 = res[0][1]
        print(f"H5b {name}: n={n}; " + "; ".join(f"{o}: letters {r} steps {S} ({S/r0:.3f} r_usual)" for o, r, S in res))


if __name__ == '__main__':
    cmd = sys.argv[1]
    {'h1': cmd_h1, 'h2': cmd_h2, 'h3': cmd_h3, 'h3big': cmd_h3big, 'h4': cmd_h4, 'h5': cmd_h5}[cmd]()
