#!/usr/bin/env python3
"""The circular rewriting of Reutenauer 2006, section 3.4 (Schutzenberger-Melancon):
a circular sequence of Hall words; a rise (h_i, h_{i+1}), h_i < h_{i+1}, is legal when
h_{i+1} >= every h_j; merge it.  Compared with the right Lyndon tree of the least rotation
(usual order) and with the standard-factorisation tree of the Galois conjugate (alternating
order); and the right-end induction's steps are checked to be such rises."""
import sys, random, functools, itertools
import lt


def flatten(tree):
    leaves, spans = [], []
    def rec(t, off):
        if not isinstance(t, tuple):
            leaves.append(t); return 1
        a = rec(t[0], off); b = rec(t[1], off + a)
        spans.append((off, off + a, off + a + b))
        return a + b
    rec(tree, 0)
    return tuple(leaves), sorted(spans)


def word(tree):
    return flatten(tree)[0]


def sm_rewrite(w, cmp, rnd):
    seq = list(w)                       # circular sequence of trees
    wd = [(c,) for c in w]
    while len(seq) > 1:
        m = len(seq)
        mx = max(wd, key=functools.cmp_to_key(cmp))
        legal = [i for i in range(m)
                 if cmp(wd[i], wd[(i + 1) % m]) < 0 and cmp(wd[(i + 1) % m], mx) == 0]
        if not legal:
            return None
        i = rnd.choice(legal)
        j = (i + 1) % m
        t = (seq[i], seq[j]); u = wd[i] + wd[j]
        if j == 0:                      # sigma' = (h_n h_1, h_2, ..., h_{n-1})
            seq = [t] + seq[1:m - 1]; wd = [u] + wd[1:m - 1]
        else:
            seq = seq[:i] + [t] + seq[j + 1:]; wd = wd[:i] + [u] + wd[j + 1:]
    return seq[0]


def run_sm():
    rnd = random.Random(3)
    tot = ok = stuck = 0
    for sig, maxn in ((2, 12), (3, 8)):
        for n in range(2, maxn + 1):
            for t in itertools.product(range(sig), repeat=n):
                if not lt.is_primitive(t):
                    continue
                tree = sm_rewrite(t, lt.omega_cmp, rnd)
                tot += 1
                if tree is None:
                    stuck += 1; continue
                wd, spans = flatten(tree)
                v = lt.least_rotation(t)
                ok += (wd == v and spans == lt.right_tree_naive(v))
    print(f"SM usual order: primitive words {tot}; stuck {stuck}; result == least rotation with its right Lyndon tree: {ok}")
    tot = ok = stuck = 0
    for sig, maxn in ((2, 12), (3, 8)):
        for n in range(2, maxn + 1):
            for t in itertools.product(range(sig), repeat=n):
                if not lt.is_primitive(t):
                    continue
                tree = sm_rewrite(t, lt.alt_omega_cmp, rnd)
                tot += 1
                if tree is None:
                    stuck += 1; continue
                wd, spans = flatten(tree)
                g = min((t[i:] + t[:i] for i in range(n)), key=functools.cmp_to_key(lt.alt_omega_cmp))
                st, okrec = lt.std_tree_gen(g, lt.alt_omega_cmp)
                ok += (wd == g and spans == st)
    print(f"SM alternating order: primitive words {tot}; stuck {stuck}; result == Galois conjugate with its standard-factorisation tree: {ok}")


def induction_is_sm(trials=4000):
    """right-end induction on a BWT column: is every step a legal rise?"""
    rnd = random.Random(4)
    steps = legal = rise = 0; words = 0
    for _ in range(trials):
        n = rnd.randint(2, 14); sig = rnd.randint(2, 4)
        t = tuple(rnd.randrange(sig) for _ in range(n))
        if not lt.is_primitive(t):
            continue
        words += 1
        L, sa = lt.bwt_col(t)
        pcs = lt.pieces_of_column(L)
        r = len(pcs)
        lam = [p[0] for p in pcs]
        w = [(p[2],) for p in pcs]
        top = list(range(r))
        bot = sorted(range(r), key=lambda i: pcs[i][1])
        while True:
            A, B = top[-1], bot[-1]
            if A == B:
                break
            steps += 1
            cur = [w[x] for x in top]
            mx = max(cur, key=functools.cmp_to_key(lt.omega_cmp))
            rise += lt.omega_cmp(w[A], w[B]) < 0
            legal += (lt.omega_cmp(w[A], w[B]) < 0 and lt.omega_cmp(w[B], mx) == 0)
            N = w[A] + w[B]
            if lam[A] > lam[B]:
                lam[A] -= lam[B]; w[B] = N
                bot.pop(); bot.insert(bot.index(A) + 1, B)
            elif lam[A] < lam[B]:
                lam[B] -= lam[A]; w[A] = N
                top.pop(); top.insert(top.index(B) + 1, A)
            else:
                w[B] = N
                bot.pop(); bot[bot.index(A)] = B
                top.pop()
    print(f"right-end induction, {words} primitive words: steps {steps}; w_A < w_B (a rise) {rise}; "
          f"and w_B a largest current word (a legal rise) {legal}")


if __name__ == '__main__':
    run_sm()
    induction_is_sm()
