#!/usr/bin/env python3
"""Controls: (1) the H4 harness with the usual order must give 100% everywhere;
(2) the prefix standard permutation (Dolce-Restivo-Reutenauer) of a Lyndon word:
its decreasing tree is the left Lyndon tree; it is the left-to-right postorder
(Badkobeh-Crochemore Thm 6); it avoids the pattern 231."""
import functools, itertools
import lt


def prec_cmp(u, v):
    c = lt.omega_cmp(u, v)
    if c:
        return c
    return (len(v) > len(u)) - (len(v) < len(u))      # the longer one is smaller


def controls():
    tot = a = b = c = 0
    for sig, maxn in ((2, 12), (3, 8)):
        for n in range(2, maxn + 1):
            for t in lt.necklaces(n, sig):
                tot += 1
                rots = sorted(range(n), key=lambda i: t[i:] + t[:i])
                R = [0] * n
                for x, i in enumerate(rots):
                    R[i] = x
                ct = lt.cartesian_spans(R, 0, n)
                st, ok = lt.std_tree_gen(t, lt.omega_cmp)
                a += ct == st and ok
                b += st == lt.right_tree_naive(t)
                sufs = sorted(range(1, n), key=functools.cmp_to_key(
                    lambda i, j: lt.omega_cmp(t[i:], t[j:]) or (j - i)))
                key = [0] * n
                for x, i in enumerate(sufs):
                    key[i] = x
                c += lt.cartesian_spans(key, 0, n) == st
    print(f"control, usual order: Lyndon words {tot}; Cartesian(rotation ranks) == standard tree {a}; "
          f"== right Lyndon tree {b}; Cartesian(suffix s^omega ranks) == it {c}")


def psp():
    tot = tree_ok = post_ok = avoid = 0
    for sig, maxn in ((2, 13), (3, 9)):
        for n in range(2, maxn + 1):
            for t in lt.necklaces(n, sig):
                tot += 1
                order = sorted(range(1, n), key=functools.cmp_to_key(
                    lambda i, j: prec_cmp(t[:i], t[:j])))
                rank = [0] * (n + 1)
                for x, i in enumerate(order):
                    rank[i] = x                      # junction i <-> prefix of length i
                ct = lt.cartesian_spans(rank, 0, n, smallest=False)
                ltree = lt.left_tree_naive(t)
                tree_ok += ct == ltree
                # left-to-right postorder index of each node of the left tree
                kids = {(lo, hi): mid for lo, mid, hi in ltree}
                post = {}
                def rec(lo, hi):
                    if hi - lo < 2:
                        return
                    mid = kids[(lo, hi)]
                    rec(lo, mid); rec(mid, hi)
                    post[mid] = len(post)
                rec(0, n)
                post_ok += all(post[j] == rank[j] for j in range(1, n))
                seq = rank[1:n]
                bad = False
                for i in range(len(seq)):
                    mx = -1
                    for j in range(i + 1, len(seq)):
                        if seq[j] > seq[i]:
                            mx = max(mx, seq[j])
                        elif mx > seq[i] and seq[j] < seq[i]:
                            bad = True
                avoid += not bad
    print(f"prefix standard permutation: Lyndon words {tot}; decreasing Cartesian tree == left Lyndon tree {tree_ok}; "
          f"rank == left-to-right postorder index {post_ok}; avoids 231 {avoid}")


if __name__ == '__main__':
    controls(); psp()
