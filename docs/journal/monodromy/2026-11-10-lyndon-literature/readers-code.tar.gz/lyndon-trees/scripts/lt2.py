#!/usr/bin/env python3
"""Incremental version of lt.digram_realizable, and the larger H3 runs."""
import sys, random
import lt


def digram_fast(n, spans, letter, one_sided=False):
    """Same question as lt.digram_realizable, by a worklist in synchronous rounds.
    Returns (realizable, pieces left, rounds, steps, steps that were two-sided)."""
    cons = lt.Cons()
    idx = {}
    for k, (lo, mid, hi) in enumerate(spans):
        idx[(lo, hi)] = n + k
    def pid(lo, hi):
        return lo if hi - lo == 1 else idx[(lo, hi)]
    m = n + len(spans)
    par = [-1] * m; isleft = [False] * m
    for k, (lo, mid, hi) in enumerate(spans):
        a, b = pid(lo, mid), pid(mid, hi)
        par[a] = n + k; isleft[a] = True
        par[b] = n + k
    typ = [0] * m
    for p in range(n):
        typ[p] = cons.leaf(letter[p])
    nxt = [(p + 1) % n for p in range(n)] + [0] * (m - n)
    prv = [(p - 1) % n for p in range(n)] + [0] * (m - n)
    count = {}
    for p in range(n):
        count[typ[p]] = count.get(typ[p], 0) + 1
    occ = {}; bad = {}; bytype = {}
    def good(P, Q):
        return par[P] == par[Q] and par[P] >= 0 and isleft[P] and not isleft[Q]
    def add(P):
        Q = nxt[P]
        d = (typ[P], typ[Q])
        s = occ.get(d)
        if s is None:
            s = occ[d] = set(); bad[d] = 0
            bytype.setdefault(d[0], set()).add(d); bytype.setdefault(d[1], set()).add(d)
        s.add(P)
        if not good(P, Q):
            bad[d] += 1
        return d
    def rem(P):
        Q = nxt[P]
        d = (typ[P], typ[Q])
        occ[d].discard(P)
        if not good(P, Q):
            bad[d] -= 1
        return d
    def is_ready(d):
        s = occ.get(d)
        if not s or bad[d]:
            return False
        if one_sided:
            return d[0] != d[1] and (len(s) == count[d[0]] or len(s) == count[d[1]])
        return True
    for p in range(n):
        add(p)
    npieces = n
    ready = [d for d in occ if is_ready(d)]
    rounds = steps = two_sided = 0
    while ready and npieces > 1:
        rounds += 1
        touched = set()
        for d in ready:
            if not is_ready(d):
                continue
            steps += 1
            if not (d[0] != d[1] and (len(occ[d]) == count[d[0]] or len(occ[d]) == count[d[1]])):
                two_sided += 1
            for P in list(occ[d]):
                Q = nxt[P]
                N = par[P]
                if npieces == 2:
                    npieces = 1
                    break
                X, Y = prv[P], nxt[Q]
                touched.add(rem(X)); rem(P); touched.add(rem(Q))
                typ[N] = cons.pair(typ[P], typ[Q])
                count[typ[P]] -= 1; count[typ[Q]] -= 1
                count[typ[N]] = count.get(typ[N], 0) + 1
                nxt[X] = N; prv[N] = X; nxt[N] = Y; prv[Y] = N
                npieces -= 1
                touched.add(add(X)); touched.add(add(N))
            touched.update(bytype.get(d[0], ())); touched.update(bytype.get(d[1], ()))
        ready = [d for d in touched if is_ready(d)]
    return npieces == 1, npieces, rounds, steps, two_sided


def check_small():
    bad = 0; tot = 0
    for sig, maxn in ((2, 12), (3, 8)):
        for n in range(2, maxn + 1):
            for t in lt.necklaces(n, sig):
                v, L, R, letter, hinge, r = lt.setting(t)
                for tree in (lt.right_tree_naive(v), lt.left_tree_naive(v)):
                    for os_ in (False, True):
                        a = lt.digram_realizable(n, tree, letter, one_sided=os_)[0]
                        b = digram_fast(n, tree, letter, one_sided=os_)[0]
                        tot += 1; bad += a != b
    print(f"fast vs slow realizability: {tot} cases, {bad} disagreements")


def depth(spans, n):
    """height of the tree in internal nodes."""
    d = {}
    for lo, mid, hi in sorted(spans, key=lambda s: s[2] - s[0]):
        d[(lo, hi)] = 1 + max(d.get((lo, mid), 0), d.get((mid, hi), 0))
    return d[(0, n)]


def big(limit=None):
    for name, data in lt.synth_texts().items():
        t = tuple(data[:limit] if limit else data)
        v, L, R, letter, hinge, r = lt.setting(t)
        n = len(v)
        ltree = lt.left_tree_bc(v)
        rtree = lt.cartesian_spans_fast(R, n)
        cons = lt.Cons()
        closed, S, kinds = lt.induce(lt.pieces_of_column(tuple(L)), cons, 'right')
        x, y = lt.hinge_nodes(ltree, hinge), lt.hinge_nodes(rtree, hinge)
        b = digram_fast(n, rtree, letter); b1 = digram_fast(n, rtree, letter, True)
        a = digram_fast(n, ltree, letter); a1 = digram_fast(n, ltree, letter, True)
        same = len(set(ltree) & set(rtree))
        lynpref = sum(1 for lo, mid, hi in ltree if lo == 0)
        print(f"H3big {name}: n={n} r={r} r/n={r/n:.3f}; S(right-end induction)={S} ({S/r:.3f} r); "
              f"right-tree hinge nodes={y}; LEFT-tree hinge nodes={x} ({x/r:.3f} r, {x/n:.3f} n); "
              f"nodes shared={same} of {n-1}; height right {depth(rtree, n)} left {depth(ltree, n)}; proper Lyndon prefixes of V={lynpref}; "
              f"right tree: digram steps ok={b[0]} rounds={b[2]} steps={b[3]} two-sided={b[4]}; one-sided only ok={b1[0]}; "
              f"LEFT tree: digram steps ok={a[0]} pieces left={a[1]} rounds={a[2]} steps={a[3]} two-sided={a[4]}; "
              f"one-sided only ok={a1[0]} pieces left={a1[1]} steps done={a1[3]}", flush=True)


if __name__ == '__main__':
    if sys.argv[1] == 'check':
        check_small()
    else:
        big(int(sys.argv[2]) if len(sys.argv) > 2 else None)
