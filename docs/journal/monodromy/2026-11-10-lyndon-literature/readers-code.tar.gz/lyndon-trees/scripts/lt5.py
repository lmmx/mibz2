#!/usr/bin/env python3
"""lt2.big on files given on the command line (first 40,000 bytes of each)."""
import sys
import lt, lt2

for path in sys.argv[1:]:
    data = open(path, 'rb').read()[:40000]
    t = tuple(data)
    v, L, R, letter, hinge, r = lt.setting(t)
    n = len(v)
    ltree = lt.left_tree_bc(v)
    rtree = lt.cartesian_spans_fast(R, n)
    cons = lt.Cons()
    closed, S, kinds = lt.induce(lt.pieces_of_column(tuple(L)), cons, 'right')
    x, y = lt.hinge_nodes(ltree, hinge), lt.hinge_nodes(rtree, hinge)
    a = lt2.digram_fast(n, ltree, letter); a1 = lt2.digram_fast(n, ltree, letter, True)
    b1 = lt2.digram_fast(n, rtree, letter, True)
    lynpref = sum(1 for lo, mid, hi in ltree if lo == 0)
    print(f"{path}: n={n} r={r} r/n={r/n:.3f}; S={S} ({S/r:.3f} r) = right-tree hinge nodes {y}; "
          f"LEFT-tree hinge nodes={x} ({x/r:.3f} r, {x/n:.3f} n); Lyndon prefixes of V={lynpref}; "
          f"left tree by digram steps (two-sided allowed) ok={a[0]} steps={a[3]} two-sided={a[4]}; "
          f"by one-sided steps only ok={a1[0]} (pieces left {a1[1]}); right tree one-sided ok={b1[0]}")
