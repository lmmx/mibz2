
/home/louis/dev/mibz2/target/c30-construction-pin/target/rust-1.97.0/release/examples/c30walk:     file format elf64-x86-64


Disassembly of section .text:

000000000005fe90 <c30walk::cbuild::c_build>:
c30walk::cbuild::c_build:
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/cbuild.rs:90
   5fe90:	push   %rax
   5fe91:	mov    %r8,%rax
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/cbuild.rs:97
   5fe94:	mov    %r9,(%rsp)
   5fe98:	xor    %r8d,%r8d
   5fe9b:	mov    %rax,%r9
   5fe9e:	call   148b0 <<c30walk::ctor::Ctor>::build::<false>>
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/cbuild.rs:98
   5fea3:	pop    %rcx
   5fea4:	ret
