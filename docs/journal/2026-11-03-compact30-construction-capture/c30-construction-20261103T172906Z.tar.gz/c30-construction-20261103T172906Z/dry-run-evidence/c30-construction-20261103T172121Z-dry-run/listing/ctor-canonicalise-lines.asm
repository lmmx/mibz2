
/home/louis/dev/mibz2/target/c30-construction-pin/target/rust-1.97.0/release/examples/c30walk:     file format elf64-x86-64


Disassembly of section .text:

0000000000049830 <c30walk::ctor::canonicalise>:
c30walk::ctor::canonicalise:
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:660
   49830:	push   %r15
   49832:	push   %r14
   49834:	push   %r13
   49836:	push   %r12
   49838:	push   %rbx
   49839:	sub    $0x10,%rsp
   4983d:	xor    %r11d,%r11d
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/non_null.rs:1714
   49840:	test   %rcx,%rcx
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/iter/macros.rs:180
   49843:	je     498d9 <c30walk::ctor::canonicalise+0xa9>
   49849:	lea    (%rdx,%rcx,8),%rcx
   4984d:	xor    %r10d,%r10d
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:664
   49850:	jmp    4986c <c30walk::ctor::canonicalise+0x3c>
   49852:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
next<core::slice::iter::Iter<u64>>():
   49860:	add    $0x8,%rdx
   49864:	inc    %r10
eq<u64>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/non_null.rs:1714
   49867:	cmp    %rcx,%rdx
next<u64>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/iter/macros.rs:180
   4986a:	je     498d6 <c30walk::ctor::canonicalise+0xa6>
c30walk::ctor::canonicalise:
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:662
   4986c:	mov    (%rdx),%rbx
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:664
   4986f:	test   %rbx,%rbx
   49872:	je     49860 <c30walk::ctor::canonicalise+0x30>
   49874:	mov    %r10,%r14
   49877:	shl    $0xc,%r14
   4987b:	add    %rsi,%r14
   4987e:	mov    %r11d,%r15d
   49881:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/num/uint_macros.rs:178
   49890:	tzcnt  %rbx,%r12
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mut_ptr.rs:961
   49895:	shl    $0x6,%r12d
add<c30walk::Rec>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mut_ptr.rs:961
   49899:	mov    0x3c(%r14,%r12,1),%eax
c30walk::ctor::canonicalise:
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:668
   4989e:	and    $0xfffff,%eax
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:670
   498a3:	cmp    %rax,%r9
   498a6:	jbe    49b11 <c30walk::ctor::canonicalise+0x2e1>
   498ac:	add    %r14,%r12
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:666
   498af:	lea    -0x1(%rbx),%r13
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:670
   498b3:	shl    $0x7,%eax
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:672
   498b6:	lea    0x1(%r15),%r11d
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:670
   498ba:	mov    %r15d,0x7c(%r8,%rax,1)
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:671
   498bf:	mov    %r15d,%eax
   498c2:	or     $0x10000000,%eax
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mod.rs:1933
   498c7:	mov    %eax,0x3c(%r12)
write<u32>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mod.rs:1933
   498cc:	mov    %r11d,%r15d
c30walk::ctor::canonicalise:
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:664
   498cf:	and    %r13,%rbx
   498d2:	jne    49890 <c30walk::ctor::canonicalise+0x60>
   498d4:	jmp    49860 <c30walk::ctor::canonicalise+0x30>
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:675
   498d6:	mov    %r11d,%r11d
   498d9:	mov    %r11,(%rsp)
   498dd:	mov    %r9,0x8(%rsp)
   498e2:	cmp    %r11,%r9
   498e5:	jne    49af1 <c30walk::ctor::canonicalise+0x2c1>
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:677
   498eb:	lea    -0x80(%r8),%r10
   498ef:	xor    %r11d,%r11d
   498f2:	xor    %ecx,%ecx
   498f4:	xor    %edx,%edx
   498f6:	xor    %esi,%esi
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/iter/range.rs:900
   498f8:	mov    %r11,%rax
spec_next<usize>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/iter/range.rs:900
   498fb:	shl    $0x7,%rax
   498ff:	add    %r10,%rax
   49902:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
c30walk::ctor::canonicalise:
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/cmp.rs:1916
   49910:	cmp    %r9,%r11
spec_next<usize>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/iter/range.rs:900
   49913:	jae    49a1c <c30walk::ctor::canonicalise+0x1ec>
c30walk::ctor::canonicalise:
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:677
   49919:	mov    %r11,%rbx
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/num/uint_macros.rs:971
   4991c:	inc    %r11
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:678
   4991f:	mov    0xfc(%rax),%r14d
   49926:	sub    $0xffffffffffffff80,%rax
   4992a:	cmp    %r14,%rbx
   4992d:	je     49910 <c30walk::ctor::canonicalise+0xe0>
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:683
   4992f:	movaps (%rax),%xmm0
   49932:	movaps 0x10(%rax),%xmm1
   49936:	movaps 0x20(%rax),%xmm2
   4993a:	movaps 0x30(%rax),%xmm3
   4993e:	movaps 0x40(%rax),%xmm4
   49942:	movaps 0x50(%rax),%xmm5
   49946:	movaps 0x60(%rax),%xmm6
   4994a:	movdqa 0x70(%rax),%xmm7
   4994f:	xor    %r14d,%r14d
   49952:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:686
   49960:	pshufd $0xee,%xmm7,%xmm8
   49966:	movq   %xmm8,%rax
   4996b:	shr    $0x20,%rax
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:687
   4996f:	cmp    %rax,%r9
   49972:	jbe    49b23 <c30walk::ctor::canonicalise+0x2f3>
   49978:	mov    %rax,%r15
   4997b:	shl    $0x7,%r15
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mod.rs:1451
   4997f:	movaps (%r8,%r15,1),%xmm8
swap_chunk<8>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mod.rs:1451
   49984:	movaps 0x10(%r8,%r15,1),%xmm9
   4998a:	movaps 0x20(%r8,%r15,1),%xmm10
   49990:	movaps 0x30(%r8,%r15,1),%xmm11
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mod.rs:1453
   49996:	movaps %xmm0,(%r8,%r15,1)
   4999b:	movaps %xmm1,0x10(%r8,%r15,1)
   499a1:	movaps %xmm2,0x20(%r8,%r15,1)
   499a7:	movaps %xmm3,0x30(%r8,%r15,1)
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mod.rs:1451
   499ad:	movaps 0x40(%r8,%r15,1),%xmm12
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mod.rs:1453
   499b3:	movaps %xmm4,0x40(%r8,%r15,1)
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mod.rs:1451
   499b9:	movaps 0x50(%r8,%r15,1),%xmm13
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mod.rs:1453
   499bf:	movaps %xmm5,0x50(%r8,%r15,1)
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mod.rs:1451
   499c5:	movaps 0x60(%r8,%r15,1),%xmm14
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mod.rs:1453
   499cb:	movaps %xmm6,0x60(%r8,%r15,1)
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mod.rs:1451
   499d1:	movaps 0x70(%r8,%r15,1),%xmm15
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mod.rs:1453
   499d7:	movdqa %xmm7,0x70(%r8,%r15,1)
c30walk::ctor::canonicalise:
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:688
   499de:	inc    %r14
   499e1:	movaps %xmm8,%xmm0
   499e5:	movaps %xmm9,%xmm1
   499e9:	movaps %xmm10,%xmm2
   499ed:	movaps %xmm11,%xmm3
   499f1:	movaps %xmm12,%xmm4
   499f5:	movaps %xmm13,%xmm5
   499f9:	movaps %xmm14,%xmm6
   499fd:	movaps %xmm15,%xmm7
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:689
   49a01:	cmp    %rax,%rbx
   49a04:	jne    49960 <c30walk::ctor::canonicalise+0x130>
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:693
   49a0a:	add    %r14,%rcx
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:694
   49a0d:	inc    %rdx
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/cmp.rs:1038
   49a10:	cmp    %rsi,%r14
max<u64>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/cmp.rs:1038
   49a13:	cmova  %r14,%rsi
c30walk::ctor::canonicalise:
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:677
   49a17:	jmp    498f8 <c30walk::ctor::canonicalise+0xc8>
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/non_null.rs:1714
   49a1c:	test   %r9,%r9
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/iter/macros.rs:180
   49a1f:	je     49ad8 <c30walk::ctor::canonicalise+0x2a8>
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:697
   49a25:	shl    $0x7,%r9
next<c30walk::RawG>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/iter/macros.rs:180
   49a29:	lea    -0x80(%r9),%r10
   49a2d:	mov    %r10d,%r11d
   49a30:	not    %r11d
   49a33:	mov    %r8,%rax
   49a36:	test   $0x380,%r11d
   49a3d:	je     49a79 <c30walk::ctor::canonicalise+0x249>
   49a3f:	mov    %r10d,%r11d
   49a42:	shr    $0x7,%r11d
   49a46:	inc    %r11d
   49a49:	and    $0x7,%r11d
   49a4d:	neg    %r11
   49a50:	mov    %r8,%rax
c30walk::ctor::canonicalise:
   49a53:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:699
   49a60:	movl   $0x0,0x7c(%rax)
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/non_null.rs:656
   49a67:	sub    $0xffffffffffffff80,%rax
next<c30walk::RawG>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/iter/macros.rs:180
   49a6b:	inc    %r11
   49a6e:	jne    49a60 <c30walk::ctor::canonicalise+0x230>
   49a70:	cmp    $0x380,%r10
   49a77:	jb     49ad8 <c30walk::ctor::canonicalise+0x2a8>
c30walk::ctor::canonicalise:
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:697
   49a79:	add    %r9,%r8
   49a7c:	nopl   0x0(%rax)
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:699
   49a80:	movl   $0x0,0x7c(%rax)
   49a87:	movl   $0x0,0xfc(%rax)
   49a91:	movl   $0x0,0x17c(%rax)
   49a9b:	movl   $0x0,0x1fc(%rax)
   49aa5:	movl   $0x0,0x27c(%rax)
   49aaf:	movl   $0x0,0x2fc(%rax)
   49ab9:	movl   $0x0,0x37c(%rax)
   49ac3:	movl   $0x0,0x3fc(%rax)
add<c30walk::RawG>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/non_null.rs:656
   49acd:	add    $0x400,%rax
eq<c30walk::RawG>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/non_null.rs:1714
   49ad3:	cmp    %r8,%rax
next<c30walk::RawG>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/iter/macros.rs:180
   49ad6:	jne    49a80 <c30walk::ctor::canonicalise+0x250>
c30walk::ctor::canonicalise:
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:701
   49ad8:	mov    %rcx,(%rdi)
   49adb:	mov    %rdx,0x8(%rdi)
   49adf:	mov    %rsi,0x10(%rdi)
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:702
   49ae3:	add    $0x10,%rsp
   49ae7:	pop    %rbx
   49ae8:	pop    %r12
   49aea:	pop    %r13
   49aec:	pop    %r14
   49aee:	pop    %r15
   49af0:	ret
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:675
   49af1:	lea    0x7acb1(%rip),%rdx        # c47a9 <_fini+0x7eed>
   49af8:	lea    0x962e9(%rip),%r8        # dfde8 <__do_global_dtors_aux_fini_array_entry+0x1c90>
   49aff:	mov    %rsp,%rdi
   49b02:	lea    0x8(%rsp),%rsi
   49b07:	mov    $0x33,%ecx
   49b0c:	call   9d67 <core::panicking::assert_failed::<usize, usize>>
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:670
   49b11:	lea    0x96300(%rip),%rdx        # dfe18 <__do_global_dtors_aux_fini_array_entry+0x1cc0>
   49b18:	mov    %rax,%rdi
   49b1b:	mov    %r9,%rsi
   49b1e:	call   9d2b <core::panicking::panic_bounds_check>
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:687
   49b23:	lea    0x962d6(%rip),%rdx        # dfe00 <__do_global_dtors_aux_fini_array_entry+0x1ca8>
   49b2a:	mov    %rax,%rdi
   49b2d:	mov    %r9,%rsi
   49b30:	call   9d2b <core::panicking::panic_bounds_check>
