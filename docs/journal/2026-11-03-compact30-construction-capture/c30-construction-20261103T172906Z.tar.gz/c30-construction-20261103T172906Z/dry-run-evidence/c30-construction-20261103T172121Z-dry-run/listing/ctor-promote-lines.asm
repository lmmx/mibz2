
/home/louis/dev/mibz2/target/c30-construction-pin/target/rust-1.97.0/release/examples/c30walk:     file format elf64-x86-64


Disassembly of section .text:

0000000000008a10 <<c30walk::ctor::W<false>>::promote>:
<c30walk::ctor::W<false>>::promote:
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:383
    8a10:	push   %rbp
    8a11:	push   %r15
    8a13:	push   %r14
    8a15:	push   %r13
    8a17:	push   %r12
    8a19:	push   %rbx
    8a1a:	sub    $0x18,%rsp
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:389
    8a1e:	mov    (%rdi),%rbx
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:344
    8a21:	mov    0x20(%rdi),%r14
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mut_ptr.rs:961
    8a25:	mov    %rsi,%r15
add<c30walk::Rec>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mut_ptr.rs:961
    8a28:	shl    $0x6,%r15
<c30walk::ctor::W<false>>::promote:
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/alloc/src/vec/mod.rs:3054
    8a2c:	mov    0x10(%rbx),%rax
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/alloc/src/vec/mod.rs:1040
    8a30:	cmp    (%rbx),%rax
push_mut<c30walk::RawG, alloc::alloc::Global>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/alloc/src/vec/mod.rs:1040
    8a33:	je     8beb <<c30walk::ctor::W<false>>::promote+0x1db>
<c30walk::ctor::W<false>>::promote:
    8a39:	lea    (%r14,%r15,1),%r8
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/alloc/src/raw_vec/mod.rs:614
    8a3d:	mov    0x8(%rbx),%r9
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mut_ptr.rs:961
    8a41:	mov    %rax,%r10
add<c30walk::RawG>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mut_ptr.rs:961
    8a44:	shl    $0x7,%r10
<c30walk::ctor::W<false>>::promote:
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mod.rs:1933
    8a48:	pxor   %xmm0,%xmm0
write<c30walk::RawG>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mod.rs:1933
    8a4c:	movdqa %xmm0,0x70(%r9,%r10,1)
    8a53:	movdqa %xmm0,0x60(%r9,%r10,1)
    8a5a:	movdqa %xmm0,0x50(%r9,%r10,1)
    8a61:	movdqa %xmm0,0x40(%r9,%r10,1)
    8a68:	movdqa %xmm0,0x30(%r9,%r10,1)
    8a6f:	movdqa %xmm0,0x20(%r9,%r10,1)
    8a76:	movdqa %xmm0,0x10(%r9,%r10,1)
    8a7d:	movdqa %xmm0,(%r9,%r10,1)
push_mut<c30walk::RawG, alloc::alloc::Global>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/alloc/src/vec/mod.rs:1046
    8a83:	mov    %rax,%r9
    8a86:	inc    %r9
    8a89:	mov    %r9,0x10(%rbx)
<c30walk::ctor::W<false>>::promote:
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:394
    8a8d:	mov    %eax,%r12d
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/alloc/src/raw_vec/mod.rs:614
    8a90:	mov    0x8(%rbx),%rbx
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/index.rs:278
    8a94:	shl    $0x7,%r12
index_mut<c30walk::RawG>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/index.rs:278
    8a98:	lea    (%rbx,%r12,1),%r9
<c30walk::ctor::W<false>>::promote:
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mut_ptr.rs:961
    8a9c:	lea    (%r9,%rdx,4),%r10
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/iter/macros.rs:180
    8aa0:	lea    -0x4(,%rdx,4),%r11
next<u32>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/iter/macros.rs:180
    8aa8:	cmp    $0x3c,%r11
    8aac:	jb     8ad9 <<c30walk::ctor::W<false>>::promote+0xc9>
<c30walk::ctor::W<false>>::promote:
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:395
    8aae:	shl    $0x2,%rdx
next<u32>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/iter/macros.rs:180
    8ab2:	add    $0xfffffffffffffffc,%rdx
    8ab6:	shr    $1,%rdx
    8ab9:	add    %r14,%rdx
    8abc:	add    %r15,%rdx
    8abf:	add    $0x2,%rdx
    8ac3:	cmp    %rdx,%r9
    8ac6:	setb   %dl
    8ac9:	cmp    %r10,%r8
    8acc:	setb   %bpl
<c30walk::ctor::W<false>>::promote:
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/iter/adapters/enumerate.rs:82
    8ad0:	test   %bpl,%dl
next<core::slice::iter::IterMut<u32>>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/iter/adapters/enumerate.rs:82
    8ad3:	je     8b65 <<c30walk::ctor::W<false>>::promote+0x155>
    8ad9:	xor    %edx,%edx
next<u32>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/iter/macros.rs:180
    8adb:	lea    (%r15,%rdx,2),%rdx
    8adf:	add    %rdx,%r14
<c30walk::ctor::W<false>>::promote:
    8ae2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
read<u16>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mod.rs:1733
    8af0:	movzwl (%r14),%edx
<c30walk::ctor::W<false>>::promote:
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:396
    8af4:	shl    $0x8,%edx
    8af7:	add    %ecx,%edx
    8af9:	mov    %edx,(%r9)
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/non_null.rs:656
    8afc:	add    $0x4,%r9
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/non_null.rs:1714
    8b00:	add    $0x2,%r14
eq<u32>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/non_null.rs:1714
    8b04:	cmp    %r10,%r9
next<u32>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/iter/macros.rs:180
    8b07:	jne    8af0 <<c30walk::ctor::W<false>>::promote+0xe0>
<c30walk::ctor::W<false>>::promote:
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:401
    8b09:	mov    %eax,%ecx
    8b0b:	or     $0x10000000,%ecx
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mod.rs:1933
    8b11:	pcmpeqd %xmm0,%xmm0
write<c30walk::Rec>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mod.rs:1933
    8b15:	movdqu %xmm0,0x2c(%r8)
    8b1b:	movdqa %xmm0,0x20(%r8)
    8b21:	movdqa %xmm0,0x10(%r8)
    8b27:	movdqa %xmm0,(%r8)
    8b2c:	mov    %ecx,0x3c(%r8)
<c30walk::ctor::W<false>>::promote:
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:403
    8b30:	mov    %rsi,%r8
    8b33:	shr    $0x6,%r8
    8b37:	mov    0x10(%rdi),%rcx
    8b3b:	cmp    %rcx,%r8
    8b3e:	jae    8c1c <<c30walk::ctor::W<false>>::promote+0x20c>
    8b44:	mov    $0x1,%edx
    8b49:	mov    %esi,%ecx
    8b4b:	shl    %cl,%rdx
    8b4e:	mov    0x8(%rdi),%rcx
    8b52:	or     %rdx,(%rcx,%r8,8)
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:414
    8b56:	add    $0x18,%rsp
    8b5a:	pop    %rbx
    8b5b:	pop    %r12
    8b5d:	pop    %r13
    8b5f:	pop    %r14
    8b61:	pop    %r15
    8b63:	pop    %rbp
    8b64:	ret
    8b65:	shr    $0x2,%r11
    8b69:	inc    %r11
    8b6c:	mov    %r11,%rdx
    8b6f:	and    $0xfffffffffffffff8,%rdx
    8b73:	lea    (%r9,%rdx,4),%r9
    8b77:	movd   %ecx,%xmm0
    8b7b:	pshufd $0x0,%xmm0,%xmm0
next<core::slice::iter::IterMut<u32>>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/iter/adapters/enumerate.rs:82
    8b80:	add    %r12,%rbx
    8b83:	add    $0x10,%rbx
    8b87:	lea    (%r15,%r14,1),%r12
    8b8b:	add    $0x8,%r12
    8b8f:	xor    %r13d,%r13d
    8b92:	pxor   %xmm1,%xmm1
read<u16>():
    8b96:	cs nopw 0x0(%rax,%rax,1)
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mod.rs:1733
    8ba0:	movq   -0x8(%r12,%r13,2),%xmm2
    8ba7:	movq   (%r12,%r13,2),%xmm3
<c30walk::ctor::W<false>>::promote:
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:396
    8bad:	punpcklwd %xmm1,%xmm2
    8bb1:	punpcklwd %xmm1,%xmm3
    8bb5:	pslld  $0x8,%xmm2
    8bba:	pslld  $0x8,%xmm3
    8bbf:	paddd  %xmm0,%xmm2
    8bc3:	paddd  %xmm0,%xmm3
    8bc7:	movdqu %xmm2,-0x10(%rbx,%r13,4)
    8bce:	movdqu %xmm3,(%rbx,%r13,4)
next<core::slice::iter::IterMut<u32>>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/iter/adapters/enumerate.rs:82
    8bd4:	add    $0x8,%r13
next<u32>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/iter/macros.rs:180
    8bd8:	cmp    %r13,%rdx
    8bdb:	jne    8ba0 <<c30walk::ctor::W<false>>::promote+0x190>
    8bdd:	cmp    %rdx,%r11
    8be0:	je     8b09 <<c30walk::ctor::W<false>>::promote+0xf9>
    8be6:	jmp    8adb <<c30walk::ctor::W<false>>::promote+0xcb>
<c30walk::ctor::W<false>>::promote:
    8beb:	mov    %rdi,0x10(%rsp)
push_mut<c30walk::RawG, alloc::alloc::Global>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/alloc/src/vec/mod.rs:1041
    8bf0:	mov    %rbx,%rdi
    8bf3:	mov    %rsi,%r13
    8bf6:	mov    %rax,%r12
    8bf9:	mov    %ecx,0xc(%rsp)
    8bfd:	mov    %rdx,%rbp
    8c00:	call   83c0 <<alloc::raw_vec::RawVec<c30walk::RawG>>::grow_one>
    8c05:	mov    %rbp,%rdx
    8c08:	mov    0xc(%rsp),%ecx
    8c0c:	mov    %r12,%rax
    8c0f:	mov    %r13,%rsi
    8c12:	mov    0x10(%rsp),%rdi
    8c17:	jmp    8a39 <<c30walk::ctor::W<false>>::promote+0x29>
<c30walk::ctor::W<false>>::promote:
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/ctor.rs:403
    8c1c:	lea    0xd6c9d(%rip),%rdx        # df8c0 <__do_global_dtors_aux_fini_array_entry+0x1768>
    8c23:	mov    %r8,%rdi
    8c26:	mov    %rcx,%rsi
    8c29:	call   9d2b <core::panicking::panic_bounds_check>
