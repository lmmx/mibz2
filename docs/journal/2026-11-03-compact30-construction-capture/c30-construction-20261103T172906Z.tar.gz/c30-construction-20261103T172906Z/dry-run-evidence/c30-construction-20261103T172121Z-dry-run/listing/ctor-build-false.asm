# <c30walk::ctor::Ctor>::build::<false>
# size 0x1b5e

/home/louis/dev/mibz2/target/c30-construction-pin/target/rust-1.97.0/release/examples/c30walk:     file format elf64-x86-64


Disassembly of section .text:

00000000000148b0 <<c30walk::ctor::Ctor>::build::<false>>:
   148b0:	push   %rbp
   148b1:	push   %r15
   148b3:	push   %r14
   148b5:	push   %r13
   148b7:	push   %r12
   148b9:	push   %rbx
   148ba:	sub    $0x1000,%rsp
   148c1:	movq   $0x0,(%rsp)
   148c9:	sub    $0x118,%rsp
   148d0:	mov    0x1150(%rsp),%rax
   148d8:	movq   $0x0,0x10(%r9)
   148e0:	movq   $0x0,0x10(%rax)
   148e8:	cmp    $0xeffe2,%rdx
   148ef:	ja     14f8b <<c30walk::ctor::Ctor>::build::<false>+0x6db>
   148f5:	mov    %rcx,%rbx
   148f8:	pxor   %xmm0,%xmm0
   148fc:	xor    %eax,%eax
   148fe:	pxor   %xmm2,%xmm2
   14902:	pxor   %xmm1,%xmm1
   14906:	cs nopw 0x0(%rax,%rax,1)
   14910:	movq   (%rbx,%rax,4),%xmm3
   14915:	movq   0x8(%rbx,%rax,4),%xmm4
   1491b:	punpckldq %xmm0,%xmm3
   1491f:	paddq  %xmm2,%xmm3
   14923:	punpckldq %xmm0,%xmm4
   14927:	paddq  %xmm1,%xmm4
   1492b:	movq   0x10(%rbx,%rax,4),%xmm2
   14931:	movq   0x18(%rbx,%rax,4),%xmm1
   14937:	punpckldq %xmm0,%xmm2
   1493b:	paddq  %xmm3,%xmm2
   1493f:	punpckldq %xmm0,%xmm1
   14943:	paddq  %xmm4,%xmm1
   14947:	add    $0x8,%rax
   1494b:	cmp    $0x100,%rax
   14951:	jne    14910 <<c30walk::ctor::Ctor>::build::<false>+0x60>
   14953:	paddq  %xmm2,%xmm1
   14957:	pshufd $0xee,%xmm1,%xmm0
   1495c:	paddq  %xmm1,%xmm0
   14960:	movq   %xmm0,%rax
   14965:	cmp    %rdx,%rax
   14968:	jne    14f8b <<c30walk::ctor::Ctor>::build::<false>+0x6db>
   1496e:	mov    %r8d,0x3c(%rsp)
   14973:	mov    %rsi,0x28(%rsp)
   14978:	mov    %rdi,%r15
   1497b:	mov    %rdx,0x20(%rsp)
   14980:	mov    %r9,0x50(%rsp)
   14985:	lea    0xd18(%rsp),%rdi
   1498d:	xor    %r12d,%r12d
   14990:	mov    0xce4a1(%rip),%r14        # e2e38 <memset@GLIBC_2.2.5>
   14997:	mov    $0x400,%edx
   1499c:	xor    %esi,%esi
   1499e:	call   *%r14
   149a1:	lea    0x918(%rsp),%rdi
   149a9:	mov    $0x400,%edx
   149ae:	xor    %esi,%esi
   149b0:	call   *%r14
   149b3:	movabs $0x8888888888888889,%r9
   149bd:	xor    %esi,%esi
   149bf:	xor    %edi,%edi
   149c1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   149d0:	mov    %r12,%rax
   149d3:	mul    %r9
   149d6:	mov    %rdx,%rcx
   149d9:	shr    $0x4,%rcx
   149dd:	mov    %ecx,%eax
   149df:	shl    $0x5,%eax
   149e2:	add    %ecx,%ecx
   149e4:	sub    %eax,%ecx
   149e6:	add    %r12d,%ecx
   149e9:	or     %eax,%ecx
   149eb:	mov    (%rbx,%rdi,4),%r8d
   149ef:	add    %r8,%r12
   149f2:	mov    %r12,%rax
   149f5:	mul    %r9
   149f8:	mov    %ecx,0x918(%rsp,%rdi,4)
   149ff:	shr    $0x4,%rdx
   14a03:	mov    %edx,%eax
   14a05:	shl    $0x5,%eax
   14a08:	add    %edx,%edx
   14a0a:	sub    %eax,%edx
   14a0c:	add    %r12d,%edx
   14a0f:	or     %eax,%edx
   14a11:	mov    %edx,0xd18(%rsp,%rdi,4)
   14a18:	inc    %rdi
   14a1b:	cmp    $0x1,%r8
   14a1f:	sbb    $0xffffffffffffffff,%rsi
   14a23:	cmp    $0x100,%rdi
   14a2a:	jne    149d0 <<c30walk::ctor::Ctor>::build::<false>+0x120>
   14a2c:	mov    0x20(%rsp),%rdx
   14a31:	mov    %edx,%eax
   14a33:	mov    $0x88888889,%ecx
   14a38:	imul   %rax,%rcx
   14a3c:	shr    $0x24,%rcx
   14a40:	imul   $0xeeeeeeef,%edx,%eax
   14a46:	ror    $1,%eax
   14a48:	cmp    $0x8888889,%eax
   14a4d:	sbb    $0xffffffffffffffff,%rcx
   14a51:	mov    %rcx,%r12
   14a54:	cmpl   $0x0,0x3c(%rsp)
   14a59:	mov    0x50(%rsp),%r8
   14a5e:	mov    0x1150(%rsp),%r9
   14a66:	mov    %r15,%rdi
   14a69:	mov    %rcx,0x48(%rsp)
   14a6e:	jne    14ab8 <<c30walk::ctor::Ctor>::build::<false>+0x208>
   14a70:	test   %rdx,%rdx
   14a73:	je     16148 <<c30walk::ctor::Ctor>::build::<false>+0x1898>
   14a79:	lea    -0x1(%rdx),%eax
   14a7c:	mov    $0x88888889,%ecx
   14a81:	imul   %rax,%rcx
   14a85:	shr    $0x23,%rcx
   14a89:	and    $0xfffffffe,%ecx
   14a8c:	lea    (%rcx,%rdx,1),%eax
   14a8f:	dec    %eax
   14a91:	shr    $1,%eax
   14a93:	mov    $0x80010003,%ecx
   14a98:	imul   %rax,%rcx
   14a9c:	shr    $0x2e,%rcx
   14aa0:	inc    %ecx
   14aa2:	imul   %rcx,%rsi
   14aa6:	dec    %rsi
   14aa9:	mov    0x48(%rsp),%rcx
   14aae:	cmp    %rcx,%rsi
   14ab1:	cmovae %rcx,%rsi
   14ab5:	mov    %rsi,%r12
   14ab8:	mov    (%r8),%rax
   14abb:	lea    0x1(%rcx),%rbp
   14abf:	cmp    %rcx,%rax
   14ac2:	jbe    16160 <<c30walk::ctor::Ctor>::build::<false>+0x18b0>
   14ac8:	mov    (%r9),%rax
   14acb:	cmp    %r12,%rax
   14ace:	jb     161b7 <<c30walk::ctor::Ctor>::build::<false>+0x1907>
   14ad4:	mov    0x48(%rsp),%rax
   14ad9:	lea    0x3f(%rax),%r14
   14add:	shr    $0x6,%r14
   14ae1:	movq   $0x0,0x10(%rdi)
   14ae9:	je     14b46 <<c30walk::ctor::Ctor>::build::<false>+0x296>
   14aeb:	cmp    (%rdi),%r14
   14aee:	ja     162ad <<c30walk::ctor::Ctor>::build::<false>+0x19fd>
   14af4:	xor    %r13d,%r13d
   14af7:	mov    %rdi,%r12
   14afa:	mov    0x8(%rdi),%r15
   14afe:	lea    (%r15,%r13,8),%rdi
   14b02:	cmp    $0x1,%r14
   14b06:	je     14b37 <<c30walk::ctor::Ctor>::build::<false>+0x287>
   14b08:	lea    -0x8(,%r14,8),%rdx
   14b10:	xor    %esi,%esi
   14b12:	call   *0xce320(%rip)        # e2e38 <memset@GLIBC_2.2.5>
   14b18:	mov    0x1150(%rsp),%r9
   14b20:	mov    0x50(%rsp),%r8
   14b25:	lea    (%r14,%r13,1),%rax
   14b29:	lea    (%r15,%rax,8),%rdi
   14b2d:	add    $0xfffffffffffffff8,%rdi
   14b31:	add    %r14,%r13
   14b34:	dec    %r13
   14b37:	movq   $0x0,(%rdi)
   14b3e:	inc    %r13
   14b41:	mov    %r12,%rdi
   14b44:	jmp    14b49 <<c30walk::ctor::Ctor>::build::<false>+0x299>
   14b46:	xor    %r13d,%r13d
   14b49:	mov    %r13,0x10(%rdi)
   14b4d:	mov    0x8(%r8),%rcx
   14b51:	mov    %rcx,%rax
   14b54:	and    $0x3f,%rax
   14b58:	mov    %rax,0xd8(%rsp)
   14b60:	jne    16271 <<c30walk::ctor::Ctor>::build::<false>+0x19c1>
   14b66:	mov    %rbp,0xc8(%rsp)
   14b6e:	lea    0x18(%rdi),%r14
   14b72:	mov    %rdi,0xd0(%rsp)
   14b7a:	mov    0x8(%rdi),%rdx
   14b7e:	mov    %rcx,0x90(%rsp)
   14b86:	mov    %rcx,0xf8(%rsp)
   14b8e:	mov    0x48(%rsp),%rax
   14b93:	mov    %rax,0x100(%rsp)
   14b9b:	mov    %r9,0xd8(%rsp)
   14ba3:	mov    %rdx,0x10(%rsp)
   14ba8:	mov    %rdx,0xe0(%rsp)
   14bb0:	mov    %r13,0x18(%rsp)
   14bb5:	mov    %r13,0xe8(%rsp)
   14bbd:	lea    0x108(%rsp),%rdi
   14bc5:	lea    0x918(%rsp),%rsi
   14bcd:	mov    0xce2f4(%rip),%r15        # e2ec8 <memcpy@GLIBC_2.14>
   14bd4:	mov    $0x400,%edx
   14bd9:	call   *%r15
   14bdc:	lea    0x508(%rsp),%rdi
   14be4:	lea    0xd18(%rsp),%rsi
   14bec:	mov    $0x400,%edx
   14bf1:	call   *%r15
   14bf4:	movabs $0x8888888888888889,%r8
   14bfe:	mov    0x20(%rsp),%r9
   14c03:	movl   $0x0,0x910(%rsp)
   14c0e:	movq   $0x0,0x908(%rsp)
   14c1a:	mov    %r14,0xf0(%rsp)
   14c22:	mov    $0xffffffffffffffff,%rcx
   14c29:	xor    %r13d,%r13d
   14c2c:	movabs $0xeeeeeeeeeeeeeeef,%r11
   14c36:	movabs $0x888888888888889,%r12
   14c40:	pxor   %xmm0,%xmm0
   14c44:	pcmpeqd %xmm1,%xmm1
   14c48:	xor    %ebp,%ebp
   14c4a:	mov    0x28(%rsp),%r10
   14c4f:	jmp    14d10 <<c30walk::ctor::Ctor>::build::<false>+0x460>
   14c54:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   14c60:	mov    0x8(%rdi),%rax
   14c64:	mov    %r15,%rcx
   14c67:	shl    $0x7,%rcx
   14c6b:	movdqa %xmm0,0x70(%rax,%rcx,1)
   14c71:	movdqa %xmm0,0x60(%rax,%rcx,1)
   14c77:	movdqa %xmm0,0x50(%rax,%rcx,1)
   14c7d:	movdqa %xmm0,0x40(%rax,%rcx,1)
   14c83:	movdqa %xmm0,0x30(%rax,%rcx,1)
   14c89:	movdqa %xmm0,0x20(%rax,%rcx,1)
   14c8f:	movdqa %xmm0,0x10(%rax,%rcx,1)
   14c95:	movdqa %xmm0,(%rax,%rcx,1)
   14c9a:	mov    %r15,%rax
   14c9d:	inc    %rax
   14ca0:	mov    %rax,0x10(%rdi)
   14ca4:	mov    %r14,%rax
   14ca7:	shl    $0x6,%rax
   14cab:	or     $0x10000000,%r15d
   14cb2:	mov    0x90(%rsp),%rcx
   14cba:	movdqu %xmm1,0x2c(%rcx,%rax,1)
   14cc0:	movdqa %xmm1,0x20(%rcx,%rax,1)
   14cc6:	movdqa %xmm1,0x10(%rcx,%rax,1)
   14ccc:	movdqa %xmm1,(%rcx,%rax,1)
   14cd1:	mov    %r15d,0x3c(%rcx,%rax,1)
   14cd6:	mov    %r14,%rdi
   14cd9:	shr    $0x6,%rdi
   14cdd:	cmp    0x18(%rsp),%rdi
   14ce2:	jae    16368 <<c30walk::ctor::Ctor>::build::<false>+0x1ab8>
   14ce8:	mov    $0x1,%eax
   14ced:	mov    %r14d,%ecx
   14cf0:	shl    %cl,%rax
   14cf3:	mov    0x10(%rsp),%rcx
   14cf8:	or     %rax,(%rcx,%rdi,8)
   14cfc:	mov    %r14,%rcx
   14cff:	add    $0x4,%rbp
   14d03:	cmp    $0x400,%rbp
   14d0a:	je     14d98 <<c30walk::ctor::Ctor>::build::<false>+0x4e8>
   14d10:	mov    %r13,%rax
   14d13:	mov    (%rbx,%rbp,1),%r13d
   14d17:	add    %rax,%r13
   14d1a:	cmp    %r9,%r13
   14d1d:	setae  %sil
   14d21:	mov    %r13,%rax
   14d24:	mul    %r8
   14d27:	mov    %rdx,%r14
   14d2a:	shr    $0x4,%r14
   14d2e:	mov    %r13,%rax
   14d31:	imul   %r11,%rax
   14d35:	ror    $1,%rax
   14d38:	cmp    %r12,%rax
   14d3b:	setb   %al
   14d3e:	cmp    %rcx,%r14
   14d41:	sete   %dl
   14d44:	or     %sil,%dl
   14d47:	or     %al,%dl
   14d49:	jne    14cff <<c30walk::ctor::Ctor>::build::<false>+0x44f>
   14d4b:	mov    0x1150(%rsp),%rdi
   14d53:	mov    0x10(%rdi),%r15
   14d57:	cmp    (%rdi),%r15
   14d5a:	jne    14c60 <<c30walk::ctor::Ctor>::build::<false>+0x3b0>
   14d60:	call   83c0 <<alloc::raw_vec::RawVec<c30walk::RawG>>::grow_one>
   14d65:	pcmpeqd %xmm1,%xmm1
   14d69:	pxor   %xmm0,%xmm0
   14d6d:	movabs $0xeeeeeeeeeeeeeeef,%r11
   14d77:	movabs $0x8888888888888889,%r8
   14d81:	mov    0x28(%rsp),%r10
   14d86:	mov    0x20(%rsp),%r9
   14d8b:	mov    0x1150(%rsp),%rdi
   14d93:	jmp    14c60 <<c30walk::ctor::Ctor>::build::<false>+0x3b0>
   14d98:	cmpl   $0x0,0x3c(%rsp)
   14d9d:	mov    0x1150(%rsp),%r11
   14da5:	mov    0x48(%rsp),%rdi
   14daa:	mov    0x18(%rsp),%rsi
   14daf:	mov    0x10(%rsp),%r8
   14db4:	je     14f46 <<c30walk::ctor::Ctor>::build::<false>+0x696>
   14dba:	test   %rdi,%rdi
   14dbd:	je     14f46 <<c30walk::ctor::Ctor>::build::<false>+0x696>
   14dc3:	mov    %r9,%r14
   14dc6:	shl    $0x20,%r14
   14dca:	mov    0x3c(%rsp),%r15d
   14dcf:	xor    %ebx,%ebx
   14dd1:	pxor   %xmm0,%xmm0
   14dd5:	pcmpeqd %xmm1,%xmm1
   14dd9:	mov    0x90(%rsp),%rbp
   14de1:	mov    %r14,0x8(%rsp)
   14de6:	jmp    14e70 <<c30walk::ctor::Ctor>::build::<false>+0x5c0>
   14deb:	mov    0x8(%r11),%rax
   14def:	mov    %r15,%rcx
   14df2:	shl    $0x7,%rcx
   14df6:	movdqa %xmm0,0x70(%rax,%rcx,1)
   14dfc:	movdqa %xmm0,0x60(%rax,%rcx,1)
   14e02:	movdqa %xmm0,0x50(%rax,%rcx,1)
   14e08:	movdqa %xmm0,0x40(%rax,%rcx,1)
   14e0e:	movdqa %xmm0,0x30(%rax,%rcx,1)
   14e14:	movdqa %xmm0,0x20(%rax,%rcx,1)
   14e1a:	movdqa %xmm0,0x10(%rax,%rcx,1)
   14e20:	movdqa %xmm0,(%rax,%rcx,1)
   14e25:	mov    %r15,%rax
   14e28:	inc    %rax
   14e2b:	mov    %rax,0x10(%r11)
   14e2f:	or     $0x10000000,%r15d
   14e36:	movdqu %xmm1,0x2c(%rbp)
   14e3b:	movdqa %xmm1,0x20(%rbp)
   14e40:	movdqa %xmm1,0x10(%rbp)
   14e45:	movdqa %xmm1,0x0(%rbp)
   14e4a:	mov    %r15d,0x3c(%rbp)
   14e4e:	or     %r12,(%r8,%r13,8)
   14e52:	mov    %r14,%r15
   14e55:	mov    0x8(%rsp),%r14
   14e5a:	nopw   0x0(%rax,%rax,1)
   14e60:	inc    %rbx
   14e63:	add    $0x40,%rbp
   14e67:	cmp    %rbx,%rdi
   14e6a:	je     14f46 <<c30walk::ctor::Ctor>::build::<false>+0x696>
   14e70:	mov    %rbx,%r13
   14e73:	shr    $0x6,%r13
   14e77:	cmp    %rsi,%r13
   14e7a:	jae    16379 <<c30walk::ctor::Ctor>::build::<false>+0x1ac9>
   14e80:	mov    (%r8,%r13,8),%rax
   14e84:	mov    $0x1,%r12d
   14e8a:	mov    %ebx,%ecx
   14e8c:	shl    %cl,%r12
   14e8f:	bt     %rbx,%rax
   14e93:	jb     14e60 <<c30walk::ctor::Ctor>::build::<false>+0x5b0>
   14e95:	mov    %rbx,%rax
   14e98:	xor    %r14,%rax
   14e9b:	mov    %rax,%rcx
   14e9e:	shr    $0x21,%rcx
   14ea2:	xor    %rax,%rcx
   14ea5:	movabs $0xff51afd7ed558ccd,%rax
   14eaf:	imul   %rax,%rcx
   14eb3:	mov    %rcx,%rax
   14eb6:	shr    $0x21,%rax
   14eba:	xor    %rcx,%rax
   14ebd:	movabs $0xc4ceb9fe1a85ec53,%rcx
   14ec7:	imul   %rcx,%rax
   14ecb:	mov    %rax,%rcx
   14ece:	shr    $0x21,%rcx
   14ed2:	xor    %rax,%rcx
   14ed5:	mov    %rcx,%rax
   14ed8:	shr    $0x3,%rax
   14edc:	movabs $0x20c49ba5e353f7cf,%rdx
   14ee6:	mul    %rdx
   14ee9:	shr    $0x4,%rdx
   14eed:	imul   $0x3e8,%rdx,%rax
   14ef4:	sub    %rax,%rcx
   14ef7:	cmp    %r15,%rcx
   14efa:	jae    14e60 <<c30walk::ctor::Ctor>::build::<false>+0x5b0>
   14f00:	mov    %r15,%r14
   14f03:	mov    0x10(%r11),%r15
   14f07:	cmp    (%r11),%r15
   14f0a:	jne    14deb <<c30walk::ctor::Ctor>::build::<false>+0x53b>
   14f10:	mov    %r11,%rdi
   14f13:	call   83c0 <<alloc::raw_vec::RawVec<c30walk::RawG>>::grow_one>
   14f18:	pcmpeqd %xmm1,%xmm1
   14f1c:	pxor   %xmm0,%xmm0
   14f20:	mov    0x10(%rsp),%r8
   14f25:	mov    0x18(%rsp),%rsi
   14f2a:	mov    0x48(%rsp),%rdi
   14f2f:	mov    0x28(%rsp),%r10
   14f34:	mov    0x20(%rsp),%r9
   14f39:	mov    0x1150(%rsp),%r11
   14f41:	jmp    14deb <<c30walk::ctor::Ctor>::build::<false>+0x53b>
   14f46:	cmp    $0x10,%r9
   14f4a:	jae    14f9f <<c30walk::ctor::Ctor>::build::<false>+0x6ef>
   14f4c:	xor    %r12d,%r12d
   14f4f:	cmp    %r9,%r12
   14f52:	jne    15e9f <<c30walk::ctor::Ctor>::build::<false>+0x15ef>
   14f58:	mov    $0x400,%edx
   14f5d:	lea    0x108(%rsp),%rdi
   14f65:	lea    0x508(%rsp),%rsi
   14f6d:	call   *0xcdf95(%rip)        # e2f08 <bcmp@GLIBC_2.2.5>
   14f73:	mov    0x1150(%rsp),%r11
   14f7b:	test   %eax,%eax
   14f7d:	je     1605d <<c30walk::ctor::Ctor>::build::<false>+0x17ad>
   14f83:	movq   $0x0,0x10(%r11)
   14f8b:	xor    %eax,%eax
   14f8d:	add    $0x1118,%rsp
   14f94:	pop    %rbx
   14f95:	pop    %r12
   14f97:	pop    %r13
   14f99:	pop    %r14
   14f9b:	pop    %r15
   14f9d:	pop    %rbp
   14f9e:	ret
   14f9f:	mov    $0x10,%r14d
   14fa5:	xor    %r12d,%r12d
   14fa8:	pxor   %xmm4,%xmm4
   14fac:	xor    %ebp,%ebp
   14fae:	jmp    14fcb <<c30walk::ctor::Ctor>::build::<false>+0x71b>
   14fb0:	mov    0xb0(%rsp),%r12
   14fb8:	lea    0x10(%r12),%rax
   14fbd:	xor    %ebp,%ebp
   14fbf:	mov    %rax,%r14
   14fc2:	cmp    %r9,%rax
   14fc5:	ja     1621a <<c30walk::ctor::Ctor>::build::<false>+0x196a>
   14fcb:	mov    %r12,%rdx
   14fce:	mov    %r13,%rdi
   14fd1:	test   $0x1,%bpl
   14fd5:	jne    15003 <<c30walk::ctor::Ctor>::build::<false>+0x753>
   14fd7:	lea    0x8(%rdx),%rsi
   14fdb:	cmp    $0xfffffffffffffff7,%rdx
   14fdf:	ja     1624a <<c30walk::ctor::Ctor>::build::<false>+0x199a>
   14fe5:	cmp    %r9,%rsi
   14fe8:	ja     1624a <<c30walk::ctor::Ctor>::build::<false>+0x199a>
   14fee:	lea    0x10(%rdx),%rax
   14ff2:	cmp    %r9,%rax
   14ff5:	ja     1625c <<c30walk::ctor::Ctor>::build::<false>+0x19ac>
   14ffb:	mov    (%r10,%rdx,1),%rbx
   14fff:	mov    (%r10,%rsi,1),%rdi
   15003:	mov    %rbx,%rax
   15006:	xor    %rdi,%rax
   15009:	mov    %rbx,%rcx
   1500c:	rol    $0x8,%rcx
   15010:	xor    %rbx,%rcx
   15013:	or     %rax,%rcx
   15016:	mov    %r14,0xb0(%rsp)
   1501e:	jne    150a0 <<c30walk::ctor::Ctor>::build::<false>+0x7f0>
   15024:	mov    %r14,%rcx
   15027:	mov    %rdx,0x88(%rsp)
   1502f:	sub    %rdx,%rcx
   15032:	xor    %edx,%edx
   15034:	mov    %r14,%rax
   15037:	nopw   0x0(%rax,%rax,1)
   15040:	mov    %rax,%r12
   15043:	mov    %rdx,%r14
   15046:	mov    %rcx,%r15
   15049:	add    $0x10,%rax
   1504d:	cmp    %r9,%rax
   15050:	setbe  %bpl
   15054:	ja     15276 <<c30walk::ctor::Ctor>::build::<false>+0x9c6>
   1505a:	lea    0x8(%r12),%rsi
   1505f:	cmp    $0xfffffffffffffff7,%r12
   15063:	ja     16238 <<c30walk::ctor::Ctor>::build::<false>+0x1988>
   15069:	cmp    %r9,%rsi
   1506c:	ja     16238 <<c30walk::ctor::Ctor>::build::<false>+0x1988>
   15072:	mov    (%r10,%r12,1),%rbx
   15076:	mov    0x8(%r10,%r12,1),%r13
   1507b:	cmp    %rdi,%rbx
   1507e:	jne    1508d <<c30walk::ctor::Ctor>::build::<false>+0x7dd>
   15080:	lea    0x1(%r14),%rdx
   15084:	lea    0x10(%r15),%rcx
   15088:	cmp    %rdi,%r13
   1508b:	je     15040 <<c30walk::ctor::Ctor>::build::<false>+0x790>
   1508d:	lea    0x10(%r12),%rax
   15092:	mov    %rax,0x78(%rsp)
   15097:	jmp    15280 <<c30walk::ctor::Ctor>::build::<false>+0x9d0>
   1509c:	nopl   0x0(%rax)
   150a0:	cmp    $0xfffffffffffffff0,%rdx
   150a4:	jae    16298 <<c30walk::ctor::Ctor>::build::<false>+0x19e8>
   150aa:	add    %r10,%rdx
   150ad:	mov    0xf8(%rsp),%rbx
   150b5:	mov    0xe8(%rsp),%r8
   150bd:	mov    0xd8(%rsp),%rax
   150c5:	mov    %rax,0x18(%rsp)
   150ca:	mov    0xe0(%rsp),%rax
   150d2:	mov    %rax,0x10(%rsp)
   150d7:	mov    0x910(%rsp),%r12d
   150df:	mov    0x908(%rsp),%r15
   150e7:	xor    %ebp,%ebp
   150e9:	mov    %rbx,0x8(%rsp)
   150ee:	jmp    15139 <<c30walk::ctor::Ctor>::build::<false>+0x889>
   150f0:	mov    %r14d,0x3c(%rax)
   150f4:	movw   $0x0,(%rax)
   150f9:	nopl   0x0(%rax)
   15100:	lea    0x1(%r15),%rax
   15104:	add    $0xffffffffffffffe3,%r15
   15108:	xor    %ecx,%ecx
   1510a:	cmp    $0x1e,%rax
   1510e:	setae  %cl
   15111:	cmovb  %rax,%r15
   15115:	lea    (%r12,%rcx,2),%r12d
   15119:	inc    %r12d
   1511c:	mov    %r15,0x908(%rsp)
   15124:	mov    %r12d,0x910(%rsp)
   1512c:	inc    %rbp
   1512f:	cmp    $0x10,%rbp
   15133:	je     14fb0 <<c30walk::ctor::Ctor>::build::<false>+0x700>
   15139:	movzbl (%rdx,%rbp,1),%eax
   1513d:	mov    0x108(%rsp,%rax,4),%esi
   15144:	cmp    0x508(%rsp,%rax,4),%esi
   1514b:	jae    14f83 <<c30walk::ctor::Ctor>::build::<false>+0x6d3>
   15151:	mov    %esi,%r13d
   15154:	and    $0x1f,%r13d
   15158:	xor    %ecx,%ecx
   1515a:	cmp    $0x1d,%r13d
   1515e:	sete   %cl
   15161:	lea    (%rsi,%rcx,2),%ecx
   15164:	inc    %ecx
   15166:	mov    %ecx,0x108(%rsp,%rax,4)
   1516d:	shr    $0x5,%esi
   15170:	mov    %r12d,%r14d
   15173:	shl    $0x8,%r14d
   15177:	or     %eax,%r14d
   1517a:	test   %r13d,%r13d
   1517d:	je     151d0 <<c30walk::ctor::Ctor>::build::<false>+0x920>
   1517f:	mov    %rsi,%rcx
   15182:	shl    $0x6,%rcx
   15186:	mov    0x3c(%rbx,%rcx,1),%eax
   1518a:	test   $0x10000000,%eax
   1518f:	jne    15210 <<c30walk::ctor::Ctor>::build::<false>+0x960>
   15191:	mov    %rdx,%rbx
   15194:	mov    %eax,%edi
   15196:	shr    $0x8,%edi
   15199:	mov    %r12d,%edx
   1519c:	sub    %edi,%edx
   1519e:	cmp    $0xfffe,%edx
   151a4:	jae    1523a <<c30walk::ctor::Ctor>::build::<false>+0x98a>
   151aa:	mov    0x8(%rsp),%rax
   151af:	add    %rax,%rcx
   151b2:	mov    %dx,(%rcx,%r13,2)
   151b7:	mov    %rbx,%rdx
   151ba:	mov    %rax,%rbx
   151bd:	jmp    15100 <<c30walk::ctor::Ctor>::build::<false>+0x850>
   151c2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   151d0:	mov    %esi,%edi
   151d2:	shr    $0x6,%edi
   151d5:	cmp    %r8,%rdi
   151d8:	jae    16388 <<c30walk::ctor::Ctor>::build::<false>+0x1ad8>
   151de:	mov    0x10(%rsp),%rax
   151e3:	mov    (%rax,%rdi,8),%rcx
   151e7:	mov    %rsi,%rax
   151ea:	shl    $0x6,%rax
   151ee:	add    %rbx,%rax
   151f1:	bt     %rsi,%rcx
   151f5:	jae    150f0 <<c30walk::ctor::Ctor>::build::<false>+0x840>
   151fb:	mov    0x3c(%rax),%eax
   151fe:	mov    $0xfffff,%ecx
   15203:	and    %ecx,%eax
   15205:	jmp    15215 <<c30walk::ctor::Ctor>::build::<false>+0x965>
   15207:	nopw   0x0(%rax,%rax,1)
   15210:	and    $0xfffff,%eax
   15215:	mov    %eax,%edi
   15217:	mov    0x18(%rsp),%rax
   1521c:	mov    0x10(%rax),%rsi
   15220:	cmp    %rdi,%rsi
   15223:	jbe    16051 <<c30walk::ctor::Ctor>::build::<false>+0x17a1>
   15229:	shl    $0x7,%rdi
   1522d:	add    0x8(%rax),%rdi
   15231:	mov    %r14d,(%rdi,%r13,4)
   15235:	jmp    15100 <<c30walk::ctor::Ctor>::build::<false>+0x850>
   1523a:	lea    0xd8(%rsp),%rdi
   15242:	mov    %r13,%rdx
   15245:	mov    %eax,%ecx
   15247:	mov    %r8,0x60(%rsp)
   1524c:	call   8a10 <<c30walk::ctor::W<false>>::promote>
   15251:	mov    0x60(%rsp),%r8
   15256:	pxor   %xmm4,%xmm4
   1525a:	mov    0x28(%rsp),%r10
   1525f:	mov    0x20(%rsp),%r9
   15264:	mov    0x1150(%rsp),%r11
   1526c:	mov    %rbx,%rdx
   1526f:	mov    0x8(%rsp),%rbx
   15274:	jmp    15215 <<c30walk::ctor::Ctor>::build::<false>+0x965>
   15276:	lea    0x10(%r12),%rax
   1527b:	mov    %rax,0x78(%rsp)
   15280:	mov    0x88(%rsp),%rax
   15288:	mov    %r12,%rcx
   1528b:	sub    %rax,%rcx
   1528e:	mov    %rdi,0x70(%rsp)
   15293:	movzbl %dil,%esi
   15297:	mov    %esi,%r11d
   1529a:	mov    0x108(%rsp,%r11,4),%edi
   152a2:	mov    %edi,%r8d
   152a5:	and    $0x1f,%r8d
   152a9:	lea    (%rcx,%r8,1),%rax
   152ad:	mov    %rax,0x10(%rsp)
   152b2:	movabs $0x8888888888888889,%rdx
   152bc:	mul    %rdx
   152bf:	shr    $0x4,%rdx
   152c3:	lea    (%rcx,%rdi,1),%eax
   152c6:	mov    %rdx,0x60(%rsp)
   152cb:	lea    (%rax,%rdx,2),%eax
   152ce:	cmp    0x508(%rsp,%r11,4),%eax
   152d6:	mov    0x1150(%rsp),%r11
   152de:	ja     14f83 <<c30walk::ctor::Ctor>::build::<false>+0x6d3>
   152e4:	mov    %eax,0x108(%rsp,%rsi,4)
   152eb:	mov    %rdi,0xa8(%rsp)
   152f3:	shr    $0x5,%edi
   152f6:	test   %r8d,%r8d
   152f9:	mov    %r8,0x40(%rsp)
   152fe:	je     1540a <<c30walk::ctor::Ctor>::build::<false>+0xb5a>
   15304:	mov    %rsi,0xb8(%rsp)
   1530c:	mov    $0x1e,%edx
   15311:	sub    %r8,%rdx
   15314:	lea    (%rcx,%r8,1),%rax
   15318:	cmp    $0x1e,%rax
   1531c:	cmovb  %rcx,%rdx
   15320:	mov    %rdx,0x30(%rsp)
   15325:	mov    0x908(%rsp),%rsi
   1532d:	cmp    $0x1e,%rsi
   15331:	jae    16397 <<c30walk::ctor::Ctor>::build::<false>+0x1ae7>
   15337:	mov    %r8,%r10
   1533a:	mov    %rsi,%rcx
   1533d:	shl    $0x6,%rcx
   15341:	lea    0xaf6b8(%rip),%rax        # c4a00 <c30walk::ctor::PATTERNS>
   15348:	mov    %rcx,0x58(%rsp)
   1534d:	lea    (%rax,%rcx,1),%r9
   15351:	mov    0x910(%rsp),%eax
   15358:	mov    %eax,0x18(%rsp)
   1535c:	mov    0xf8(%rsp),%rcx
   15364:	mov    %rdi,%rax
   15367:	shl    $0x6,%rax
   1536b:	mov    %rax,0x80(%rsp)
   15373:	mov    0x3c(%rcx,%rax,1),%eax
   15377:	test   $0x10000000,%eax
   1537c:	mov    %rdi,0x8(%rsp)
   15381:	mov    %rsi,0xc0(%rsp)
   15389:	mov    %r9,0x68(%rsp)
   1538e:	jne    1541d <<c30walk::ctor::Ctor>::build::<false>+0xb6d>
   15394:	mov    0x30(%rsp),%r8
   15399:	lea    -0x1(%r8),%rdi
   1539d:	cmp    $0x1d,%rdi
   153a1:	ja     163ce <<c30walk::ctor::Ctor>::build::<false>+0x1b1e>
   153a7:	mov    %eax,%edi
   153a9:	shr    $0x8,%edi
   153ac:	mov    0x18(%rsp),%edx
   153b0:	sub    %edi,%edx
   153b2:	movzwl -0x2(%r9,%r8,2),%edi
   153b8:	add    %edx,%edi
   153ba:	cmp    $0xfffd,%edi
   153c0:	ja     15e6d <<c30walk::ctor::Ctor>::build::<false>+0x15bd>
   153c6:	mov    0x10(%rsp),%rax
   153cb:	cmp    $0x1e,%rax
   153cf:	mov    $0x1e,%edi
   153d4:	cmovb  %rax,%rdi
   153d8:	mov    %r10,%rax
   153db:	not    %rax
   153de:	add    %rdi,%rax
   153e1:	movabs $0x7fffffffffffffff,%rdi
   153eb:	and    %rdi,%rax
   153ee:	cmp    $0x3,%rax
   153f2:	jae    15500 <<c30walk::ctor::Ctor>::build::<false>+0xc50>
   153f8:	xor    %eax,%eax
   153fa:	mov    %r9,%r10
   153fd:	mov    0x80(%rsp),%r9
   15405:	jmp    157bf <<c30walk::ctor::Ctor>::build::<false>+0xf0f>
   1540a:	mov    0x60(%rsp),%rcx
   1540f:	test   %rcx,%rcx
   15412:	jne    1586c <<c30walk::ctor::Ctor>::build::<false>+0xfbc>
   15418:	jmp    158b3 <<c30walk::ctor::Ctor>::build::<false>+0x1003>
   1541d:	and    $0xfffff,%eax
   15422:	mov    0x30(%rsp),%r8
   15427:	mov    0xd8(%rsp),%rcx
   1542f:	mov    %eax,%edi
   15431:	mov    0x10(%rcx),%rsi
   15435:	cmp    %rdi,%rsi
   15438:	jbe    163df <<c30walk::ctor::Ctor>::build::<false>+0x1b2f>
   1543e:	lea    (%r8,%r10,1),%rsi
   15442:	cmp    %r10,%rsi
   15445:	jb     162de <<c30walk::ctor::Ctor>::build::<false>+0x1a2e>
   1544b:	cmp    $0x21,%rsi
   1544f:	jae    162de <<c30walk::ctor::Ctor>::build::<false>+0x1a2e>
   15455:	cmp    $0x1f,%r8
   15459:	jae    162f2 <<c30walk::ctor::Ctor>::build::<false>+0x1a42>
   1545f:	test   %r8,%r8
   15462:	je     157f7 <<c30walk::ctor::Ctor>::build::<false>+0xf47>
   15468:	mov    %r8,%r10
   1546b:	mov    0x8(%rcx),%r8
   1546f:	shl    $0x7,%rdi
   15473:	lea    (%r8,%rdi,1),%rdx
   15477:	mov    0x40(%rsp),%r9
   1547c:	lea    (%rdx,%r9,4),%rax
   15480:	movzbl 0x70(%rsp),%ecx
   15485:	cmp    $0x8,%r10
   15489:	jb     154bc <<c30walk::ctor::Ctor>::build::<false>+0xc0c>
   1548b:	add    %r9d,%r9d
   1548e:	mov    0x58(%rsp),%r10
   15493:	sub    %r9,%r10
   15496:	lea    0xaf563(%rip),%r9        # c4a00 <c30walk::ctor::PATTERNS>
   1549d:	add    %r9,%r10
   154a0:	lea    (%r10,%rsi,2),%r9
   154a4:	cmp    %r9,%rax
   154a7:	jae    1555f <<c30walk::ctor::Ctor>::build::<false>+0xcaf>
   154ad:	lea    (%rdx,%rsi,4),%rdx
   154b1:	cmp    %rdx,0x68(%rsp)
   154b6:	jae    1555f <<c30walk::ctor::Ctor>::build::<false>+0xcaf>
   154bc:	xor    %edx,%edx
   154be:	mov    0x30(%rsp),%r8
   154c3:	mov    0x58(%rsp),%rsi
   154c8:	lea    (%rsi,%rdx,2),%rsi
   154cc:	lea    0xaf52d(%rip),%rdi        # c4a00 <c30walk::ctor::PATTERNS>
   154d3:	add    %rdi,%rsi
   154d6:	cs nopw 0x0(%rax,%rax,1)
   154e0:	movzwl (%rsi),%edi
   154e3:	add    0x18(%rsp),%edi
   154e7:	shl    $0x8,%edi
   154ea:	or     %ecx,%edi
   154ec:	mov    %edi,(%rax,%rdx,4)
   154ef:	inc    %rdx
   154f2:	add    $0x2,%rsi
   154f6:	cmp    %r8,%rdx
   154f9:	jb     154e0 <<c30walk::ctor::Ctor>::build::<false>+0xc30>
   154fb:	jmp    157f7 <<c30walk::ctor::Ctor>::build::<false>+0xf47>
   15500:	mov    %rcx,%rdi
   15503:	lea    0xaf4f6(%rip),%r9        # c4a00 <c30walk::ctor::PATTERNS>
   1550a:	sub    %r9,%rdi
   1550d:	mov    0x80(%rsp),%r9
   15515:	add    %r9,%rdi
   15518:	lea    (%r10,%r10,1),%esi
   1551c:	add    %rsi,%rdi
   1551f:	sub    0x58(%rsp),%rdi
   15524:	cmp    $0x20,%rdi
   15528:	jae    15536 <<c30walk::ctor::Ctor>::build::<false>+0xc86>
   1552a:	xor    %eax,%eax
   1552c:	mov    0x68(%rsp),%r10
   15531:	jmp    157bf <<c30walk::ctor::Ctor>::build::<false>+0xf0f>
   15536:	mov    %rsi,0x98(%rsp)
   1553e:	lea    0x1(%rax),%rsi
   15542:	cmp    $0xf,%rax
   15546:	mov    %ebp,0x38(%rsp)
   1554a:	mov    %rsi,0xa0(%rsp)
   15552:	jae    15618 <<c30walk::ctor::Ctor>::build::<false>+0xd68>
   15558:	xor    %eax,%eax
   1555a:	jmp    156f6 <<c30walk::ctor::Ctor>::build::<false>+0xe46>
   1555f:	mov    0x30(%rsp),%rdx
   15564:	and    $0x18,%edx
   15567:	movd   %ecx,%xmm0
   1556b:	pshufd $0x0,%xmm0,%xmm0
   15570:	movd   0x18(%rsp),%xmm1
   15576:	pshufd $0x0,%xmm1,%xmm1
   1557b:	mov    0x40(%rsp),%r10
   15580:	lea    (%r10,%r15,1),%rsi
   15584:	cmp    $0x1e,%rsi
   15588:	mov    $0x1e,%r9d
   1558e:	cmovae %r9,%rsi
   15592:	sub    %r10d,%esi
   15595:	and    $0x18,%esi
   15598:	lea    0xaf461(%rip),%r9        # c4a00 <c30walk::ctor::PATTERNS>
   1559f:	mov    0x58(%rsp),%r10
   155a4:	add    %r10,%r9
   155a7:	add    $0x8,%r9
   155ab:	mov    0x40(%rsp),%r10
   155b0:	lea    (%rdi,%r10,4),%rdi
   155b4:	add    %r8,%rdi
   155b7:	add    $0x10,%rdi
   155bb:	xor    %r8d,%r8d
   155be:	xchg   %ax,%ax
   155c0:	movq   -0x8(%r9,%r8,2),%xmm2
   155c7:	movq   (%r9,%r8,2),%xmm3
   155cd:	punpcklwd %xmm4,%xmm2
   155d1:	punpcklwd %xmm4,%xmm3
   155d5:	paddd  %xmm1,%xmm2
   155d9:	paddd  %xmm1,%xmm3
   155dd:	pslld  $0x8,%xmm2
   155e2:	pslld  $0x8,%xmm3
   155e7:	por    %xmm0,%xmm2
   155eb:	por    %xmm0,%xmm3
   155ef:	movdqu %xmm2,-0x10(%rdi,%r8,4)
   155f6:	movdqu %xmm3,(%rdi,%r8,4)
   155fc:	add    $0x8,%r8
   15600:	cmp    %r8,%rsi
   15603:	jne    155c0 <<c30walk::ctor::Ctor>::build::<false>+0xd10>
   15605:	mov    0x30(%rsp),%r8
   1560a:	cmp    %rdx,%r8
   1560d:	jne    154c3 <<c30walk::ctor::Ctor>::build::<false>+0xc13>
   15613:	jmp    157f7 <<c30walk::ctor::Ctor>::build::<false>+0xf47>
   15618:	mov    %rsi,%rax
   1561b:	and    $0xfffffffffffffff0,%rax
   1561f:	movd   %edx,%xmm0
   15623:	pshuflw $0x0,%xmm0,%xmm0
   15628:	pshufd $0x44,%xmm0,%xmm0
   1562d:	lea    0xaf3cc(%rip),%rdi        # c4a00 <c30walk::ctor::PATTERNS>
   15634:	mov    %r10,%rsi
   15637:	mov    0x58(%rsp),%r10
   1563c:	lea    0x10(%r10,%rdi,1),%r10
   15641:	mov    0xa8(%rsp),%r11
   15649:	not    %r11d
   1564c:	lea    (%rsi,%r15,1),%rdi
   15650:	cmp    $0x1e,%rdi
   15654:	mov    $0x1e,%ebp
   15659:	cmovae %rbp,%rdi
   1565d:	movabs $0x7fffffffffffffe0,%rbp
   15667:	or     %rbp,%r11
   1566a:	add    %rdi,%r11
   1566d:	movabs $0x7fffffffffffffff,%rdi
   15677:	and    %rdi,%r11
   1567a:	inc    %r11
   1567d:	and    $0xfffffffffffffff0,%r11
   15681:	mov    0x98(%rsp),%rsi
   15689:	lea    (%r9,%rsi,1),%rdi
   1568d:	lea    (%rcx,%rdi,1),%rbp
   15691:	add    $0x10,%rbp
   15695:	xor    %edi,%edi
   15697:	nopw   0x0(%rax,%rax,1)
   156a0:	movdqa -0x10(%r10,%rdi,2),%xmm1
   156a7:	paddw  %xmm0,%xmm1
   156ab:	movdqa (%r10,%rdi,2),%xmm2
   156b1:	paddw  %xmm0,%xmm2
   156b5:	movdqu %xmm1,-0x10(%rbp,%rdi,2)
   156bb:	movdqu %xmm2,0x0(%rbp,%rdi,2)
   156c1:	add    $0x10,%rdi
   156c5:	cmp    %rdi,%r11
   156c8:	jne    156a0 <<c30walk::ctor::Ctor>::build::<false>+0xdf0>
   156ca:	mov    0xa0(%rsp),%rsi
   156d2:	cmp    %rax,%rsi
   156d5:	mov    0x1150(%rsp),%r11
   156dd:	mov    0x38(%rsp),%ebp
   156e1:	je     157f7 <<c30walk::ctor::Ctor>::build::<false>+0xf47>
   156e7:	test   $0xc,%sil
   156eb:	je     15e56 <<c30walk::ctor::Ctor>::build::<false>+0x15a6>
   156f1:	mov    0x40(%rsp),%r10
   156f6:	mov    %rax,%rbp
   156f9:	mov    %rsi,%rax
   156fc:	and    $0xfffffffffffffffc,%rax
   15700:	mov    0x58(%rsp),%rsi
   15705:	lea    (%rsi,%rbp,2),%r11
   15709:	lea    0xaf2f0(%rip),%rdi        # c4a00 <c30walk::ctor::PATTERNS>
   15710:	add    %rdi,%r11
   15713:	mov    0xa8(%rsp),%r9
   1571b:	not    %r9d
   1571e:	lea    (%r10,%r15,1),%rdi
   15722:	cmp    $0x1e,%rdi
   15726:	mov    $0x1e,%r10d
   1572c:	cmovae %r10,%rdi
   15730:	movabs $0x7fffffffffffffe0,%r10
   1573a:	or     %r10,%r9
   1573d:	add    %rdi,%r9
   15740:	mov    0x68(%rsp),%rsi
   15745:	lea    (%rsi,%rax,2),%r10
   15749:	mov    %r9,%rsi
   1574c:	movd   %edx,%xmm0
   15750:	pshuflw $0x0,%xmm0,%xmm0
   15755:	movabs $0x7fffffffffffffff,%rdi
   1575f:	and    %rdi,%rsi
   15762:	inc    %rsi
   15765:	and    $0xfffffffffffffffc,%rsi
   15769:	sub    %rbp,%rsi
   1576c:	mov    0x80(%rsp),%r9
   15774:	lea    (%r9,%rbp,2),%rbp
   15778:	add    0x98(%rsp),%rbp
   15780:	add    %rcx,%rbp
   15783:	xor    %edi,%edi
   15785:	data16 cs nopw 0x0(%rax,%rax,1)
   15790:	movq   (%r11,%rdi,2),%xmm1
   15796:	paddw  %xmm0,%xmm1
   1579a:	movq   %xmm1,0x0(%rbp,%rdi,2)
   157a0:	add    $0x4,%rdi
   157a4:	cmp    %rdi,%rsi
   157a7:	jne    15790 <<c30walk::ctor::Ctor>::build::<false>+0xee0>
   157a9:	cmp    %rax,0xa0(%rsp)
   157b1:	mov    0x1150(%rsp),%r11
   157b9:	mov    0x38(%rsp),%ebp
   157bd:	je     157f7 <<c30walk::ctor::Ctor>::build::<false>+0xf47>
   157bf:	mov    0x68(%rsp),%rsi
   157c4:	lea    (%rsi,%r8,2),%rsi
   157c8:	lea    (%r9,%rax,2),%rax
   157cc:	mov    0x40(%rsp),%rdi
   157d1:	lea    (%rax,%rdi,2),%rax
   157d5:	add    %rax,%rcx
   157d8:	nopl   0x0(%rax,%rax,1)
   157e0:	movzwl (%r10),%eax
   157e4:	add    %dx,%ax
   157e7:	add    $0x2,%r10
   157eb:	mov    %ax,(%rcx)
   157ee:	add    $0x2,%rcx
   157f2:	cmp    %rsi,%r10
   157f5:	jne    157e0 <<c30walk::ctor::Ctor>::build::<false>+0xf30>
   157f7:	mov    0xc0(%rsp),%rdx
   157ff:	add    %r8,%rdx
   15802:	lea    0x2(%r8),%eax
   15806:	mov    %rdx,%rcx
   15809:	sub    $0x1e,%rcx
   1580d:	cmovb  %rdx,%rcx
   15811:	cmovb  %r8d,%eax
   15815:	add    0x18(%rsp),%eax
   15819:	mov    %rcx,0x908(%rsp)
   15821:	mov    %eax,0x910(%rsp)
   15828:	cmpq   $0x1e,0x10(%rsp)
   1582e:	jae    15844 <<c30walk::ctor::Ctor>::build::<false>+0xf94>
   15830:	mov    0x20(%rsp),%r9
   15835:	mov    0x28(%rsp),%r10
   1583a:	mov    0x78(%rsp),%rax
   1583f:	jmp    14fbf <<c30walk::ctor::Ctor>::build::<false>+0x70f>
   15844:	mov    0x8(%rsp),%rdi
   15849:	inc    %rdi
   1584c:	mov    0x60(%rsp),%rax
   15851:	lea    -0x1(%rax),%rcx
   15855:	mov    0x20(%rsp),%r9
   1585a:	mov    0x28(%rsp),%r10
   1585f:	mov    0xb8(%rsp),%rsi
   15867:	test   %rcx,%rcx
   1586a:	je     158b3 <<c30walk::ctor::Ctor>::build::<false>+0x1003>
   1586c:	mov    %rdi,0x8(%rsp)
   15871:	cmpl   $0x0,0x3c(%rsp)
   15876:	mov    %rcx,0x18(%rsp)
   1587b:	je     15a30 <<c30walk::ctor::Ctor>::build::<false>+0x1180>
   15881:	lea    0xd8(%rsp),%rdi
   15889:	mov    0x8(%rsp),%rdx
   1588e:	call   42550 <<c30walk::ctor::W<false>>::complete_checked>
   15893:	mov    0x8(%rsp),%rdi
   15898:	pxor   %xmm4,%xmm4
   1589c:	mov    0x28(%rsp),%r10
   158a1:	mov    0x20(%rsp),%r9
   158a6:	mov    0x1150(%rsp),%r11
   158ae:	add    0x18(%rsp),%rdi
   158b3:	imul   $0xffffffffffffffe2,0x60(%rsp),%rdx
   158b9:	mov    %rdx,%rsi
   158bc:	add    0x10(%rsp),%rsi
   158c1:	je     15c77 <<c30walk::ctor::Ctor>::build::<false>+0x13c7>
   158c7:	mov    %rdi,%r9
   158ca:	mov    0x908(%rsp),%rdi
   158d2:	cmp    $0x1d,%rdi
   158d6:	ja     163ab <<c30walk::ctor::Ctor>::build::<false>+0x1afb>
   158dc:	mov    %r9,%rax
   158df:	shr    $0x6,%rax
   158e3:	mov    0xe8(%rsp),%rcx
   158eb:	cmp    %rcx,%rax
   158ee:	mov    0x40(%rsp),%r11
   158f3:	jae    163bc <<c30walk::ctor::Ctor>::build::<false>+0x1b0c>
   158f9:	mov    %rdi,0x18(%rsp)
   158fe:	mov    %rdi,%r8
   15901:	shl    $0x6,%r8
   15905:	lea    0xaf0f4(%rip),%rcx        # c4a00 <c30walk::ctor::PATTERNS>
   1590c:	mov    %r8,%r10
   1590f:	lea    (%rcx,%r8,1),%rdi
   15913:	mov    0x910(%rsp),%r8d
   1591b:	mov    0xe0(%rsp),%rcx
   15923:	mov    (%rcx,%rax,8),%rax
   15927:	bt     %r9,%rax
   1592b:	mov    %ebp,0x38(%rsp)
   1592f:	jae    15a88 <<c30walk::ctor::Ctor>::build::<false>+0x11d8>
   15935:	mov    0xd8(%rsp),%r11
   1593d:	mov    0xf8(%rsp),%rax
   15945:	shl    $0x6,%r9
   15949:	mov    0x3c(%rax,%r9,1),%ecx
   1594e:	and    $0xfffff,%ecx
   15954:	mov    0x10(%r11),%rax
   15958:	cmp    %rcx,%rax
   1595b:	jbe    163eb <<c30walk::ctor::Ctor>::build::<false>+0x1b3b>
   15961:	cmp    $0x21,%rsi
   15965:	mov    %r10,0x10(%rsp)
   1596a:	jae    16308 <<c30walk::ctor::Ctor>::build::<false>+0x1a58>
   15970:	cmp    $0x1e,%rsi
   15974:	ja     1631b <<c30walk::ctor::Ctor>::build::<false>+0x1a6b>
   1597a:	mov    %rdi,%r9
   1597d:	mov    0x8(%r11),%rdi
   15981:	mov    %ecx,%r11d
   15984:	shl    $0x7,%r11d
   15988:	add    %rdi,%r11
   1598b:	movzbl 0x70(%rsp),%ebp
   15990:	cmp    $0xc,%rsi
   15994:	jb     159f7 <<c30walk::ctor::Ctor>::build::<false>+0x1147>
   15996:	mov    0x88(%rsp),%r10
   1599e:	not    %r10
   159a1:	mov    0xb0(%rsp),%rax
   159a9:	add    %r10,%rax
   159ac:	mov    0x40(%rsp),%r10
   159b1:	shl    $0x4,%r14
   159b5:	add    %rax,%r14
   159b8:	add    %r10,%r14
   159bb:	add    %r14,%rdx
   159be:	lea    0xaf03b(%rip),%rax        # c4a00 <c30walk::ctor::PATTERNS>
   159c5:	mov    0x10(%rsp),%r14
   159ca:	add    %r14,%rax
   159cd:	lea    (%rax,%rdx,2),%rax
   159d1:	add    $0x2,%rax
   159d5:	cmp    %rax,%r11
   159d8:	jae    15c81 <<c30walk::ctor::Ctor>::build::<false>+0x13d1>
   159de:	mov    %ecx,%eax
   159e0:	shl    $0x7,%eax
   159e3:	add    %rdi,%rax
   159e6:	lea    (%rax,%rdx,4),%rax
   159ea:	add    $0x4,%rax
   159ee:	cmp    %rax,%r9
   159f1:	jae    15c81 <<c30walk::ctor::Ctor>::build::<false>+0x13d1>
   159f7:	xor    %r10d,%r10d
   159fa:	mov    0x10(%rsp),%rax
   159ff:	lea    (%rax,%r10,2),%rax
   15a03:	lea    0xaeff6(%rip),%rcx        # c4a00 <c30walk::ctor::PATTERNS>
   15a0a:	add    %rcx,%rax
   15a0d:	nopl   (%rax)
   15a10:	movzwl (%rax),%ecx
   15a13:	add    %r8d,%ecx
   15a16:	shl    $0x8,%ecx
   15a19:	or     %ebp,%ecx
   15a1b:	mov    %ecx,(%r11,%r10,4)
   15a1f:	inc    %r10
   15a22:	add    $0x2,%rax
   15a26:	cmp    %rsi,%r10
   15a29:	jb     15a10 <<c30walk::ctor::Ctor>::build::<false>+0x1160>
   15a2b:	jmp    15b25 <<c30walk::ctor::Ctor>::build::<false>+0x1275>
   15a30:	mov    0x908(%rsp),%rdi
   15a38:	cmp    $0x1d,%rdi
   15a3c:	ja     163fd <<c30walk::ctor::Ctor>::build::<false>+0x1b4d>
   15a42:	shl    $0x6,%rdi
   15a46:	lea    0xaefb3(%rip),%rax        # c4a00 <c30walk::ctor::PATTERNS>
   15a4d:	add    %rax,%rdi
   15a50:	mov    0x910(%rsp),%edx
   15a57:	mov    %edx,0x30(%rsp)
   15a5b:	shl    $0x8,%edx
   15a5e:	movzbl 0x70(%rsp),%eax
   15a63:	or     %edx,%eax
   15a65:	mov    0xf8(%rsp),%rdx
   15a6d:	mov    0x8(%rsp),%rsi
   15a72:	shl    $0x6,%rsi
   15a76:	cmp    $0x1,%rcx
   15a7a:	jne    15b70 <<c30walk::ctor::Ctor>::build::<false>+0x12c0>
   15a80:	xor    %r8d,%r8d
   15a83:	jmp    15c0c <<c30walk::ctor::Ctor>::build::<false>+0x135c>
   15a88:	mov    %r8d,%eax
   15a8b:	shl    $0x8,%eax
   15a8e:	movzbl 0x70(%rsp),%edx
   15a93:	or     %eax,%edx
   15a95:	mov    0xf8(%rsp),%rcx
   15a9d:	shl    $0x6,%r9
   15aa1:	mov    %r9,0x8(%rsp)
   15aa6:	mov    %edx,0x3c(%rcx,%r9,1)
   15aab:	cmp    $0x1f,%rsi
   15aaf:	jae    1632e <<c30walk::ctor::Ctor>::build::<false>+0x1a7e>
   15ab5:	imul   $0xffffffffffffffc4,0x60(%rsp),%rax
   15abb:	mov    0x10(%rsp),%rdx
   15ac0:	lea    (%rax,%rdx,2),%rax
   15ac4:	add    $0xfffffffffffffffe,%rax
   15ac8:	cmp    $0x6,%rax
   15acc:	jb     15af3 <<c30walk::ctor::Ctor>::build::<false>+0x1243>
   15ace:	mov    %r10,%r9
   15ad1:	mov    %r11,%r10
   15ad4:	mov    %rcx,%rdx
   15ad7:	lea    0xaef22(%rip),%r11        # c4a00 <c30walk::ctor::PATTERNS>
   15ade:	sub    %r11,%rdx
   15ae1:	add    0x8(%rsp),%rdx
   15ae6:	sub    %r9,%rdx
   15ae9:	cmp    $0x20,%rdx
   15aed:	jae    15d33 <<c30walk::ctor::Ctor>::build::<false>+0x1483>
   15af3:	mov    %rdi,%rax
   15af6:	xor    %r14d,%r14d
   15af9:	lea    (%rdi,%rsi,2),%rdx
   15afd:	mov    0x8(%rsp),%r9
   15b02:	lea    (%r9,%r14,2),%r9
   15b06:	add    %r9,%rcx
   15b09:	nopl   0x0(%rax)
   15b10:	movzwl (%rax),%r9d
   15b14:	add    $0x2,%rax
   15b18:	mov    %r9w,(%rcx)
   15b1c:	add    $0x2,%rcx
   15b20:	cmp    %rdx,%rax
   15b23:	jne    15b10 <<c30walk::ctor::Ctor>::build::<false>+0x1260>
   15b25:	mov    0x18(%rsp),%rdx
   15b2a:	add    %rsi,%rdx
   15b2d:	lea    0x2(%rsi),%eax
   15b30:	mov    %rdx,%rcx
   15b33:	sub    $0x1e,%rcx
   15b37:	cmovb  %rdx,%rcx
   15b3b:	cmovb  %esi,%eax
   15b3e:	add    %r8d,%eax
   15b41:	mov    %rcx,0x908(%rsp)
   15b49:	mov    %eax,0x910(%rsp)
   15b50:	mov    0x1150(%rsp),%r11
   15b58:	mov    0x20(%rsp),%r9
   15b5d:	mov    0x28(%rsp),%r10
   15b62:	mov    0x38(%rsp),%ebp
   15b66:	mov    0x78(%rsp),%rax
   15b6b:	jmp    14fbf <<c30walk::ctor::Ctor>::build::<false>+0x70f>
   15b70:	mov    %rcx,%r9
   15b73:	and    $0xfffffffffffffffe,%r9
   15b77:	lea    (%rdx,%rsi,1),%r10
   15b7b:	add    $0x7c,%r10
   15b7f:	xor    %r8d,%r8d
   15b82:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   15b90:	movdqu 0x2c(%rdi),%xmm0
   15b95:	movdqu %xmm0,-0x50(%r10)
   15b9b:	movdqa (%rdi),%xmm1
   15b9f:	movdqa 0x10(%rdi),%xmm2
   15ba4:	movdqa 0x20(%rdi),%xmm3
   15ba9:	movdqa %xmm3,-0x5c(%r10)
   15baf:	movdqa %xmm2,-0x6c(%r10)
   15bb5:	movdqa %xmm1,-0x7c(%r10)
   15bbb:	mov    %eax,-0x40(%r10)
   15bbf:	add    $0x2,%r8
   15bc3:	movdqa %xmm1,-0x3c(%r10)
   15bc9:	movdqa %xmm2,-0x2c(%r10)
   15bcf:	movdqa %xmm3,-0x1c(%r10)
   15bd5:	movdqu %xmm0,-0x10(%r10)
   15bdb:	lea    0x2000(%rax),%r11d
   15be2:	mov    %r11d,(%r10)
   15be5:	add    $0x4000,%eax
   15bea:	sub    $0xffffffffffffff80,%r10
   15bee:	cmp    %r8,%r9
   15bf1:	jne    15b90 <<c30walk::ctor::Ctor>::build::<false>+0x12e0>
   15bf3:	testb  $0x1,0x18(%rsp)
   15bf8:	mov    0x1150(%rsp),%r11
   15c00:	mov    0x20(%rsp),%r9
   15c05:	mov    0x28(%rsp),%r10
   15c0a:	je     15c44 <<c30walk::ctor::Ctor>::build::<false>+0x1394>
   15c0c:	add    %rsi,%rdx
   15c0f:	shl    $0x6,%r8
   15c13:	movups 0x2c(%rdi),%xmm0
   15c17:	movups %xmm0,0x2c(%rdx,%r8,1)
   15c1d:	movdqa (%rdi),%xmm0
   15c21:	movdqa 0x10(%rdi),%xmm1
   15c26:	movdqa 0x20(%rdi),%xmm2
   15c2b:	movdqa %xmm2,0x20(%rdx,%r8,1)
   15c32:	movdqa %xmm1,0x10(%rdx,%r8,1)
   15c39:	movdqa %xmm0,(%rdx,%r8,1)
   15c3f:	mov    %eax,0x3c(%rdx,%r8,1)
   15c44:	mov    0x18(%rsp),%rax
   15c49:	mov    %eax,%ecx
   15c4b:	shl    $0x5,%ecx
   15c4e:	mov    0x30(%rsp),%edx
   15c52:	add    %ecx,%edx
   15c54:	mov    %edx,0x910(%rsp)
   15c5b:	mov    0x8(%rsp),%rdi
   15c60:	add    %rax,%rdi
   15c63:	imul   $0xffffffffffffffe2,0x60(%rsp),%rdx
   15c69:	mov    %rdx,%rsi
   15c6c:	add    0x10(%rsp),%rsi
   15c71:	jne    158c7 <<c30walk::ctor::Ctor>::build::<false>+0x1017>
   15c77:	mov    0x78(%rsp),%rax
   15c7c:	jmp    14fbf <<c30walk::ctor::Ctor>::build::<false>+0x70f>
   15c81:	mov    %r10,%r14
   15c84:	mov    %esi,%r10d
   15c87:	and    $0x18,%r10d
   15c8b:	movd   %ebp,%xmm0
   15c8f:	pshufd $0x0,%xmm0,%xmm0
   15c94:	movd   %r8d,%xmm1
   15c99:	pshufd $0x0,%xmm1,%xmm1
   15c9e:	add    %r15,%r14
   15ca1:	mov    %r14,%rax
   15ca4:	movabs $0x8888888888888889,%rdx
   15cae:	mul    %rdx
   15cb1:	shr    $0x4,%edx
   15cb4:	lea    (%r14,%rdx,2),%eax
   15cb8:	and    $0x18,%eax
   15cbb:	lea    0xaed3e(%rip),%rdx        # c4a00 <c30walk::ctor::PATTERNS>
   15cc2:	mov    0x10(%rsp),%r9
   15cc7:	add    %r9,%rdx
   15cca:	add    $0x8,%rdx
   15cce:	shl    $0x7,%ecx
   15cd1:	add    %rdi,%rcx
   15cd4:	add    $0x10,%rcx
   15cd8:	xor    %r14d,%r14d
   15cdb:	nopl   0x0(%rax,%rax,1)
   15ce0:	movq   -0x8(%rdx,%r14,2),%xmm2
   15ce7:	movq   (%rdx,%r14,2),%xmm3
   15ced:	punpcklwd %xmm4,%xmm2
   15cf1:	punpcklwd %xmm4,%xmm3
   15cf5:	paddd  %xmm1,%xmm2
   15cf9:	paddd  %xmm1,%xmm3
   15cfd:	pslld  $0x8,%xmm2
   15d02:	pslld  $0x8,%xmm3
   15d07:	por    %xmm0,%xmm2
   15d0b:	por    %xmm0,%xmm3
   15d0f:	movdqu %xmm2,-0x10(%rcx,%r14,4)
   15d16:	movdqu %xmm3,(%rcx,%r14,4)
   15d1c:	add    $0x8,%r14
   15d20:	cmp    %r14,%rax
   15d23:	jne    15ce0 <<c30walk::ctor::Ctor>::build::<false>+0x1430>
   15d25:	cmp    %r10,%rsi
   15d28:	je     15b25 <<c30walk::ctor::Ctor>::build::<false>+0x1275>
   15d2e:	jmp    159fa <<c30walk::ctor::Ctor>::build::<false>+0x114a>
   15d33:	mov    %rax,%r11
   15d36:	shr    $1,%r11
   15d39:	inc    %r11
   15d3c:	cmp    $0x1e,%rax
   15d40:	jae    15d4a <<c30walk::ctor::Ctor>::build::<false>+0x149a>
   15d42:	xor    %r14d,%r14d
   15d45:	jmp    15dd9 <<c30walk::ctor::Ctor>::build::<false>+0x1529>
   15d4a:	mov    %r11,0x10(%rsp)
   15d4f:	mov    %r11,%r14
   15d52:	and    $0xfffffffffffffff0,%r14
   15d56:	lea    0xaeca3(%rip),%rax        # c4a00 <c30walk::ctor::PATTERNS>
   15d5d:	lea    (%r9,%rax,1),%rbp
   15d61:	add    $0x10,%rbp
   15d65:	lea    (%r10,%r15,1),%rax
   15d69:	lea    (%rax,%rax,1),%r11
   15d6d:	movabs $0x8888888888888889,%rdx
   15d77:	mul    %rdx
   15d7a:	shr    $0x4,%rdx
   15d7e:	imul   $0x3c,%rdx,%rax
   15d82:	sub    %rax,%r11
   15d85:	add    $0xfffffffffffffffe,%r11
   15d89:	shr    $1,%r11
   15d8c:	inc    %r11
   15d8f:	and    $0xfffffffffffffff0,%r11
   15d93:	mov    0x8(%rsp),%rax
   15d98:	add    %rcx,%rax
   15d9b:	add    $0x10,%rax
   15d9f:	xor    %edx,%edx
   15da1:	movdqa -0x10(%rbp,%rdx,2),%xmm0
   15da7:	movdqa 0x0(%rbp,%rdx,2),%xmm1
   15dad:	movdqu %xmm0,-0x10(%rax,%rdx,2)
   15db3:	movdqu %xmm1,(%rax,%rdx,2)
   15db8:	add    $0x10,%rdx
   15dbc:	cmp    %rdx,%r11
   15dbf:	jne    15da1 <<c30walk::ctor::Ctor>::build::<false>+0x14f1>
   15dc1:	mov    0x10(%rsp),%r11
   15dc6:	cmp    %r14,%r11
   15dc9:	je     15b25 <<c30walk::ctor::Ctor>::build::<false>+0x1275>
   15dcf:	test   $0xc,%r11b
   15dd3:	je     15e64 <<c30walk::ctor::Ctor>::build::<false>+0x15b4>
   15dd9:	movabs $0x8888888888888889,%rdx
   15de3:	mov    %r10,%rax
   15de6:	lea    (%r9,%r14,2),%r9
   15dea:	add    %r15,%rax
   15ded:	lea    (%rax,%rax,1),%r15
   15df1:	mul    %rdx
   15df4:	shr    $0x4,%rdx
   15df8:	imul   $0x3c,%rdx,%rax
   15dfc:	sub    %rax,%r15
   15dff:	add    $0xfffffffffffffffe,%r15
   15e03:	shr    $1,%r15
   15e06:	inc    %r15
   15e09:	and    $0xfffffffffffffffc,%r15
   15e0d:	sub    %r14,%r15
   15e10:	mov    0x8(%rsp),%rax
   15e15:	lea    (%rax,%r14,2),%rdx
   15e19:	mov    %r11,%r10
   15e1c:	mov    %r11,%r14
   15e1f:	and    $0xfffffffffffffffc,%r14
   15e23:	lea    (%rdi,%r14,2),%rax
   15e27:	lea    0xaebd2(%rip),%r11        # c4a00 <c30walk::ctor::PATTERNS>
   15e2e:	add    %r11,%r9
   15e31:	add    %rcx,%rdx
   15e34:	xor    %r11d,%r11d
   15e37:	mov    (%r9,%r11,2),%rbp
   15e3b:	mov    %rbp,(%rdx,%r11,2)
   15e3f:	add    $0x4,%r11
   15e43:	cmp    %r11,%r15
   15e46:	jne    15e37 <<c30walk::ctor::Ctor>::build::<false>+0x1587>
   15e48:	cmp    %r14,%r10
   15e4b:	jne    15af9 <<c30walk::ctor::Ctor>::build::<false>+0x1249>
   15e51:	jmp    15b25 <<c30walk::ctor::Ctor>::build::<false>+0x1275>
   15e56:	mov    0x68(%rsp),%rsi
   15e5b:	lea    (%rsi,%rax,2),%r10
   15e5f:	jmp    157bf <<c30walk::ctor::Ctor>::build::<false>+0xf0f>
   15e64:	lea    (%rdi,%r14,2),%rax
   15e68:	jmp    15af9 <<c30walk::ctor::Ctor>::build::<false>+0x1249>
   15e6d:	lea    0xd8(%rsp),%rdi
   15e75:	mov    0x8(%rsp),%rsi
   15e7a:	mov    %r10,%rdx
   15e7d:	mov    %eax,%ecx
   15e7f:	call   8a10 <<c30walk::ctor::W<false>>::promote>
   15e84:	mov    0x30(%rsp),%r8
   15e89:	mov    0x40(%rsp),%r10
   15e8e:	pxor   %xmm4,%xmm4
   15e92:	mov    0x1150(%rsp),%r11
   15e9a:	jmp    15427 <<c30walk::ctor::Ctor>::build::<false>+0xb77>
   15e9f:	mov    0xf8(%rsp),%r14
   15ea7:	mov    0xe8(%rsp),%r8
   15eaf:	mov    0xd8(%rsp),%rdx
   15eb7:	mov    0xe0(%rsp),%rax
   15ebf:	mov    %rax,0x18(%rsp)
   15ec4:	mov    0x910(%rsp),%ebx
   15ecb:	mov    0x908(%rsp),%r15
   15ed3:	mov    %rdx,0x10(%rsp)
   15ed8:	jmp    15f35 <<c30walk::ctor::Ctor>::build::<false>+0x1685>
   15eda:	nopw   0x0(%rax,%rax,1)
   15ee0:	and    $0xfffff,%eax
   15ee5:	mov    %eax,%edi
   15ee7:	mov    0x10(%rdx),%rsi
   15eeb:	cmp    %rdi,%rsi
   15eee:	jbe    16051 <<c30walk::ctor::Ctor>::build::<false>+0x17a1>
   15ef4:	shl    $0x7,%rdi
   15ef8:	add    0x8(%rdx),%rdi
   15efc:	mov    %ebp,(%rdi,%r13,4)
   15f00:	lea    0x1(%r15),%rax
   15f04:	add    $0xffffffffffffffe3,%r15
   15f08:	xor    %ecx,%ecx
   15f0a:	cmp    $0x1e,%rax
   15f0e:	setae  %cl
   15f11:	cmovb  %rax,%r15
   15f15:	lea    (%rbx,%rcx,2),%ebx
   15f18:	inc    %ebx
   15f1a:	mov    %r15,0x908(%rsp)
   15f22:	mov    %ebx,0x910(%rsp)
   15f29:	inc    %r12
   15f2c:	cmp    %r12,%r9
   15f2f:	je     14f58 <<c30walk::ctor::Ctor>::build::<false>+0x6a8>
   15f35:	movzbl (%r10,%r12,1),%eax
   15f3a:	mov    0x108(%rsp,%rax,4),%esi
   15f41:	cmp    0x508(%rsp,%rax,4),%esi
   15f48:	jae    14f83 <<c30walk::ctor::Ctor>::build::<false>+0x6d3>
   15f4e:	mov    %esi,%r13d
   15f51:	and    $0x1f,%r13d
   15f55:	xor    %ecx,%ecx
   15f57:	cmp    $0x1d,%r13d
   15f5b:	sete   %cl
   15f5e:	lea    (%rsi,%rcx,2),%ecx
   15f61:	inc    %ecx
   15f63:	mov    %ecx,0x108(%rsp,%rax,4)
   15f6a:	shr    $0x5,%esi
   15f6d:	mov    %ebx,%ebp
   15f6f:	shl    $0x8,%ebp
   15f72:	or     %eax,%ebp
   15f74:	test   %r13d,%r13d
   15f77:	je     15fc0 <<c30walk::ctor::Ctor>::build::<false>+0x1710>
   15f79:	mov    %rsi,%rcx
   15f7c:	shl    $0x6,%rcx
   15f80:	mov    0x3c(%r14,%rcx,1),%eax
   15f85:	test   $0x10000000,%eax
   15f8a:	jne    15ee0 <<c30walk::ctor::Ctor>::build::<false>+0x1630>
   15f90:	mov    %eax,%edi
   15f92:	shr    $0x8,%edi
   15f95:	mov    %ebx,%edx
   15f97:	sub    %edi,%edx
   15f99:	cmp    $0xfffe,%edx
   15f9f:	jae    1600f <<c30walk::ctor::Ctor>::build::<false>+0x175f>
   15fa1:	add    %r14,%rcx
   15fa4:	mov    %dx,(%rcx,%r13,2)
   15fa9:	mov    0x10(%rsp),%rdx
   15fae:	jmp    15f00 <<c30walk::ctor::Ctor>::build::<false>+0x1650>
   15fb3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   15fc0:	mov    %esi,%edi
   15fc2:	shr    $0x6,%edi
   15fc5:	cmp    %r8,%rdi
   15fc8:	jae    16388 <<c30walk::ctor::Ctor>::build::<false>+0x1ad8>
   15fce:	mov    0x18(%rsp),%rax
   15fd3:	mov    (%rax,%rdi,8),%rcx
   15fd7:	mov    %rsi,%rax
   15fda:	shl    $0x6,%rax
   15fde:	add    %r14,%rax
   15fe1:	bt     %rsi,%rcx
   15fe5:	jae    16002 <<c30walk::ctor::Ctor>::build::<false>+0x1752>
   15fe7:	mov    0x3c(%rax),%eax
   15fea:	mov    $0xfffff,%ecx
   15fef:	and    %ecx,%eax
   15ff1:	mov    %eax,%edi
   15ff3:	mov    0x10(%rdx),%rsi
   15ff7:	cmp    %rdi,%rsi
   15ffa:	ja     15ef4 <<c30walk::ctor::Ctor>::build::<false>+0x1644>
   16000:	jmp    16051 <<c30walk::ctor::Ctor>::build::<false>+0x17a1>
   16002:	mov    %ebp,0x3c(%rax)
   16005:	movw   $0x0,(%rax)
   1600a:	jmp    15f00 <<c30walk::ctor::Ctor>::build::<false>+0x1650>
   1600f:	lea    0xd8(%rsp),%rdi
   16017:	mov    %r13,%rdx
   1601a:	mov    %eax,%ecx
   1601c:	mov    %r8,0x8(%rsp)
   16021:	call   8a10 <<c30walk::ctor::W<false>>::promote>
   16026:	mov    0x8(%rsp),%r8
   1602b:	mov    0x28(%rsp),%r10
   16030:	mov    0x20(%rsp),%r9
   16035:	mov    0x1150(%rsp),%r11
   1603d:	mov    0x10(%rsp),%rdx
   16042:	mov    %eax,%edi
   16044:	mov    0x10(%rdx),%rsi
   16048:	cmp    %rdi,%rsi
   1604b:	ja     15ef4 <<c30walk::ctor::Ctor>::build::<false>+0x1644>
   16051:	lea    0xc9838(%rip),%rdx        # df890 <__do_global_dtors_aux_fini_array_entry+0x1738>
   16058:	call   9d2b <core::panicking::panic_bounds_check>
   1605d:	xor    %ecx,%ecx
   1605f:	mov    0x48(%rsp),%rsi
   16064:	test   %rsi,%rsi
   16067:	setne  %al
   1606a:	mov    0x20(%rsp),%rdx
   1606f:	mov    0x90(%rsp),%rbx
   16077:	je     160c8 <<c30walk::ctor::Ctor>::build::<false>+0x1818>
   16079:	mov    %al,%cl
   1607b:	mov    %rsi,%rax
   1607e:	sub    %rcx,%rax
   16081:	imul   $0xffffffffffffffe2,%rax,%rcx
   16085:	add    %rdx,%rcx
   16088:	cmp    $0x1e,%rcx
   1608c:	jae    160c8 <<c30walk::ctor::Ctor>::build::<false>+0x1818>
   1608e:	lea    (%rbx,%rsi,4),%rcx
   16092:	lea    (%rcx,%rdx,2),%rdi
   16096:	add    $0xfffffffffffffffc,%rdi
   1609a:	lea    (%rax,%rax,1),%rcx
   1609e:	shl    $0x5,%rax
   160a2:	sub    %rcx,%rax
   160a5:	sub    %rdx,%rax
   160a8:	lea    0x3c(,%rax,2),%rdx
   160b0:	mov    $0xff,%esi
   160b5:	call   *0xccd7d(%rip)        # e2e38 <memset@GLIBC_2.2.5>
   160bb:	mov    0x48(%rsp),%rsi
   160c0:	mov    0x1150(%rsp),%r11
   160c8:	shl    $0x6,%rsi
   160cc:	pcmpeqd %xmm0,%xmm0
   160d0:	movdqu %xmm0,0x2c(%rbx,%rsi,1)
   160d6:	movdqa %xmm0,0x20(%rbx,%rsi,1)
   160dc:	movdqa %xmm0,0x10(%rbx,%rsi,1)
   160e2:	movdqa %xmm0,(%rbx,%rsi,1)
   160e7:	movl   $0x100fffff,0x3c(%rbx,%rsi,1)
   160ef:	mov    0xd0(%rsp),%rax
   160f7:	mov    0x8(%rax),%rdx
   160fb:	mov    0x10(%rax),%rcx
   160ff:	mov    0x8(%r11),%r8
   16103:	mov    0x10(%r11),%r9
   16107:	lea    0xd8(%rsp),%rdi
   1610f:	mov    %rbx,%rsi
   16112:	mov    %r11,%rbx
   16115:	call   49830 <c30walk::ctor::canonicalise>
   1611a:	mov    0x50(%rsp),%rax
   1611f:	mov    0xc8(%rsp),%rcx
   16127:	mov    %rcx,0x10(%rax)
   1612b:	mov    0x8(%rbx),%rax
   1612f:	and    $0x3f,%rax
   16133:	mov    %rax,0xd8(%rsp)
   1613b:	jne    16341 <<c30walk::ctor::Ctor>::build::<false>+0x1a91>
   16141:	mov    $0x1,%al
   16143:	jmp    14f8d <<c30walk::ctor::Ctor>::build::<false>+0x6dd>
   16148:	xor    %r12d,%r12d
   1614b:	mov    0x48(%rsp),%rcx
   16150:	mov    (%r8),%rax
   16153:	lea    0x1(%rcx),%rbp
   16157:	cmp    %rcx,%rax
   1615a:	ja     14ac8 <<c30walk::ctor::Ctor>::build::<false>+0x218>
   16160:	test   %rax,%rax
   16163:	je     16174 <<c30walk::ctor::Ctor>::build::<false>+0x18c4>
   16165:	mov    0x8(%r8),%rdi
   16169:	call   *0xccc01(%rip)        # e2d70 <free@GLIBC_2.2.5>
   1616f:	mov    0x50(%rsp),%r8
   16174:	movq   $0x0,(%r8)
   1617b:	movq   $0x40,0x8(%r8)
   16183:	movq   $0x0,0x10(%r8)
   1618b:	mov    $0x40,%edx
   16190:	mov    %r8,%rdi
   16193:	mov    %rbp,%rsi
   16196:	call   82f0 <<alloc::raw_vec::RawVecInner>::grow_exact>
   1619b:	mov    0x50(%rsp),%r8
   161a0:	cmp    $0xffffffffffffffff,%rax
   161a4:	mov    0x1150(%rsp),%r9
   161ac:	mov    %r15,%rdi
   161af:	je     14ac8 <<c30walk::ctor::Ctor>::build::<false>+0x218>
   161b5:	jmp    1620f <<c30walk::ctor::Ctor>::build::<false>+0x195f>
   161b7:	test   %rax,%rax
   161ba:	je     161ce <<c30walk::ctor::Ctor>::build::<false>+0x191e>
   161bc:	mov    0x8(%r9),%rdi
   161c0:	call   *0xccbaa(%rip)        # e2d70 <free@GLIBC_2.2.5>
   161c6:	mov    0x1150(%rsp),%r9
   161ce:	movq   $0x0,(%r9)
   161d5:	movq   $0x40,0x8(%r9)
   161dd:	movq   $0x0,0x10(%r9)
   161e5:	mov    $0x80,%edx
   161ea:	mov    %r9,%rdi
   161ed:	mov    %r12,%rsi
   161f0:	call   82f0 <<alloc::raw_vec::RawVecInner>::grow_exact>
   161f5:	mov    0x1150(%rsp),%r9
   161fd:	cmp    $0xffffffffffffffff,%rax
   16201:	mov    0x50(%rsp),%r8
   16206:	mov    %r15,%rdi
   16209:	je     14ad4 <<c30walk::ctor::Ctor>::build::<false>+0x224>
   1620f:	mov    %rax,%rdi
   16212:	mov    %rdx,%rsi
   16215:	call   9a31 <alloc::raw_vec::handle_error>
   1621a:	cmp    %r9,%r12
   1621d:	jbe    14f4f <<c30walk::ctor::Ctor>::build::<false>+0x69f>
   16223:	lea    0xc80fe(%rip),%rcx        # de328 <__do_global_dtors_aux_fini_array_entry+0x1d0>
   1622a:	mov    %r12,%rdi
   1622d:	mov    %r9,%rsi
   16230:	mov    %r9,%rdx
   16233:	call   9de0 <core::slice::index::slice_index_fail>
   16238:	lea    0xc9bf1(%rip),%rcx        # dfe30 <__do_global_dtors_aux_fini_array_entry+0x1cd8>
   1623f:	mov    %r12,%rdi
   16242:	mov    %r9,%rdx
   16245:	call   9de0 <core::slice::index::slice_index_fail>
   1624a:	lea    0xc9bdf(%rip),%rcx        # dfe30 <__do_global_dtors_aux_fini_array_entry+0x1cd8>
   16251:	mov    %rdx,%rdi
   16254:	mov    %r9,%rdx
   16257:	call   9de0 <core::slice::index::slice_index_fail>
   1625c:	lea    0xc9bcd(%rip),%rcx        # dfe30 <__do_global_dtors_aux_fini_array_entry+0x1cd8>
   16263:	mov    %rsi,%rdi
   16266:	mov    %rax,%rsi
   16269:	mov    %r9,%rdx
   1626c:	call   9de0 <core::slice::index::slice_index_fail>
   16271:	lea    0xa7810(%rip),%rsi        # bda88 <_fini+0x11cc>
   16278:	lea    0xadd65(%rip),%rdx        # c3fe4 <_fini+0x7728>
   1627f:	lea    0xc808a(%rip),%r8        # de310 <__do_global_dtors_aux_fini_array_entry+0x1b8>
   16286:	lea    0xd8(%rsp),%rdi
   1628e:	mov    $0x2f,%ecx
   16293:	call   9d67 <core::panicking::assert_failed::<usize, usize>>
   16298:	lea    0xc80a1(%rip),%rcx        # de340 <__do_global_dtors_aux_fini_array_entry+0x1e8>
   1629f:	mov    %rdx,%rdi
   162a2:	mov    %r14,%rsi
   162a5:	mov    %r9,%rdx
   162a8:	call   9de0 <core::slice::index::slice_index_fail>
   162ad:	mov    $0x8,%ecx
   162b2:	mov    $0x8,%r8d
   162b8:	mov    %r15,%rdi
   162bb:	xor    %esi,%esi
   162bd:	mov    %r14,%rdx
   162c0:	call   71f0 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
   162c5:	mov    %r15,%rdi
   162c8:	mov    0x1150(%rsp),%r9
   162d0:	mov    0x50(%rsp),%r8
   162d5:	mov    0x10(%r15),%r13
   162d9:	jmp    14af7 <<c30walk::ctor::Ctor>::build::<false>+0x247>
   162de:	lea    0xc9683(%rip),%rcx        # df968 <__do_global_dtors_aux_fini_array_entry+0x1810>
   162e5:	mov    $0x20,%edx
   162ea:	mov    %r10,%rdi
   162ed:	call   9de0 <core::slice::index::slice_index_fail>
   162f2:	lea    0xc9657(%rip),%rcx        # df950 <__do_global_dtors_aux_fini_array_entry+0x17f8>
   162f9:	mov    $0x1e,%edx
   162fe:	xor    %edi,%edi
   16300:	mov    %r8,%rsi
   16303:	call   9de0 <core::slice::index::slice_index_fail>
   16308:	lea    0xc9659(%rip),%rcx        # df968 <__do_global_dtors_aux_fini_array_entry+0x1810>
   1630f:	mov    $0x20,%edx
   16314:	xor    %edi,%edi
   16316:	call   9de0 <core::slice::index::slice_index_fail>
   1631b:	lea    0xc962e(%rip),%rcx        # df950 <__do_global_dtors_aux_fini_array_entry+0x17f8>
   16322:	mov    $0x1e,%edx
   16327:	xor    %edi,%edi
   16329:	call   9de0 <core::slice::index::slice_index_fail>
   1632e:	lea    0xc95d3(%rip),%rcx        # df908 <__do_global_dtors_aux_fini_array_entry+0x17b0>
   16335:	mov    $0x1e,%edx
   1633a:	xor    %edi,%edi
   1633c:	call   9de0 <core::slice::index::slice_index_fail>
   16341:	lea    0xa7740(%rip),%rsi        # bda88 <_fini+0x11cc>
   16348:	lea    0xadc7b(%rip),%rdx        # c3fca <_fini+0x770e>
   1634f:	lea    0xc7fa2(%rip),%r8        # de2f8 <__do_global_dtors_aux_fini_array_entry+0x1a0>
   16356:	lea    0xd8(%rsp),%rdi
   1635e:	mov    $0x35,%ecx
   16363:	call   9d67 <core::panicking::assert_failed::<usize, usize>>
   16368:	lea    0xc94f1(%rip),%rdx        # df860 <__do_global_dtors_aux_fini_array_entry+0x1708>
   1636f:	mov    0x18(%rsp),%rsi
   16374:	call   9d2b <core::panicking::panic_bounds_check>
   16379:	lea    0xc7fd8(%rip),%rdx        # de358 <__do_global_dtors_aux_fini_array_entry+0x200>
   16380:	mov    %r13,%rdi
   16383:	call   9d2b <core::panicking::panic_bounds_check>
   16388:	lea    0xc7fc9(%rip),%rdx        # de358 <__do_global_dtors_aux_fini_array_entry+0x200>
   1638f:	mov    %r8,%rsi
   16392:	call   9d2b <core::panicking::panic_bounds_check>
   16397:	lea    0xc9552(%rip),%rdx        # df8f0 <__do_global_dtors_aux_fini_array_entry+0x1798>
   1639e:	mov    %rsi,%rdi
   163a1:	mov    $0x1e,%esi
   163a6:	call   9d2b <core::panicking::panic_bounds_check>
   163ab:	lea    0xc953e(%rip),%rdx        # df8f0 <__do_global_dtors_aux_fini_array_entry+0x1798>
   163b2:	mov    $0x1e,%esi
   163b7:	call   9d2b <core::panicking::panic_bounds_check>
   163bc:	lea    0xc7f95(%rip),%rdx        # de358 <__do_global_dtors_aux_fini_array_entry+0x200>
   163c3:	mov    %rax,%rdi
   163c6:	mov    %rcx,%rsi
   163c9:	call   9d2b <core::panicking::panic_bounds_check>
   163ce:	lea    0xc954b(%rip),%rdx        # df920 <__do_global_dtors_aux_fini_array_entry+0x17c8>
   163d5:	mov    $0x1e,%esi
   163da:	call   9d2b <core::panicking::panic_bounds_check>
   163df:	lea    0xc9552(%rip),%rdx        # df938 <__do_global_dtors_aux_fini_array_entry+0x17e0>
   163e6:	call   9d2b <core::panicking::panic_bounds_check>
   163eb:	lea    0xc9546(%rip),%rdx        # df938 <__do_global_dtors_aux_fini_array_entry+0x17e0>
   163f2:	mov    %rcx,%rdi
   163f5:	mov    %rax,%rsi
   163f8:	call   9d2b <core::panicking::panic_bounds_check>
   163fd:	lea    0xc94d4(%rip),%rdx        # df8d8 <__do_global_dtors_aux_fini_array_entry+0x1780>
   16404:	mov    $0x1e,%esi
   16409:	call   9d2b <core::panicking::panic_bounds_check>
