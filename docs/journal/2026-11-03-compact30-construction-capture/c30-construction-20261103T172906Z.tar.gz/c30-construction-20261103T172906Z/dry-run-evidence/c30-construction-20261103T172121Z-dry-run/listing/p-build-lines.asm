
/home/louis/dev/mibz2/target/c30-construction-pin/target/rust-1.97.0/release/examples/c30walk:     file format elf64-x86-64


Disassembly of section .text:

000000000005feb0 <c30walk::cbuild::p_build>:
c30walk::cbuild::p_build:
/home/louis/dev/mibz2/target/c30-construction-pin/examples/c30walk/cbuild.rs:85
   5feb0:	jmp    7a120 <mibz2::bwt::build>
