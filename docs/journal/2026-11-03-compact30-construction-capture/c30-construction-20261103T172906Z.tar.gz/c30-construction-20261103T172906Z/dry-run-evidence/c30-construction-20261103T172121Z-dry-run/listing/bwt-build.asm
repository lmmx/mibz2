# mibz2::bwt::build
# size 0xe97

/home/louis/dev/mibz2/target/c30-construction-pin/target/rust-1.97.0/release/examples/c30walk:     file format elf64-x86-64


Disassembly of section .text:

000000000007a120 <mibz2::bwt::build>:
   7a120:	push   %rbp
   7a121:	push   %r15
   7a123:	push   %r14
   7a125:	push   %r13
   7a127:	push   %r12
   7a129:	push   %rbx
   7a12a:	sub    $0x808,%rsp
   7a131:	mov    %rdx,%r15
   7a134:	mov    %rsi,%rbx
   7a137:	mov    %rdi,%r14
   7a13a:	movq   $0x0,0x10(%rcx)
   7a142:	cmp    $0xffffff,%rsi
   7a149:	ja     7a2c6 <mibz2::bwt::build+0x1a6>
   7a14f:	pxor   %xmm0,%xmm0
   7a153:	xor    %eax,%eax
   7a155:	pxor   %xmm2,%xmm2
   7a159:	pxor   %xmm1,%xmm1
   7a15d:	nopl   (%rax)
   7a160:	movq   (%r15,%rax,4),%xmm3
   7a166:	movq   0x8(%r15,%rax,4),%xmm4
   7a16d:	punpckldq %xmm0,%xmm3
   7a171:	paddq  %xmm2,%xmm3
   7a175:	punpckldq %xmm0,%xmm4
   7a179:	paddq  %xmm1,%xmm4
   7a17d:	movq   0x10(%r15,%rax,4),%xmm2
   7a184:	movq   0x18(%r15,%rax,4),%xmm1
   7a18b:	punpckldq %xmm0,%xmm2
   7a18f:	paddq  %xmm3,%xmm2
   7a193:	punpckldq %xmm0,%xmm1
   7a197:	paddq  %xmm4,%xmm1
   7a19b:	add    $0x8,%rax
   7a19f:	cmp    $0x100,%rax
   7a1a5:	jne    7a160 <mibz2::bwt::build+0x40>
   7a1a7:	paddq  %xmm2,%xmm1
   7a1ab:	pshufd $0xee,%xmm1,%xmm0
   7a1b0:	paddq  %xmm1,%xmm0
   7a1b4:	movq   %xmm0,%rax
   7a1b9:	cmp    %rbx,%rax
   7a1bc:	jne    7a2c6 <mibz2::bwt::build+0x1a6>
   7a1c2:	mov    %rcx,%r12
   7a1c5:	lea    0x8(%rsp),%rdi
   7a1ca:	xor    %ebp,%ebp
   7a1cc:	mov    0x68c65(%rip),%r13        # e2e38 <memset@GLIBC_2.2.5>
   7a1d3:	mov    $0x400,%edx
   7a1d8:	xor    %esi,%esi
   7a1da:	call   *%r13
   7a1dd:	lea    0x408(%rsp),%rdi
   7a1e5:	mov    $0x400,%edx
   7a1ea:	xor    %esi,%esi
   7a1ec:	call   *%r13
   7a1ef:	mov    $0x1,%eax
   7a1f4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   7a200:	mov    %ebp,0x404(%rsp,%rax,4)
   7a207:	add    -0x4(%r15,%rax,4),%ebp
   7a20c:	mov    %ebp,0x4(%rsp,%rax,4)
   7a210:	mov    %ebp,0x408(%rsp,%rax,4)
   7a217:	add    (%r15,%rax,4),%ebp
   7a21b:	mov    %ebp,0x8(%rsp,%rax,4)
   7a21f:	add    $0x2,%rax
   7a223:	cmp    $0x101,%rax
   7a229:	jne    7a200 <mibz2::bwt::build+0xe0>
   7a22b:	mov    %r12,%rcx
   7a22e:	cmp    (%r12),%rbx
   7a232:	ja     7a386 <mibz2::bwt::build+0x266>
   7a238:	mov    0x8(%rcx),%rdx
   7a23c:	xor    %r8d,%r8d
   7a23f:	cmp    $0x10,%rbx
   7a243:	jae    7a3b2 <mibz2::bwt::build+0x292>
   7a249:	cmp    %rbx,%r8
   7a24c:	jae    7a2a7 <mibz2::bwt::build+0x187>
   7a24e:	mov    %r8d,%eax
   7a251:	shl    $0x8,%eax
   7a254:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   7a260:	movzbl (%r14,%r8,1),%esi
   7a265:	lea    0x0(,%rsi,4),%r9d
   7a26d:	mov    0x408(%rsp,%r9,1),%edi
   7a275:	cmp    0x8(%rsp,%r9,1),%edi
   7a27a:	jae    7a2c6 <mibz2::bwt::build+0x1a6>
   7a27c:	cmp    %rdi,%rbx
   7a27f:	jbe    7a9e8 <mibz2::bwt::build+0x8c8>
   7a285:	movzbl (%r14,%rdi,1),%r9d
   7a28a:	add    %eax,%r9d
   7a28d:	mov    %r9d,(%rdx,%rdi,4)
   7a291:	inc    %edi
   7a293:	mov    %edi,0x408(%rsp,%rsi,4)
   7a29a:	inc    %r8
   7a29d:	add    $0x100,%eax
   7a2a2:	cmp    %r8,%rbx
   7a2a5:	jne    7a260 <mibz2::bwt::build+0x140>
   7a2a7:	lea    0x408(%rsp),%rdi
   7a2af:	lea    0x8(%rsp),%rsi
   7a2b4:	mov    $0x400,%edx
   7a2b9:	call   *0x68c49(%rip)        # e2f08 <bcmp@GLIBC_2.2.5>
   7a2bf:	mov    %r12,%rcx
   7a2c2:	test   %eax,%eax
   7a2c4:	je     7a2f0 <mibz2::bwt::build+0x1d0>
   7a2c6:	movq   $0x0,0x10(%rcx)
   7a2ce:	cmp    (%rcx),%rbx
   7a2d1:	ja     7a2f9 <mibz2::bwt::build+0x1d9>
   7a2d3:	mov    0x8(%rcx),%r13
   7a2d7:	xor    %r12d,%r12d
   7a2da:	test   %rbx,%rbx
   7a2dd:	je     7aa4a <mibz2::bwt::build+0x92a>
   7a2e3:	cmp    $0x8,%rbx
   7a2e7:	jae    7a327 <mibz2::bwt::build+0x207>
   7a2e9:	xor    %eax,%eax
   7a2eb:	jmp    7aa35 <mibz2::bwt::build+0x915>
   7a2f0:	mov    %rbx,0x10(%rcx)
   7a2f4:	jmp    7aa23 <mibz2::bwt::build+0x903>
   7a2f9:	mov    %rcx,%r12
   7a2fc:	mov    $0x4,%ecx
   7a301:	mov    $0x4,%r8d
   7a307:	mov    %r12,%rdi
   7a30a:	xor    %esi,%esi
   7a30c:	mov    %rbx,%rdx
   7a30f:	call   a1f0 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
   7a314:	mov    %r12,%rcx
   7a317:	mov    0x8(%r12),%r13
   7a31c:	mov    0x10(%r12),%r12
   7a321:	cmp    $0x8,%rbx
   7a325:	jb     7a2e9 <mibz2::bwt::build+0x1c9>
   7a327:	movabs $0x7ffffffffffffff0,%rax
   7a331:	or     $0x8,%rax
   7a335:	and    %rbx,%rax
   7a338:	lea    0x10(,%r12,4),%rdx
   7a340:	add    %r13,%rdx
   7a343:	add    %rax,%r12
   7a346:	xor    %esi,%esi
   7a348:	pxor   %xmm0,%xmm0
   7a34c:	nopl   0x0(%rax)
   7a350:	movd   (%r14,%rsi,1),%xmm1
   7a356:	movd   0x4(%r14,%rsi,1),%xmm2
   7a35d:	punpcklbw %xmm0,%xmm1
   7a361:	punpcklwd %xmm0,%xmm1
   7a365:	punpcklbw %xmm0,%xmm2
   7a369:	punpcklwd %xmm0,%xmm2
   7a36d:	movdqu %xmm1,-0x10(%rdx,%rsi,4)
   7a373:	movdqu %xmm2,(%rdx,%rsi,4)
   7a378:	add    $0x8,%rsi
   7a37c:	cmp    %rsi,%rax
   7a37f:	jne    7a350 <mibz2::bwt::build+0x230>
   7a381:	jmp    7aa45 <mibz2::bwt::build+0x925>
   7a386:	mov    $0x4,%ecx
   7a38b:	mov    $0x4,%r8d
   7a391:	mov    %r12,%rdi
   7a394:	xor    %esi,%esi
   7a396:	mov    %rbx,%rdx
   7a399:	call   a1f0 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
   7a39e:	mov    %r12,%rcx
   7a3a1:	mov    0x8(%rcx),%rdx
   7a3a5:	xor    %r8d,%r8d
   7a3a8:	cmp    $0x10,%rbx
   7a3ac:	jb     7a249 <mibz2::bwt::build+0x129>
   7a3b2:	mov    $0x8,%esi
   7a3b7:	pxor   %xmm0,%xmm0
   7a3bb:	movdqa 0x4327d(%rip),%xmm1        # bd640 <_fini+0xd84>
   7a3c3:	movdqa 0x43285(%rip),%xmm2        # bd650 <_fini+0xd94>
   7a3cb:	movdqa 0x4328d(%rip),%xmm3        # bd660 <_fini+0xda4>
   7a3d3:	jmp    7a3fb <mibz2::bwt::build+0x2db>
   7a3d5:	data16 cs nopw 0x0(%rax,%rax,1)
   7a3e0:	lea    0x10(%rsi),%rax
   7a3e4:	add    $0x18,%rsi
   7a3e8:	add    $0x1000,%r8d
   7a3ef:	cmp    %rbx,%rsi
   7a3f2:	mov    %rax,%rsi
   7a3f5:	ja     7a9b7 <mibz2::bwt::build+0x897>
   7a3fb:	lea    -0x8(%rsi),%rax
   7a3ff:	cmp    %rbx,%rsi
   7a402:	ja     7a9f7 <mibz2::bwt::build+0x8d7>
   7a408:	lea    0x7(%rsi),%rdi
   7a40c:	cmp    %rbx,%rdi
   7a40f:	jae    7a9cc <mibz2::bwt::build+0x8ac>
   7a415:	mov    -0x8(%r14,%rsi,1),%r9
   7a41a:	mov    (%r14,%rsi,1),%rax
   7a41e:	mov    %r9,%rdi
   7a421:	xor    %rax,%rdi
   7a424:	mov    %r9,%r10
   7a427:	rol    $0x8,%r10
   7a42b:	xor    %r9,%r10
   7a42e:	or     %rdi,%r10
   7a431:	jne    7a520 <mibz2::bwt::build+0x400>
   7a437:	movzbl %r9b,%r9d
   7a43b:	lea    0x0(,%r9,4),%r10d
   7a443:	mov    0x408(%rsp,%r10,1),%edi
   7a44b:	lea    0x10(%rdi),%rax
   7a44f:	mov    0x8(%rsp,%r10,1),%r10d
   7a454:	cmp    %r10,%rax
   7a457:	ja     7a2c6 <mibz2::bwt::build+0x1a6>
   7a45d:	cmp    %rbx,%rax
   7a460:	ja     7a9d6 <mibz2::bwt::build+0x8b6>
   7a466:	movzbl (%r14,%rdi,1),%eax
   7a46b:	add    %r8d,%eax
   7a46e:	mov    %eax,(%rdx,%rdi,4)
   7a471:	movd   0x1(%r14,%rdi,1),%xmm4
   7a478:	punpcklbw %xmm0,%xmm4
   7a47c:	punpcklwd %xmm0,%xmm4
   7a480:	movd   %r8d,%xmm5
   7a485:	pshufd $0x0,%xmm5,%xmm5
   7a48a:	por    %xmm5,%xmm4
   7a48e:	por    %xmm1,%xmm4
   7a492:	movdqu %xmm4,0x4(%rdx,%rdi,4)
   7a498:	movd   0x5(%r14,%rdi,1),%xmm4
   7a49f:	punpcklbw %xmm0,%xmm4
   7a4a3:	punpcklwd %xmm0,%xmm4
   7a4a7:	por    %xmm5,%xmm4
   7a4ab:	por    %xmm2,%xmm4
   7a4af:	movdqu %xmm4,0x14(%rdx,%rdi,4)
   7a4b5:	movd   0x9(%r14,%rdi,1),%xmm4
   7a4bc:	punpcklbw %xmm0,%xmm4
   7a4c0:	punpcklwd %xmm0,%xmm4
   7a4c4:	por    %xmm5,%xmm4
   7a4c8:	por    %xmm3,%xmm4
   7a4cc:	movdqu %xmm4,0x24(%rdx,%rdi,4)
   7a4d2:	movzbl 0xd(%r14,%rdi,1),%eax
   7a4d8:	lea    0xd00(%r8,%rax,1),%eax
   7a4e0:	mov    %eax,0x34(%rdx,%rdi,4)
   7a4e4:	movzbl 0xe(%r14,%rdi,1),%eax
   7a4ea:	lea    0xe00(%r8,%rax,1),%eax
   7a4f2:	mov    %eax,0x38(%rdx,%rdi,4)
   7a4f6:	movzbl 0xf(%r14,%rdi,1),%eax
   7a4fc:	lea    0xf00(%r8,%rax,1),%eax
   7a504:	mov    %eax,0x3c(%rdx,%rdi,4)
   7a508:	lea    0x10(%rdi),%eax
   7a50b:	mov    %eax,0x408(%rsp,%r9,4)
   7a513:	jmp    7a3e0 <mibz2::bwt::build+0x2c0>
   7a518:	nopl   0x0(%rax,%rax,1)
   7a520:	movzbl %r9b,%r10d
   7a524:	lea    0x0(,%r10,4),%r11d
   7a52c:	mov    0x408(%rsp,%r11,1),%edi
   7a534:	cmp    0x8(%rsp,%r11,1),%edi
   7a539:	jae    7a2c6 <mibz2::bwt::build+0x1a6>
   7a53f:	cmp    %rdi,%rbx
   7a542:	jbe    7a9e8 <mibz2::bwt::build+0x8c8>
   7a548:	mov    %r9,%r11
   7a54b:	shr    $0x8,%r11
   7a54f:	movzbl (%r14,%rdi,1),%ebp
   7a554:	add    %r8d,%ebp
   7a557:	mov    %ebp,(%rdx,%rdi,4)
   7a55a:	inc    %edi
   7a55c:	mov    %edi,0x408(%rsp,%r10,4)
   7a564:	movzbl %r11b,%r10d
   7a568:	lea    0x0(,%r10,4),%r11d
   7a570:	mov    0x408(%rsp,%r11,1),%edi
   7a578:	cmp    0x8(%rsp,%r11,1),%edi
   7a57d:	jae    7a2c6 <mibz2::bwt::build+0x1a6>
   7a583:	cmp    %rdi,%rbx
   7a586:	jbe    7a9e8 <mibz2::bwt::build+0x8c8>
   7a58c:	mov    %r9,%r11
   7a58f:	shr    $0x10,%r11
   7a593:	movzbl (%r14,%rdi,1),%r13d
   7a598:	lea    (%r8,%r13,1),%ebp
   7a59c:	add    $0x100,%ebp
   7a5a2:	mov    %ebp,(%rdx,%rdi,4)
   7a5a5:	inc    %edi
   7a5a7:	mov    %edi,0x408(%rsp,%r10,4)
   7a5af:	movzbl %r11b,%r10d
   7a5b3:	lea    0x0(,%r10,4),%r11d
   7a5bb:	mov    0x408(%rsp,%r11,1),%edi
   7a5c3:	cmp    0x8(%rsp,%r11,1),%edi
   7a5c8:	jae    7a2c6 <mibz2::bwt::build+0x1a6>
   7a5ce:	cmp    %rdi,%rbx
   7a5d1:	jbe    7a9e8 <mibz2::bwt::build+0x8c8>
   7a5d7:	mov    %r9,%r11
   7a5da:	shr    $0x18,%r11
   7a5de:	movzbl (%r14,%rdi,1),%r13d
   7a5e3:	lea    (%r8,%r13,1),%ebp
   7a5e7:	add    $0x200,%ebp
   7a5ed:	mov    %ebp,(%rdx,%rdi,4)
   7a5f0:	inc    %edi
   7a5f2:	mov    %edi,0x408(%rsp,%r10,4)
   7a5fa:	movzbl %r11b,%r10d
   7a5fe:	lea    0x0(,%r10,4),%r11d
   7a606:	mov    0x408(%rsp,%r11,1),%edi
   7a60e:	cmp    0x8(%rsp,%r11,1),%edi
   7a613:	jae    7a2c6 <mibz2::bwt::build+0x1a6>
   7a619:	cmp    %rdi,%rbx
   7a61c:	jbe    7a9e8 <mibz2::bwt::build+0x8c8>
   7a622:	mov    %r9,%r11
   7a625:	shr    $0x20,%r11
   7a629:	movzbl (%r14,%rdi,1),%r13d
   7a62e:	lea    (%r8,%r13,1),%ebp
   7a632:	add    $0x300,%ebp
   7a638:	mov    %ebp,(%rdx,%rdi,4)
   7a63b:	inc    %edi
   7a63d:	mov    %edi,0x408(%rsp,%r10,4)
   7a645:	movzbl %r11b,%r10d
   7a649:	lea    0x0(,%r10,4),%r11d
   7a651:	mov    0x408(%rsp,%r11,1),%edi
   7a659:	cmp    0x8(%rsp,%r11,1),%edi
   7a65e:	jae    7a2c6 <mibz2::bwt::build+0x1a6>
   7a664:	cmp    %rdi,%rbx
   7a667:	jbe    7a9e8 <mibz2::bwt::build+0x8c8>
   7a66d:	mov    %r9,%r11
   7a670:	shr    $0x28,%r11
   7a674:	movzbl (%r14,%rdi,1),%r13d
   7a679:	lea    (%r8,%r13,1),%ebp
   7a67d:	add    $0x400,%ebp
   7a683:	mov    %ebp,(%rdx,%rdi,4)
   7a686:	inc    %edi
   7a688:	mov    %edi,0x408(%rsp,%r10,4)
   7a690:	movzbl %r11b,%r10d
   7a694:	lea    0x0(,%r10,4),%r11d
   7a69c:	mov    0x408(%rsp,%r11,1),%edi
   7a6a4:	cmp    0x8(%rsp,%r11,1),%edi
   7a6a9:	jae    7a2c6 <mibz2::bwt::build+0x1a6>
   7a6af:	cmp    %rdi,%rbx
   7a6b2:	jbe    7a9e8 <mibz2::bwt::build+0x8c8>
   7a6b8:	mov    %r9,%r11
   7a6bb:	shr    $0x30,%r11
   7a6bf:	movzbl (%r14,%rdi,1),%r13d
   7a6c4:	lea    (%r8,%r13,1),%ebp
   7a6c8:	add    $0x500,%ebp
   7a6ce:	mov    %ebp,(%rdx,%rdi,4)
   7a6d1:	inc    %edi
   7a6d3:	mov    %edi,0x408(%rsp,%r10,4)
   7a6db:	movzbl %r11b,%r10d
   7a6df:	lea    0x0(,%r10,4),%r11d
   7a6e7:	mov    0x408(%rsp,%r11,1),%edi
   7a6ef:	cmp    0x8(%rsp,%r11,1),%edi
   7a6f4:	jae    7a2c6 <mibz2::bwt::build+0x1a6>
   7a6fa:	cmp    %rdi,%rbx
   7a6fd:	jbe    7a9e8 <mibz2::bwt::build+0x8c8>
   7a703:	shr    $0x38,%r9
   7a707:	movzbl (%r14,%rdi,1),%r11d
   7a70c:	add    %r8d,%r11d
   7a70f:	add    $0x600,%r11d
   7a716:	mov    %r11d,(%rdx,%rdi,4)
   7a71a:	inc    %edi
   7a71c:	mov    %edi,0x408(%rsp,%r10,4)
   7a724:	lea    0x0(,%r9,4),%r10d
   7a72c:	mov    0x408(%rsp,%r10,1),%edi
   7a734:	cmp    0x8(%rsp,%r10,1),%edi
   7a739:	jae    7a2c6 <mibz2::bwt::build+0x1a6>
   7a73f:	cmp    %rdi,%rbx
   7a742:	jbe    7a9e8 <mibz2::bwt::build+0x8c8>
   7a748:	movzbl (%r14,%rdi,1),%r10d
   7a74d:	add    %r8d,%r10d
   7a750:	add    $0x700,%r10d
   7a757:	mov    %r10d,(%rdx,%rdi,4)
   7a75b:	inc    %edi
   7a75d:	mov    %edi,0x408(%rsp,%r9,4)
   7a765:	movzbl %al,%r9d
   7a769:	lea    0x0(,%r9,4),%r10d
   7a771:	mov    0x408(%rsp,%r10,1),%edi
   7a779:	cmp    0x8(%rsp,%r10,1),%edi
   7a77e:	jae    7a2c6 <mibz2::bwt::build+0x1a6>
   7a784:	cmp    %rdi,%rbx
   7a787:	jbe    7a9e8 <mibz2::bwt::build+0x8c8>
   7a78d:	mov    %rax,%r10
   7a790:	shr    $0x8,%r10
   7a794:	movzbl (%r14,%rdi,1),%r11d
   7a799:	add    %r8d,%r11d
   7a79c:	add    $0x800,%r11d
   7a7a3:	mov    %r11d,(%rdx,%rdi,4)
   7a7a7:	inc    %edi
   7a7a9:	mov    %edi,0x408(%rsp,%r9,4)
   7a7b1:	movzbl %r10b,%r9d
   7a7b5:	lea    0x0(,%r9,4),%r10d
   7a7bd:	mov    0x408(%rsp,%r10,1),%edi
   7a7c5:	cmp    0x8(%rsp,%r10,1),%edi
   7a7ca:	jae    7a2c6 <mibz2::bwt::build+0x1a6>
   7a7d0:	cmp    %rdi,%rbx
   7a7d3:	jbe    7a9e8 <mibz2::bwt::build+0x8c8>
   7a7d9:	mov    %rax,%r10
   7a7dc:	shr    $0x10,%r10
   7a7e0:	movzbl (%r14,%rdi,1),%r11d
   7a7e5:	add    %r8d,%r11d
   7a7e8:	add    $0x900,%r11d
   7a7ef:	mov    %r11d,(%rdx,%rdi,4)
   7a7f3:	inc    %edi
   7a7f5:	mov    %edi,0x408(%rsp,%r9,4)
   7a7fd:	movzbl %r10b,%r9d
   7a801:	lea    0x0(,%r9,4),%r10d
   7a809:	mov    0x408(%rsp,%r10,1),%edi
   7a811:	cmp    0x8(%rsp,%r10,1),%edi
   7a816:	jae    7a2c6 <mibz2::bwt::build+0x1a6>
   7a81c:	cmp    %rdi,%rbx
   7a81f:	jbe    7a9e8 <mibz2::bwt::build+0x8c8>
   7a825:	mov    %rax,%r10
   7a828:	shr    $0x18,%r10
   7a82c:	movzbl (%r14,%rdi,1),%r11d
   7a831:	add    %r8d,%r11d
   7a834:	add    $0xa00,%r11d
   7a83b:	mov    %r11d,(%rdx,%rdi,4)
   7a83f:	inc    %edi
   7a841:	mov    %edi,0x408(%rsp,%r9,4)
   7a849:	movzbl %r10b,%r9d
   7a84d:	lea    0x0(,%r9,4),%r10d
   7a855:	mov    0x408(%rsp,%r10,1),%edi
   7a85d:	cmp    0x8(%rsp,%r10,1),%edi
   7a862:	jae    7a2c6 <mibz2::bwt::build+0x1a6>
   7a868:	cmp    %rdi,%rbx
   7a86b:	jbe    7a9e8 <mibz2::bwt::build+0x8c8>
   7a871:	mov    %rax,%r10
   7a874:	shr    $0x20,%r10
   7a878:	movzbl (%r14,%rdi,1),%r11d
   7a87d:	add    %r8d,%r11d
   7a880:	add    $0xb00,%r11d
   7a887:	mov    %r11d,(%rdx,%rdi,4)
   7a88b:	inc    %edi
   7a88d:	mov    %edi,0x408(%rsp,%r9,4)
   7a895:	movzbl %r10b,%r9d
   7a899:	lea    0x0(,%r9,4),%r10d
   7a8a1:	mov    0x408(%rsp,%r10,1),%edi
   7a8a9:	cmp    0x8(%rsp,%r10,1),%edi
   7a8ae:	jae    7a2c6 <mibz2::bwt::build+0x1a6>
   7a8b4:	cmp    %rdi,%rbx
   7a8b7:	jbe    7a9e8 <mibz2::bwt::build+0x8c8>
   7a8bd:	mov    %rax,%r10
   7a8c0:	shr    $0x28,%r10
   7a8c4:	movzbl (%r14,%rdi,1),%r11d
   7a8c9:	add    %r8d,%r11d
   7a8cc:	add    $0xc00,%r11d
   7a8d3:	mov    %r11d,(%rdx,%rdi,4)
   7a8d7:	inc    %edi
   7a8d9:	mov    %edi,0x408(%rsp,%r9,4)
   7a8e1:	movzbl %r10b,%r9d
   7a8e5:	lea    0x0(,%r9,4),%r10d
   7a8ed:	mov    0x408(%rsp,%r10,1),%edi
   7a8f5:	cmp    0x8(%rsp,%r10,1),%edi
   7a8fa:	jae    7a2c6 <mibz2::bwt::build+0x1a6>
   7a900:	cmp    %rdi,%rbx
   7a903:	jbe    7a9e8 <mibz2::bwt::build+0x8c8>
   7a909:	mov    %rax,%r10
   7a90c:	shr    $0x30,%r10
   7a910:	movzbl (%r14,%rdi,1),%r11d
   7a915:	add    %r8d,%r11d
   7a918:	add    $0xd00,%r11d
   7a91f:	mov    %r11d,(%rdx,%rdi,4)
   7a923:	inc    %edi
   7a925:	mov    %edi,0x408(%rsp,%r9,4)
   7a92d:	movzbl %r10b,%r9d
   7a931:	lea    0x0(,%r9,4),%r10d
   7a939:	mov    0x408(%rsp,%r10,1),%edi
   7a941:	cmp    0x8(%rsp,%r10,1),%edi
   7a946:	jae    7a2c6 <mibz2::bwt::build+0x1a6>
   7a94c:	cmp    %rdi,%rbx
   7a94f:	jbe    7a9e8 <mibz2::bwt::build+0x8c8>
   7a955:	shr    $0x38,%rax
   7a959:	movzbl (%r14,%rdi,1),%r10d
   7a95e:	add    %r8d,%r10d
   7a961:	add    $0xe00,%r10d
   7a968:	mov    %r10d,(%rdx,%rdi,4)
   7a96c:	inc    %edi
   7a96e:	mov    %edi,0x408(%rsp,%r9,4)
   7a976:	lea    0x0(,%rax,4),%r9d
   7a97e:	mov    0x408(%rsp,%r9,1),%edi
   7a986:	cmp    0x8(%rsp,%r9,1),%edi
   7a98b:	jae    7a2c6 <mibz2::bwt::build+0x1a6>
   7a991:	cmp    %rdi,%rbx
   7a994:	jbe    7a9e8 <mibz2::bwt::build+0x8c8>
   7a996:	movzbl (%r14,%rdi,1),%r9d
   7a99b:	add    %r8d,%r9d
   7a99e:	add    $0xf00,%r9d
   7a9a5:	mov    %r9d,(%rdx,%rdi,4)
   7a9a9:	inc    %edi
   7a9ab:	mov    %edi,0x408(%rsp,%rax,4)
   7a9b2:	jmp    7a3e0 <mibz2::bwt::build+0x2c0>
   7a9b7:	add    $0xfffffffffffffff8,%rax
   7a9bb:	mov    %rax,%r8
   7a9be:	cmp    %rbx,%r8
   7a9c1:	jb     7a24e <mibz2::bwt::build+0x12e>
   7a9c7:	jmp    7a2a7 <mibz2::bwt::build+0x187>
   7a9cc:	mov    %ebx,%edi
   7a9ce:	and    $0xfffff0,%edi
   7a9d4:	jmp    7aa09 <mibz2::bwt::build+0x8e9>
   7a9d6:	lea    0x6679b(%rip),%rcx        # e1178 <__do_global_dtors_aux_fini_array_entry+0x3020>
   7a9dd:	mov    %rax,%rsi
   7a9e0:	mov    %rbx,%rdx
   7a9e3:	call   9de0 <core::slice::index::slice_index_fail>
   7a9e8:	lea    0x66669(%rip),%rdx        # e1058 <__do_global_dtors_aux_fini_array_entry+0x2f00>
   7a9ef:	mov    %rbx,%rsi
   7a9f2:	call   9d2b <core::panicking::panic_bounds_check>
   7a9f7:	lea    0x667da(%rip),%rcx        # e11d8 <__do_global_dtors_aux_fini_array_entry+0x3080>
   7a9fe:	mov    %rax,%rdi
   7aa01:	mov    %rbx,%rdx
   7aa04:	call   9de0 <core::slice::index::slice_index_fail>
   7aa09:	or     $0x8,%rdi
   7aa0d:	add    $0x10,%rax
   7aa11:	lea    0x667c0(%rip),%rcx        # e11d8 <__do_global_dtors_aux_fini_array_entry+0x3080>
   7aa18:	mov    %rax,%rsi
   7aa1b:	mov    %rbx,%rdx
   7aa1e:	call   9de0 <core::slice::index::slice_index_fail>
   7aa23:	add    $0x808,%rsp
   7aa2a:	pop    %rbx
   7aa2b:	pop    %r12
   7aa2d:	pop    %r13
   7aa2f:	pop    %r14
   7aa31:	pop    %r15
   7aa33:	pop    %rbp
   7aa34:	ret
   7aa35:	movzbl (%r14,%rax,1),%edx
   7aa3a:	mov    %edx,0x0(%r13,%r12,4)
   7aa3f:	inc    %r12
   7aa42:	inc    %rax
   7aa45:	cmp    %rax,%rbx
   7aa48:	jne    7aa35 <mibz2::bwt::build+0x915>
   7aa4a:	mov    %r12,0x10(%rcx)
   7aa4e:	lea    0x8(%rsp),%rdi
   7aa53:	xor    %ebp,%ebp
   7aa55:	mov    $0x400,%edx
   7aa5a:	xor    %esi,%esi
   7aa5c:	call   *0x683d6(%rip)        # e2e38 <memset@GLIBC_2.2.5>
   7aa62:	xor    %eax,%eax
   7aa64:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   7aa70:	mov    %eax,0x8(%rsp,%rbp,4)
   7aa74:	add    (%r15,%rbp,4),%eax
   7aa78:	mov    %eax,0xc(%rsp,%rbp,4)
   7aa7c:	add    0x4(%r15,%rbp,4),%eax
   7aa81:	mov    %eax,0x10(%rsp,%rbp,4)
   7aa85:	add    0x8(%r15,%rbp,4),%eax
   7aa8a:	mov    %eax,0x14(%rsp,%rbp,4)
   7aa8e:	add    0xc(%r15,%rbp,4),%eax
   7aa93:	add    $0x4,%rbp
   7aa97:	cmp    $0x100,%rbp
   7aa9e:	jne    7aa70 <mibz2::bwt::build+0x950>
   7aaa0:	xor    %ecx,%ecx
   7aaa2:	cmp    $0x10,%rbx
   7aaa6:	jb     7af3a <mibz2::bwt::build+0xe1a>
   7aaac:	mov    $0x8,%esi
   7aab1:	movdqa 0x42bb7(%rip),%xmm0        # bd670 <_fini+0xdb4>
   7aab9:	movdqa 0x42b7f(%rip),%xmm1        # bd640 <_fini+0xd84>
   7aac1:	movdqa 0x42b87(%rip),%xmm2        # bd650 <_fini+0xd94>
   7aac9:	movdqa 0x42b8f(%rip),%xmm3        # bd660 <_fini+0xda4>
   7aad1:	movq   0x42ba7(%rip),%xmm4        # bd680 <_fini+0xdc4>
   7aad9:	movq   0x42baf(%rip),%xmm5        # bd690 <_fini+0xdd4>
   7aae1:	jmp    7abbd <mibz2::bwt::build+0xa9d>
   7aae6:	cs nopw 0x0(%rax,%rax,1)
   7aaf0:	movzbl %dl,%edx
   7aaf3:	mov    %edx,%eax
   7aaf5:	mov    0x8(%rsp,%rax,4),%edi
   7aaf9:	lea    0x10(%rdi),%rax
   7aafd:	cmp    %r12,%rax
   7ab00:	ja     7af96 <mibz2::bwt::build+0xe76>
   7ab06:	movzbl 0x0(%r13,%rdi,4),%eax
   7ab0c:	add    %ecx,%eax
   7ab0e:	mov    %eax,0x0(%r13,%rdi,4)
   7ab13:	movdqu 0x4(%r13,%rdi,4),%xmm6
   7ab1a:	movdqu 0x14(%r13,%rdi,4),%xmm7
   7ab21:	movdqu 0x24(%r13,%rdi,4),%xmm8
   7ab28:	pand   %xmm0,%xmm6
   7ab2c:	movd   %ecx,%xmm9
   7ab31:	pshufd $0x0,%xmm9,%xmm9
   7ab37:	por    %xmm9,%xmm6
   7ab3c:	por    %xmm1,%xmm6
   7ab40:	movdqu %xmm6,0x4(%r13,%rdi,4)
   7ab47:	pand   %xmm0,%xmm7
   7ab4b:	por    %xmm9,%xmm7
   7ab50:	por    %xmm2,%xmm7
   7ab54:	movdqu %xmm7,0x14(%r13,%rdi,4)
   7ab5b:	pand   %xmm0,%xmm8
   7ab60:	por    %xmm9,%xmm8
   7ab65:	por    %xmm3,%xmm8
   7ab6a:	movdqu %xmm8,0x24(%r13,%rdi,4)
   7ab71:	movq   0x34(%r13,%rdi,4),%xmm6
   7ab78:	pand   %xmm4,%xmm6
   7ab7c:	por    %xmm9,%xmm6
   7ab81:	por    %xmm5,%xmm6
   7ab85:	movq   %xmm6,0x34(%r13,%rdi,4)
   7ab8c:	movzbl 0x3c(%r13,%rdi,4),%eax
   7ab92:	add    %ecx,%eax
   7ab94:	add    $0xf00,%eax
   7ab99:	mov    %eax,0x3c(%r13,%rdi,4)
   7ab9e:	addl   $0x10,0x8(%rsp,%rdx,4)
   7aba3:	lea    0x10(%rsi),%rax
   7aba7:	add    $0x18,%rsi
   7abab:	add    $0x1000,%ecx
   7abb1:	cmp    %rbx,%rsi
   7abb4:	mov    %rax,%rsi
   7abb7:	ja     7af33 <mibz2::bwt::build+0xe13>
   7abbd:	lea    -0x8(%rsi),%rax
   7abc1:	cmp    %rbx,%rsi
   7abc4:	ja     7a9f7 <mibz2::bwt::build+0x8d7>
   7abca:	lea    0x7(%rsi),%rdx
   7abce:	cmp    %rbx,%rdx
   7abd1:	jae    7af84 <mibz2::bwt::build+0xe64>
   7abd7:	mov    -0x8(%r14,%rsi,1),%rdx
   7abdc:	mov    (%r14,%rsi,1),%rax
   7abe0:	mov    %rdx,%rdi
   7abe3:	xor    %rax,%rdi
   7abe6:	mov    %rdx,%r8
   7abe9:	rol    $0x8,%r8
   7abed:	xor    %rdx,%r8
   7abf0:	or     %rdi,%r8
   7abf3:	je     7aaf0 <mibz2::bwt::build+0x9d0>
   7abf9:	movzbl %dl,%r8d
   7abfd:	mov    %r8d,%edi
   7ac00:	mov    0x8(%rsp,%rdi,4),%edi
   7ac04:	cmp    %rdi,%r12
   7ac07:	jbe    7afa8 <mibz2::bwt::build+0xe88>
   7ac0d:	mov    %rdx,%r9
   7ac10:	shr    $0x8,%r9
   7ac14:	movzbl 0x0(%r13,%rdi,4),%r10d
   7ac1a:	add    %ecx,%r10d
   7ac1d:	mov    %r10d,0x0(%r13,%rdi,4)
   7ac22:	inc    %edi
   7ac24:	mov    %edi,0x8(%rsp,%r8,4)
   7ac29:	movzbl %r9b,%r8d
   7ac2d:	mov    %r8d,%edi
   7ac30:	mov    0x8(%rsp,%rdi,4),%edi
   7ac34:	cmp    %rdi,%r12
   7ac37:	jbe    7afa8 <mibz2::bwt::build+0xe88>
   7ac3d:	mov    %rdx,%r9
   7ac40:	shr    $0x10,%r9
   7ac44:	movzbl 0x0(%r13,%rdi,4),%r10d
   7ac4a:	add    %ecx,%r10d
   7ac4d:	add    $0x100,%r10d
   7ac54:	mov    %r10d,0x0(%r13,%rdi,4)
   7ac59:	inc    %edi
   7ac5b:	mov    %edi,0x8(%rsp,%r8,4)
   7ac60:	movzbl %r9b,%r8d
   7ac64:	mov    %r8d,%edi
   7ac67:	mov    0x8(%rsp,%rdi,4),%edi
   7ac6b:	cmp    %rdi,%r12
   7ac6e:	jbe    7afa8 <mibz2::bwt::build+0xe88>
   7ac74:	mov    %rdx,%r9
   7ac77:	shr    $0x18,%r9
   7ac7b:	movzbl 0x0(%r13,%rdi,4),%r10d
   7ac81:	add    %ecx,%r10d
   7ac84:	add    $0x200,%r10d
   7ac8b:	mov    %r10d,0x0(%r13,%rdi,4)
   7ac90:	inc    %edi
   7ac92:	mov    %edi,0x8(%rsp,%r8,4)
   7ac97:	movzbl %r9b,%r8d
   7ac9b:	mov    %r8d,%edi
   7ac9e:	mov    0x8(%rsp,%rdi,4),%edi
   7aca2:	cmp    %rdi,%r12
   7aca5:	jbe    7afa8 <mibz2::bwt::build+0xe88>
   7acab:	mov    %rdx,%r9
   7acae:	shr    $0x20,%r9
   7acb2:	movzbl 0x0(%r13,%rdi,4),%r10d
   7acb8:	add    %ecx,%r10d
   7acbb:	add    $0x300,%r10d
   7acc2:	mov    %r10d,0x0(%r13,%rdi,4)
   7acc7:	inc    %edi
   7acc9:	mov    %edi,0x8(%rsp,%r8,4)
   7acce:	movzbl %r9b,%r8d
   7acd2:	mov    %r8d,%edi
   7acd5:	mov    0x8(%rsp,%rdi,4),%edi
   7acd9:	cmp    %rdi,%r12
   7acdc:	jbe    7afa8 <mibz2::bwt::build+0xe88>
   7ace2:	mov    %rdx,%r9
   7ace5:	shr    $0x28,%r9
   7ace9:	movzbl 0x0(%r13,%rdi,4),%r10d
   7acef:	add    %ecx,%r10d
   7acf2:	add    $0x400,%r10d
   7acf9:	mov    %r10d,0x0(%r13,%rdi,4)
   7acfe:	inc    %edi
   7ad00:	mov    %edi,0x8(%rsp,%r8,4)
   7ad05:	movzbl %r9b,%r8d
   7ad09:	mov    %r8d,%edi
   7ad0c:	mov    0x8(%rsp,%rdi,4),%edi
   7ad10:	cmp    %rdi,%r12
   7ad13:	jbe    7afa8 <mibz2::bwt::build+0xe88>
   7ad19:	mov    %rdx,%r9
   7ad1c:	shr    $0x30,%r9
   7ad20:	movzbl 0x0(%r13,%rdi,4),%r10d
   7ad26:	add    %ecx,%r10d
   7ad29:	add    $0x500,%r10d
   7ad30:	mov    %r10d,0x0(%r13,%rdi,4)
   7ad35:	inc    %edi
   7ad37:	mov    %edi,0x8(%rsp,%r8,4)
   7ad3c:	movzbl %r9b,%r8d
   7ad40:	mov    %r8d,%edi
   7ad43:	mov    0x8(%rsp,%rdi,4),%edi
   7ad47:	cmp    %rdi,%r12
   7ad4a:	jbe    7afa8 <mibz2::bwt::build+0xe88>
   7ad50:	shr    $0x38,%rdx
   7ad54:	movzbl 0x0(%r13,%rdi,4),%r9d
   7ad5a:	add    %ecx,%r9d
   7ad5d:	add    $0x600,%r9d
   7ad64:	mov    %r9d,0x0(%r13,%rdi,4)
   7ad69:	inc    %edi
   7ad6b:	mov    %edi,0x8(%rsp,%r8,4)
   7ad70:	mov    0x8(%rsp,%rdx,4),%edi
   7ad74:	cmp    %rdi,%r12
   7ad77:	jbe    7afa8 <mibz2::bwt::build+0xe88>
   7ad7d:	movzbl 0x0(%r13,%rdi,4),%r8d
   7ad83:	add    %ecx,%r8d
   7ad86:	add    $0x700,%r8d
   7ad8d:	mov    %r8d,0x0(%r13,%rdi,4)
   7ad92:	inc    %edi
   7ad94:	mov    %edi,0x8(%rsp,%rdx,4)
   7ad98:	movzbl %al,%edx
   7ad9b:	mov    %edx,%edi
   7ad9d:	mov    0x8(%rsp,%rdi,4),%edi
   7ada1:	cmp    %rdi,%r12
   7ada4:	jbe    7afa8 <mibz2::bwt::build+0xe88>
   7adaa:	mov    %rax,%r8
   7adad:	shr    $0x8,%r8
   7adb1:	movzbl 0x0(%r13,%rdi,4),%r9d
   7adb7:	add    %ecx,%r9d
   7adba:	add    $0x800,%r9d
   7adc1:	mov    %r9d,0x0(%r13,%rdi,4)
   7adc6:	inc    %edi
   7adc8:	mov    %edi,0x8(%rsp,%rdx,4)
   7adcc:	movzbl %r8b,%edx
   7add0:	mov    %edx,%edi
   7add2:	mov    0x8(%rsp,%rdi,4),%edi
   7add6:	cmp    %rdi,%r12
   7add9:	jbe    7afa8 <mibz2::bwt::build+0xe88>
   7addf:	mov    %rax,%r8
   7ade2:	shr    $0x10,%r8
   7ade6:	movzbl 0x0(%r13,%rdi,4),%r9d
   7adec:	add    %ecx,%r9d
   7adef:	add    $0x900,%r9d
   7adf6:	mov    %r9d,0x0(%r13,%rdi,4)
   7adfb:	inc    %edi
   7adfd:	mov    %edi,0x8(%rsp,%rdx,4)
   7ae01:	movzbl %r8b,%edx
   7ae05:	mov    %edx,%edi
   7ae07:	mov    0x8(%rsp,%rdi,4),%edi
   7ae0b:	cmp    %rdi,%r12
   7ae0e:	jbe    7afa8 <mibz2::bwt::build+0xe88>
   7ae14:	mov    %rax,%r8
   7ae17:	shr    $0x18,%r8
   7ae1b:	movzbl 0x0(%r13,%rdi,4),%r9d
   7ae21:	add    %ecx,%r9d
   7ae24:	add    $0xa00,%r9d
   7ae2b:	mov    %r9d,0x0(%r13,%rdi,4)
   7ae30:	inc    %edi
   7ae32:	mov    %edi,0x8(%rsp,%rdx,4)
   7ae36:	movzbl %r8b,%edx
   7ae3a:	mov    %edx,%edi
   7ae3c:	mov    0x8(%rsp,%rdi,4),%edi
   7ae40:	cmp    %rdi,%r12
   7ae43:	jbe    7afa8 <mibz2::bwt::build+0xe88>
   7ae49:	mov    %rax,%r8
   7ae4c:	shr    $0x20,%r8
   7ae50:	movzbl 0x0(%r13,%rdi,4),%r9d
   7ae56:	add    %ecx,%r9d
   7ae59:	add    $0xb00,%r9d
   7ae60:	mov    %r9d,0x0(%r13,%rdi,4)
   7ae65:	inc    %edi
   7ae67:	mov    %edi,0x8(%rsp,%rdx,4)
   7ae6b:	movzbl %r8b,%edx
   7ae6f:	mov    %edx,%edi
   7ae71:	mov    0x8(%rsp,%rdi,4),%edi
   7ae75:	cmp    %rdi,%r12
   7ae78:	jbe    7afa8 <mibz2::bwt::build+0xe88>
   7ae7e:	mov    %rax,%r8
   7ae81:	shr    $0x28,%r8
   7ae85:	movzbl 0x0(%r13,%rdi,4),%r9d
   7ae8b:	add    %ecx,%r9d
   7ae8e:	add    $0xc00,%r9d
   7ae95:	mov    %r9d,0x0(%r13,%rdi,4)
   7ae9a:	inc    %edi
   7ae9c:	mov    %edi,0x8(%rsp,%rdx,4)
   7aea0:	movzbl %r8b,%edx
   7aea4:	mov    %edx,%edi
   7aea6:	mov    0x8(%rsp,%rdi,4),%edi
   7aeaa:	cmp    %rdi,%r12
   7aead:	jbe    7afa8 <mibz2::bwt::build+0xe88>
   7aeb3:	mov    %rax,%r8
   7aeb6:	shr    $0x30,%r8
   7aeba:	movzbl 0x0(%r13,%rdi,4),%r9d
   7aec0:	add    %ecx,%r9d
   7aec3:	add    $0xd00,%r9d
   7aeca:	mov    %r9d,0x0(%r13,%rdi,4)
   7aecf:	inc    %edi
   7aed1:	mov    %edi,0x8(%rsp,%rdx,4)
   7aed5:	movzbl %r8b,%edx
   7aed9:	mov    %edx,%edi
   7aedb:	mov    0x8(%rsp,%rdi,4),%edi
   7aedf:	cmp    %rdi,%r12
   7aee2:	jbe    7afa8 <mibz2::bwt::build+0xe88>
   7aee8:	shr    $0x38,%rax
   7aeec:	movzbl 0x0(%r13,%rdi,4),%r8d
   7aef2:	add    %ecx,%r8d
   7aef5:	add    $0xe00,%r8d
   7aefc:	mov    %r8d,0x0(%r13,%rdi,4)
   7af01:	inc    %edi
   7af03:	mov    %edi,0x8(%rsp,%rdx,4)
   7af07:	mov    0x8(%rsp,%rax,4),%edi
   7af0b:	cmp    %rdi,%r12
   7af0e:	jbe    7afa8 <mibz2::bwt::build+0xe88>
   7af14:	movzbl 0x0(%r13,%rdi,4),%edx
   7af1a:	add    %ecx,%edx
   7af1c:	add    $0xf00,%edx
   7af22:	mov    %edx,0x0(%r13,%rdi,4)
   7af27:	lea    0x1(%rdi),%edx
   7af2a:	mov    %edx,0x8(%rsp,%rax,4)
   7af2e:	jmp    7aba3 <mibz2::bwt::build+0xa83>
   7af33:	add    $0xfffffffffffffff8,%rax
   7af37:	mov    %rax,%rcx
   7af3a:	cmp    %rbx,%rcx
   7af3d:	jae    7aa23 <mibz2::bwt::build+0x903>
   7af43:	mov    %ecx,%eax
   7af45:	shl    $0x8,%eax
   7af48:	nopl   0x0(%rax,%rax,1)
   7af50:	movzbl (%r14,%rcx,1),%edx
   7af55:	mov    0x8(%rsp,%rdx,4),%edi
   7af59:	cmp    %rdi,%r12
   7af5c:	jbe    7afa8 <mibz2::bwt::build+0xe88>
   7af5e:	inc    %rcx
   7af61:	movzbl 0x0(%r13,%rdi,4),%esi
   7af67:	add    %eax,%esi
   7af69:	mov    %esi,0x0(%r13,%rdi,4)
   7af6e:	lea    0x1(%rdi),%esi
   7af71:	mov    %esi,0x8(%rsp,%rdx,4)
   7af75:	add    $0x100,%eax
   7af7a:	cmp    %rcx,%rbx
   7af7d:	jne    7af50 <mibz2::bwt::build+0xe30>
   7af7f:	jmp    7aa23 <mibz2::bwt::build+0x903>
   7af84:	movabs $0x7ffffffffffffff0,%rdi
   7af8e:	and    %rbx,%rdi
   7af91:	jmp    7aa09 <mibz2::bwt::build+0x8e9>
   7af96:	lea    0x661f3(%rip),%rcx        # e1190 <__do_global_dtors_aux_fini_array_entry+0x3038>
   7af9d:	mov    %rax,%rsi
   7afa0:	mov    %r12,%rdx
   7afa3:	call   9de0 <core::slice::index::slice_index_fail>
   7afa8:	lea    0x661f9(%rip),%rdx        # e11a8 <__do_global_dtors_aux_fini_array_entry+0x3050>
   7afaf:	mov    %r12,%rsi
   7afb2:	call   9d2b <core::panicking::panic_bounds_check>
