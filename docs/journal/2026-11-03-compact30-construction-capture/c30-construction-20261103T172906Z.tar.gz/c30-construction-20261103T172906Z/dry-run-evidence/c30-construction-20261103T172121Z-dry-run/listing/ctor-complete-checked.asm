# <c30walk::ctor::W<false>>::complete_checked
# size 0x3be

/home/louis/dev/mibz2/target/c30-construction-pin/target/rust-1.97.0/release/examples/c30walk:     file format elf64-x86-64


Disassembly of section .text:

0000000000042550 <<c30walk::ctor::W<false>>::complete_checked>:
   42550:	push   %rbp
   42551:	push   %r15
   42553:	push   %r14
   42555:	push   %r13
   42557:	push   %r12
   42559:	push   %rbx
   4255a:	push   %rax
   4255b:	mov    %esi,%r8d
   4255e:	mov    0x10(%rdi),%rax
   42562:	mov    %rax,(%rsp)
   42566:	mov    0x8(%rdi),%rsi
   4256a:	mov    0x830(%rdi),%rax
   42571:	cmp    $0x1d,%rax
   42575:	ja     428bc <<c30walk::ctor::W<false>>::complete_checked+0x36c>
   4257b:	mov    (%rdi),%r10
   4257e:	shl    $0x6,%rax
   42582:	lea    0x82477(%rip),%r11        # c4a00 <c30walk::ctor::PATTERNS>
   42589:	add    %rax,%r11
   4258c:	mov    0x20(%rdi),%rax
   42590:	movzbl %r8b,%ebx
   42594:	mov    0x838(%rdi),%r14d
   4259b:	mov    %r14d,%ebp
   4259e:	shl    $0x8,%ebp
   425a1:	or     %ebx,%ebp
   425a3:	mov    %rdx,%r8
   425a6:	shl    $0x6,%r8
   425aa:	lea    (%r8,%rax,1),%r15
   425ae:	add    $0x3c,%r15
   425b2:	xor    %r12d,%r12d
   425b5:	jmp    42612 <<c30walk::ctor::W<false>>::complete_checked+0xc2>
   425b7:	nopw   0x0(%rax,%rax,1)
   425c0:	movups 0x2c(%r11),%xmm0
   425c5:	movups %xmm0,-0x10(%r15,%r12,2)
   425cb:	movaps (%r11),%xmm0
   425cf:	movaps 0x10(%r11),%xmm1
   425d4:	movaps 0x20(%r11),%xmm2
   425d9:	movaps %xmm2,-0x1c(%r15,%r12,2)
   425df:	movaps %xmm1,-0x2c(%r15,%r12,2)
   425e5:	movaps %xmm0,-0x3c(%r15,%r12,2)
   425eb:	mov    %ebp,(%r15,%r12,2)
   425ef:	lea    (%r14,%r12,1),%eax
   425f3:	add    $0x20,%eax
   425f6:	mov    %eax,0x838(%rdi)
   425fc:	add    $0x2000,%ebp
   42602:	add    $0x20,%r12
   42606:	inc    %rdx
   42609:	dec    %rcx
   4260c:	je     4289b <<c30walk::ctor::W<false>>::complete_checked+0x34b>
   42612:	mov    %rdx,%r8
   42615:	shr    $0x6,%r8
   42619:	cmp    (%rsp),%r8
   4261d:	jae    428e7 <<c30walk::ctor::W<false>>::complete_checked+0x397>
   42623:	mov    (%rsi,%r8,8),%rax
   42627:	bt     %rdx,%rax
   4262b:	jae    425c0 <<c30walk::ctor::W<false>>::complete_checked+0x70>
   4262d:	mov    (%r15,%r12,2),%eax
   42631:	and    $0xfffff,%eax
   42636:	mov    0x10(%r10),%r8
   4263a:	cmp    %rax,%r8
   4263d:	jbe    428aa <<c30walk::ctor::W<false>>::complete_checked+0x35a>
   42643:	mov    0x8(%r10),%r8
   42647:	shl    $0x7,%eax
   4264a:	mov    %ebp,(%r8,%rax,1)
   4264e:	movzwl 0x2(%r11),%r9d
   42653:	lea    (%r14,%r12,1),%r13d
   42657:	add    %r13d,%r9d
   4265a:	shl    $0x8,%r9d
   4265e:	or     %ebx,%r9d
   42661:	mov    %r9d,0x4(%r8,%rax,1)
   42666:	movzwl 0x4(%r11),%r9d
   4266b:	add    %r13d,%r9d
   4266e:	shl    $0x8,%r9d
   42672:	or     %ebx,%r9d
   42675:	mov    %r9d,0x8(%r8,%rax,1)
   4267a:	movzwl 0x6(%r11),%r9d
   4267f:	add    %r13d,%r9d
   42682:	shl    $0x8,%r9d
   42686:	or     %ebx,%r9d
   42689:	mov    %r9d,0xc(%r8,%rax,1)
   4268e:	movzwl 0x8(%r11),%r9d
   42693:	add    %r13d,%r9d
   42696:	shl    $0x8,%r9d
   4269a:	or     %ebx,%r9d
   4269d:	mov    %r9d,0x10(%r8,%rax,1)
   426a2:	movzwl 0xa(%r11),%r9d
   426a7:	add    %r13d,%r9d
   426aa:	shl    $0x8,%r9d
   426ae:	or     %ebx,%r9d
   426b1:	mov    %r9d,0x14(%r8,%rax,1)
   426b6:	movzwl 0xc(%r11),%r9d
   426bb:	add    %r13d,%r9d
   426be:	shl    $0x8,%r9d
   426c2:	or     %ebx,%r9d
   426c5:	mov    %r9d,0x18(%r8,%rax,1)
   426ca:	movzwl 0xe(%r11),%r9d
   426cf:	add    %r13d,%r9d
   426d2:	shl    $0x8,%r9d
   426d6:	or     %ebx,%r9d
   426d9:	mov    %r9d,0x1c(%r8,%rax,1)
   426de:	movzwl 0x10(%r11),%r9d
   426e3:	add    %r13d,%r9d
   426e6:	shl    $0x8,%r9d
   426ea:	or     %ebx,%r9d
   426ed:	mov    %r9d,0x20(%r8,%rax,1)
   426f2:	movzwl 0x12(%r11),%r9d
   426f7:	add    %r13d,%r9d
   426fa:	shl    $0x8,%r9d
   426fe:	or     %ebx,%r9d
   42701:	mov    %r9d,0x24(%r8,%rax,1)
   42706:	movzwl 0x14(%r11),%r9d
   4270b:	add    %r13d,%r9d
   4270e:	shl    $0x8,%r9d
   42712:	or     %ebx,%r9d
   42715:	mov    %r9d,0x28(%r8,%rax,1)
   4271a:	movzwl 0x16(%r11),%r9d
   4271f:	add    %r13d,%r9d
   42722:	shl    $0x8,%r9d
   42726:	or     %ebx,%r9d
   42729:	mov    %r9d,0x2c(%r8,%rax,1)
   4272e:	movzwl 0x18(%r11),%r9d
   42733:	add    %r13d,%r9d
   42736:	shl    $0x8,%r9d
   4273a:	or     %ebx,%r9d
   4273d:	mov    %r9d,0x30(%r8,%rax,1)
   42742:	movzwl 0x1a(%r11),%r9d
   42747:	add    %r13d,%r9d
   4274a:	shl    $0x8,%r9d
   4274e:	or     %ebx,%r9d
   42751:	mov    %r9d,0x34(%r8,%rax,1)
   42756:	movzwl 0x1c(%r11),%r9d
   4275b:	add    %r13d,%r9d
   4275e:	shl    $0x8,%r9d
   42762:	or     %ebx,%r9d
   42765:	mov    %r9d,0x38(%r8,%rax,1)
   4276a:	movzwl 0x1e(%r11),%r9d
   4276f:	add    %r13d,%r9d
   42772:	shl    $0x8,%r9d
   42776:	or     %ebx,%r9d
   42779:	mov    %r9d,0x3c(%r8,%rax,1)
   4277e:	movzwl 0x20(%r11),%r9d
   42783:	add    %r13d,%r9d
   42786:	shl    $0x8,%r9d
   4278a:	or     %ebx,%r9d
   4278d:	mov    %r9d,0x40(%r8,%rax,1)
   42792:	movzwl 0x22(%r11),%r9d
   42797:	add    %r13d,%r9d
   4279a:	shl    $0x8,%r9d
   4279e:	or     %ebx,%r9d
   427a1:	mov    %r9d,0x44(%r8,%rax,1)
   427a6:	movzwl 0x24(%r11),%r9d
   427ab:	add    %r13d,%r9d
   427ae:	shl    $0x8,%r9d
   427b2:	or     %ebx,%r9d
   427b5:	mov    %r9d,0x48(%r8,%rax,1)
   427ba:	movzwl 0x26(%r11),%r9d
   427bf:	add    %r13d,%r9d
   427c2:	shl    $0x8,%r9d
   427c6:	or     %ebx,%r9d
   427c9:	mov    %r9d,0x4c(%r8,%rax,1)
   427ce:	movzwl 0x28(%r11),%r9d
   427d3:	add    %r13d,%r9d
   427d6:	shl    $0x8,%r9d
   427da:	or     %ebx,%r9d
   427dd:	mov    %r9d,0x50(%r8,%rax,1)
   427e2:	movzwl 0x2a(%r11),%r9d
   427e7:	add    %r13d,%r9d
   427ea:	shl    $0x8,%r9d
   427ee:	or     %ebx,%r9d
   427f1:	mov    %r9d,0x54(%r8,%rax,1)
   427f6:	movzwl 0x2c(%r11),%r9d
   427fb:	add    %r13d,%r9d
   427fe:	shl    $0x8,%r9d
   42802:	or     %ebx,%r9d
   42805:	mov    %r9d,0x58(%r8,%rax,1)
   4280a:	movzwl 0x2e(%r11),%r9d
   4280f:	add    %r13d,%r9d
   42812:	shl    $0x8,%r9d
   42816:	or     %ebx,%r9d
   42819:	mov    %r9d,0x5c(%r8,%rax,1)
   4281e:	movzwl 0x30(%r11),%r9d
   42823:	add    %r13d,%r9d
   42826:	shl    $0x8,%r9d
   4282a:	or     %ebx,%r9d
   4282d:	mov    %r9d,0x60(%r8,%rax,1)
   42832:	movzwl 0x32(%r11),%r9d
   42837:	add    %r13d,%r9d
   4283a:	shl    $0x8,%r9d
   4283e:	or     %ebx,%r9d
   42841:	mov    %r9d,0x64(%r8,%rax,1)
   42846:	movzwl 0x34(%r11),%r9d
   4284b:	add    %r13d,%r9d
   4284e:	shl    $0x8,%r9d
   42852:	or     %ebx,%r9d
   42855:	mov    %r9d,0x68(%r8,%rax,1)
   4285a:	movzwl 0x36(%r11),%r9d
   4285f:	add    %r13d,%r9d
   42862:	shl    $0x8,%r9d
   42866:	or     %ebx,%r9d
   42869:	mov    %r9d,0x6c(%r8,%rax,1)
   4286e:	movzwl 0x38(%r11),%r9d
   42873:	add    %r13d,%r9d
   42876:	shl    $0x8,%r9d
   4287a:	or     %ebx,%r9d
   4287d:	mov    %r9d,0x70(%r8,%rax,1)
   42882:	movzwl 0x3a(%r11),%r9d
   42887:	add    %r13d,%r9d
   4288a:	shl    $0x8,%r9d
   4288e:	or     %ebx,%r9d
   42891:	mov    %r9d,0x74(%r8,%rax,1)
   42896:	jmp    425ef <<c30walk::ctor::W<false>>::complete_checked+0x9f>
   4289b:	add    $0x8,%rsp
   4289f:	pop    %rbx
   428a0:	pop    %r12
   428a2:	pop    %r13
   428a4:	pop    %r14
   428a6:	pop    %r15
   428a8:	pop    %rbp
   428a9:	ret
   428aa:	lea    0x9d087(%rip),%rdx        # df938 <__do_global_dtors_aux_fini_array_entry+0x17e0>
   428b1:	mov    %rax,%rdi
   428b4:	mov    %r8,%rsi
   428b7:	call   9d2b <core::panicking::panic_bounds_check>
   428bc:	mov    %rdx,%r8
   428bf:	shr    $0x6,%r8
   428c3:	cmp    (%rsp),%r8
   428c7:	jae    428e7 <<c30walk::ctor::W<false>>::complete_checked+0x397>
   428c9:	mov    (%rsi,%r8,8),%rcx
   428cd:	bt     %rdx,%rcx
   428d1:	jb     428fa <<c30walk::ctor::W<false>>::complete_checked+0x3aa>
   428d3:	lea    0x9cf9e(%rip),%rdx        # df878 <__do_global_dtors_aux_fini_array_entry+0x1720>
   428da:	mov    $0x1e,%esi
   428df:	mov    %rax,%rdi
   428e2:	call   9d2b <core::panicking::panic_bounds_check>
   428e7:	lea    0x9ba6a(%rip),%rdx        # de358 <__do_global_dtors_aux_fini_array_entry+0x200>
   428ee:	mov    %r8,%rdi
   428f1:	mov    (%rsp),%rsi
   428f5:	call   9d2b <core::panicking::panic_bounds_check>
   428fa:	lea    0x9cfef(%rip),%rdx        # df8f0 <__do_global_dtors_aux_fini_array_entry+0x1798>
   42901:	mov    $0x1e,%esi
   42906:	mov    %rax,%rdi
   42909:	call   9d2b <core::panicking::panic_bounds_check>
