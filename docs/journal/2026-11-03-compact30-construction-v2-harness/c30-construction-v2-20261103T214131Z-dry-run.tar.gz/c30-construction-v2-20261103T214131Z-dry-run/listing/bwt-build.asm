# mibz2::bwt::build
# size 0xe97

/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/target/rust-1.97.0/release/examples/c30walk:     file format elf64-x86-64


Disassembly of section .text:

00000000000b7730 <mibz2::bwt::build>:
   b7730:	push   %rbp
   b7731:	push   %r15
   b7733:	push   %r14
   b7735:	push   %r13
   b7737:	push   %r12
   b7739:	push   %rbx
   b773a:	sub    $0x808,%rsp
   b7741:	mov    %rdx,%r15
   b7744:	mov    %rsi,%rbx
   b7747:	mov    %rdi,%r14
   b774a:	movq   $0x0,0x10(%rcx)
   b7752:	cmp    $0xffffff,%rsi
   b7759:	ja     b78d6 <mibz2::bwt::build+0x1a6>
   b775f:	pxor   %xmm0,%xmm0
   b7763:	xor    %eax,%eax
   b7765:	pxor   %xmm2,%xmm2
   b7769:	pxor   %xmm1,%xmm1
   b776d:	nopl   (%rax)
   b7770:	movq   (%r15,%rax,4),%xmm3
   b7776:	movq   0x8(%r15,%rax,4),%xmm4
   b777d:	punpckldq %xmm0,%xmm3
   b7781:	paddq  %xmm2,%xmm3
   b7785:	punpckldq %xmm0,%xmm4
   b7789:	paddq  %xmm1,%xmm4
   b778d:	movq   0x10(%r15,%rax,4),%xmm2
   b7794:	movq   0x18(%r15,%rax,4),%xmm1
   b779b:	punpckldq %xmm0,%xmm2
   b779f:	paddq  %xmm3,%xmm2
   b77a3:	punpckldq %xmm0,%xmm1
   b77a7:	paddq  %xmm4,%xmm1
   b77ab:	add    $0x8,%rax
   b77af:	cmp    $0x100,%rax
   b77b5:	jne    b7770 <mibz2::bwt::build+0x40>
   b77b7:	paddq  %xmm2,%xmm1
   b77bb:	pshufd $0xee,%xmm1,%xmm0
   b77c0:	paddq  %xmm1,%xmm0
   b77c4:	movq   %xmm0,%rax
   b77c9:	cmp    %rbx,%rax
   b77cc:	jne    b78d6 <mibz2::bwt::build+0x1a6>
   b77d2:	mov    %rcx,%r12
   b77d5:	lea    0x8(%rsp),%rdi
   b77da:	xor    %ebp,%ebp
   b77dc:	mov    0x4e45d(%rip),%r13        # 105c40 <memset@GLIBC_2.2.5>
   b77e3:	mov    $0x400,%edx
   b77e8:	xor    %esi,%esi
   b77ea:	call   *%r13
   b77ed:	lea    0x408(%rsp),%rdi
   b77f5:	mov    $0x400,%edx
   b77fa:	xor    %esi,%esi
   b77fc:	call   *%r13
   b77ff:	mov    $0x1,%eax
   b7804:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   b7810:	mov    %ebp,0x404(%rsp,%rax,4)
   b7817:	add    -0x4(%r15,%rax,4),%ebp
   b781c:	mov    %ebp,0x4(%rsp,%rax,4)
   b7820:	mov    %ebp,0x408(%rsp,%rax,4)
   b7827:	add    (%r15,%rax,4),%ebp
   b782b:	mov    %ebp,0x8(%rsp,%rax,4)
   b782f:	add    $0x2,%rax
   b7833:	cmp    $0x101,%rax
   b7839:	jne    b7810 <mibz2::bwt::build+0xe0>
   b783b:	mov    %r12,%rcx
   b783e:	cmp    (%r12),%rbx
   b7842:	ja     b7996 <mibz2::bwt::build+0x266>
   b7848:	mov    0x8(%rcx),%rdx
   b784c:	xor    %r8d,%r8d
   b784f:	cmp    $0x10,%rbx
   b7853:	jae    b79c2 <mibz2::bwt::build+0x292>
   b7859:	cmp    %rbx,%r8
   b785c:	jae    b78b7 <mibz2::bwt::build+0x187>
   b785e:	mov    %r8d,%eax
   b7861:	shl    $0x8,%eax
   b7864:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   b7870:	movzbl (%r14,%r8,1),%esi
   b7875:	lea    0x0(,%rsi,4),%r9d
   b787d:	mov    0x408(%rsp,%r9,1),%edi
   b7885:	cmp    0x8(%rsp,%r9,1),%edi
   b788a:	jae    b78d6 <mibz2::bwt::build+0x1a6>
   b788c:	cmp    %rdi,%rbx
   b788f:	jbe    b7ff8 <mibz2::bwt::build+0x8c8>
   b7895:	movzbl (%r14,%rdi,1),%r9d
   b789a:	add    %eax,%r9d
   b789d:	mov    %r9d,(%rdx,%rdi,4)
   b78a1:	inc    %edi
   b78a3:	mov    %edi,0x408(%rsp,%rsi,4)
   b78aa:	inc    %r8
   b78ad:	add    $0x100,%eax
   b78b2:	cmp    %r8,%rbx
   b78b5:	jne    b7870 <mibz2::bwt::build+0x140>
   b78b7:	lea    0x408(%rsp),%rdi
   b78bf:	lea    0x8(%rsp),%rsi
   b78c4:	mov    $0x400,%edx
   b78c9:	call   *0x4e399(%rip)        # 105c68 <bcmp@GLIBC_2.2.5>
   b78cf:	mov    %r12,%rcx
   b78d2:	test   %eax,%eax
   b78d4:	je     b7900 <mibz2::bwt::build+0x1d0>
   b78d6:	movq   $0x0,0x10(%rcx)
   b78de:	cmp    (%rcx),%rbx
   b78e1:	ja     b7909 <mibz2::bwt::build+0x1d9>
   b78e3:	mov    0x8(%rcx),%r13
   b78e7:	xor    %r12d,%r12d
   b78ea:	test   %rbx,%rbx
   b78ed:	je     b805a <mibz2::bwt::build+0x92a>
   b78f3:	cmp    $0x8,%rbx
   b78f7:	jae    b7937 <mibz2::bwt::build+0x207>
   b78f9:	xor    %eax,%eax
   b78fb:	jmp    b8045 <mibz2::bwt::build+0x915>
   b7900:	mov    %rbx,0x10(%rcx)
   b7904:	jmp    b8033 <mibz2::bwt::build+0x903>
   b7909:	mov    %rcx,%r12
   b790c:	mov    $0x4,%ecx
   b7911:	mov    $0x4,%r8d
   b7917:	mov    %r12,%rdi
   b791a:	xor    %esi,%esi
   b791c:	mov    %rbx,%rdx
   b791f:	call   b6870 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
   b7924:	mov    %r12,%rcx
   b7927:	mov    0x8(%r12),%r13
   b792c:	mov    0x10(%r12),%r12
   b7931:	cmp    $0x8,%rbx
   b7935:	jb     b78f9 <mibz2::bwt::build+0x1c9>
   b7937:	movabs $0x7ffffffffffffff0,%rax
   b7941:	or     $0x8,%rax
   b7945:	and    %rbx,%rax
   b7948:	lea    0x10(,%r12,4),%rdx
   b7950:	add    %r13,%rdx
   b7953:	add    %rax,%r12
   b7956:	xor    %esi,%esi
   b7958:	pxor   %xmm0,%xmm0
   b795c:	nopl   0x0(%rax)
   b7960:	movd   (%r14,%rsi,1),%xmm1
   b7966:	movd   0x4(%r14,%rsi,1),%xmm2
   b796d:	punpcklbw %xmm0,%xmm1
   b7971:	punpcklwd %xmm0,%xmm1
   b7975:	punpcklbw %xmm0,%xmm2
   b7979:	punpcklwd %xmm0,%xmm2
   b797d:	movdqu %xmm1,-0x10(%rdx,%rsi,4)
   b7983:	movdqu %xmm2,(%rdx,%rsi,4)
   b7988:	add    $0x8,%rsi
   b798c:	cmp    %rsi,%rax
   b798f:	jne    b7960 <mibz2::bwt::build+0x230>
   b7991:	jmp    b8055 <mibz2::bwt::build+0x925>
   b7996:	mov    $0x4,%ecx
   b799b:	mov    $0x4,%r8d
   b79a1:	mov    %r12,%rdi
   b79a4:	xor    %esi,%esi
   b79a6:	mov    %rbx,%rdx
   b79a9:	call   b6870 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
   b79ae:	mov    %r12,%rcx
   b79b1:	mov    0x8(%rcx),%rdx
   b79b5:	xor    %r8d,%r8d
   b79b8:	cmp    $0x10,%rbx
   b79bc:	jb     b7859 <mibz2::bwt::build+0x129>
   b79c2:	mov    $0x8,%esi
   b79c7:	pxor   %xmm0,%xmm0
   b79cb:	movdqa -0xab093(%rip),%xmm1        # c940 <GCC_except_table910+0x80>
   b79d3:	movdqa -0xaab3b(%rip),%xmm2        # cea0 <GCC_except_table910+0x5e0>
   b79db:	movdqa -0xaa6e3(%rip),%xmm3        # d300 <GCC_except_table910+0xa40>
   b79e3:	jmp    b7a0b <mibz2::bwt::build+0x2db>
   b79e5:	data16 cs nopw 0x0(%rax,%rax,1)
   b79f0:	lea    0x10(%rsi),%rax
   b79f4:	add    $0x18,%rsi
   b79f8:	add    $0x1000,%r8d
   b79ff:	cmp    %rbx,%rsi
   b7a02:	mov    %rax,%rsi
   b7a05:	ja     b7fc7 <mibz2::bwt::build+0x897>
   b7a0b:	lea    -0x8(%rsi),%rax
   b7a0f:	cmp    %rbx,%rsi
   b7a12:	ja     b8007 <mibz2::bwt::build+0x8d7>
   b7a18:	lea    0x7(%rsi),%rdi
   b7a1c:	cmp    %rbx,%rdi
   b7a1f:	jae    b7fdc <mibz2::bwt::build+0x8ac>
   b7a25:	mov    -0x8(%r14,%rsi,1),%r9
   b7a2a:	mov    (%r14,%rsi,1),%rax
   b7a2e:	mov    %r9,%rdi
   b7a31:	xor    %rax,%rdi
   b7a34:	mov    %r9,%r10
   b7a37:	rol    $0x8,%r10
   b7a3b:	xor    %r9,%r10
   b7a3e:	or     %rdi,%r10
   b7a41:	jne    b7b30 <mibz2::bwt::build+0x400>
   b7a47:	movzbl %r9b,%r9d
   b7a4b:	lea    0x0(,%r9,4),%r10d
   b7a53:	mov    0x408(%rsp,%r10,1),%edi
   b7a5b:	lea    0x10(%rdi),%rax
   b7a5f:	mov    0x8(%rsp,%r10,1),%r10d
   b7a64:	cmp    %r10,%rax
   b7a67:	ja     b78d6 <mibz2::bwt::build+0x1a6>
   b7a6d:	cmp    %rbx,%rax
   b7a70:	ja     b7fe6 <mibz2::bwt::build+0x8b6>
   b7a76:	movzbl (%r14,%rdi,1),%eax
   b7a7b:	add    %r8d,%eax
   b7a7e:	mov    %eax,(%rdx,%rdi,4)
   b7a81:	movd   0x1(%r14,%rdi,1),%xmm4
   b7a88:	punpcklbw %xmm0,%xmm4
   b7a8c:	punpcklwd %xmm0,%xmm4
   b7a90:	movd   %r8d,%xmm5
   b7a95:	pshufd $0x0,%xmm5,%xmm5
   b7a9a:	por    %xmm5,%xmm4
   b7a9e:	por    %xmm1,%xmm4
   b7aa2:	movdqu %xmm4,0x4(%rdx,%rdi,4)
   b7aa8:	movd   0x5(%r14,%rdi,1),%xmm4
   b7aaf:	punpcklbw %xmm0,%xmm4
   b7ab3:	punpcklwd %xmm0,%xmm4
   b7ab7:	por    %xmm5,%xmm4
   b7abb:	por    %xmm2,%xmm4
   b7abf:	movdqu %xmm4,0x14(%rdx,%rdi,4)
   b7ac5:	movd   0x9(%r14,%rdi,1),%xmm4
   b7acc:	punpcklbw %xmm0,%xmm4
   b7ad0:	punpcklwd %xmm0,%xmm4
   b7ad4:	por    %xmm5,%xmm4
   b7ad8:	por    %xmm3,%xmm4
   b7adc:	movdqu %xmm4,0x24(%rdx,%rdi,4)
   b7ae2:	movzbl 0xd(%r14,%rdi,1),%eax
   b7ae8:	lea    0xd00(%r8,%rax,1),%eax
   b7af0:	mov    %eax,0x34(%rdx,%rdi,4)
   b7af4:	movzbl 0xe(%r14,%rdi,1),%eax
   b7afa:	lea    0xe00(%r8,%rax,1),%eax
   b7b02:	mov    %eax,0x38(%rdx,%rdi,4)
   b7b06:	movzbl 0xf(%r14,%rdi,1),%eax
   b7b0c:	lea    0xf00(%r8,%rax,1),%eax
   b7b14:	mov    %eax,0x3c(%rdx,%rdi,4)
   b7b18:	lea    0x10(%rdi),%eax
   b7b1b:	mov    %eax,0x408(%rsp,%r9,4)
   b7b23:	jmp    b79f0 <mibz2::bwt::build+0x2c0>
   b7b28:	nopl   0x0(%rax,%rax,1)
   b7b30:	movzbl %r9b,%r10d
   b7b34:	lea    0x0(,%r10,4),%r11d
   b7b3c:	mov    0x408(%rsp,%r11,1),%edi
   b7b44:	cmp    0x8(%rsp,%r11,1),%edi
   b7b49:	jae    b78d6 <mibz2::bwt::build+0x1a6>
   b7b4f:	cmp    %rdi,%rbx
   b7b52:	jbe    b7ff8 <mibz2::bwt::build+0x8c8>
   b7b58:	mov    %r9,%r11
   b7b5b:	shr    $0x8,%r11
   b7b5f:	movzbl (%r14,%rdi,1),%ebp
   b7b64:	add    %r8d,%ebp
   b7b67:	mov    %ebp,(%rdx,%rdi,4)
   b7b6a:	inc    %edi
   b7b6c:	mov    %edi,0x408(%rsp,%r10,4)
   b7b74:	movzbl %r11b,%r10d
   b7b78:	lea    0x0(,%r10,4),%r11d
   b7b80:	mov    0x408(%rsp,%r11,1),%edi
   b7b88:	cmp    0x8(%rsp,%r11,1),%edi
   b7b8d:	jae    b78d6 <mibz2::bwt::build+0x1a6>
   b7b93:	cmp    %rdi,%rbx
   b7b96:	jbe    b7ff8 <mibz2::bwt::build+0x8c8>
   b7b9c:	mov    %r9,%r11
   b7b9f:	shr    $0x10,%r11
   b7ba3:	movzbl (%r14,%rdi,1),%r13d
   b7ba8:	lea    (%r8,%r13,1),%ebp
   b7bac:	add    $0x100,%ebp
   b7bb2:	mov    %ebp,(%rdx,%rdi,4)
   b7bb5:	inc    %edi
   b7bb7:	mov    %edi,0x408(%rsp,%r10,4)
   b7bbf:	movzbl %r11b,%r10d
   b7bc3:	lea    0x0(,%r10,4),%r11d
   b7bcb:	mov    0x408(%rsp,%r11,1),%edi
   b7bd3:	cmp    0x8(%rsp,%r11,1),%edi
   b7bd8:	jae    b78d6 <mibz2::bwt::build+0x1a6>
   b7bde:	cmp    %rdi,%rbx
   b7be1:	jbe    b7ff8 <mibz2::bwt::build+0x8c8>
   b7be7:	mov    %r9,%r11
   b7bea:	shr    $0x18,%r11
   b7bee:	movzbl (%r14,%rdi,1),%r13d
   b7bf3:	lea    (%r8,%r13,1),%ebp
   b7bf7:	add    $0x200,%ebp
   b7bfd:	mov    %ebp,(%rdx,%rdi,4)
   b7c00:	inc    %edi
   b7c02:	mov    %edi,0x408(%rsp,%r10,4)
   b7c0a:	movzbl %r11b,%r10d
   b7c0e:	lea    0x0(,%r10,4),%r11d
   b7c16:	mov    0x408(%rsp,%r11,1),%edi
   b7c1e:	cmp    0x8(%rsp,%r11,1),%edi
   b7c23:	jae    b78d6 <mibz2::bwt::build+0x1a6>
   b7c29:	cmp    %rdi,%rbx
   b7c2c:	jbe    b7ff8 <mibz2::bwt::build+0x8c8>
   b7c32:	mov    %r9,%r11
   b7c35:	shr    $0x20,%r11
   b7c39:	movzbl (%r14,%rdi,1),%r13d
   b7c3e:	lea    (%r8,%r13,1),%ebp
   b7c42:	add    $0x300,%ebp
   b7c48:	mov    %ebp,(%rdx,%rdi,4)
   b7c4b:	inc    %edi
   b7c4d:	mov    %edi,0x408(%rsp,%r10,4)
   b7c55:	movzbl %r11b,%r10d
   b7c59:	lea    0x0(,%r10,4),%r11d
   b7c61:	mov    0x408(%rsp,%r11,1),%edi
   b7c69:	cmp    0x8(%rsp,%r11,1),%edi
   b7c6e:	jae    b78d6 <mibz2::bwt::build+0x1a6>
   b7c74:	cmp    %rdi,%rbx
   b7c77:	jbe    b7ff8 <mibz2::bwt::build+0x8c8>
   b7c7d:	mov    %r9,%r11
   b7c80:	shr    $0x28,%r11
   b7c84:	movzbl (%r14,%rdi,1),%r13d
   b7c89:	lea    (%r8,%r13,1),%ebp
   b7c8d:	add    $0x400,%ebp
   b7c93:	mov    %ebp,(%rdx,%rdi,4)
   b7c96:	inc    %edi
   b7c98:	mov    %edi,0x408(%rsp,%r10,4)
   b7ca0:	movzbl %r11b,%r10d
   b7ca4:	lea    0x0(,%r10,4),%r11d
   b7cac:	mov    0x408(%rsp,%r11,1),%edi
   b7cb4:	cmp    0x8(%rsp,%r11,1),%edi
   b7cb9:	jae    b78d6 <mibz2::bwt::build+0x1a6>
   b7cbf:	cmp    %rdi,%rbx
   b7cc2:	jbe    b7ff8 <mibz2::bwt::build+0x8c8>
   b7cc8:	mov    %r9,%r11
   b7ccb:	shr    $0x30,%r11
   b7ccf:	movzbl (%r14,%rdi,1),%r13d
   b7cd4:	lea    (%r8,%r13,1),%ebp
   b7cd8:	add    $0x500,%ebp
   b7cde:	mov    %ebp,(%rdx,%rdi,4)
   b7ce1:	inc    %edi
   b7ce3:	mov    %edi,0x408(%rsp,%r10,4)
   b7ceb:	movzbl %r11b,%r10d
   b7cef:	lea    0x0(,%r10,4),%r11d
   b7cf7:	mov    0x408(%rsp,%r11,1),%edi
   b7cff:	cmp    0x8(%rsp,%r11,1),%edi
   b7d04:	jae    b78d6 <mibz2::bwt::build+0x1a6>
   b7d0a:	cmp    %rdi,%rbx
   b7d0d:	jbe    b7ff8 <mibz2::bwt::build+0x8c8>
   b7d13:	shr    $0x38,%r9
   b7d17:	movzbl (%r14,%rdi,1),%r11d
   b7d1c:	add    %r8d,%r11d
   b7d1f:	add    $0x600,%r11d
   b7d26:	mov    %r11d,(%rdx,%rdi,4)
   b7d2a:	inc    %edi
   b7d2c:	mov    %edi,0x408(%rsp,%r10,4)
   b7d34:	lea    0x0(,%r9,4),%r10d
   b7d3c:	mov    0x408(%rsp,%r10,1),%edi
   b7d44:	cmp    0x8(%rsp,%r10,1),%edi
   b7d49:	jae    b78d6 <mibz2::bwt::build+0x1a6>
   b7d4f:	cmp    %rdi,%rbx
   b7d52:	jbe    b7ff8 <mibz2::bwt::build+0x8c8>
   b7d58:	movzbl (%r14,%rdi,1),%r10d
   b7d5d:	add    %r8d,%r10d
   b7d60:	add    $0x700,%r10d
   b7d67:	mov    %r10d,(%rdx,%rdi,4)
   b7d6b:	inc    %edi
   b7d6d:	mov    %edi,0x408(%rsp,%r9,4)
   b7d75:	movzbl %al,%r9d
   b7d79:	lea    0x0(,%r9,4),%r10d
   b7d81:	mov    0x408(%rsp,%r10,1),%edi
   b7d89:	cmp    0x8(%rsp,%r10,1),%edi
   b7d8e:	jae    b78d6 <mibz2::bwt::build+0x1a6>
   b7d94:	cmp    %rdi,%rbx
   b7d97:	jbe    b7ff8 <mibz2::bwt::build+0x8c8>
   b7d9d:	mov    %rax,%r10
   b7da0:	shr    $0x8,%r10
   b7da4:	movzbl (%r14,%rdi,1),%r11d
   b7da9:	add    %r8d,%r11d
   b7dac:	add    $0x800,%r11d
   b7db3:	mov    %r11d,(%rdx,%rdi,4)
   b7db7:	inc    %edi
   b7db9:	mov    %edi,0x408(%rsp,%r9,4)
   b7dc1:	movzbl %r10b,%r9d
   b7dc5:	lea    0x0(,%r9,4),%r10d
   b7dcd:	mov    0x408(%rsp,%r10,1),%edi
   b7dd5:	cmp    0x8(%rsp,%r10,1),%edi
   b7dda:	jae    b78d6 <mibz2::bwt::build+0x1a6>
   b7de0:	cmp    %rdi,%rbx
   b7de3:	jbe    b7ff8 <mibz2::bwt::build+0x8c8>
   b7de9:	mov    %rax,%r10
   b7dec:	shr    $0x10,%r10
   b7df0:	movzbl (%r14,%rdi,1),%r11d
   b7df5:	add    %r8d,%r11d
   b7df8:	add    $0x900,%r11d
   b7dff:	mov    %r11d,(%rdx,%rdi,4)
   b7e03:	inc    %edi
   b7e05:	mov    %edi,0x408(%rsp,%r9,4)
   b7e0d:	movzbl %r10b,%r9d
   b7e11:	lea    0x0(,%r9,4),%r10d
   b7e19:	mov    0x408(%rsp,%r10,1),%edi
   b7e21:	cmp    0x8(%rsp,%r10,1),%edi
   b7e26:	jae    b78d6 <mibz2::bwt::build+0x1a6>
   b7e2c:	cmp    %rdi,%rbx
   b7e2f:	jbe    b7ff8 <mibz2::bwt::build+0x8c8>
   b7e35:	mov    %rax,%r10
   b7e38:	shr    $0x18,%r10
   b7e3c:	movzbl (%r14,%rdi,1),%r11d
   b7e41:	add    %r8d,%r11d
   b7e44:	add    $0xa00,%r11d
   b7e4b:	mov    %r11d,(%rdx,%rdi,4)
   b7e4f:	inc    %edi
   b7e51:	mov    %edi,0x408(%rsp,%r9,4)
   b7e59:	movzbl %r10b,%r9d
   b7e5d:	lea    0x0(,%r9,4),%r10d
   b7e65:	mov    0x408(%rsp,%r10,1),%edi
   b7e6d:	cmp    0x8(%rsp,%r10,1),%edi
   b7e72:	jae    b78d6 <mibz2::bwt::build+0x1a6>
   b7e78:	cmp    %rdi,%rbx
   b7e7b:	jbe    b7ff8 <mibz2::bwt::build+0x8c8>
   b7e81:	mov    %rax,%r10
   b7e84:	shr    $0x20,%r10
   b7e88:	movzbl (%r14,%rdi,1),%r11d
   b7e8d:	add    %r8d,%r11d
   b7e90:	add    $0xb00,%r11d
   b7e97:	mov    %r11d,(%rdx,%rdi,4)
   b7e9b:	inc    %edi
   b7e9d:	mov    %edi,0x408(%rsp,%r9,4)
   b7ea5:	movzbl %r10b,%r9d
   b7ea9:	lea    0x0(,%r9,4),%r10d
   b7eb1:	mov    0x408(%rsp,%r10,1),%edi
   b7eb9:	cmp    0x8(%rsp,%r10,1),%edi
   b7ebe:	jae    b78d6 <mibz2::bwt::build+0x1a6>
   b7ec4:	cmp    %rdi,%rbx
   b7ec7:	jbe    b7ff8 <mibz2::bwt::build+0x8c8>
   b7ecd:	mov    %rax,%r10
   b7ed0:	shr    $0x28,%r10
   b7ed4:	movzbl (%r14,%rdi,1),%r11d
   b7ed9:	add    %r8d,%r11d
   b7edc:	add    $0xc00,%r11d
   b7ee3:	mov    %r11d,(%rdx,%rdi,4)
   b7ee7:	inc    %edi
   b7ee9:	mov    %edi,0x408(%rsp,%r9,4)
   b7ef1:	movzbl %r10b,%r9d
   b7ef5:	lea    0x0(,%r9,4),%r10d
   b7efd:	mov    0x408(%rsp,%r10,1),%edi
   b7f05:	cmp    0x8(%rsp,%r10,1),%edi
   b7f0a:	jae    b78d6 <mibz2::bwt::build+0x1a6>
   b7f10:	cmp    %rdi,%rbx
   b7f13:	jbe    b7ff8 <mibz2::bwt::build+0x8c8>
   b7f19:	mov    %rax,%r10
   b7f1c:	shr    $0x30,%r10
   b7f20:	movzbl (%r14,%rdi,1),%r11d
   b7f25:	add    %r8d,%r11d
   b7f28:	add    $0xd00,%r11d
   b7f2f:	mov    %r11d,(%rdx,%rdi,4)
   b7f33:	inc    %edi
   b7f35:	mov    %edi,0x408(%rsp,%r9,4)
   b7f3d:	movzbl %r10b,%r9d
   b7f41:	lea    0x0(,%r9,4),%r10d
   b7f49:	mov    0x408(%rsp,%r10,1),%edi
   b7f51:	cmp    0x8(%rsp,%r10,1),%edi
   b7f56:	jae    b78d6 <mibz2::bwt::build+0x1a6>
   b7f5c:	cmp    %rdi,%rbx
   b7f5f:	jbe    b7ff8 <mibz2::bwt::build+0x8c8>
   b7f65:	shr    $0x38,%rax
   b7f69:	movzbl (%r14,%rdi,1),%r10d
   b7f6e:	add    %r8d,%r10d
   b7f71:	add    $0xe00,%r10d
   b7f78:	mov    %r10d,(%rdx,%rdi,4)
   b7f7c:	inc    %edi
   b7f7e:	mov    %edi,0x408(%rsp,%r9,4)
   b7f86:	lea    0x0(,%rax,4),%r9d
   b7f8e:	mov    0x408(%rsp,%r9,1),%edi
   b7f96:	cmp    0x8(%rsp,%r9,1),%edi
   b7f9b:	jae    b78d6 <mibz2::bwt::build+0x1a6>
   b7fa1:	cmp    %rdi,%rbx
   b7fa4:	jbe    b7ff8 <mibz2::bwt::build+0x8c8>
   b7fa6:	movzbl (%r14,%rdi,1),%r9d
   b7fab:	add    %r8d,%r9d
   b7fae:	add    $0xf00,%r9d
   b7fb5:	mov    %r9d,(%rdx,%rdi,4)
   b7fb9:	inc    %edi
   b7fbb:	mov    %edi,0x408(%rsp,%rax,4)
   b7fc2:	jmp    b79f0 <mibz2::bwt::build+0x2c0>
   b7fc7:	add    $0xfffffffffffffff8,%rax
   b7fcb:	mov    %rax,%r8
   b7fce:	cmp    %rbx,%r8
   b7fd1:	jb     b785e <mibz2::bwt::build+0x12e>
   b7fd7:	jmp    b78b7 <mibz2::bwt::build+0x187>
   b7fdc:	mov    %ebx,%edi
   b7fde:	and    $0xfffff0,%edi
   b7fe4:	jmp    b8019 <mibz2::bwt::build+0x8e9>
   b7fe6:	lea    0x4c0ab(%rip),%rcx        # 104098 <__frame_dummy_init_array_entry+0x36f8>
   b7fed:	mov    %rax,%rsi
   b7ff0:	mov    %rbx,%rdx
   b7ff3:	call   aad00 <core::slice::index::slice_index_fail>
   b7ff8:	lea    0x4bf79(%rip),%rdx        # 103f78 <__frame_dummy_init_array_entry+0x35d8>
   b7fff:	mov    %rbx,%rsi
   b8002:	call   a9f23 <core::panicking::panic_bounds_check>
   b8007:	lea    0x4c0ea(%rip),%rcx        # 1040f8 <__frame_dummy_init_array_entry+0x3758>
   b800e:	mov    %rax,%rdi
   b8011:	mov    %rbx,%rdx
   b8014:	call   aad00 <core::slice::index::slice_index_fail>
   b8019:	or     $0x8,%rdi
   b801d:	add    $0x10,%rax
   b8021:	lea    0x4c0d0(%rip),%rcx        # 1040f8 <__frame_dummy_init_array_entry+0x3758>
   b8028:	mov    %rax,%rsi
   b802b:	mov    %rbx,%rdx
   b802e:	call   aad00 <core::slice::index::slice_index_fail>
   b8033:	add    $0x808,%rsp
   b803a:	pop    %rbx
   b803b:	pop    %r12
   b803d:	pop    %r13
   b803f:	pop    %r14
   b8041:	pop    %r15
   b8043:	pop    %rbp
   b8044:	ret
   b8045:	movzbl (%r14,%rax,1),%edx
   b804a:	mov    %edx,0x0(%r13,%r12,4)
   b804f:	inc    %r12
   b8052:	inc    %rax
   b8055:	cmp    %rax,%rbx
   b8058:	jne    b8045 <mibz2::bwt::build+0x915>
   b805a:	mov    %r12,0x10(%rcx)
   b805e:	lea    0x8(%rsp),%rdi
   b8063:	xor    %ebp,%ebp
   b8065:	mov    $0x400,%edx
   b806a:	xor    %esi,%esi
   b806c:	call   *0x4dbce(%rip)        # 105c40 <memset@GLIBC_2.2.5>
   b8072:	xor    %eax,%eax
   b8074:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   b8080:	mov    %eax,0x8(%rsp,%rbp,4)
   b8084:	add    (%r15,%rbp,4),%eax
   b8088:	mov    %eax,0xc(%rsp,%rbp,4)
   b808c:	add    0x4(%r15,%rbp,4),%eax
   b8091:	mov    %eax,0x10(%rsp,%rbp,4)
   b8095:	add    0x8(%r15,%rbp,4),%eax
   b809a:	mov    %eax,0x14(%rsp,%rbp,4)
   b809e:	add    0xc(%r15,%rbp,4),%eax
   b80a3:	add    $0x4,%rbp
   b80a7:	cmp    $0x100,%rbp
   b80ae:	jne    b8080 <mibz2::bwt::build+0x950>
   b80b0:	xor    %ecx,%ecx
   b80b2:	cmp    $0x10,%rbx
   b80b6:	jb     b854a <mibz2::bwt::build+0xe1a>
   b80bc:	mov    $0x8,%esi
   b80c1:	movdqa -0xaaf09(%rip),%xmm0        # d1c0 <GCC_except_table910+0x900>
   b80c9:	movdqa -0xab791(%rip),%xmm1        # c940 <GCC_except_table910+0x80>
   b80d1:	movdqa -0xab239(%rip),%xmm2        # cea0 <GCC_except_table910+0x5e0>
   b80d9:	movdqa -0xaade1(%rip),%xmm3        # d300 <GCC_except_table910+0xa40>
   b80e1:	movq   -0xab2d9(%rip),%xmm4        # ce10 <GCC_except_table910+0x550>
   b80e9:	movq   -0xab2a1(%rip),%xmm5        # ce50 <GCC_except_table910+0x590>
   b80f1:	jmp    b81cd <mibz2::bwt::build+0xa9d>
   b80f6:	cs nopw 0x0(%rax,%rax,1)
   b8100:	movzbl %dl,%edx
   b8103:	mov    %edx,%eax
   b8105:	mov    0x8(%rsp,%rax,4),%edi
   b8109:	lea    0x10(%rdi),%rax
   b810d:	cmp    %r12,%rax
   b8110:	ja     b85a6 <mibz2::bwt::build+0xe76>
   b8116:	movzbl 0x0(%r13,%rdi,4),%eax
   b811c:	add    %ecx,%eax
   b811e:	mov    %eax,0x0(%r13,%rdi,4)
   b8123:	movdqu 0x4(%r13,%rdi,4),%xmm6
   b812a:	movdqu 0x14(%r13,%rdi,4),%xmm7
   b8131:	movdqu 0x24(%r13,%rdi,4),%xmm8
   b8138:	pand   %xmm0,%xmm6
   b813c:	movd   %ecx,%xmm9
   b8141:	pshufd $0x0,%xmm9,%xmm9
   b8147:	por    %xmm9,%xmm6
   b814c:	por    %xmm1,%xmm6
   b8150:	movdqu %xmm6,0x4(%r13,%rdi,4)
   b8157:	pand   %xmm0,%xmm7
   b815b:	por    %xmm9,%xmm7
   b8160:	por    %xmm2,%xmm7
   b8164:	movdqu %xmm7,0x14(%r13,%rdi,4)
   b816b:	pand   %xmm0,%xmm8
   b8170:	por    %xmm9,%xmm8
   b8175:	por    %xmm3,%xmm8
   b817a:	movdqu %xmm8,0x24(%r13,%rdi,4)
   b8181:	movq   0x34(%r13,%rdi,4),%xmm6
   b8188:	pand   %xmm4,%xmm6
   b818c:	por    %xmm9,%xmm6
   b8191:	por    %xmm5,%xmm6
   b8195:	movq   %xmm6,0x34(%r13,%rdi,4)
   b819c:	movzbl 0x3c(%r13,%rdi,4),%eax
   b81a2:	add    %ecx,%eax
   b81a4:	add    $0xf00,%eax
   b81a9:	mov    %eax,0x3c(%r13,%rdi,4)
   b81ae:	addl   $0x10,0x8(%rsp,%rdx,4)
   b81b3:	lea    0x10(%rsi),%rax
   b81b7:	add    $0x18,%rsi
   b81bb:	add    $0x1000,%ecx
   b81c1:	cmp    %rbx,%rsi
   b81c4:	mov    %rax,%rsi
   b81c7:	ja     b8543 <mibz2::bwt::build+0xe13>
   b81cd:	lea    -0x8(%rsi),%rax
   b81d1:	cmp    %rbx,%rsi
   b81d4:	ja     b8007 <mibz2::bwt::build+0x8d7>
   b81da:	lea    0x7(%rsi),%rdx
   b81de:	cmp    %rbx,%rdx
   b81e1:	jae    b8594 <mibz2::bwt::build+0xe64>
   b81e7:	mov    -0x8(%r14,%rsi,1),%rdx
   b81ec:	mov    (%r14,%rsi,1),%rax
   b81f0:	mov    %rdx,%rdi
   b81f3:	xor    %rax,%rdi
   b81f6:	mov    %rdx,%r8
   b81f9:	rol    $0x8,%r8
   b81fd:	xor    %rdx,%r8
   b8200:	or     %rdi,%r8
   b8203:	je     b8100 <mibz2::bwt::build+0x9d0>
   b8209:	movzbl %dl,%r8d
   b820d:	mov    %r8d,%edi
   b8210:	mov    0x8(%rsp,%rdi,4),%edi
   b8214:	cmp    %rdi,%r12
   b8217:	jbe    b85b8 <mibz2::bwt::build+0xe88>
   b821d:	mov    %rdx,%r9
   b8220:	shr    $0x8,%r9
   b8224:	movzbl 0x0(%r13,%rdi,4),%r10d
   b822a:	add    %ecx,%r10d
   b822d:	mov    %r10d,0x0(%r13,%rdi,4)
   b8232:	inc    %edi
   b8234:	mov    %edi,0x8(%rsp,%r8,4)
   b8239:	movzbl %r9b,%r8d
   b823d:	mov    %r8d,%edi
   b8240:	mov    0x8(%rsp,%rdi,4),%edi
   b8244:	cmp    %rdi,%r12
   b8247:	jbe    b85b8 <mibz2::bwt::build+0xe88>
   b824d:	mov    %rdx,%r9
   b8250:	shr    $0x10,%r9
   b8254:	movzbl 0x0(%r13,%rdi,4),%r10d
   b825a:	add    %ecx,%r10d
   b825d:	add    $0x100,%r10d
   b8264:	mov    %r10d,0x0(%r13,%rdi,4)
   b8269:	inc    %edi
   b826b:	mov    %edi,0x8(%rsp,%r8,4)
   b8270:	movzbl %r9b,%r8d
   b8274:	mov    %r8d,%edi
   b8277:	mov    0x8(%rsp,%rdi,4),%edi
   b827b:	cmp    %rdi,%r12
   b827e:	jbe    b85b8 <mibz2::bwt::build+0xe88>
   b8284:	mov    %rdx,%r9
   b8287:	shr    $0x18,%r9
   b828b:	movzbl 0x0(%r13,%rdi,4),%r10d
   b8291:	add    %ecx,%r10d
   b8294:	add    $0x200,%r10d
   b829b:	mov    %r10d,0x0(%r13,%rdi,4)
   b82a0:	inc    %edi
   b82a2:	mov    %edi,0x8(%rsp,%r8,4)
   b82a7:	movzbl %r9b,%r8d
   b82ab:	mov    %r8d,%edi
   b82ae:	mov    0x8(%rsp,%rdi,4),%edi
   b82b2:	cmp    %rdi,%r12
   b82b5:	jbe    b85b8 <mibz2::bwt::build+0xe88>
   b82bb:	mov    %rdx,%r9
   b82be:	shr    $0x20,%r9
   b82c2:	movzbl 0x0(%r13,%rdi,4),%r10d
   b82c8:	add    %ecx,%r10d
   b82cb:	add    $0x300,%r10d
   b82d2:	mov    %r10d,0x0(%r13,%rdi,4)
   b82d7:	inc    %edi
   b82d9:	mov    %edi,0x8(%rsp,%r8,4)
   b82de:	movzbl %r9b,%r8d
   b82e2:	mov    %r8d,%edi
   b82e5:	mov    0x8(%rsp,%rdi,4),%edi
   b82e9:	cmp    %rdi,%r12
   b82ec:	jbe    b85b8 <mibz2::bwt::build+0xe88>
   b82f2:	mov    %rdx,%r9
   b82f5:	shr    $0x28,%r9
   b82f9:	movzbl 0x0(%r13,%rdi,4),%r10d
   b82ff:	add    %ecx,%r10d
   b8302:	add    $0x400,%r10d
   b8309:	mov    %r10d,0x0(%r13,%rdi,4)
   b830e:	inc    %edi
   b8310:	mov    %edi,0x8(%rsp,%r8,4)
   b8315:	movzbl %r9b,%r8d
   b8319:	mov    %r8d,%edi
   b831c:	mov    0x8(%rsp,%rdi,4),%edi
   b8320:	cmp    %rdi,%r12
   b8323:	jbe    b85b8 <mibz2::bwt::build+0xe88>
   b8329:	mov    %rdx,%r9
   b832c:	shr    $0x30,%r9
   b8330:	movzbl 0x0(%r13,%rdi,4),%r10d
   b8336:	add    %ecx,%r10d
   b8339:	add    $0x500,%r10d
   b8340:	mov    %r10d,0x0(%r13,%rdi,4)
   b8345:	inc    %edi
   b8347:	mov    %edi,0x8(%rsp,%r8,4)
   b834c:	movzbl %r9b,%r8d
   b8350:	mov    %r8d,%edi
   b8353:	mov    0x8(%rsp,%rdi,4),%edi
   b8357:	cmp    %rdi,%r12
   b835a:	jbe    b85b8 <mibz2::bwt::build+0xe88>
   b8360:	shr    $0x38,%rdx
   b8364:	movzbl 0x0(%r13,%rdi,4),%r9d
   b836a:	add    %ecx,%r9d
   b836d:	add    $0x600,%r9d
   b8374:	mov    %r9d,0x0(%r13,%rdi,4)
   b8379:	inc    %edi
   b837b:	mov    %edi,0x8(%rsp,%r8,4)
   b8380:	mov    0x8(%rsp,%rdx,4),%edi
   b8384:	cmp    %rdi,%r12
   b8387:	jbe    b85b8 <mibz2::bwt::build+0xe88>
   b838d:	movzbl 0x0(%r13,%rdi,4),%r8d
   b8393:	add    %ecx,%r8d
   b8396:	add    $0x700,%r8d
   b839d:	mov    %r8d,0x0(%r13,%rdi,4)
   b83a2:	inc    %edi
   b83a4:	mov    %edi,0x8(%rsp,%rdx,4)
   b83a8:	movzbl %al,%edx
   b83ab:	mov    %edx,%edi
   b83ad:	mov    0x8(%rsp,%rdi,4),%edi
   b83b1:	cmp    %rdi,%r12
   b83b4:	jbe    b85b8 <mibz2::bwt::build+0xe88>
   b83ba:	mov    %rax,%r8
   b83bd:	shr    $0x8,%r8
   b83c1:	movzbl 0x0(%r13,%rdi,4),%r9d
   b83c7:	add    %ecx,%r9d
   b83ca:	add    $0x800,%r9d
   b83d1:	mov    %r9d,0x0(%r13,%rdi,4)
   b83d6:	inc    %edi
   b83d8:	mov    %edi,0x8(%rsp,%rdx,4)
   b83dc:	movzbl %r8b,%edx
   b83e0:	mov    %edx,%edi
   b83e2:	mov    0x8(%rsp,%rdi,4),%edi
   b83e6:	cmp    %rdi,%r12
   b83e9:	jbe    b85b8 <mibz2::bwt::build+0xe88>
   b83ef:	mov    %rax,%r8
   b83f2:	shr    $0x10,%r8
   b83f6:	movzbl 0x0(%r13,%rdi,4),%r9d
   b83fc:	add    %ecx,%r9d
   b83ff:	add    $0x900,%r9d
   b8406:	mov    %r9d,0x0(%r13,%rdi,4)
   b840b:	inc    %edi
   b840d:	mov    %edi,0x8(%rsp,%rdx,4)
   b8411:	movzbl %r8b,%edx
   b8415:	mov    %edx,%edi
   b8417:	mov    0x8(%rsp,%rdi,4),%edi
   b841b:	cmp    %rdi,%r12
   b841e:	jbe    b85b8 <mibz2::bwt::build+0xe88>
   b8424:	mov    %rax,%r8
   b8427:	shr    $0x18,%r8
   b842b:	movzbl 0x0(%r13,%rdi,4),%r9d
   b8431:	add    %ecx,%r9d
   b8434:	add    $0xa00,%r9d
   b843b:	mov    %r9d,0x0(%r13,%rdi,4)
   b8440:	inc    %edi
   b8442:	mov    %edi,0x8(%rsp,%rdx,4)
   b8446:	movzbl %r8b,%edx
   b844a:	mov    %edx,%edi
   b844c:	mov    0x8(%rsp,%rdi,4),%edi
   b8450:	cmp    %rdi,%r12
   b8453:	jbe    b85b8 <mibz2::bwt::build+0xe88>
   b8459:	mov    %rax,%r8
   b845c:	shr    $0x20,%r8
   b8460:	movzbl 0x0(%r13,%rdi,4),%r9d
   b8466:	add    %ecx,%r9d
   b8469:	add    $0xb00,%r9d
   b8470:	mov    %r9d,0x0(%r13,%rdi,4)
   b8475:	inc    %edi
   b8477:	mov    %edi,0x8(%rsp,%rdx,4)
   b847b:	movzbl %r8b,%edx
   b847f:	mov    %edx,%edi
   b8481:	mov    0x8(%rsp,%rdi,4),%edi
   b8485:	cmp    %rdi,%r12
   b8488:	jbe    b85b8 <mibz2::bwt::build+0xe88>
   b848e:	mov    %rax,%r8
   b8491:	shr    $0x28,%r8
   b8495:	movzbl 0x0(%r13,%rdi,4),%r9d
   b849b:	add    %ecx,%r9d
   b849e:	add    $0xc00,%r9d
   b84a5:	mov    %r9d,0x0(%r13,%rdi,4)
   b84aa:	inc    %edi
   b84ac:	mov    %edi,0x8(%rsp,%rdx,4)
   b84b0:	movzbl %r8b,%edx
   b84b4:	mov    %edx,%edi
   b84b6:	mov    0x8(%rsp,%rdi,4),%edi
   b84ba:	cmp    %rdi,%r12
   b84bd:	jbe    b85b8 <mibz2::bwt::build+0xe88>
   b84c3:	mov    %rax,%r8
   b84c6:	shr    $0x30,%r8
   b84ca:	movzbl 0x0(%r13,%rdi,4),%r9d
   b84d0:	add    %ecx,%r9d
   b84d3:	add    $0xd00,%r9d
   b84da:	mov    %r9d,0x0(%r13,%rdi,4)
   b84df:	inc    %edi
   b84e1:	mov    %edi,0x8(%rsp,%rdx,4)
   b84e5:	movzbl %r8b,%edx
   b84e9:	mov    %edx,%edi
   b84eb:	mov    0x8(%rsp,%rdi,4),%edi
   b84ef:	cmp    %rdi,%r12
   b84f2:	jbe    b85b8 <mibz2::bwt::build+0xe88>
   b84f8:	shr    $0x38,%rax
   b84fc:	movzbl 0x0(%r13,%rdi,4),%r8d
   b8502:	add    %ecx,%r8d
   b8505:	add    $0xe00,%r8d
   b850c:	mov    %r8d,0x0(%r13,%rdi,4)
   b8511:	inc    %edi
   b8513:	mov    %edi,0x8(%rsp,%rdx,4)
   b8517:	mov    0x8(%rsp,%rax,4),%edi
   b851b:	cmp    %rdi,%r12
   b851e:	jbe    b85b8 <mibz2::bwt::build+0xe88>
   b8524:	movzbl 0x0(%r13,%rdi,4),%edx
   b852a:	add    %ecx,%edx
   b852c:	add    $0xf00,%edx
   b8532:	mov    %edx,0x0(%r13,%rdi,4)
   b8537:	lea    0x1(%rdi),%edx
   b853a:	mov    %edx,0x8(%rsp,%rax,4)
   b853e:	jmp    b81b3 <mibz2::bwt::build+0xa83>
   b8543:	add    $0xfffffffffffffff8,%rax
   b8547:	mov    %rax,%rcx
   b854a:	cmp    %rbx,%rcx
   b854d:	jae    b8033 <mibz2::bwt::build+0x903>
   b8553:	mov    %ecx,%eax
   b8555:	shl    $0x8,%eax
   b8558:	nopl   0x0(%rax,%rax,1)
   b8560:	movzbl (%r14,%rcx,1),%edx
   b8565:	mov    0x8(%rsp,%rdx,4),%edi
   b8569:	cmp    %rdi,%r12
   b856c:	jbe    b85b8 <mibz2::bwt::build+0xe88>
   b856e:	inc    %rcx
   b8571:	movzbl 0x0(%r13,%rdi,4),%esi
   b8577:	add    %eax,%esi
   b8579:	mov    %esi,0x0(%r13,%rdi,4)
   b857e:	lea    0x1(%rdi),%esi
   b8581:	mov    %esi,0x8(%rsp,%rdx,4)
   b8585:	add    $0x100,%eax
   b858a:	cmp    %rcx,%rbx
   b858d:	jne    b8560 <mibz2::bwt::build+0xe30>
   b858f:	jmp    b8033 <mibz2::bwt::build+0x903>
   b8594:	movabs $0x7ffffffffffffff0,%rdi
   b859e:	and    %rbx,%rdi
   b85a1:	jmp    b8019 <mibz2::bwt::build+0x8e9>
   b85a6:	lea    0x4bb03(%rip),%rcx        # 1040b0 <__frame_dummy_init_array_entry+0x3710>
   b85ad:	mov    %rax,%rsi
   b85b0:	mov    %r12,%rdx
   b85b3:	call   aad00 <core::slice::index::slice_index_fail>
   b85b8:	lea    0x4bb09(%rip),%rdx        # 1040c8 <__frame_dummy_init_array_entry+0x3728>
   b85bf:	mov    %r12,%rsi
   b85c2:	call   a9f23 <core::panicking::panic_bounds_check>
