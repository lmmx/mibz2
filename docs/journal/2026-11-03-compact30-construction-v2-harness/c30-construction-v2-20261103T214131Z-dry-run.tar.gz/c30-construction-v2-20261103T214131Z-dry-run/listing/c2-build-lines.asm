
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/target/rust-1.97.0/release/examples/c30walk:     file format elf64-x86-64


Disassembly of section .text:

000000000009cbf0 <c30walk::cbuild::c2_build>:
c30walk::cbuild::c2_build:
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/cbuild.rs:116
   9cbf0:	push   %rax
   9cbf1:	mov    %r8,%rax
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/cbuild.rs:123
   9cbf4:	mov    %r9,(%rsp)
   9cbf8:	xor    %r8d,%r8d
   9cbfb:	mov    %rax,%r9
   9cbfe:	call   347f0 <<c30walk::ctor2::Ctor2>::build::<false>>
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/cbuild.rs:124
   9cc03:	pop    %rcx
   9cc04:	ret
