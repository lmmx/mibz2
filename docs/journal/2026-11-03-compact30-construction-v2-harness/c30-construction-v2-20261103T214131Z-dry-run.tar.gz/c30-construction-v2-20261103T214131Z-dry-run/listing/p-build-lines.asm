
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/target/rust-1.97.0/release/examples/c30walk:     file format elf64-x86-64


Disassembly of section .text:

000000000009c2d0 <c30walk::cbuild::p_build>:
c30walk::cbuild::p_build:
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/cbuild.rs:98
   9c2d0:	jmp    b7730 <mibz2::bwt::build>
