# c30walk::ctor::canonicalise
# size 0x305

/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/target/rust-1.97.0/release/examples/c30walk:     file format elf64-x86-64


Disassembly of section .text:

0000000000084b60 <c30walk::ctor::canonicalise>:
   84b60:	push   %r15
   84b62:	push   %r14
   84b64:	push   %r13
   84b66:	push   %r12
   84b68:	push   %rbx
   84b69:	sub    $0x10,%rsp
   84b6d:	xor    %r11d,%r11d
   84b70:	test   %rcx,%rcx
   84b73:	je     84c09 <c30walk::ctor::canonicalise+0xa9>
   84b79:	lea    (%rdx,%rcx,8),%rcx
   84b7d:	xor    %r10d,%r10d
   84b80:	jmp    84b9c <c30walk::ctor::canonicalise+0x3c>
   84b82:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   84b90:	add    $0x8,%rdx
   84b94:	inc    %r10
   84b97:	cmp    %rcx,%rdx
   84b9a:	je     84c06 <c30walk::ctor::canonicalise+0xa6>
   84b9c:	mov    (%rdx),%rbx
   84b9f:	test   %rbx,%rbx
   84ba2:	je     84b90 <c30walk::ctor::canonicalise+0x30>
   84ba4:	mov    %r10,%r14
   84ba7:	shl    $0xc,%r14
   84bab:	add    %rsi,%r14
   84bae:	mov    %r11d,%r15d
   84bb1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   84bc0:	tzcnt  %rbx,%r12
   84bc5:	shl    $0x6,%r12d
   84bc9:	mov    0x3c(%r14,%r12,1),%eax
   84bce:	and    $0xfffff,%eax
   84bd3:	cmp    %rax,%r9
   84bd6:	jbe    84e41 <c30walk::ctor::canonicalise+0x2e1>
   84bdc:	add    %r14,%r12
   84bdf:	lea    -0x1(%rbx),%r13
   84be3:	shl    $0x7,%eax
   84be6:	lea    0x1(%r15),%r11d
   84bea:	mov    %r15d,0x7c(%r8,%rax,1)
   84bef:	mov    %r15d,%eax
   84bf2:	or     $0x10000000,%eax
   84bf7:	mov    %eax,0x3c(%r12)
   84bfc:	mov    %r11d,%r15d
   84bff:	and    %r13,%rbx
   84c02:	jne    84bc0 <c30walk::ctor::canonicalise+0x60>
   84c04:	jmp    84b90 <c30walk::ctor::canonicalise+0x30>
   84c06:	mov    %r11d,%r11d
   84c09:	mov    %r11,(%rsp)
   84c0d:	mov    %r9,0x8(%rsp)
   84c12:	cmp    %r11,%r9
   84c15:	jne    84e21 <c30walk::ctor::canonicalise+0x2c1>
   84c1b:	lea    -0x80(%r8),%r10
   84c1f:	xor    %r11d,%r11d
   84c22:	xor    %ecx,%ecx
   84c24:	xor    %edx,%edx
   84c26:	xor    %esi,%esi
   84c28:	mov    %r11,%rax
   84c2b:	shl    $0x7,%rax
   84c2f:	add    %r10,%rax
   84c32:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   84c40:	cmp    %r9,%r11
   84c43:	jae    84d4c <c30walk::ctor::canonicalise+0x1ec>
   84c49:	mov    %r11,%rbx
   84c4c:	inc    %r11
   84c4f:	mov    0xfc(%rax),%r14d
   84c56:	sub    $0xffffffffffffff80,%rax
   84c5a:	cmp    %r14,%rbx
   84c5d:	je     84c40 <c30walk::ctor::canonicalise+0xe0>
   84c5f:	movaps (%rax),%xmm0
   84c62:	movaps 0x10(%rax),%xmm1
   84c66:	movaps 0x20(%rax),%xmm2
   84c6a:	movaps 0x30(%rax),%xmm3
   84c6e:	movaps 0x40(%rax),%xmm4
   84c72:	movaps 0x50(%rax),%xmm5
   84c76:	movaps 0x60(%rax),%xmm6
   84c7a:	movdqa 0x70(%rax),%xmm7
   84c7f:	xor    %r14d,%r14d
   84c82:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   84c90:	pshufd $0xee,%xmm7,%xmm8
   84c96:	movq   %xmm8,%rax
   84c9b:	shr    $0x20,%rax
   84c9f:	cmp    %rax,%r9
   84ca2:	jbe    84e53 <c30walk::ctor::canonicalise+0x2f3>
   84ca8:	mov    %rax,%r15
   84cab:	shl    $0x7,%r15
   84caf:	movaps (%r8,%r15,1),%xmm8
   84cb4:	movaps 0x10(%r8,%r15,1),%xmm9
   84cba:	movaps 0x20(%r8,%r15,1),%xmm10
   84cc0:	movaps 0x30(%r8,%r15,1),%xmm11
   84cc6:	movaps %xmm0,(%r8,%r15,1)
   84ccb:	movaps %xmm1,0x10(%r8,%r15,1)
   84cd1:	movaps %xmm2,0x20(%r8,%r15,1)
   84cd7:	movaps %xmm3,0x30(%r8,%r15,1)
   84cdd:	movaps 0x40(%r8,%r15,1),%xmm12
   84ce3:	movaps %xmm4,0x40(%r8,%r15,1)
   84ce9:	movaps 0x50(%r8,%r15,1),%xmm13
   84cef:	movaps %xmm5,0x50(%r8,%r15,1)
   84cf5:	movaps 0x60(%r8,%r15,1),%xmm14
   84cfb:	movaps %xmm6,0x60(%r8,%r15,1)
   84d01:	movaps 0x70(%r8,%r15,1),%xmm15
   84d07:	movdqa %xmm7,0x70(%r8,%r15,1)
   84d0e:	inc    %r14
   84d11:	movaps %xmm8,%xmm0
   84d15:	movaps %xmm9,%xmm1
   84d19:	movaps %xmm10,%xmm2
   84d1d:	movaps %xmm11,%xmm3
   84d21:	movaps %xmm12,%xmm4
   84d25:	movaps %xmm13,%xmm5
   84d29:	movaps %xmm14,%xmm6
   84d2d:	movaps %xmm15,%xmm7
   84d31:	cmp    %rax,%rbx
   84d34:	jne    84c90 <c30walk::ctor::canonicalise+0x130>
   84d3a:	add    %r14,%rcx
   84d3d:	inc    %rdx
   84d40:	cmp    %rsi,%r14
   84d43:	cmova  %r14,%rsi
   84d47:	jmp    84c28 <c30walk::ctor::canonicalise+0xc8>
   84d4c:	test   %r9,%r9
   84d4f:	je     84e08 <c30walk::ctor::canonicalise+0x2a8>
   84d55:	shl    $0x7,%r9
   84d59:	lea    -0x80(%r9),%r10
   84d5d:	mov    %r10d,%r11d
   84d60:	not    %r11d
   84d63:	mov    %r8,%rax
   84d66:	test   $0x380,%r11d
   84d6d:	je     84da9 <c30walk::ctor::canonicalise+0x249>
   84d6f:	mov    %r10d,%r11d
   84d72:	shr    $0x7,%r11d
   84d76:	inc    %r11d
   84d79:	and    $0x7,%r11d
   84d7d:	neg    %r11
   84d80:	mov    %r8,%rax
   84d83:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   84d90:	movl   $0x0,0x7c(%rax)
   84d97:	sub    $0xffffffffffffff80,%rax
   84d9b:	inc    %r11
   84d9e:	jne    84d90 <c30walk::ctor::canonicalise+0x230>
   84da0:	cmp    $0x380,%r10
   84da7:	jb     84e08 <c30walk::ctor::canonicalise+0x2a8>
   84da9:	add    %r9,%r8
   84dac:	nopl   0x0(%rax)
   84db0:	movl   $0x0,0x7c(%rax)
   84db7:	movl   $0x0,0xfc(%rax)
   84dc1:	movl   $0x0,0x17c(%rax)
   84dcb:	movl   $0x0,0x1fc(%rax)
   84dd5:	movl   $0x0,0x27c(%rax)
   84ddf:	movl   $0x0,0x2fc(%rax)
   84de9:	movl   $0x0,0x37c(%rax)
   84df3:	movl   $0x0,0x3fc(%rax)
   84dfd:	add    $0x400,%rax
   84e03:	cmp    %r8,%rax
   84e06:	jne    84db0 <c30walk::ctor::canonicalise+0x250>
   84e08:	mov    %rcx,(%rdi)
   84e0b:	mov    %rdx,0x8(%rdi)
   84e0f:	mov    %rsi,0x10(%rdi)
   84e13:	add    $0x10,%rsp
   84e17:	pop    %rbx
   84e18:	pop    %r12
   84e1a:	pop    %r13
   84e1c:	pop    %r14
   84e1e:	pop    %r15
   84e20:	ret
   84e21:	lea    -0x70077(%rip),%rdx        # 14db1 <GCC_except_table910+0x84f1>
   84e28:	lea    0x7dfc9(%rip),%r8        # 102df8 <__frame_dummy_init_array_entry+0x2458>
   84e2f:	mov    %rsp,%rdi
   84e32:	lea    0x8(%rsp),%rsi
   84e37:	mov    $0x33,%ecx
   84e3c:	call   aa312 <core::panicking::assert_failed::<usize, usize>>
   84e41:	lea    0x7dfe0(%rip),%rdx        # 102e28 <__frame_dummy_init_array_entry+0x2488>
   84e48:	mov    %rax,%rdi
   84e4b:	mov    %r9,%rsi
   84e4e:	call   a9f23 <core::panicking::panic_bounds_check>
   84e53:	lea    0x7dfb6(%rip),%rdx        # 102e10 <__frame_dummy_init_array_entry+0x2470>
   84e5a:	mov    %rax,%rdi
   84e5d:	mov    %r9,%rsi
   84e60:	call   a9f23 <core::panicking::panic_bounds_check>
