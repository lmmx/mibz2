
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/target/rust-1.97.0/release/examples/c30walk:     file format elf64-x86-64


Disassembly of section .text:

0000000000076af0 <<c30walk::ctor2::W<false>>::refill>:
<c30walk::ctor2::W<false>>::refill:
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:387
   76af0:	push   %r15
   76af2:	push   %r14
   76af4:	push   %rbx
   76af5:	mov    %rdi,%rbx
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:372
   76af8:	lea    (%rsi,%rsi,4),%rax
close<false>():
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:372
   76afc:	lea    (%rdi,%rax,8),%r15
   76b00:	add    $0x40,%r15
   76b04:	mov    0x40(%rdi,%rax,8),%r14
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:373
   76b09:	sub    0x50(%rdi,%rax,8),%r14
   76b0e:	je     76b18 <<c30walk::ctor2::W<false>>::refill+0x28>
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:374
   76b10:	mov    %rbx,%rdi
   76b13:	call   764f0 <<c30walk::ctor2::W<false>>::finish>
<c30walk::ctor2::W<false>>::refill:
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:247
   76b18:	shr    $1,%r14
rank():
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:247
   76b1b:	add    0x18(%r15),%r14d
close<false>():
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:377
   76b1f:	mov    %r14d,0x18(%r15)
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:379
   76b23:	xorps  %xmm0,%xmm0
   76b26:	movups %xmm0,(%r15)
   76b2a:	movq   $0x0,0x10(%r15)
<c30walk::ctor2::W<false>>::refill:
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:390
   76b32:	mov    0x1c(%r15),%eax
   76b36:	cmp    %eax,%r14d
   76b39:	jae    76bc4 <<c30walk::ctor2::W<false>>::refill+0xd4>
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:291
   76b3f:	mov    %r14d,%ecx
field<false>():
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:291
   76b42:	mov    $0x88888889,%edi
   76b47:	imul   %rcx,%rdi
   76b4b:	mov    %rdi,%rcx
   76b4e:	shr    $0x24,%rcx
   76b52:	mov    %ecx,%r9d
   76b55:	shl    $0x5,%r9d
   76b59:	sub    %ecx,%r9d
   76b5c:	sub    %ecx,%r9d
<c30walk::ctor2::W<false>>::refill:
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:350
   76b5f:	lea    0x1e(%r9),%edx
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/cmp.rs:1077
   76b63:	cmp    %eax,%edx
min<u32>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/cmp.rs:1077
   76b65:	cmovae %eax,%edx
<c30walk::ctor2::W<false>>::refill:
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:285
   76b68:	shr    $0x2a,%rdi
is_raw<false>():
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:285
   76b6c:	mov    0x10(%rbx),%rsi
   76b70:	cmp    %rsi,%rdi
   76b73:	jae    76bd0 <<c30walk::ctor2::W<false>>::refill+0xe0>
open<false>():
   76b75:	mov    %r14d,%esi
   76b78:	mov    %rcx,%r8
   76b7b:	shl    $0x6,%r8
   76b7f:	add    0x28(%rbx),%r8
   76b83:	sub    %r9d,%esi
is_raw<false>():
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:285
   76b86:	mov    0x8(%rbx),%r9
   76b8a:	mov    (%r9,%rdi,8),%rdi
open<false>():
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:352
   76b8e:	bt     %rcx,%rdi
   76b92:	jae    76b9f <<c30walk::ctor2::W<false>>::refill+0xaf>
   76b94:	mov    $0xfffff,%edi
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:353
   76b99:	and    0x3c(%r8),%edi
   76b9d:	jmp    76ba4 <<c30walk::ctor2::W<false>>::refill+0xb4>
   76b9f:	mov    $0xffffffff,%edi
field<false>():
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:291
   76ba4:	mov    %esi,%esi
<c30walk::ctor2::W<false>>::refill:
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mut_ptr.rs:961
   76ba6:	lea    (%r8,%rsi,2),%rsi
open<false>():
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:361
   76baa:	mov    %rsi,0x10(%r15)
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:362
   76bae:	mov    %rsi,(%r15)
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:363
   76bb1:	sub    %r14d,%edx
<c30walk::ctor2::W<false>>::refill:
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mut_ptr.rs:961
   76bb4:	lea    (%rsi,%rdx,2),%rdx
open<false>():
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:363
   76bb8:	mov    %rdx,0x8(%r15)
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:365
   76bbc:	mov    %ecx,0x20(%r15)
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:366
   76bc0:	mov    %edi,0x24(%r15)
<c30walk::ctor2::W<false>>::refill:
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:390
   76bc4:	cmp    %eax,%r14d
   76bc7:	setb   %al
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:395
   76bca:	pop    %rbx
   76bcb:	pop    %r14
   76bcd:	pop    %r15
   76bcf:	ret
is_raw<false>():
/tmp/claude-0/-home-user/a3c6f4e5-fac5-5911-974c-cd24e5aa55fb/scratchpad/wt-c30ctor/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:285
   76bd0:	lea    0x8a009(%rip),%rdx        # 100be0 <__frame_dummy_init_array_entry+0x240>
   76bd7:	call   a9f23 <core::panicking::panic_bounds_check>
