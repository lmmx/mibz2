# c30walk::ctor::canonicalise
# size 0x305

/home/louis/dev/mibz2/target/c30-construction-v2-pin/target/rust-1.97.0/release/examples/c30walk:     file format elf64-x86-64


Disassembly of section .text:

0000000000067990 <c30walk::ctor::canonicalise>:
   67990:	push   %r15
   67992:	push   %r14
   67994:	push   %r13
   67996:	push   %r12
   67998:	push   %rbx
   67999:	sub    $0x10,%rsp
   6799d:	xor    %r11d,%r11d
   679a0:	test   %rcx,%rcx
   679a3:	je     67a39 <c30walk::ctor::canonicalise+0xa9>
   679a9:	lea    (%rdx,%rcx,8),%rcx
   679ad:	xor    %r10d,%r10d
   679b0:	jmp    679cc <c30walk::ctor::canonicalise+0x3c>
   679b2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   679c0:	add    $0x8,%rdx
   679c4:	inc    %r10
   679c7:	cmp    %rcx,%rdx
   679ca:	je     67a36 <c30walk::ctor::canonicalise+0xa6>
   679cc:	mov    (%rdx),%rbx
   679cf:	test   %rbx,%rbx
   679d2:	je     679c0 <c30walk::ctor::canonicalise+0x30>
   679d4:	mov    %r10,%r14
   679d7:	shl    $0xc,%r14
   679db:	add    %rsi,%r14
   679de:	mov    %r11d,%r15d
   679e1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   679f0:	tzcnt  %rbx,%r12
   679f5:	shl    $0x6,%r12d
   679f9:	mov    0x3c(%r14,%r12,1),%eax
   679fe:	and    $0xfffff,%eax
   67a03:	cmp    %rax,%r9
   67a06:	jbe    67c71 <c30walk::ctor::canonicalise+0x2e1>
   67a0c:	add    %r14,%r12
   67a0f:	lea    -0x1(%rbx),%r13
   67a13:	shl    $0x7,%eax
   67a16:	lea    0x1(%r15),%r11d
   67a1a:	mov    %r15d,0x7c(%r8,%rax,1)
   67a1f:	mov    %r15d,%eax
   67a22:	or     $0x10000000,%eax
   67a27:	mov    %eax,0x3c(%r12)
   67a2c:	mov    %r11d,%r15d
   67a2f:	and    %r13,%rbx
   67a32:	jne    679f0 <c30walk::ctor::canonicalise+0x60>
   67a34:	jmp    679c0 <c30walk::ctor::canonicalise+0x30>
   67a36:	mov    %r11d,%r11d
   67a39:	mov    %r11,(%rsp)
   67a3d:	mov    %r9,0x8(%rsp)
   67a42:	cmp    %r11,%r9
   67a45:	jne    67c51 <c30walk::ctor::canonicalise+0x2c1>
   67a4b:	lea    -0x80(%r8),%r10
   67a4f:	xor    %r11d,%r11d
   67a52:	xor    %ecx,%ecx
   67a54:	xor    %edx,%edx
   67a56:	xor    %esi,%esi
   67a58:	mov    %r11,%rax
   67a5b:	shl    $0x7,%rax
   67a5f:	add    %r10,%rax
   67a62:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   67a70:	cmp    %r9,%r11
   67a73:	jae    67b7c <c30walk::ctor::canonicalise+0x1ec>
   67a79:	mov    %r11,%rbx
   67a7c:	inc    %r11
   67a7f:	mov    0xfc(%rax),%r14d
   67a86:	sub    $0xffffffffffffff80,%rax
   67a8a:	cmp    %r14,%rbx
   67a8d:	je     67a70 <c30walk::ctor::canonicalise+0xe0>
   67a8f:	movaps (%rax),%xmm0
   67a92:	movaps 0x10(%rax),%xmm1
   67a96:	movaps 0x20(%rax),%xmm2
   67a9a:	movaps 0x30(%rax),%xmm3
   67a9e:	movaps 0x40(%rax),%xmm4
   67aa2:	movaps 0x50(%rax),%xmm5
   67aa6:	movaps 0x60(%rax),%xmm6
   67aaa:	movdqa 0x70(%rax),%xmm7
   67aaf:	xor    %r14d,%r14d
   67ab2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   67ac0:	pshufd $0xee,%xmm7,%xmm8
   67ac6:	movq   %xmm8,%rax
   67acb:	shr    $0x20,%rax
   67acf:	cmp    %rax,%r9
   67ad2:	jbe    67c83 <c30walk::ctor::canonicalise+0x2f3>
   67ad8:	mov    %rax,%r15
   67adb:	shl    $0x7,%r15
   67adf:	movaps (%r8,%r15,1),%xmm8
   67ae4:	movaps 0x10(%r8,%r15,1),%xmm9
   67aea:	movaps 0x20(%r8,%r15,1),%xmm10
   67af0:	movaps 0x30(%r8,%r15,1),%xmm11
   67af6:	movaps %xmm0,(%r8,%r15,1)
   67afb:	movaps %xmm1,0x10(%r8,%r15,1)
   67b01:	movaps %xmm2,0x20(%r8,%r15,1)
   67b07:	movaps %xmm3,0x30(%r8,%r15,1)
   67b0d:	movaps 0x40(%r8,%r15,1),%xmm12
   67b13:	movaps %xmm4,0x40(%r8,%r15,1)
   67b19:	movaps 0x50(%r8,%r15,1),%xmm13
   67b1f:	movaps %xmm5,0x50(%r8,%r15,1)
   67b25:	movaps 0x60(%r8,%r15,1),%xmm14
   67b2b:	movaps %xmm6,0x60(%r8,%r15,1)
   67b31:	movaps 0x70(%r8,%r15,1),%xmm15
   67b37:	movdqa %xmm7,0x70(%r8,%r15,1)
   67b3e:	inc    %r14
   67b41:	movaps %xmm8,%xmm0
   67b45:	movaps %xmm9,%xmm1
   67b49:	movaps %xmm10,%xmm2
   67b4d:	movaps %xmm11,%xmm3
   67b51:	movaps %xmm12,%xmm4
   67b55:	movaps %xmm13,%xmm5
   67b59:	movaps %xmm14,%xmm6
   67b5d:	movaps %xmm15,%xmm7
   67b61:	cmp    %rax,%rbx
   67b64:	jne    67ac0 <c30walk::ctor::canonicalise+0x130>
   67b6a:	add    %r14,%rcx
   67b6d:	inc    %rdx
   67b70:	cmp    %rsi,%r14
   67b73:	cmova  %r14,%rsi
   67b77:	jmp    67a58 <c30walk::ctor::canonicalise+0xc8>
   67b7c:	test   %r9,%r9
   67b7f:	je     67c38 <c30walk::ctor::canonicalise+0x2a8>
   67b85:	shl    $0x7,%r9
   67b89:	lea    -0x80(%r9),%r10
   67b8d:	mov    %r10d,%r11d
   67b90:	not    %r11d
   67b93:	mov    %r8,%rax
   67b96:	test   $0x380,%r11d
   67b9d:	je     67bd9 <c30walk::ctor::canonicalise+0x249>
   67b9f:	mov    %r10d,%r11d
   67ba2:	shr    $0x7,%r11d
   67ba6:	inc    %r11d
   67ba9:	and    $0x7,%r11d
   67bad:	neg    %r11
   67bb0:	mov    %r8,%rax
   67bb3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   67bc0:	movl   $0x0,0x7c(%rax)
   67bc7:	sub    $0xffffffffffffff80,%rax
   67bcb:	inc    %r11
   67bce:	jne    67bc0 <c30walk::ctor::canonicalise+0x230>
   67bd0:	cmp    $0x380,%r10
   67bd7:	jb     67c38 <c30walk::ctor::canonicalise+0x2a8>
   67bd9:	add    %r9,%r8
   67bdc:	nopl   0x0(%rax)
   67be0:	movl   $0x0,0x7c(%rax)
   67be7:	movl   $0x0,0xfc(%rax)
   67bf1:	movl   $0x0,0x17c(%rax)
   67bfb:	movl   $0x0,0x1fc(%rax)
   67c05:	movl   $0x0,0x27c(%rax)
   67c0f:	movl   $0x0,0x2fc(%rax)
   67c19:	movl   $0x0,0x37c(%rax)
   67c23:	movl   $0x0,0x3fc(%rax)
   67c2d:	add    $0x400,%rax
   67c33:	cmp    %r8,%rax
   67c36:	jne    67be0 <c30walk::ctor::canonicalise+0x250>
   67c38:	mov    %rcx,(%rdi)
   67c3b:	mov    %rdx,0x8(%rdi)
   67c3f:	mov    %rsi,0x10(%rdi)
   67c43:	add    $0x10,%rsp
   67c47:	pop    %rbx
   67c48:	pop    %r12
   67c4a:	pop    %r13
   67c4c:	pop    %r14
   67c4e:	pop    %r15
   67c50:	ret
   67c51:	lea    0x7c799(%rip),%rdx        # e43f1 <_fini+0x8ba5>
   67c58:	lea    0x9b279(%rip),%r8        # 102ed8 <__do_global_dtors_aux_fini_array_entry+0x2458>
   67c5f:	mov    %rsp,%rdi
   67c62:	lea    0x8(%rsp),%rsi
   67c67:	mov    $0x33,%ecx
   67c6c:	call   af77 <core::panicking::assert_failed::<usize, usize>>
   67c71:	lea    0x9b290(%rip),%rdx        # 102f08 <__do_global_dtors_aux_fini_array_entry+0x2488>
   67c78:	mov    %rax,%rdi
   67c7b:	mov    %r9,%rsi
   67c7e:	call   af3b <core::panicking::panic_bounds_check>
   67c83:	lea    0x9b266(%rip),%rdx        # 102ef0 <__do_global_dtors_aux_fini_array_entry+0x2470>
   67c8a:	mov    %rax,%rdi
   67c8d:	mov    %r9,%rsi
   67c90:	call   af3b <core::panicking::panic_bounds_check>
