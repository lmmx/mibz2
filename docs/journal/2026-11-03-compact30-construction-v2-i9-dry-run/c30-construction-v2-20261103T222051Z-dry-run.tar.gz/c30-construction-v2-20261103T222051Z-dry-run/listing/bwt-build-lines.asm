
/home/louis/dev/mibz2/target/c30-construction-v2-pin/target/rust-1.97.0/release/examples/c30walk:     file format elf64-x86-64


Disassembly of section .text:

0000000000099120 <mibz2::bwt::build>:
mibz2::bwt::build:
   99120:	push   %rbp
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:250
   99121:	push   %r15
   99123:	push   %r14
   99125:	push   %r13
   99127:	push   %r12
   99129:	push   %rbx
   9912a:	sub    $0x808,%rsp
   99131:	mov    %rdx,%r15
   99134:	mov    %rsi,%rbx
   99137:	mov    %rdi,%r14
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/alloc/src/vec/mod.rs:3035
   9913a:	movq   $0x0,0x10(%rcx)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:265
   99142:	cmp    $0xffffff,%rsi
build_one_pass():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:265
   99149:	ja     992c6 <mibz2::bwt::build+0x1a6>
   9914f:	pxor   %xmm0,%xmm0
   99153:	xor    %eax,%eax
   99155:	pxor   %xmm2,%xmm2
   99159:	pxor   %xmm1,%xmm1
   9915d:	nopl   (%rax)
mibz2::bwt::build:
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/iter/macros.rs:279
   99160:	movq   (%r15,%rax,4),%xmm3
fold<u32, usize, core::iter::adapters::map::map_fold::{closure_env#0}<&u32, usize, usize, mibz2::bwt::build_one_pass::{closure_env#0}, core::iter::traits::accum::{impl#48}::sum::{closure_env#0}<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, mibz2::bwt::build_one_pass::{closure_env#0}>>>>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/iter/macros.rs:279
   99166:	movq   0x8(%r15,%rax,4),%xmm4
mibz2::bwt::build:
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:265
   9916d:	punpckldq %xmm0,%xmm3
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/iter/traits/accum.rs:55
   99171:	paddq  %xmm2,%xmm3
{closure#0}():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:265
   99175:	punpckldq %xmm0,%xmm4
{closure#0}<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, mibz2::bwt::build_one_pass::{closure_env#0}>>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/iter/traits/accum.rs:55
   99179:	paddq  %xmm1,%xmm4
fold<u32, usize, core::iter::adapters::map::map_fold::{closure_env#0}<&u32, usize, usize, mibz2::bwt::build_one_pass::{closure_env#0}, core::iter::traits::accum::{impl#48}::sum::{closure_env#0}<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, mibz2::bwt::build_one_pass::{closure_env#0}>>>>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/iter/macros.rs:279
   9917d:	movq   0x10(%r15,%rax,4),%xmm2
   99184:	movq   0x18(%r15,%rax,4),%xmm1
{closure#0}():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:265
   9918b:	punpckldq %xmm0,%xmm2
{closure#0}<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, mibz2::bwt::build_one_pass::{closure_env#0}>>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/iter/traits/accum.rs:55
   9918f:	paddq  %xmm3,%xmm2
{closure#0}():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:265
   99193:	punpckldq %xmm0,%xmm1
{closure#0}<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, mibz2::bwt::build_one_pass::{closure_env#0}>>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/iter/traits/accum.rs:55
   99197:	paddq  %xmm4,%xmm1
fold<u32, usize, core::iter::adapters::map::map_fold::{closure_env#0}<&u32, usize, usize, mibz2::bwt::build_one_pass::{closure_env#0}, core::iter::traits::accum::{impl#48}::sum::{closure_env#0}<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, mibz2::bwt::build_one_pass::{closure_env#0}>>>>():
   9919b:	add    $0x8,%rax
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/iter/macros.rs:284
   9919f:	cmp    $0x100,%rax
   991a5:	jne    99160 <mibz2::bwt::build+0x40>
   991a7:	paddq  %xmm2,%xmm1
   991ab:	pshufd $0xee,%xmm1,%xmm0
   991b0:	paddq  %xmm1,%xmm0
   991b4:	movq   %xmm0,%rax
build_one_pass():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:265
   991b9:	cmp    %rbx,%rax
   991bc:	jne    992c6 <mibz2::bwt::build+0x1a6>
   991c2:	mov    %rcx,%r12
   991c5:	lea    0x8(%rsp),%rdi
   991ca:	xor    %ebp,%ebp
   991cc:	mov    0x6cc65(%rip),%r13        # 105e38 <memset@GLIBC_2.2.5>
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:268
   991d3:	mov    $0x400,%edx
   991d8:	xor    %esi,%esi
   991da:	call   *%r13
   991dd:	lea    0x408(%rsp),%rdi
   991e5:	mov    $0x400,%edx
   991ea:	xor    %esi,%esi
   991ec:	call   *%r13
   991ef:	mov    $0x1,%eax
   991f4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:271
   99200:	mov    %ebp,0x404(%rsp,%rax,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:272
   99207:	add    -0x4(%r15,%rax,4),%ebp
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:273
   9920c:	mov    %ebp,0x4(%rsp,%rax,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:271
   99210:	mov    %ebp,0x408(%rsp,%rax,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:272
   99217:	add    (%r15,%rax,4),%ebp
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:273
   9921b:	mov    %ebp,0x8(%rsp,%rax,4)
mibz2::bwt::build:
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/cmp.rs:1916
   9921f:	add    $0x2,%rax
lt():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/cmp.rs:1916
   99223:	cmp    $0x101,%rax
mibz2::bwt::build:
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/iter/range.rs:900
   99229:	jne    99200 <mibz2::bwt::build+0xe0>
build_one_pass():
   9922b:	mov    %r12,%rcx
mibz2::bwt::build:
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/alloc/src/raw_vec/mod.rs:767
   9922e:	cmp    (%r12),%rbx
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/alloc/src/raw_vec/mod.rs:673
   99232:	ja     99386 <mibz2::bwt::build+0x266>
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/alloc/src/raw_vec/mod.rs:614
   99238:	mov    0x8(%rcx),%rdx
non_null<alloc::alloc::Global, u32>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/alloc/src/raw_vec/mod.rs:614
   9923c:	xor    %r8d,%r8d
build_one_pass():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:291
   9923f:	cmp    $0x10,%rbx
   99243:	jae    993b2 <mibz2::bwt::build+0x292>
mibz2::bwt::build:
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/cmp.rs:1916
   99249:	cmp    %rbx,%r8
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/iter/range.rs:900
   9924c:	jae    992a7 <mibz2::bwt::build+0x187>
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:281
   9924e:	mov    %r8d,%eax
{closure#1}():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:281
   99251:	shl    $0x8,%eax
   99254:	data16 data16 cs nopw 0x0(%rax,%rax,1)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:279
   99260:	movzbl (%r14,%r8,1),%esi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:280
   99265:	lea    0x0(,%rsi,4),%r9d
   9926d:	mov    0x408(%rsp,%r9,1),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:281
   99275:	cmp    0x8(%rsp,%r9,1),%edi
   9927a:	jae    992c6 <mibz2::bwt::build+0x1a6>
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:285
   9927c:	cmp    %rdi,%rbx
   9927f:	jbe    999e8 <mibz2::bwt::build+0x8c8>
   99285:	movzbl (%r14,%rdi,1),%r9d
   9928a:	add    %eax,%r9d
   9928d:	mov    %r9d,(%rdx,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:286
   99291:	inc    %edi
   99293:	mov    %edi,0x408(%rsp,%rsi,4)
mibz2::bwt::build:
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/num/uint_macros.rs:971
   9929a:	inc    %r8
lt():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/cmp.rs:1916
   9929d:	add    $0x100,%eax
   992a2:	cmp    %r8,%rbx
spec_next<usize>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/iter/range.rs:900
   992a5:	jne    99260 <mibz2::bwt::build+0x140>
build_one_pass():
   992a7:	lea    0x408(%rsp),%rdi
   992af:	lea    0x8(%rsp),%rsi
mibz2::bwt::build:
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/array/equality.rs:157
   992b4:	mov    $0x400,%edx
spec_eq<u32, u32, 256>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/array/equality.rs:157
   992b9:	call   *0x6cc49(%rip)        # 105f08 <bcmp@GLIBC_2.2.5>
   992bf:	mov    %r12,%rcx
   992c2:	test   %eax,%eax
build_one_pass():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:319
   992c4:	je     992f0 <mibz2::bwt::build+0x1d0>
mibz2::bwt::build:
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/alloc/src/vec/mod.rs:3035
   992c6:	movq   $0x0,0x10(%rcx)
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/alloc/src/raw_vec/mod.rs:767
   992ce:	cmp    (%rcx),%rbx
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/alloc/src/raw_vec/mod.rs:673
   992d1:	ja     992f9 <mibz2::bwt::build+0x1d9>
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/alloc/src/raw_vec/mod.rs:614
   992d3:	mov    0x8(%rcx),%r13
non_null<alloc::alloc::Global, u32>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/alloc/src/raw_vec/mod.rs:614
   992d7:	xor    %r12d,%r12d
mibz2::bwt::build:
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/non_null.rs:1714
   992da:	test   %rbx,%rbx
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/iter/macros.rs:25
   992dd:	je     99a4a <mibz2::bwt::build+0x92a>
fold<u8, (), core::iter::adapters::map::map_fold::{closure_env#0}<&u8, u32, (), mibz2::bwt::build_two_pass::{closure_env#0}, core::iter::traits::iterator::Iterator::for_each::call::{closure_env#0}<u32, alloc::vec::{impl#21}::extend_trusted::{closure_env#0}<u32, alloc::alloc::Global, core::iter::adapters::map::Map<core::slice::iter::Iter<u8>, mibz2::bwt::build_two_pass::{closure_env#0}>>>>>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/iter/macros.rs:284
   992e3:	cmp    $0x8,%rbx
   992e7:	jae    99327 <mibz2::bwt::build+0x207>
mibz2::bwt::build:
   992e9:	xor    %eax,%eax
   992eb:	jmp    99a35 <mibz2::bwt::build+0x915>
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/alloc/src/vec/mod.rs:2221
   992f0:	mov    %rbx,0x10(%rcx)
set_len<u32, alloc::alloc::Global>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/alloc/src/vec/mod.rs:2221
   992f4:	jmp    99a23 <mibz2::bwt::build+0x903>
mibz2::bwt::build:
   992f9:	mov    %rcx,%r12
reserve<alloc::alloc::Global>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/alloc/src/raw_vec/mod.rs:675
   992fc:	mov    $0x4,%ecx
   99301:	mov    $0x4,%r8d
   99307:	mov    %r12,%rdi
   9930a:	xor    %esi,%esi
   9930c:	mov    %rbx,%rdx
   9930f:	call   b400 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
   99314:	mov    %r12,%rcx
non_null<alloc::alloc::Global, u32>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/alloc/src/raw_vec/mod.rs:614
   99317:	mov    0x8(%r12),%r13
mibz2::bwt::build:
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/alloc/src/vec/set_len_on_drop.rs:14
   9931c:	mov    0x10(%r12),%r12
fold<u8, (), core::iter::adapters::map::map_fold::{closure_env#0}<&u8, u32, (), mibz2::bwt::build_two_pass::{closure_env#0}, core::iter::traits::iterator::Iterator::for_each::call::{closure_env#0}<u32, alloc::vec::{impl#21}::extend_trusted::{closure_env#0}<u32, alloc::alloc::Global, core::iter::adapters::map::Map<core::slice::iter::Iter<u8>, mibz2::bwt::build_two_pass::{closure_env#0}>>>>>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/iter/macros.rs:284
   99321:	cmp    $0x8,%rbx
   99325:	jb     992e9 <mibz2::bwt::build+0x1c9>
   99327:	movabs $0x7ffffffffffffff0,%rax
   99331:	or     $0x8,%rax
   99335:	and    %rbx,%rax
   99338:	lea    0x10(,%r12,4),%rdx
   99340:	add    %r13,%rdx
   99343:	add    %rax,%r12
   99346:	xor    %esi,%esi
   99348:	pxor   %xmm0,%xmm0
   9934c:	nopl   0x0(%rax)
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/iter/macros.rs:279
   99350:	movd   (%r14,%rsi,1),%xmm1
   99356:	movd   0x4(%r14,%rsi,1),%xmm2
mibz2::bwt::build:
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:334
   9935d:	punpcklbw %xmm0,%xmm1
{closure#0}():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:334
   99361:	punpcklwd %xmm0,%xmm1
   99365:	punpcklbw %xmm0,%xmm2
   99369:	punpcklwd %xmm0,%xmm2
mibz2::bwt::build:
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mod.rs:1933
   9936d:	movdqu %xmm1,-0x10(%rdx,%rsi,4)
write<u32>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mod.rs:1933
   99373:	movdqu %xmm2,(%rdx,%rsi,4)
fold<u8, (), core::iter::adapters::map::map_fold::{closure_env#0}<&u8, u32, (), mibz2::bwt::build_two_pass::{closure_env#0}, core::iter::traits::iterator::Iterator::for_each::call::{closure_env#0}<u32, alloc::vec::{impl#21}::extend_trusted::{closure_env#0}<u32, alloc::alloc::Global, core::iter::adapters::map::Map<core::slice::iter::Iter<u8>, mibz2::bwt::build_two_pass::{closure_env#0}>>>>>():
   99378:	add    $0x8,%rsi
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/iter/macros.rs:284
   9937c:	cmp    %rsi,%rax
   9937f:	jne    99350 <mibz2::bwt::build+0x230>
   99381:	jmp    99a45 <mibz2::bwt::build+0x925>
reserve<alloc::alloc::Global>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/alloc/src/raw_vec/mod.rs:675
   99386:	mov    $0x4,%ecx
   9938b:	mov    $0x4,%r8d
   99391:	mov    %r12,%rdi
   99394:	xor    %esi,%esi
   99396:	mov    %rbx,%rdx
   99399:	call   b400 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
   9939e:	mov    %r12,%rcx
non_null<alloc::alloc::Global, u32>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/alloc/src/raw_vec/mod.rs:614
   993a1:	mov    0x8(%rcx),%rdx
   993a5:	xor    %r8d,%r8d
build_one_pass():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:291
   993a8:	cmp    $0x10,%rbx
   993ac:	jb     99249 <mibz2::bwt::build+0x129>
   993b2:	mov    $0x8,%esi
   993b7:	pxor   %xmm0,%xmm0
   993bb:	movdqa 0x4327d(%rip),%xmm1        # dc640 <_fini+0xdf4>
   993c3:	movdqa 0x43285(%rip),%xmm2        # dc650 <_fini+0xe04>
   993cb:	movdqa 0x4328d(%rip),%xmm3        # dc660 <_fini+0xe14>
   993d3:	jmp    993fb <mibz2::bwt::build+0x2db>
   993d5:	data16 cs nopw 0x0(%rax,%rax,1)
   993e0:	lea    0x10(%rsi),%rax
   993e4:	add    $0x18,%rsi
   993e8:	add    $0x1000,%r8d
   993ef:	cmp    %rbx,%rsi
   993f2:	mov    %rax,%rsi
   993f5:	ja     999b7 <mibz2::bwt::build+0x897>
mibz2::bwt::build:
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:379
   993fb:	lea    -0x8(%rsi),%rax
read_u64():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:379
   993ff:	cmp    %rbx,%rsi
mibz2::bwt::build:
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/num/uint_macros.rs:1050
   99402:	ja     999f7 <mibz2::bwt::build+0x8d7>
   99408:	lea    0x7(%rsi),%rdi
checked_sub():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/num/uint_macros.rs:1050
   9940c:	cmp    %rbx,%rdi
   9940f:	jae    999cc <mibz2::bwt::build+0x8ac>
mibz2::bwt::build:
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:379
   99415:	mov    -0x8(%r14,%rsi,1),%r9
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/result.rs:1718
   9941a:	mov    (%r14,%rsi,1),%rax
build_one_pass():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:293
   9941e:	mov    %r9,%rdi
   99421:	xor    %rax,%rdi
   99424:	mov    %r9,%r10
   99427:	rol    $0x8,%r10
   9942b:	xor    %r9,%r10
   9942e:	or     %rdi,%r10
   99431:	jne    99520 <mibz2::bwt::build+0x400>
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:294
   99437:	movzbl %r9b,%r9d
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:295
   9943b:	lea    0x0(,%r9,4),%r10d
   99443:	mov    0x408(%rsp,%r10,1),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:296
   9944b:	lea    0x10(%rdi),%rax
   9944f:	mov    0x8(%rsp,%r10,1),%r10d
   99454:	cmp    %r10,%rax
   99457:	ja     992c6 <mibz2::bwt::build+0x1a6>
mibz2::bwt::build:
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/index.rs:438
   9945d:	cmp    %rbx,%rax
index<u8>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/index.rs:438
   99460:	ja     999d6 <mibz2::bwt::build+0x8b6>
build_one_pass():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:300
   99466:	movzbl (%r14,%rdi,1),%eax
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:302
   9946b:	add    %r8d,%eax
   9946e:	mov    %eax,(%rdx,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:300
   99471:	movd   0x1(%r14,%rdi,1),%xmm4
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:302
   99478:	punpcklbw %xmm0,%xmm4
   9947c:	punpcklwd %xmm0,%xmm4
   99480:	movd   %r8d,%xmm5
   99485:	pshufd $0x0,%xmm5,%xmm5
   9948a:	por    %xmm5,%xmm4
   9948e:	por    %xmm1,%xmm4
   99492:	movdqu %xmm4,0x4(%rdx,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:300
   99498:	movd   0x5(%r14,%rdi,1),%xmm4
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:302
   9949f:	punpcklbw %xmm0,%xmm4
   994a3:	punpcklwd %xmm0,%xmm4
   994a7:	por    %xmm5,%xmm4
   994ab:	por    %xmm2,%xmm4
   994af:	movdqu %xmm4,0x14(%rdx,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:300
   994b5:	movd   0x9(%r14,%rdi,1),%xmm4
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:302
   994bc:	punpcklbw %xmm0,%xmm4
   994c0:	punpcklwd %xmm0,%xmm4
   994c4:	por    %xmm5,%xmm4
   994c8:	por    %xmm3,%xmm4
   994cc:	movdqu %xmm4,0x24(%rdx,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:300
   994d2:	movzbl 0xd(%r14,%rdi,1),%eax
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:302
   994d8:	lea    0xd00(%r8,%rax,1),%eax
   994e0:	mov    %eax,0x34(%rdx,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:300
   994e4:	movzbl 0xe(%r14,%rdi,1),%eax
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:302
   994ea:	lea    0xe00(%r8,%rax,1),%eax
   994f2:	mov    %eax,0x38(%rdx,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:300
   994f6:	movzbl 0xf(%r14,%rdi,1),%eax
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:302
   994fc:	lea    0xf00(%r8,%rax,1),%eax
   99504:	mov    %eax,0x3c(%rdx,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:304
   99508:	lea    0x10(%rdi),%eax
   9950b:	mov    %eax,0x408(%rsp,%r9,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:293
   99513:	jmp    993e0 <mibz2::bwt::build+0x2c0>
   99518:	nopl   0x0(%rax,%rax,1)
mibz2::bwt::build:
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:279
   99520:	movzbl %r9b,%r10d
{closure#1}():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:280
   99524:	lea    0x0(,%r10,4),%r11d
   9952c:	mov    0x408(%rsp,%r11,1),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:281
   99534:	cmp    0x8(%rsp,%r11,1),%edi
   99539:	jae    992c6 <mibz2::bwt::build+0x1a6>
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:285
   9953f:	cmp    %rdi,%rbx
   99542:	jbe    999e8 <mibz2::bwt::build+0x8c8>
   99548:	mov    %r9,%r11
   9954b:	shr    $0x8,%r11
   9954f:	movzbl (%r14,%rdi,1),%ebp
   99554:	add    %r8d,%ebp
   99557:	mov    %ebp,(%rdx,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:286
   9955a:	inc    %edi
   9955c:	mov    %edi,0x408(%rsp,%r10,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:279
   99564:	movzbl %r11b,%r10d
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:280
   99568:	lea    0x0(,%r10,4),%r11d
   99570:	mov    0x408(%rsp,%r11,1),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:281
   99578:	cmp    0x8(%rsp,%r11,1),%edi
   9957d:	jae    992c6 <mibz2::bwt::build+0x1a6>
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:285
   99583:	cmp    %rdi,%rbx
   99586:	jbe    999e8 <mibz2::bwt::build+0x8c8>
   9958c:	mov    %r9,%r11
   9958f:	shr    $0x10,%r11
   99593:	movzbl (%r14,%rdi,1),%r13d
   99598:	lea    (%r8,%r13,1),%ebp
   9959c:	add    $0x100,%ebp
   995a2:	mov    %ebp,(%rdx,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:286
   995a5:	inc    %edi
   995a7:	mov    %edi,0x408(%rsp,%r10,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:279
   995af:	movzbl %r11b,%r10d
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:280
   995b3:	lea    0x0(,%r10,4),%r11d
   995bb:	mov    0x408(%rsp,%r11,1),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:281
   995c3:	cmp    0x8(%rsp,%r11,1),%edi
   995c8:	jae    992c6 <mibz2::bwt::build+0x1a6>
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:285
   995ce:	cmp    %rdi,%rbx
   995d1:	jbe    999e8 <mibz2::bwt::build+0x8c8>
   995d7:	mov    %r9,%r11
   995da:	shr    $0x18,%r11
   995de:	movzbl (%r14,%rdi,1),%r13d
   995e3:	lea    (%r8,%r13,1),%ebp
   995e7:	add    $0x200,%ebp
   995ed:	mov    %ebp,(%rdx,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:286
   995f0:	inc    %edi
   995f2:	mov    %edi,0x408(%rsp,%r10,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:279
   995fa:	movzbl %r11b,%r10d
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:280
   995fe:	lea    0x0(,%r10,4),%r11d
   99606:	mov    0x408(%rsp,%r11,1),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:281
   9960e:	cmp    0x8(%rsp,%r11,1),%edi
   99613:	jae    992c6 <mibz2::bwt::build+0x1a6>
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:285
   99619:	cmp    %rdi,%rbx
   9961c:	jbe    999e8 <mibz2::bwt::build+0x8c8>
   99622:	mov    %r9,%r11
   99625:	shr    $0x20,%r11
   99629:	movzbl (%r14,%rdi,1),%r13d
   9962e:	lea    (%r8,%r13,1),%ebp
   99632:	add    $0x300,%ebp
   99638:	mov    %ebp,(%rdx,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:286
   9963b:	inc    %edi
   9963d:	mov    %edi,0x408(%rsp,%r10,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:279
   99645:	movzbl %r11b,%r10d
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:280
   99649:	lea    0x0(,%r10,4),%r11d
   99651:	mov    0x408(%rsp,%r11,1),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:281
   99659:	cmp    0x8(%rsp,%r11,1),%edi
   9965e:	jae    992c6 <mibz2::bwt::build+0x1a6>
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:285
   99664:	cmp    %rdi,%rbx
   99667:	jbe    999e8 <mibz2::bwt::build+0x8c8>
   9966d:	mov    %r9,%r11
   99670:	shr    $0x28,%r11
   99674:	movzbl (%r14,%rdi,1),%r13d
   99679:	lea    (%r8,%r13,1),%ebp
   9967d:	add    $0x400,%ebp
   99683:	mov    %ebp,(%rdx,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:286
   99686:	inc    %edi
   99688:	mov    %edi,0x408(%rsp,%r10,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:279
   99690:	movzbl %r11b,%r10d
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:280
   99694:	lea    0x0(,%r10,4),%r11d
   9969c:	mov    0x408(%rsp,%r11,1),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:281
   996a4:	cmp    0x8(%rsp,%r11,1),%edi
   996a9:	jae    992c6 <mibz2::bwt::build+0x1a6>
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:285
   996af:	cmp    %rdi,%rbx
   996b2:	jbe    999e8 <mibz2::bwt::build+0x8c8>
   996b8:	mov    %r9,%r11
   996bb:	shr    $0x30,%r11
   996bf:	movzbl (%r14,%rdi,1),%r13d
   996c4:	lea    (%r8,%r13,1),%ebp
   996c8:	add    $0x500,%ebp
   996ce:	mov    %ebp,(%rdx,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:286
   996d1:	inc    %edi
   996d3:	mov    %edi,0x408(%rsp,%r10,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:279
   996db:	movzbl %r11b,%r10d
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:280
   996df:	lea    0x0(,%r10,4),%r11d
   996e7:	mov    0x408(%rsp,%r11,1),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:281
   996ef:	cmp    0x8(%rsp,%r11,1),%edi
   996f4:	jae    992c6 <mibz2::bwt::build+0x1a6>
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:285
   996fa:	cmp    %rdi,%rbx
   996fd:	jbe    999e8 <mibz2::bwt::build+0x8c8>
   99703:	shr    $0x38,%r9
   99707:	movzbl (%r14,%rdi,1),%r11d
   9970c:	add    %r8d,%r11d
   9970f:	add    $0x600,%r11d
   99716:	mov    %r11d,(%rdx,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:286
   9971a:	inc    %edi
   9971c:	mov    %edi,0x408(%rsp,%r10,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:280
   99724:	lea    0x0(,%r9,4),%r10d
   9972c:	mov    0x408(%rsp,%r10,1),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:281
   99734:	cmp    0x8(%rsp,%r10,1),%edi
   99739:	jae    992c6 <mibz2::bwt::build+0x1a6>
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:285
   9973f:	cmp    %rdi,%rbx
   99742:	jbe    999e8 <mibz2::bwt::build+0x8c8>
   99748:	movzbl (%r14,%rdi,1),%r10d
   9974d:	add    %r8d,%r10d
   99750:	add    $0x700,%r10d
   99757:	mov    %r10d,(%rdx,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:286
   9975b:	inc    %edi
   9975d:	mov    %edi,0x408(%rsp,%r9,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:279
   99765:	movzbl %al,%r9d
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:280
   99769:	lea    0x0(,%r9,4),%r10d
   99771:	mov    0x408(%rsp,%r10,1),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:281
   99779:	cmp    0x8(%rsp,%r10,1),%edi
   9977e:	jae    992c6 <mibz2::bwt::build+0x1a6>
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:285
   99784:	cmp    %rdi,%rbx
   99787:	jbe    999e8 <mibz2::bwt::build+0x8c8>
   9978d:	mov    %rax,%r10
   99790:	shr    $0x8,%r10
   99794:	movzbl (%r14,%rdi,1),%r11d
   99799:	add    %r8d,%r11d
   9979c:	add    $0x800,%r11d
   997a3:	mov    %r11d,(%rdx,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:286
   997a7:	inc    %edi
   997a9:	mov    %edi,0x408(%rsp,%r9,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:279
   997b1:	movzbl %r10b,%r9d
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:280
   997b5:	lea    0x0(,%r9,4),%r10d
   997bd:	mov    0x408(%rsp,%r10,1),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:281
   997c5:	cmp    0x8(%rsp,%r10,1),%edi
   997ca:	jae    992c6 <mibz2::bwt::build+0x1a6>
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:285
   997d0:	cmp    %rdi,%rbx
   997d3:	jbe    999e8 <mibz2::bwt::build+0x8c8>
   997d9:	mov    %rax,%r10
   997dc:	shr    $0x10,%r10
   997e0:	movzbl (%r14,%rdi,1),%r11d
   997e5:	add    %r8d,%r11d
   997e8:	add    $0x900,%r11d
   997ef:	mov    %r11d,(%rdx,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:286
   997f3:	inc    %edi
   997f5:	mov    %edi,0x408(%rsp,%r9,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:279
   997fd:	movzbl %r10b,%r9d
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:280
   99801:	lea    0x0(,%r9,4),%r10d
   99809:	mov    0x408(%rsp,%r10,1),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:281
   99811:	cmp    0x8(%rsp,%r10,1),%edi
   99816:	jae    992c6 <mibz2::bwt::build+0x1a6>
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:285
   9981c:	cmp    %rdi,%rbx
   9981f:	jbe    999e8 <mibz2::bwt::build+0x8c8>
   99825:	mov    %rax,%r10
   99828:	shr    $0x18,%r10
   9982c:	movzbl (%r14,%rdi,1),%r11d
   99831:	add    %r8d,%r11d
   99834:	add    $0xa00,%r11d
   9983b:	mov    %r11d,(%rdx,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:286
   9983f:	inc    %edi
   99841:	mov    %edi,0x408(%rsp,%r9,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:279
   99849:	movzbl %r10b,%r9d
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:280
   9984d:	lea    0x0(,%r9,4),%r10d
   99855:	mov    0x408(%rsp,%r10,1),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:281
   9985d:	cmp    0x8(%rsp,%r10,1),%edi
   99862:	jae    992c6 <mibz2::bwt::build+0x1a6>
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:285
   99868:	cmp    %rdi,%rbx
   9986b:	jbe    999e8 <mibz2::bwt::build+0x8c8>
   99871:	mov    %rax,%r10
   99874:	shr    $0x20,%r10
   99878:	movzbl (%r14,%rdi,1),%r11d
   9987d:	add    %r8d,%r11d
   99880:	add    $0xb00,%r11d
   99887:	mov    %r11d,(%rdx,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:286
   9988b:	inc    %edi
   9988d:	mov    %edi,0x408(%rsp,%r9,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:279
   99895:	movzbl %r10b,%r9d
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:280
   99899:	lea    0x0(,%r9,4),%r10d
   998a1:	mov    0x408(%rsp,%r10,1),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:281
   998a9:	cmp    0x8(%rsp,%r10,1),%edi
   998ae:	jae    992c6 <mibz2::bwt::build+0x1a6>
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:285
   998b4:	cmp    %rdi,%rbx
   998b7:	jbe    999e8 <mibz2::bwt::build+0x8c8>
   998bd:	mov    %rax,%r10
   998c0:	shr    $0x28,%r10
   998c4:	movzbl (%r14,%rdi,1),%r11d
   998c9:	add    %r8d,%r11d
   998cc:	add    $0xc00,%r11d
   998d3:	mov    %r11d,(%rdx,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:286
   998d7:	inc    %edi
   998d9:	mov    %edi,0x408(%rsp,%r9,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:279
   998e1:	movzbl %r10b,%r9d
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:280
   998e5:	lea    0x0(,%r9,4),%r10d
   998ed:	mov    0x408(%rsp,%r10,1),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:281
   998f5:	cmp    0x8(%rsp,%r10,1),%edi
   998fa:	jae    992c6 <mibz2::bwt::build+0x1a6>
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:285
   99900:	cmp    %rdi,%rbx
   99903:	jbe    999e8 <mibz2::bwt::build+0x8c8>
   99909:	mov    %rax,%r10
   9990c:	shr    $0x30,%r10
   99910:	movzbl (%r14,%rdi,1),%r11d
   99915:	add    %r8d,%r11d
   99918:	add    $0xd00,%r11d
   9991f:	mov    %r11d,(%rdx,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:286
   99923:	inc    %edi
   99925:	mov    %edi,0x408(%rsp,%r9,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:279
   9992d:	movzbl %r10b,%r9d
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:280
   99931:	lea    0x0(,%r9,4),%r10d
   99939:	mov    0x408(%rsp,%r10,1),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:281
   99941:	cmp    0x8(%rsp,%r10,1),%edi
   99946:	jae    992c6 <mibz2::bwt::build+0x1a6>
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:285
   9994c:	cmp    %rdi,%rbx
   9994f:	jbe    999e8 <mibz2::bwt::build+0x8c8>
   99955:	shr    $0x38,%rax
   99959:	movzbl (%r14,%rdi,1),%r10d
   9995e:	add    %r8d,%r10d
   99961:	add    $0xe00,%r10d
   99968:	mov    %r10d,(%rdx,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:286
   9996c:	inc    %edi
   9996e:	mov    %edi,0x408(%rsp,%r9,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:280
   99976:	lea    0x0(,%rax,4),%r9d
   9997e:	mov    0x408(%rsp,%r9,1),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:281
   99986:	cmp    0x8(%rsp,%r9,1),%edi
   9998b:	jae    992c6 <mibz2::bwt::build+0x1a6>
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:285
   99991:	cmp    %rdi,%rbx
   99994:	jbe    999e8 <mibz2::bwt::build+0x8c8>
   99996:	movzbl (%r14,%rdi,1),%r9d
   9999b:	add    %r8d,%r9d
   9999e:	add    $0xf00,%r9d
   999a5:	mov    %r9d,(%rdx,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:286
   999a9:	inc    %edi
   999ab:	mov    %edi,0x408(%rsp,%rax,4)
   999b2:	jmp    993e0 <mibz2::bwt::build+0x2c0>
lt():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/cmp.rs:1916
   999b7:	add    $0xfffffffffffffff8,%rax
   999bb:	mov    %rax,%r8
   999be:	cmp    %rbx,%r8
spec_next<usize>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/iter/range.rs:900
   999c1:	jb     9924e <mibz2::bwt::build+0x12e>
   999c7:	jmp    992a7 <mibz2::bwt::build+0x187>
checked_sub():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/num/uint_macros.rs:1050
   999cc:	mov    %ebx,%edi
   999ce:	and    $0xfffff0,%edi
   999d4:	jmp    99a09 <mibz2::bwt::build+0x8e9>
index<u8>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/index.rs:443
   999d6:	lea    0x6a79b(%rip),%rcx        # 104178 <__do_global_dtors_aux_fini_array_entry+0x36f8>
mibz2::bwt::build:
   999dd:	mov    %rax,%rsi
   999e0:	mov    %rbx,%rdx
   999e3:	call   aff0 <core::slice::index::slice_index_fail>
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:285
   999e8:	lea    0x6a669(%rip),%rdx        # 104058 <__do_global_dtors_aux_fini_array_entry+0x35d8>
{closure#1}():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:285
   999ef:	mov    %rbx,%rsi
   999f2:	call   af3b <core::panicking::panic_bounds_check>
mibz2::bwt::build:
   999f7:	lea    0x6a7da(%rip),%rcx        # 1041d8 <__do_global_dtors_aux_fini_array_entry+0x3758>
   999fe:	mov    %rax,%rdi
   99a01:	mov    %rbx,%rdx
   99a04:	call   aff0 <core::slice::index::slice_index_fail>
   99a09:	or     $0x8,%rdi
   99a0d:	add    $0x10,%rax
   99a11:	lea    0x6a7c0(%rip),%rcx        # 1041d8 <__do_global_dtors_aux_fini_array_entry+0x3758>
   99a18:	mov    %rax,%rsi
   99a1b:	mov    %rbx,%rdx
   99a1e:	call   aff0 <core::slice::index::slice_index_fail>
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:254
   99a23:	add    $0x808,%rsp
   99a2a:	pop    %rbx
   99a2b:	pop    %r12
   99a2d:	pop    %r13
   99a2f:	pop    %r14
   99a31:	pop    %r15
   99a33:	pop    %rbp
   99a34:	ret
fold<u8, (), core::iter::adapters::map::map_fold::{closure_env#0}<&u8, u32, (), mibz2::bwt::build_two_pass::{closure_env#0}, core::iter::traits::iterator::Iterator::for_each::call::{closure_env#0}<u32, alloc::vec::{impl#21}::extend_trusted::{closure_env#0}<u32, alloc::alloc::Global, core::iter::adapters::map::Map<core::slice::iter::Iter<u8>, mibz2::bwt::build_two_pass::{closure_env#0}>>>>>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/iter/macros.rs:279
   99a35:	movzbl (%r14,%rax,1),%edx
write<u32>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mod.rs:1933
   99a3a:	mov    %edx,0x0(%r13,%r12,4)
mibz2::bwt::build:
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/alloc/src/vec/set_len_on_drop.rs:19
   99a3f:	inc    %r12
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/num/uint_macros.rs:971
   99a42:	inc    %rax
fold<u8, (), core::iter::adapters::map::map_fold::{closure_env#0}<&u8, u32, (), mibz2::bwt::build_two_pass::{closure_env#0}, core::iter::traits::iterator::Iterator::for_each::call::{closure_env#0}<u32, alloc::vec::{impl#21}::extend_trusted::{closure_env#0}<u32, alloc::alloc::Global, core::iter::adapters::map::Map<core::slice::iter::Iter<u8>, mibz2::bwt::build_two_pass::{closure_env#0}>>>>>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/iter/macros.rs:284
   99a45:	cmp    %rax,%rbx
   99a48:	jne    99a35 <mibz2::bwt::build+0x915>
mibz2::bwt::build:
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/alloc/src/vec/set_len_on_drop.rs:31
   99a4a:	mov    %r12,0x10(%rcx)
drop():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/alloc/src/vec/set_len_on_drop.rs:31
   99a4e:	lea    0x8(%rsp),%rdi
   99a53:	xor    %ebp,%ebp
mibz2::bwt::build:
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:335
   99a55:	mov    $0x400,%edx
build_two_pass():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:335
   99a5a:	xor    %esi,%esi
   99a5c:	call   *0x6c3d6(%rip)        # 105e38 <memset@GLIBC_2.2.5>
   99a62:	xor    %eax,%eax
   99a64:	data16 data16 cs nopw 0x0(%rax,%rax,1)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:338
   99a70:	mov    %eax,0x8(%rsp,%rbp,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:339
   99a74:	add    (%r15,%rbp,4),%eax
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:338
   99a78:	mov    %eax,0xc(%rsp,%rbp,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:339
   99a7c:	add    0x4(%r15,%rbp,4),%eax
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:338
   99a81:	mov    %eax,0x10(%rsp,%rbp,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:339
   99a85:	add    0x8(%r15,%rbp,4),%eax
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:338
   99a8a:	mov    %eax,0x14(%rsp,%rbp,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:339
   99a8e:	add    0xc(%r15,%rbp,4),%eax
mibz2::bwt::build:
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/num/uint_macros.rs:971
   99a93:	add    $0x4,%rbp
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/cmp.rs:1916
   99a97:	cmp    $0x100,%rbp
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/iter/range.rs:900
   99a9e:	jne    99a70 <mibz2::bwt::build+0x950>
build_two_pass():
   99aa0:	xor    %ecx,%ecx
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:346
   99aa2:	cmp    $0x10,%rbx
   99aa6:	jb     99f3a <mibz2::bwt::build+0xe1a>
   99aac:	mov    $0x8,%esi
   99ab1:	movdqa 0x42bb7(%rip),%xmm0        # dc670 <_fini+0xe24>
   99ab9:	movdqa 0x42b7f(%rip),%xmm1        # dc640 <_fini+0xdf4>
   99ac1:	movdqa 0x42b87(%rip),%xmm2        # dc650 <_fini+0xe04>
   99ac9:	movdqa 0x42b8f(%rip),%xmm3        # dc660 <_fini+0xe14>
   99ad1:	movq   0x42ba7(%rip),%xmm4        # dc680 <_fini+0xe34>
   99ad9:	movq   0x42baf(%rip),%xmm5        # dc690 <_fini+0xe44>
   99ae1:	jmp    99bbd <mibz2::bwt::build+0xa9d>
   99ae6:	cs nopw 0x0(%rax,%rax,1)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:349
   99af0:	movzbl %dl,%edx
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:350
   99af3:	mov    %edx,%eax
   99af5:	mov    0x8(%rsp,%rax,4),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:352
   99af9:	lea    0x10(%rdi),%rax
mibz2::bwt::build:
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/index.rs:451
   99afd:	cmp    %r12,%rax
index_mut<u32>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/index.rs:451
   99b00:	ja     99f96 <mibz2::bwt::build+0xe76>
build_two_pass():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:353
   99b06:	movzbl 0x0(%r13,%rdi,4),%eax
   99b0c:	add    %ecx,%eax
   99b0e:	mov    %eax,0x0(%r13,%rdi,4)
   99b13:	movdqu 0x4(%r13,%rdi,4),%xmm6
   99b1a:	movdqu 0x14(%r13,%rdi,4),%xmm7
   99b21:	movdqu 0x24(%r13,%rdi,4),%xmm8
   99b28:	pand   %xmm0,%xmm6
   99b2c:	movd   %ecx,%xmm9
   99b31:	pshufd $0x0,%xmm9,%xmm9
   99b37:	por    %xmm9,%xmm6
   99b3c:	por    %xmm1,%xmm6
   99b40:	movdqu %xmm6,0x4(%r13,%rdi,4)
   99b47:	pand   %xmm0,%xmm7
   99b4b:	por    %xmm9,%xmm7
   99b50:	por    %xmm2,%xmm7
   99b54:	movdqu %xmm7,0x14(%r13,%rdi,4)
   99b5b:	pand   %xmm0,%xmm8
   99b60:	por    %xmm9,%xmm8
   99b65:	por    %xmm3,%xmm8
   99b6a:	movdqu %xmm8,0x24(%r13,%rdi,4)
   99b71:	movq   0x34(%r13,%rdi,4),%xmm6
   99b78:	pand   %xmm4,%xmm6
   99b7c:	por    %xmm9,%xmm6
   99b81:	por    %xmm5,%xmm6
   99b85:	movq   %xmm6,0x34(%r13,%rdi,4)
   99b8c:	movzbl 0x3c(%r13,%rdi,4),%eax
   99b92:	add    %ecx,%eax
   99b94:	add    $0xf00,%eax
   99b99:	mov    %eax,0x3c(%r13,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:355
   99b9e:	addl   $0x10,0x8(%rsp,%rdx,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:346
   99ba3:	lea    0x10(%rsi),%rax
   99ba7:	add    $0x18,%rsi
   99bab:	add    $0x1000,%ecx
   99bb1:	cmp    %rbx,%rsi
   99bb4:	mov    %rax,%rsi
   99bb7:	ja     99f33 <mibz2::bwt::build+0xe13>
mibz2::bwt::build:
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:379
   99bbd:	lea    -0x8(%rsi),%rax
read_u64():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:379
   99bc1:	cmp    %rbx,%rsi
   99bc4:	ja     999f7 <mibz2::bwt::build+0x8d7>
mibz2::bwt::build:
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/num/uint_macros.rs:1050
   99bca:	lea    0x7(%rsi),%rdx
checked_sub():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/num/uint_macros.rs:1050
   99bce:	cmp    %rbx,%rdx
   99bd1:	jae    99f84 <mibz2::bwt::build+0xe64>
mibz2::bwt::build:
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:379
   99bd7:	mov    -0x8(%r14,%rsi,1),%rdx
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/result.rs:1718
   99bdc:	mov    (%r14,%rsi,1),%rax
build_two_pass():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:348
   99be0:	mov    %rdx,%rdi
   99be3:	xor    %rax,%rdi
   99be6:	mov    %rdx,%r8
   99be9:	rol    $0x8,%r8
   99bed:	xor    %rdx,%r8
   99bf0:	or     %rdi,%r8
   99bf3:	je     99af0 <mibz2::bwt::build+0x9d0>
mibz2::bwt::build:
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:369
   99bf9:	movzbl %dl,%r8d
link():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:369
   99bfd:	mov    %r8d,%edi
   99c00:	mov    0x8(%rsp,%rdi,4),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:372
   99c04:	cmp    %rdi,%r12
   99c07:	jbe    99fa8 <mibz2::bwt::build+0xe88>
   99c0d:	mov    %rdx,%r9
   99c10:	shr    $0x8,%r9
   99c14:	movzbl 0x0(%r13,%rdi,4),%r10d
   99c1a:	add    %ecx,%r10d
   99c1d:	mov    %r10d,0x0(%r13,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:373
   99c22:	inc    %edi
   99c24:	mov    %edi,0x8(%rsp,%r8,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:369
   99c29:	movzbl %r9b,%r8d
   99c2d:	mov    %r8d,%edi
   99c30:	mov    0x8(%rsp,%rdi,4),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:372
   99c34:	cmp    %rdi,%r12
   99c37:	jbe    99fa8 <mibz2::bwt::build+0xe88>
   99c3d:	mov    %rdx,%r9
   99c40:	shr    $0x10,%r9
   99c44:	movzbl 0x0(%r13,%rdi,4),%r10d
   99c4a:	add    %ecx,%r10d
   99c4d:	add    $0x100,%r10d
   99c54:	mov    %r10d,0x0(%r13,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:373
   99c59:	inc    %edi
   99c5b:	mov    %edi,0x8(%rsp,%r8,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:369
   99c60:	movzbl %r9b,%r8d
   99c64:	mov    %r8d,%edi
   99c67:	mov    0x8(%rsp,%rdi,4),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:372
   99c6b:	cmp    %rdi,%r12
   99c6e:	jbe    99fa8 <mibz2::bwt::build+0xe88>
   99c74:	mov    %rdx,%r9
   99c77:	shr    $0x18,%r9
   99c7b:	movzbl 0x0(%r13,%rdi,4),%r10d
   99c81:	add    %ecx,%r10d
   99c84:	add    $0x200,%r10d
   99c8b:	mov    %r10d,0x0(%r13,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:373
   99c90:	inc    %edi
   99c92:	mov    %edi,0x8(%rsp,%r8,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:369
   99c97:	movzbl %r9b,%r8d
   99c9b:	mov    %r8d,%edi
   99c9e:	mov    0x8(%rsp,%rdi,4),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:372
   99ca2:	cmp    %rdi,%r12
   99ca5:	jbe    99fa8 <mibz2::bwt::build+0xe88>
   99cab:	mov    %rdx,%r9
   99cae:	shr    $0x20,%r9
   99cb2:	movzbl 0x0(%r13,%rdi,4),%r10d
   99cb8:	add    %ecx,%r10d
   99cbb:	add    $0x300,%r10d
   99cc2:	mov    %r10d,0x0(%r13,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:373
   99cc7:	inc    %edi
   99cc9:	mov    %edi,0x8(%rsp,%r8,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:369
   99cce:	movzbl %r9b,%r8d
   99cd2:	mov    %r8d,%edi
   99cd5:	mov    0x8(%rsp,%rdi,4),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:372
   99cd9:	cmp    %rdi,%r12
   99cdc:	jbe    99fa8 <mibz2::bwt::build+0xe88>
   99ce2:	mov    %rdx,%r9
   99ce5:	shr    $0x28,%r9
   99ce9:	movzbl 0x0(%r13,%rdi,4),%r10d
   99cef:	add    %ecx,%r10d
   99cf2:	add    $0x400,%r10d
   99cf9:	mov    %r10d,0x0(%r13,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:373
   99cfe:	inc    %edi
   99d00:	mov    %edi,0x8(%rsp,%r8,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:369
   99d05:	movzbl %r9b,%r8d
   99d09:	mov    %r8d,%edi
   99d0c:	mov    0x8(%rsp,%rdi,4),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:372
   99d10:	cmp    %rdi,%r12
   99d13:	jbe    99fa8 <mibz2::bwt::build+0xe88>
   99d19:	mov    %rdx,%r9
   99d1c:	shr    $0x30,%r9
   99d20:	movzbl 0x0(%r13,%rdi,4),%r10d
   99d26:	add    %ecx,%r10d
   99d29:	add    $0x500,%r10d
   99d30:	mov    %r10d,0x0(%r13,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:373
   99d35:	inc    %edi
   99d37:	mov    %edi,0x8(%rsp,%r8,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:369
   99d3c:	movzbl %r9b,%r8d
   99d40:	mov    %r8d,%edi
   99d43:	mov    0x8(%rsp,%rdi,4),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:372
   99d47:	cmp    %rdi,%r12
   99d4a:	jbe    99fa8 <mibz2::bwt::build+0xe88>
   99d50:	shr    $0x38,%rdx
   99d54:	movzbl 0x0(%r13,%rdi,4),%r9d
   99d5a:	add    %ecx,%r9d
   99d5d:	add    $0x600,%r9d
   99d64:	mov    %r9d,0x0(%r13,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:373
   99d69:	inc    %edi
   99d6b:	mov    %edi,0x8(%rsp,%r8,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:369
   99d70:	mov    0x8(%rsp,%rdx,4),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:372
   99d74:	cmp    %rdi,%r12
   99d77:	jbe    99fa8 <mibz2::bwt::build+0xe88>
   99d7d:	movzbl 0x0(%r13,%rdi,4),%r8d
   99d83:	add    %ecx,%r8d
   99d86:	add    $0x700,%r8d
   99d8d:	mov    %r8d,0x0(%r13,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:373
   99d92:	inc    %edi
   99d94:	mov    %edi,0x8(%rsp,%rdx,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:369
   99d98:	movzbl %al,%edx
   99d9b:	mov    %edx,%edi
   99d9d:	mov    0x8(%rsp,%rdi,4),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:372
   99da1:	cmp    %rdi,%r12
   99da4:	jbe    99fa8 <mibz2::bwt::build+0xe88>
   99daa:	mov    %rax,%r8
   99dad:	shr    $0x8,%r8
   99db1:	movzbl 0x0(%r13,%rdi,4),%r9d
   99db7:	add    %ecx,%r9d
   99dba:	add    $0x800,%r9d
   99dc1:	mov    %r9d,0x0(%r13,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:373
   99dc6:	inc    %edi
   99dc8:	mov    %edi,0x8(%rsp,%rdx,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:369
   99dcc:	movzbl %r8b,%edx
   99dd0:	mov    %edx,%edi
   99dd2:	mov    0x8(%rsp,%rdi,4),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:372
   99dd6:	cmp    %rdi,%r12
   99dd9:	jbe    99fa8 <mibz2::bwt::build+0xe88>
   99ddf:	mov    %rax,%r8
   99de2:	shr    $0x10,%r8
   99de6:	movzbl 0x0(%r13,%rdi,4),%r9d
   99dec:	add    %ecx,%r9d
   99def:	add    $0x900,%r9d
   99df6:	mov    %r9d,0x0(%r13,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:373
   99dfb:	inc    %edi
   99dfd:	mov    %edi,0x8(%rsp,%rdx,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:369
   99e01:	movzbl %r8b,%edx
   99e05:	mov    %edx,%edi
   99e07:	mov    0x8(%rsp,%rdi,4),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:372
   99e0b:	cmp    %rdi,%r12
   99e0e:	jbe    99fa8 <mibz2::bwt::build+0xe88>
   99e14:	mov    %rax,%r8
   99e17:	shr    $0x18,%r8
   99e1b:	movzbl 0x0(%r13,%rdi,4),%r9d
   99e21:	add    %ecx,%r9d
   99e24:	add    $0xa00,%r9d
   99e2b:	mov    %r9d,0x0(%r13,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:373
   99e30:	inc    %edi
   99e32:	mov    %edi,0x8(%rsp,%rdx,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:369
   99e36:	movzbl %r8b,%edx
   99e3a:	mov    %edx,%edi
   99e3c:	mov    0x8(%rsp,%rdi,4),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:372
   99e40:	cmp    %rdi,%r12
   99e43:	jbe    99fa8 <mibz2::bwt::build+0xe88>
   99e49:	mov    %rax,%r8
   99e4c:	shr    $0x20,%r8
   99e50:	movzbl 0x0(%r13,%rdi,4),%r9d
   99e56:	add    %ecx,%r9d
   99e59:	add    $0xb00,%r9d
   99e60:	mov    %r9d,0x0(%r13,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:373
   99e65:	inc    %edi
   99e67:	mov    %edi,0x8(%rsp,%rdx,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:369
   99e6b:	movzbl %r8b,%edx
   99e6f:	mov    %edx,%edi
   99e71:	mov    0x8(%rsp,%rdi,4),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:372
   99e75:	cmp    %rdi,%r12
   99e78:	jbe    99fa8 <mibz2::bwt::build+0xe88>
   99e7e:	mov    %rax,%r8
   99e81:	shr    $0x28,%r8
   99e85:	movzbl 0x0(%r13,%rdi,4),%r9d
   99e8b:	add    %ecx,%r9d
   99e8e:	add    $0xc00,%r9d
   99e95:	mov    %r9d,0x0(%r13,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:373
   99e9a:	inc    %edi
   99e9c:	mov    %edi,0x8(%rsp,%rdx,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:369
   99ea0:	movzbl %r8b,%edx
   99ea4:	mov    %edx,%edi
   99ea6:	mov    0x8(%rsp,%rdi,4),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:372
   99eaa:	cmp    %rdi,%r12
   99ead:	jbe    99fa8 <mibz2::bwt::build+0xe88>
   99eb3:	mov    %rax,%r8
   99eb6:	shr    $0x30,%r8
   99eba:	movzbl 0x0(%r13,%rdi,4),%r9d
   99ec0:	add    %ecx,%r9d
   99ec3:	add    $0xd00,%r9d
   99eca:	mov    %r9d,0x0(%r13,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:373
   99ecf:	inc    %edi
   99ed1:	mov    %edi,0x8(%rsp,%rdx,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:369
   99ed5:	movzbl %r8b,%edx
   99ed9:	mov    %edx,%edi
   99edb:	mov    0x8(%rsp,%rdi,4),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:372
   99edf:	cmp    %rdi,%r12
   99ee2:	jbe    99fa8 <mibz2::bwt::build+0xe88>
   99ee8:	shr    $0x38,%rax
   99eec:	movzbl 0x0(%r13,%rdi,4),%r8d
   99ef2:	add    %ecx,%r8d
   99ef5:	add    $0xe00,%r8d
   99efc:	mov    %r8d,0x0(%r13,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:373
   99f01:	inc    %edi
   99f03:	mov    %edi,0x8(%rsp,%rdx,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:369
   99f07:	mov    0x8(%rsp,%rax,4),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:372
   99f0b:	cmp    %rdi,%r12
   99f0e:	jbe    99fa8 <mibz2::bwt::build+0xe88>
   99f14:	movzbl 0x0(%r13,%rdi,4),%edx
   99f1a:	add    %ecx,%edx
   99f1c:	add    $0xf00,%edx
   99f22:	mov    %edx,0x0(%r13,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:373
   99f27:	lea    0x1(%rdi),%edx
   99f2a:	mov    %edx,0x8(%rsp,%rax,4)
   99f2e:	jmp    99ba3 <mibz2::bwt::build+0xa83>
build_two_pass():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:361
   99f33:	add    $0xfffffffffffffff8,%rax
   99f37:	mov    %rax,%rcx
mibz2::bwt::build:
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/cmp.rs:1916
   99f3a:	cmp    %rbx,%rcx
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/iter/range.rs:900
   99f3d:	jae    99a23 <mibz2::bwt::build+0x903>
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:372
   99f43:	mov    %ecx,%eax
link():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:372
   99f45:	shl    $0x8,%eax
   99f48:	nopl   0x0(%rax,%rax,1)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:368
   99f50:	movzbl (%r14,%rcx,1),%edx
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:369
   99f55:	mov    0x8(%rsp,%rdx,4),%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:372
   99f59:	cmp    %rdi,%r12
   99f5c:	jbe    99fa8 <mibz2::bwt::build+0xe88>
mibz2::bwt::build:
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/num/uint_macros.rs:971
   99f5e:	inc    %rcx
link():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:372
   99f61:	movzbl 0x0(%r13,%rdi,4),%esi
   99f67:	add    %eax,%esi
   99f69:	mov    %esi,0x0(%r13,%rdi,4)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:373
   99f6e:	lea    0x1(%rdi),%esi
   99f71:	mov    %esi,0x8(%rsp,%rdx,4)
lt():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/cmp.rs:1916
   99f75:	add    $0x100,%eax
   99f7a:	cmp    %rcx,%rbx
spec_next<usize>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/iter/range.rs:900
   99f7d:	jne    99f50 <mibz2::bwt::build+0xe30>
   99f7f:	jmp    99a23 <mibz2::bwt::build+0x903>
build_two_pass():
   99f84:	movabs $0x7ffffffffffffff0,%rdi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:346
   99f8e:	and    %rbx,%rdi
   99f91:	jmp    99a09 <mibz2::bwt::build+0x8e9>
index_mut<u32>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/slice/index.rs:456
   99f96:	lea    0x6a1f3(%rip),%rcx        # 104190 <__do_global_dtors_aux_fini_array_entry+0x3710>
   99f9d:	mov    %rax,%rsi
   99fa0:	mov    %r12,%rdx
   99fa3:	call   aff0 <core::slice::index::slice_index_fail>
mibz2::bwt::build:
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:372
   99fa8:	lea    0x6a1f9(%rip),%rdx        # 1041a8 <__do_global_dtors_aux_fini_array_entry+0x3728>
link():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/src/bwt.rs:372
   99faf:	mov    %r12,%rsi
   99fb2:	call   af3b <core::panicking::panic_bounds_check>
