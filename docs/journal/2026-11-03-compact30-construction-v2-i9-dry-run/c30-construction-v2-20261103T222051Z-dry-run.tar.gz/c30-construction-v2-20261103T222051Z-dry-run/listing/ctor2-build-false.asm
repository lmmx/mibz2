# <c30walk::ctor2::Ctor2>::build::<false>
# size 0x18e5

/home/louis/dev/mibz2/target/c30-construction-v2-pin/target/rust-1.97.0/release/examples/c30walk:     file format elf64-x86-64


Disassembly of section .text:

0000000000019720 <<c30walk::ctor2::Ctor2>::build::<false>>:
   19720:	push   %rbp
   19721:	push   %r15
   19723:	push   %r14
   19725:	push   %r13
   19727:	push   %r12
   19729:	push   %rbx
   1972a:	sub    $0x1000,%rsp
   19731:	movq   $0x0,(%rsp)
   19739:	sub    $0x1000,%rsp
   19740:	movq   $0x0,(%rsp)
   19748:	sub    $0x1000,%rsp
   1974f:	movq   $0x0,(%rsp)
   19757:	sub    $0x1000,%rsp
   1975e:	movq   $0x0,(%rsp)
   19766:	sub    $0x1000,%rsp
   1976d:	movq   $0x0,(%rsp)
   19775:	sub    $0x4e8,%rsp
   1977c:	mov    %r8d,0x1c(%rsp)
   19781:	mov    0x5520(%rsp),%rax
   19789:	movq   $0x0,0x10(%r9)
   19791:	movq   $0x0,0x10(%rax)
   19799:	cmp    $0xeffe2,%rdx
   197a0:	ja     1ac97 <<c30walk::ctor2::Ctor2>::build::<false>+0x1577>
   197a6:	mov    %rcx,%r15
   197a9:	mov    %rdx,%r13
   197ac:	pxor   %xmm0,%xmm0
   197b0:	xor    %eax,%eax
   197b2:	pxor   %xmm2,%xmm2
   197b6:	pxor   %xmm1,%xmm1
   197ba:	nopw   0x0(%rax,%rax,1)
   197c0:	movq   (%r15,%rax,4),%xmm3
   197c6:	movq   0x8(%r15,%rax,4),%xmm4
   197cd:	punpckldq %xmm0,%xmm3
   197d1:	paddq  %xmm2,%xmm3
   197d5:	punpckldq %xmm0,%xmm4
   197d9:	paddq  %xmm1,%xmm4
   197dd:	movq   0x10(%r15,%rax,4),%xmm2
   197e4:	movq   0x18(%r15,%rax,4),%xmm1
   197eb:	punpckldq %xmm0,%xmm2
   197ef:	paddq  %xmm3,%xmm2
   197f3:	punpckldq %xmm0,%xmm1
   197f7:	paddq  %xmm4,%xmm1
   197fb:	add    $0x8,%rax
   197ff:	cmp    $0x100,%rax
   19805:	jne    197c0 <<c30walk::ctor2::Ctor2>::build::<false>+0xa0>
   19807:	paddq  %xmm2,%xmm1
   1980b:	pshufd $0xee,%xmm1,%xmm0
   19810:	paddq  %xmm1,%xmm0
   19814:	movq   %xmm0,%rax
   19819:	cmp    %r13,%rax
   1981c:	jne    1ac97 <<c30walk::ctor2::Ctor2>::build::<false>+0x1577>
   19822:	pxor   %xmm2,%xmm2
   19826:	xor    %eax,%eax
   19828:	movdqa 0xc27f0(%rip),%xmm3        # dc020 <_fini+0x7d4>
   19830:	pxor   %xmm1,%xmm1
   19834:	pxor   %xmm0,%xmm0
   19838:	nopl   0x0(%rax,%rax,1)
   19840:	movq   (%r15,%rax,4),%xmm4
   19846:	movq   0x8(%r15,%rax,4),%xmm5
   1984d:	pshufd $0xd4,%xmm4,%xmm4
   19852:	pcmpeqd %xmm2,%xmm4
   19856:	pandn  %xmm3,%xmm4
   1985a:	paddq  %xmm1,%xmm4
   1985e:	pshufd $0xd4,%xmm5,%xmm5
   19863:	pcmpeqd %xmm2,%xmm5
   19867:	pandn  %xmm3,%xmm5
   1986b:	paddq  %xmm0,%xmm5
   1986f:	movq   0x10(%r15,%rax,4),%xmm0
   19876:	movq   0x18(%r15,%rax,4),%xmm6
   1987d:	pshufd $0xd4,%xmm0,%xmm1
   19882:	pcmpeqd %xmm2,%xmm1
   19886:	pandn  %xmm3,%xmm1
   1988a:	paddq  %xmm4,%xmm1
   1988e:	pshufd $0xd4,%xmm6,%xmm0
   19893:	pcmpeqd %xmm2,%xmm0
   19897:	pandn  %xmm3,%xmm0
   1989b:	paddq  %xmm5,%xmm0
   1989f:	add    $0x8,%rax
   198a3:	cmp    $0x100,%rax
   198a9:	jne    19840 <<c30walk::ctor2::Ctor2>::build::<false>+0x120>
   198ab:	mov    $0x88888889,%ebp
   198b0:	imul   %r13,%rbp
   198b4:	shr    $0x24,%rbp
   198b8:	imul   $0xeeeeeeef,%r13d,%eax
   198bf:	ror    $1,%eax
   198c1:	cmp    $0x8888889,%eax
   198c6:	sbb    $0xffffffffffffffff,%rbp
   198ca:	mov    %rbp,%rbx
   198cd:	cmpl   $0x0,0x1c(%rsp)
   198d2:	jne    19928 <<c30walk::ctor2::Ctor2>::build::<false>+0x208>
   198d4:	test   %r13,%r13
   198d7:	je     19926 <<c30walk::ctor2::Ctor2>::build::<false>+0x206>
   198d9:	paddq  %xmm1,%xmm0
   198dd:	pshufd $0xee,%xmm0,%xmm1
   198e2:	paddq  %xmm0,%xmm1
   198e6:	movq   %xmm1,%rax
   198eb:	lea    -0x1(%r13),%ecx
   198ef:	mov    $0x88888889,%edx
   198f4:	imul   %rcx,%rdx
   198f8:	shr    $0x23,%rdx
   198fc:	and    $0xfffffffe,%edx
   198ff:	lea    (%rdx,%r13,1),%ecx
   19903:	dec    %ecx
   19905:	shr    $1,%ecx
   19907:	mov    $0x80010003,%ebx
   1990c:	imul   %rcx,%rbx
   19910:	shr    $0x2e,%rbx
   19914:	inc    %ebx
   19916:	imul   %rax,%rbx
   1991a:	dec    %rbx
   1991d:	cmp    %rbp,%rbx
   19920:	cmovae %rbp,%rbx
   19924:	jmp    19928 <<c30walk::ctor2::Ctor2>::build::<false>+0x208>
   19926:	xor    %ebx,%ebx
   19928:	mov    (%r9),%rax
   1992b:	lea    0x1(%rbp),%rcx
   1992f:	mov    %rcx,0x80(%rsp)
   19937:	cmp    %rbp,%rax
   1993a:	mov    %rsi,0x28(%rsp)
   1993f:	jbe    1adff <<c30walk::ctor2::Ctor2>::build::<false>+0x16df>
   19945:	mov    0x5520(%rsp),%rax
   1994d:	mov    (%rax),%rax
   19950:	cmp    %rbx,%rax
   19953:	jb     1ae54 <<c30walk::ctor2::Ctor2>::build::<false>+0x1734>
   19959:	movq   $0x0,0x10(%rdi)
   19961:	lea    0x3f(%rbp),%rbx
   19965:	shr    $0x6,%rbx
   19969:	mov    %r13,0x8(%rsp)
   1996e:	mov    %rdi,0x58(%rsp)
   19973:	mov    %rbp,0x60(%rsp)
   19978:	je     199d2 <<c30walk::ctor2::Ctor2>::build::<false>+0x2b2>
   1997a:	cmp    (%rdi),%rbx
   1997d:	ja     1af83 <<c30walk::ctor2::Ctor2>::build::<false>+0x1863>
   19983:	mov    %r9,%r13
   19986:	xor    %r14d,%r14d
   19989:	mov    0x8(%rdi),%r12
   1998d:	lea    (%r12,%r14,8),%rdi
   19991:	cmp    $0x1,%rbx
   19995:	je     199b9 <<c30walk::ctor2::Ctor2>::build::<false>+0x299>
   19997:	lea    -0x8(,%rbx,8),%rdx
   1999f:	xor    %esi,%esi
   199a1:	call   *0xec491(%rip)        # 105e38 <memset@GLIBC_2.2.5>
   199a7:	lea    (%r14,%rbx,1),%rax
   199ab:	lea    (%r12,%rax,8),%rdi
   199af:	add    $0xfffffffffffffff8,%rdi
   199b3:	add    %rbx,%r14
   199b6:	dec    %r14
   199b9:	mov    %r13,%r9
   199bc:	movq   $0x0,(%rdi)
   199c3:	inc    %r14
   199c6:	mov    0x8(%rsp),%r13
   199cb:	mov    0x58(%rsp),%rdi
   199d0:	jmp    199d5 <<c30walk::ctor2::Ctor2>::build::<false>+0x2b5>
   199d2:	xor    %r14d,%r14d
   199d5:	lea    0x18(%rdi),%r12
   199d9:	mov    %r14,0x10(%rdi)
   199dd:	movq   $0x0,0x28(%rdi)
   199e5:	cmpq   $0xf,0x18(%rdi)
   199ea:	jbe    1af58 <<c30walk::ctor2::Ctor2>::build::<false>+0x1838>
   199f0:	lea    0x30(%rdi),%rax
   199f4:	mov    %rax,(%rsp)
   199f8:	xor    %eax,%eax
   199fa:	pxor   %xmm0,%xmm0
   199fe:	movabs $0xffffffff00000000,%rcx
   19a08:	nopl   0x0(%rax,%rax,1)
   19a10:	movdqu %xmm0,0x2cf8(%rsp,%rax,1)
   19a19:	movdqu %xmm0,0x2ce8(%rsp,%rax,1)
   19a22:	mov    %rcx,0x2d08(%rsp,%rax,1)
   19a2a:	movdqu %xmm0,0x2d10(%rsp,%rax,1)
   19a33:	movdqu %xmm0,0x2d20(%rsp,%rax,1)
   19a3c:	mov    %rcx,0x2d30(%rsp,%rax,1)
   19a44:	movdqu %xmm0,0x2d38(%rsp,%rax,1)
   19a4d:	movdqu %xmm0,0x2d48(%rsp,%rax,1)
   19a56:	mov    %rcx,0x2d58(%rsp,%rax,1)
   19a5e:	movdqu %xmm0,0x2d60(%rsp,%rax,1)
   19a67:	movdqu %xmm0,0x2d70(%rsp,%rax,1)
   19a70:	mov    %rcx,0x2d80(%rsp,%rax,1)
   19a78:	add    $0xa0,%rax
   19a7e:	cmp    $0x2800,%rax
   19a84:	jne    19a10 <<c30walk::ctor2::Ctor2>::build::<false>+0x2f0>
   19a86:	mov    %r12,%r14
   19a89:	lea    0xc(%r15),%rax
   19a8d:	xor    %edx,%edx
   19a8f:	mov    $0x25,%ecx
   19a94:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   19aa0:	mov    -0xc(%rax),%esi
   19aa3:	add    %edx,%esi
   19aa5:	mov    %edx,0x2c6c(%rsp,%rcx,4)
   19aac:	mov    %esi,0x2c70(%rsp,%rcx,4)
   19ab3:	mov    -0x8(%rax),%edx
   19ab6:	add    %esi,%edx
   19ab8:	mov    %esi,0x2c94(%rsp,%rcx,4)
   19abf:	mov    %edx,0x2c98(%rsp,%rcx,4)
   19ac6:	mov    -0x4(%rax),%esi
   19ac9:	add    %edx,%esi
   19acb:	mov    %edx,0x2cbc(%rsp,%rcx,4)
   19ad2:	mov    %esi,0x2cc0(%rsp,%rcx,4)
   19ad9:	mov    (%rax),%edx
   19adb:	add    %esi,%edx
   19add:	mov    %esi,0x2ce4(%rsp,%rcx,4)
   19ae4:	mov    %edx,0x2ce8(%rsp,%rcx,4)
   19aeb:	add    $0x28,%rcx
   19aef:	add    $0x10,%rax
   19af3:	cmp    $0xa25,%rcx
   19afa:	jne    19aa0 <<c30walk::ctor2::Ctor2>::build::<false>+0x380>
   19afc:	mov    %r9,0x78(%rsp)
   19b01:	mov    0x8(%r9),%rbx
   19b05:	mov    0x8(%rdi),%rbp
   19b09:	mov    0x10(%rdi),%r12
   19b0d:	lea    0xd8(%rsp),%rdi
   19b15:	lea    0x2ce8(%rsp),%rsi
   19b1d:	mov    $0x2800,%edx
   19b22:	call   *0xec3a0(%rip)        # 105ec8 <memcpy@GLIBC_2.14>
   19b28:	mov    %rbp,%r8
   19b2b:	mov    %r12,%rsi
   19b2e:	mov    %rbx,0xc0(%rsp)
   19b36:	mov    0x60(%rsp),%rax
   19b3b:	mov    %rax,0xc8(%rsp)
   19b43:	mov    %r13,0xd0(%rsp)
   19b4b:	mov    0x5520(%rsp),%rax
   19b53:	mov    %rax,0x98(%rsp)
   19b5b:	mov    %rbp,0xa0(%rsp)
   19b63:	mov    %r12,0xa8(%rsp)
   19b6b:	mov    %r14,0xb0(%rsp)
   19b73:	movl   $0x0,0x28e0(%rsp)
   19b7e:	movq   $0x0,0x28d8(%rsp)
   19b8a:	mov    (%rsp),%rax
   19b8e:	mov    %rax,0xb8(%rsp)
   19b96:	mov    $0xffffffffffffffff,%rcx
   19b9d:	xor    %ebp,%ebp
   19b9f:	movabs $0xeeeeeeeeeeeeeeef,%r9
   19ba9:	movabs $0x888888888888889,%r10
   19bb3:	pxor   %xmm0,%xmm0
   19bb7:	pcmpeqd %xmm1,%xmm1
   19bbb:	xor    %r12d,%r12d
   19bbe:	jmp    19c76 <<c30walk::ctor2::Ctor2>::build::<false>+0x556>
   19bc3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   19bd0:	mov    0x8(%rdi),%rax
   19bd4:	mov    %r13,%rcx
   19bd7:	shl    $0x7,%rcx
   19bdb:	movdqa %xmm0,0x70(%rax,%rcx,1)
   19be1:	movdqa %xmm0,0x60(%rax,%rcx,1)
   19be7:	movdqa %xmm0,0x50(%rax,%rcx,1)
   19bed:	movdqa %xmm0,0x40(%rax,%rcx,1)
   19bf3:	movdqa %xmm0,0x30(%rax,%rcx,1)
   19bf9:	movdqa %xmm0,0x20(%rax,%rcx,1)
   19bff:	movdqa %xmm0,0x10(%rax,%rcx,1)
   19c05:	movdqa %xmm0,(%rax,%rcx,1)
   19c0a:	mov    %r13,%rax
   19c0d:	inc    %rax
   19c10:	mov    %rax,0x10(%rdi)
   19c14:	mov    %r14,%rax
   19c17:	shl    $0x6,%rax
   19c1b:	or     $0x10000000,%r13d
   19c22:	movdqu %xmm1,0x2c(%rbx,%rax,1)
   19c28:	movdqa %xmm1,0x20(%rbx,%rax,1)
   19c2e:	movdqa %xmm1,0x10(%rbx,%rax,1)
   19c34:	movdqa %xmm1,(%rbx,%rax,1)
   19c39:	mov    %r13d,0x3c(%rbx,%rax,1)
   19c3e:	mov    %r14,%rdi
   19c41:	shr    $0x6,%rdi
   19c45:	cmp    %rsi,%rdi
   19c48:	jae    1afea <<c30walk::ctor2::Ctor2>::build::<false>+0x18ca>
   19c4e:	mov    $0x1,%eax
   19c53:	mov    %r14d,%ecx
   19c56:	shl    %cl,%rax
   19c59:	or     %rax,(%r8,%rdi,8)
   19c5d:	mov    %r14,%rcx
   19c60:	mov    0x8(%rsp),%r13
   19c65:	add    $0x4,%r12
   19c69:	cmp    $0x400,%r12
   19c70:	je     19d10 <<c30walk::ctor2::Ctor2>::build::<false>+0x5f0>
   19c76:	mov    %rbp,%rax
   19c79:	mov    (%r15,%r12,1),%ebp
   19c7d:	add    %rax,%rbp
   19c80:	cmp    %r13,%rbp
   19c83:	setae  %dil
   19c87:	mov    %rbp,%rax
   19c8a:	movabs $0x8888888888888889,%rdx
   19c94:	mul    %rdx
   19c97:	mov    %rdx,%r14
   19c9a:	shr    $0x4,%r14
   19c9e:	mov    %rbp,%rax
   19ca1:	imul   %r9,%rax
   19ca5:	ror    $1,%rax
   19ca8:	cmp    %r10,%rax
   19cab:	setb   %al
   19cae:	cmp    %rcx,%r14
   19cb1:	sete   %dl
   19cb4:	or     %dil,%dl
   19cb7:	or     %al,%dl
   19cb9:	jne    19c65 <<c30walk::ctor2::Ctor2>::build::<false>+0x545>
   19cbb:	mov    0x5520(%rsp),%rdi
   19cc3:	mov    0x10(%rdi),%r13
   19cc7:	cmp    (%rdi),%r13
   19cca:	jne    19bd0 <<c30walk::ctor2::Ctor2>::build::<false>+0x4b0>
   19cd0:	mov    %rsi,(%rsp)
   19cd4:	mov    %r8,0x10(%rsp)
   19cd9:	call   95d0 <<alloc::raw_vec::RawVec<c30walk::RawG>>::grow_one>
   19cde:	pcmpeqd %xmm1,%xmm1
   19ce2:	pxor   %xmm0,%xmm0
   19ce6:	movabs $0x888888888888889,%r10
   19cf0:	movabs $0xeeeeeeeeeeeeeeef,%r9
   19cfa:	mov    0x10(%rsp),%r8
   19cff:	mov    (%rsp),%rsi
   19d03:	mov    0x5520(%rsp),%rdi
   19d0b:	jmp    19bd0 <<c30walk::ctor2::Ctor2>::build::<false>+0x4b0>
   19d10:	cmpl   $0x0,0x1c(%rsp)
   19d15:	lea    0xd8(%rsp),%r8
   19d1d:	je     19ed4 <<c30walk::ctor2::Ctor2>::build::<false>+0x7b4>
   19d23:	mov    0xc8(%rsp),%r11
   19d2b:	test   %r11,%r11
   19d2e:	je     19ed4 <<c30walk::ctor2::Ctor2>::build::<false>+0x7b4>
   19d34:	mov    0x8(%rsp),%r9
   19d39:	shl    $0x20,%r9
   19d3d:	mov    0x1c(%rsp),%r10d
   19d42:	mov    0x98(%rsp),%rdi
   19d4a:	mov    0xc0(%rsp),%r13
   19d52:	xor    %r12d,%r12d
   19d55:	movabs $0xff51afd7ed558ccd,%rbx
   19d5f:	pxor   %xmm0,%xmm0
   19d63:	pcmpeqd %xmm1,%xmm1
   19d67:	jmp    19df0 <<c30walk::ctor2::Ctor2>::build::<false>+0x6d0>
   19d6c:	mov    0x8(%rdi),%rax
   19d70:	mov    %rbx,%rcx
   19d73:	shl    $0x7,%rcx
   19d77:	movdqa %xmm0,0x70(%rax,%rcx,1)
   19d7d:	movdqa %xmm0,0x60(%rax,%rcx,1)
   19d83:	movdqa %xmm0,0x50(%rax,%rcx,1)
   19d89:	movdqa %xmm0,0x40(%rax,%rcx,1)
   19d8f:	movdqa %xmm0,0x30(%rax,%rcx,1)
   19d95:	movdqa %xmm0,0x20(%rax,%rcx,1)
   19d9b:	movdqa %xmm0,0x10(%rax,%rcx,1)
   19da1:	movdqa %xmm0,(%rax,%rcx,1)
   19da6:	mov    %rbx,%rax
   19da9:	inc    %rax
   19dac:	mov    %rax,0x10(%rdi)
   19db0:	or     $0x10000000,%ebx
   19db6:	movdqu %xmm1,0x2c(%r13)
   19dbc:	movdqa %xmm1,0x20(%r13)
   19dc2:	movdqa %xmm1,0x10(%r13)
   19dc8:	movdqa %xmm1,0x0(%r13)
   19dce:	mov    %ebx,0x3c(%r13)
   19dd2:	or     %r15,(%r14,%rbp,8)
   19dd6:	movabs $0xff51afd7ed558ccd,%rbx
   19de0:	inc    %r12
   19de3:	add    $0x40,%r13
   19de7:	cmp    %r12,%r11
   19dea:	je     19ed4 <<c30walk::ctor2::Ctor2>::build::<false>+0x7b4>
   19df0:	mov    %r12,%rbp
   19df3:	shr    $0x6,%rbp
   19df7:	mov    0xa8(%rsp),%rsi
   19dff:	cmp    %rsi,%rbp
   19e02:	jae    1aff6 <<c30walk::ctor2::Ctor2>::build::<false>+0x18d6>
   19e08:	mov    0xa0(%rsp),%r14
   19e10:	mov    (%r14,%rbp,8),%rax
   19e14:	mov    $0x1,%r15d
   19e1a:	mov    %r12d,%ecx
   19e1d:	shl    %cl,%r15
   19e20:	bt     %r12,%rax
   19e24:	jb     19de0 <<c30walk::ctor2::Ctor2>::build::<false>+0x6c0>
   19e26:	mov    %r12,%rax
   19e29:	xor    %r9,%rax
   19e2c:	mov    %rax,%rcx
   19e2f:	shr    $0x21,%rcx
   19e33:	xor    %rax,%rcx
   19e36:	imul   %rbx,%rcx
   19e3a:	mov    %rcx,%rax
   19e3d:	shr    $0x21,%rax
   19e41:	xor    %rcx,%rax
   19e44:	movabs $0xc4ceb9fe1a85ec53,%rcx
   19e4e:	imul   %rcx,%rax
   19e52:	mov    %rax,%rcx
   19e55:	shr    $0x21,%rcx
   19e59:	xor    %rax,%rcx
   19e5c:	mov    %rcx,%rax
   19e5f:	shr    $0x3,%rax
   19e63:	movabs $0x20c49ba5e353f7cf,%rdx
   19e6d:	mul    %rdx
   19e70:	shr    $0x4,%rdx
   19e74:	imul   $0x3e8,%rdx,%rax
   19e7b:	sub    %rax,%rcx
   19e7e:	cmp    %r10,%rcx
   19e81:	jae    19de0 <<c30walk::ctor2::Ctor2>::build::<false>+0x6c0>
   19e87:	mov    0x10(%rdi),%rbx
   19e8b:	cmp    (%rdi),%rbx
   19e8e:	jne    19d6c <<c30walk::ctor2::Ctor2>::build::<false>+0x64c>
   19e94:	mov    %r11,(%rsp)
   19e98:	mov    %r9,0x10(%rsp)
   19e9d:	mov    %r10,0x50(%rsp)
   19ea2:	mov    %rdi,0x48(%rsp)
   19ea7:	call   95d0 <<alloc::raw_vec::RawVec<c30walk::RawG>>::grow_one>
   19eac:	pcmpeqd %xmm1,%xmm1
   19eb0:	pxor   %xmm0,%xmm0
   19eb4:	mov    0x48(%rsp),%rdi
   19eb9:	mov    0x50(%rsp),%r10
   19ebe:	mov    0x10(%rsp),%r9
   19ec3:	mov    (%rsp),%r11
   19ec7:	lea    0xd8(%rsp),%r8
   19ecf:	jmp    19d6c <<c30walk::ctor2::Ctor2>::build::<false>+0x64c>
   19ed4:	mov    0x8(%rsp),%r13
   19ed9:	test   %r13,%r13
   19edc:	mov    0x28(%rsp),%r14
   19ee1:	je     1ac2f <<c30walk::ctor2::Ctor2>::build::<false>+0x150f>
   19ee7:	xor    %r11d,%r11d
   19eea:	jmp    19efc <<c30walk::ctor2::Ctor2>::build::<false>+0x7dc>
   19eec:	nopl   0x0(%rax)
   19ef0:	mov    %r11,%r10
   19ef3:	cmp    %r13,%r10
   19ef6:	jae    1ac2f <<c30walk::ctor2::Ctor2>::build::<false>+0x150f>
   19efc:	mov    %r11,%rbp
   19eff:	mov    %r9,%r12
   19f02:	mov    $0x400,%edx
   19f07:	lea    0x28e8(%rsp),%rdi
   19f0f:	xor    %esi,%esi
   19f11:	call   *0xebf21(%rip)        # 105e38 <memset@GLIBC_2.2.5>
   19f17:	lea    0x118(%rsp),%rax
   19f1f:	xor    %ecx,%ecx
   19f21:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   19f30:	mov    -0x40(%rax),%rdx
   19f34:	sub    -0x30(%rax),%rdx
   19f38:	shr    $1,%rdx
   19f3b:	add    -0x28(%rax),%edx
   19f3e:	mov    -0x18(%rax),%rsi
   19f42:	sub    -0x8(%rax),%rsi
   19f46:	mov    %edx,0x28e8(%rsp,%rcx,4)
   19f4d:	shr    $1,%rsi
   19f50:	add    (%rax),%esi
   19f52:	mov    %esi,0x28ec(%rsp,%rcx,4)
   19f59:	add    $0x2,%rcx
   19f5d:	add    $0x50,%rax
   19f61:	cmp    $0x100,%rcx
   19f68:	jne    19f30 <<c30walk::ctor2::Ctor2>::build::<false>+0x810>
   19f6a:	mov    0xb0(%rsp),%r15
   19f72:	mov    0x10(%r15),%rbx
   19f76:	cmp    (%r15),%rbx
   19f79:	je     1ac22 <<c30walk::ctor2::Ctor2>::build::<false>+0x1502>
   19f7f:	mov    %rbx,%rdi
   19f82:	shl    $0xa,%rdi
   19f86:	add    0x8(%r15),%rdi
   19f8a:	mov    $0x400,%edx
   19f8f:	lea    0x28e8(%rsp),%rsi
   19f97:	call   *0xebf2b(%rip)        # 105ec8 <memcpy@GLIBC_2.14>
   19f9d:	inc    %rbx
   19fa0:	mov    %rbx,0x10(%r15)
   19fa4:	mov    %rbp,%r11
   19fa7:	lea    0xf000(%rbp),%r10
   19fae:	cmp    %r13,%r10
   19fb1:	cmovae %r13,%r10
   19fb5:	lea    0x10(%rbp),%rdi
   19fb9:	cmp    %r10,%rdi
   19fbc:	mov    %r10,0x20(%rsp)
   19fc1:	jbe    1a090 <<c30walk::ctor2::Ctor2>::build::<false>+0x970>
   19fc7:	lea    0xd8(%rsp),%r8
   19fcf:	mov    %r12,%r9
   19fd2:	mov    0x38(%rsp),%rcx
   19fd7:	mov    %r10,%rdx
   19fda:	sub    %r11,%rdx
   19fdd:	mov    %rcx,0x38(%rsp)
   19fe2:	jbe    19ef0 <<c30walk::ctor2::Ctor2>::build::<false>+0x7d0>
   19fe8:	mov    %r9,%rbp
   19feb:	mov    %r14,%rax
   19fee:	mov    0x28e0(%rsp),%r12d
   19ff6:	mov    $0x1e,%r14d
   19ffc:	sub    0x28d8(%rsp),%r14
   1a004:	cmp    %rdx,%r14
   1a007:	cmovae %rdx,%r14
   1a00b:	lea    (%rax,%r11,1),%r15
   1a00f:	test   %r14,%r14
   1a012:	je     1aa90 <<c30walk::ctor2::Ctor2>::build::<false>+0x1370>
   1a018:	xor    %r13d,%r13d
   1a01b:	nopl   0x0(%rax,%rax,1)
   1a020:	movzbl (%r15,%r13,1),%esi
   1a025:	lea    (%rsi,%rsi,4),%rcx
   1a029:	lea    (%r8,%rcx,8),%rbx
   1a02d:	mov    (%r8,%rcx,8),%rax
   1a031:	cmp    0x8(%r8,%rcx,8),%rax
   1a036:	je     1a050 <<c30walk::ctor2::Ctor2>::build::<false>+0x930>
   1a038:	lea    (%r12,%r13,1),%rcx
   1a03c:	mov    %cx,(%rax)
   1a03f:	addq   $0x2,(%rbx)
   1a043:	inc    %r13
   1a046:	cmp    %r13,%r14
   1a049:	jne    1a020 <<c30walk::ctor2::Ctor2>::build::<false>+0x900>
   1a04b:	jmp    1aa90 <<c30walk::ctor2::Ctor2>::build::<false>+0x1370>
   1a050:	mov    %rdx,0x10(%rsp)
   1a055:	mov    %r11,(%rsp)
   1a059:	lea    0x98(%rsp),%rdi
   1a061:	call   92e0 <<c30walk::ctor2::W<false>>::refill>
   1a066:	lea    0xd8(%rsp),%r8
   1a06e:	test   %al,%al
   1a070:	je     1ac87 <<c30walk::ctor2::Ctor2>::build::<false>+0x1567>
   1a076:	mov    (%rbx),%rax
   1a079:	mov    0x20(%rsp),%r10
   1a07e:	mov    (%rsp),%r11
   1a082:	mov    0x10(%rsp),%rdx
   1a087:	jmp    1a038 <<c30walk::ctor2::Ctor2>::build::<false>+0x918>
   1a089:	nopl   0x0(%rax)
   1a090:	xor    %edx,%edx
   1a092:	lea    0xd8(%rsp),%r8
   1a09a:	mov    %r12,%r9
   1a09d:	mov    0x38(%rsp),%rcx
   1a0a2:	jmp    1a103 <<c30walk::ctor2::Ctor2>::build::<false>+0x9e3>
   1a0a4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   1a0b0:	mov    0x28d8(%rsp),%rax
   1a0b8:	lea    0x10(%rax),%rcx
   1a0bc:	add    $0xfffffffffffffff2,%rax
   1a0c0:	xor    %edx,%edx
   1a0c2:	cmp    $0x1e,%rcx
   1a0c6:	setae  %dl
   1a0c9:	cmovb  %rcx,%rax
   1a0cd:	mov    %rax,0x28d8(%rsp)
   1a0d5:	mov    0x28e0(%rsp),%eax
   1a0dc:	lea    0x10(%rax,%rdx,2),%eax
   1a0e0:	mov    %eax,0x28e0(%rsp)
   1a0e7:	mov    0x30(%rsp),%r11
   1a0ec:	lea    0x10(%r11),%rsi
   1a0f0:	xor    %edx,%edx
   1a0f2:	mov    %rsi,%rdi
   1a0f5:	cmp    %r10,%rsi
   1a0f8:	mov    0x28(%rsp),%r14
   1a0fd:	ja     19fd7 <<c30walk::ctor2::Ctor2>::build::<false>+0x8b7>
   1a103:	test   $0x1,%dl
   1a106:	jne    1a134 <<c30walk::ctor2::Ctor2>::build::<false>+0xa14>
   1a108:	lea    0x8(%r11),%rsi
   1a10c:	cmp    $0xfffffffffffffff7,%r11
   1a110:	ja     1aeb8 <<c30walk::ctor2::Ctor2>::build::<false>+0x1798>
   1a116:	cmp    %r13,%rsi
   1a119:	ja     1aeb8 <<c30walk::ctor2::Ctor2>::build::<false>+0x1798>
   1a11f:	lea    0x10(%r11),%rax
   1a123:	cmp    %r13,%rax
   1a126:	ja     1aedf <<c30walk::ctor2::Ctor2>::build::<false>+0x17bf>
   1a12c:	mov    (%r14,%r11,1),%r9
   1a130:	mov    (%r14,%rsi,1),%rcx
   1a134:	mov    %r9,%rax
   1a137:	xor    %rcx,%rax
   1a13a:	mov    %r9,%rdx
   1a13d:	rol    $0x8,%rdx
   1a141:	xor    %r9,%rdx
   1a144:	or     %rax,%rdx
   1a147:	jne    1a1a0 <<c30walk::ctor2::Ctor2>::build::<false>+0xa80>
   1a149:	mov    %rdi,%rax
   1a14c:	nopl   0x0(%rax)
   1a150:	mov    %rax,%r12
   1a153:	add    $0x10,%rax
   1a157:	cmp    %r10,%rax
   1a15a:	setbe  %r9b
   1a15e:	ja     1a200 <<c30walk::ctor2::Ctor2>::build::<false>+0xae0>
   1a164:	lea    0x8(%r12),%rsi
   1a169:	cmp    $0xfffffffffffffff7,%r12
   1a16d:	ja     1adda <<c30walk::ctor2::Ctor2>::build::<false>+0x16ba>
   1a173:	cmp    %r13,%rsi
   1a176:	ja     1adda <<c30walk::ctor2::Ctor2>::build::<false>+0x16ba>
   1a17c:	mov    (%r14,%r12,1),%rdx
   1a180:	mov    0x8(%r14,%r12,1),%rsi
   1a185:	cmp    %rcx,%rdx
   1a188:	jne    1a18f <<c30walk::ctor2::Ctor2>::build::<false>+0xa6f>
   1a18a:	cmp    %rcx,%rsi
   1a18d:	je     1a150 <<c30walk::ctor2::Ctor2>::build::<false>+0xa30>
   1a18f:	mov    %rsi,0x38(%rsp)
   1a194:	mov    %rdx,0x68(%rsp)
   1a199:	lea    0x10(%r12),%r10
   1a19e:	jmp    1a205 <<c30walk::ctor2::Ctor2>::build::<false>+0xae5>
   1a1a0:	mov    %rdi,0x30(%rsp)
   1a1a5:	mov    0x28d8(%rsp),%rax
   1a1ad:	mov    $0x1e,%r12d
   1a1b3:	sub    %rax,%r12
   1a1b6:	cmp    $0x10,%r12
   1a1ba:	mov    $0x10,%ebx
   1a1bf:	cmovb  %r12,%rbx
   1a1c3:	mov    %rbx,%r15
   1a1c6:	add    %r11,%r15
   1a1c9:	jb     1aeca <<c30walk::ctor2::Ctor2>::build::<false>+0x17aa>
   1a1cf:	cmp    %r13,%r15
   1a1d2:	ja     1aeca <<c30walk::ctor2::Ctor2>::build::<false>+0x17aa>
   1a1d8:	mov    0x28e0(%rsp),%r14d
   1a1e0:	cmp    $0x1e,%rax
   1a1e4:	jne    1a960 <<c30walk::ctor2::Ctor2>::build::<false>+0x1240>
   1a1ea:	cmp    %r15,0x30(%rsp)
   1a1ef:	jae    1a9ea <<c30walk::ctor2::Ctor2>::build::<false>+0x12ca>
   1a1f5:	jmp    1aef4 <<c30walk::ctor2::Ctor2>::build::<false>+0x17d4>
   1a1fa:	nopw   0x0(%rax,%rax,1)
   1a200:	lea    0x10(%r12),%r10
   1a205:	mov    %r12,0x30(%rsp)
   1a20a:	sub    %r11,%r12
   1a20d:	movzbl %cl,%eax
   1a210:	mov    %rax,0x90(%rsp)
   1a218:	lea    (%rax,%rax,4),%rdx
   1a21c:	mov    (%r8,%rdx,8),%rax
   1a220:	mov    0x1c(%r8,%rdx,8),%esi
   1a225:	mov    %rax,%rdi
   1a228:	sub    0x10(%r8,%rdx,8),%rdi
   1a22d:	shr    $1,%rdi
   1a230:	add    0x18(%r8,%rdx,8),%edi
   1a235:	add    %r12,%rdi
   1a238:	cmp    %rsi,%rdi
   1a23b:	ja     1ac87 <<c30walk::ctor2::Ctor2>::build::<false>+0x1567>
   1a241:	mov    %r10,0x70(%rsp)
   1a246:	mov    %r9d,0x44(%rsp)
   1a24b:	lea    (%r8,%rdx,8),%rbp
   1a24f:	movzbl %cl,%r13d
   1a253:	mov    0x8(%rbp),%rsi
   1a257:	mov    $0x88888889,%r14d
   1a25d:	lea    0xcb0dc(%rip),%r15        # e5340 <c30walk::ctor2::PATTERNS>
   1a264:	mov    %rbp,0x88(%rsp)
   1a26c:	jmp    1a2a7 <<c30walk::ctor2::Ctor2>::build::<false>+0xb87>
   1a26e:	xchg   %ax,%ax
   1a270:	mov    0x3c(%rsi),%edi
   1a273:	mov    $0xfffff,%r9d
   1a279:	and    %r9d,%edi
   1a27c:	sub    %r8d,%ecx
   1a27f:	sub    %eax,%r8d
   1a282:	mov    %r8d,%eax
   1a285:	lea    (%rsi,%rax,2),%rax
   1a289:	mov    %rax,0x10(%rbp)
   1a28d:	mov    %rax,0x0(%rbp)
   1a291:	lea    (%rax,%rcx,2),%rsi
   1a295:	mov    %rsi,0x8(%rbp)
   1a299:	mov    %edx,0x20(%rbp)
   1a29c:	mov    %edi,0x24(%rbp)
   1a29f:	lea    0xd8(%rsp),%r8
   1a2a7:	sub    %rax,%rsi
   1a2aa:	shr    $1,%rsi
   1a2ad:	cmp    %rsi,%r12
   1a2b0:	cmovb  %r12,%rsi
   1a2b4:	test   %rsi,%rsi
   1a2b7:	je     1a371 <<c30walk::ctor2::Ctor2>::build::<false>+0xc51>
   1a2bd:	mov    0x28d8(%rsp),%rdi
   1a2c5:	cmp    $0x1d,%rdi
   1a2c9:	ja     1afc8 <<c30walk::ctor2::Ctor2>::build::<false>+0x18a8>
   1a2cf:	cmp    $0x1f,%rsi
   1a2d3:	jae    1adec <<c30walk::ctor2::Ctor2>::build::<false>+0x16cc>
   1a2d9:	mov    0x28e0(%rsp),%ecx
   1a2e0:	mov    %rdi,%r11
   1a2e3:	shl    $0x6,%r11
   1a2e7:	lea    (%r15,%r11,1),%rdx
   1a2eb:	lea    -0x2(,%rsi,2),%r9
   1a2f3:	cmp    $0xe,%r9
   1a2f7:	jb     1a30c <<c30walk::ctor2::Ctor2>::build::<false>+0xbec>
   1a2f9:	mov    %rax,%r8
   1a2fc:	sub    %r15,%r8
   1a2ff:	sub    %r11,%r8
   1a302:	cmp    $0x10,%r8
   1a306:	jae    1a773 <<c30walk::ctor2::Ctor2>::build::<false>+0x1053>
   1a30c:	xor    %r10d,%r10d
   1a30f:	mov    %rdx,%r8
   1a312:	lea    (%rdx,%rsi,2),%rdx
   1a316:	lea    (%rax,%r10,2),%r9
   1a31a:	nopw   0x0(%rax,%rax,1)
   1a320:	movzwl (%r8),%r10d
   1a324:	add    %cx,%r10w
   1a328:	add    $0x2,%r8
   1a32c:	mov    %r10w,(%r9)
   1a330:	add    $0x2,%r9
   1a334:	cmp    %rdx,%r8
   1a337:	jne    1a320 <<c30walk::ctor2::Ctor2>::build::<false>+0xc00>
   1a339:	lea    (%rax,%rsi,2),%rax
   1a33d:	mov    %rax,0x0(%rbp)
   1a341:	add    %rsi,%rdi
   1a344:	lea    0x2(%rsi),%edx
   1a347:	mov    %rdi,%r8
   1a34a:	sub    $0x1e,%r8
   1a34e:	cmovb  %rdi,%r8
   1a352:	cmovb  %esi,%edx
   1a355:	mov    %r8,0x28d8(%rsp)
   1a35d:	add    %ecx,%edx
   1a35f:	mov    %edx,0x28e0(%rsp)
   1a366:	sub    %rsi,%r12
   1a369:	lea    0xd8(%rsp),%r8
   1a371:	test   %r12,%r12
   1a374:	je     1a950 <<c30walk::ctor2::Ctor2>::build::<false>+0x1230>
   1a37a:	mov    %rax,%r8
   1a37d:	cmp    0x10(%rbp),%rax
   1a381:	je     1a3a0 <<c30walk::ctor2::Ctor2>::build::<false>+0xc80>
   1a383:	lea    0x98(%rsp),%rdi
   1a38b:	mov    0x90(%rsp),%rsi
   1a393:	call   5a210 <<c30walk::ctor2::W<false>>::finish>
   1a398:	mov    0x0(%rbp),%r8
   1a39c:	mov    0x10(%rbp),%rax
   1a3a0:	sub    %rax,%r8
   1a3a3:	shr    $1,%r8
   1a3a6:	add    0x18(%rbp),%r8d
   1a3aa:	mov    %r8d,0x18(%rbp)
   1a3ae:	pxor   %xmm0,%xmm0
   1a3b2:	movdqu %xmm0,0x0(%rbp)
   1a3b7:	movq   $0x0,0x10(%rbp)
   1a3bf:	cmp    $0x1e,%r12
   1a3c3:	jb     1a8e4 <<c30walk::ctor2::Ctor2>::build::<false>+0x11c4>
   1a3c9:	mov    %r8,%rcx
   1a3cc:	imul   %r14,%rcx
   1a3d0:	shr    $0x24,%rcx
   1a3d4:	mov    %ecx,%eax
   1a3d6:	shl    $0x5,%eax
   1a3d9:	lea    (%rcx,%rcx,1),%edx
   1a3dc:	sub    %eax,%edx
   1a3de:	add    %r8d,%edx
   1a3e1:	jne    1a8e4 <<c30walk::ctor2::Ctor2>::build::<false>+0x11c4>
   1a3e7:	mov    %r12,%rax
   1a3ea:	movabs $0x8888888888888889,%rdx
   1a3f4:	mul    %rdx
   1a3f7:	shr    $0x4,%rdx
   1a3fb:	mov    %ecx,%r9d
   1a3fe:	cmpl   $0x0,0x1c(%rsp)
   1a403:	mov    %r12,0x50(%rsp)
   1a408:	mov    %rdx,0x48(%rsp)
   1a40d:	je     1a730 <<c30walk::ctor2::Ctor2>::build::<false>+0x1010>
   1a413:	mov    0x28e0(%rsp),%r10d
   1a41b:	mov    0xa8(%rsp),%rax
   1a423:	mov    %rax,(%rsp)
   1a427:	mov    0x98(%rsp),%r11
   1a42f:	mov    0xa0(%rsp),%rax
   1a437:	mov    %rax,0x10(%rsp)
   1a43c:	mov    0xc0(%rsp),%rax
   1a444:	mov    0x28d8(%rsp),%rbx
   1a44c:	mov    %rbx,%rdi
   1a44f:	shl    $0x6,%rdi
   1a453:	add    %r15,%rdi
   1a456:	mov    %r9,%rcx
   1a459:	shl    $0x6,%rcx
   1a45d:	lea    (%rax,%rcx,1),%r12
   1a461:	add    $0x3c,%r12
   1a465:	mov    %r10d,%r15d
   1a468:	shl    $0x8,%r15d
   1a46c:	or     %r13d,%r15d
   1a46f:	xor    %ebp,%ebp
   1a471:	jmp    1a6a1 <<c30walk::ctor2::Ctor2>::build::<false>+0xf81>
   1a476:	cs nopw 0x0(%rax,%rax,1)
   1a480:	mov    0x8(%r11),%rcx
   1a484:	shl    $0x7,%eax
   1a487:	mov    %r15d,(%rcx,%rax,1)
   1a48b:	movzwl 0x2(%rdi),%esi
   1a48f:	lea    (%r10,%rbp,1),%r14d
   1a493:	add    %r14d,%esi
   1a496:	shl    $0x8,%esi
   1a499:	or     %r13d,%esi
   1a49c:	mov    %esi,0x4(%rcx,%rax,1)
   1a4a0:	movzwl 0x4(%rdi),%esi
   1a4a4:	add    %r14d,%esi
   1a4a7:	shl    $0x8,%esi
   1a4aa:	or     %r13d,%esi
   1a4ad:	mov    %esi,0x8(%rcx,%rax,1)
   1a4b1:	movzwl 0x6(%rdi),%esi
   1a4b5:	add    %r14d,%esi
   1a4b8:	shl    $0x8,%esi
   1a4bb:	or     %r13d,%esi
   1a4be:	mov    %esi,0xc(%rcx,%rax,1)
   1a4c2:	movzwl 0x8(%rdi),%esi
   1a4c6:	add    %r14d,%esi
   1a4c9:	shl    $0x8,%esi
   1a4cc:	or     %r13d,%esi
   1a4cf:	mov    %esi,0x10(%rcx,%rax,1)
   1a4d3:	movzwl 0xa(%rdi),%esi
   1a4d7:	add    %r14d,%esi
   1a4da:	shl    $0x8,%esi
   1a4dd:	or     %r13d,%esi
   1a4e0:	mov    %esi,0x14(%rcx,%rax,1)
   1a4e4:	movzwl 0xc(%rdi),%esi
   1a4e8:	add    %r14d,%esi
   1a4eb:	shl    $0x8,%esi
   1a4ee:	or     %r13d,%esi
   1a4f1:	mov    %esi,0x18(%rcx,%rax,1)
   1a4f5:	movzwl 0xe(%rdi),%esi
   1a4f9:	add    %r14d,%esi
   1a4fc:	shl    $0x8,%esi
   1a4ff:	or     %r13d,%esi
   1a502:	mov    %esi,0x1c(%rcx,%rax,1)
   1a506:	movzwl 0x10(%rdi),%esi
   1a50a:	add    %r14d,%esi
   1a50d:	shl    $0x8,%esi
   1a510:	or     %r13d,%esi
   1a513:	mov    %esi,0x20(%rcx,%rax,1)
   1a517:	movzwl 0x12(%rdi),%esi
   1a51b:	add    %r14d,%esi
   1a51e:	shl    $0x8,%esi
   1a521:	or     %r13d,%esi
   1a524:	mov    %esi,0x24(%rcx,%rax,1)
   1a528:	movzwl 0x14(%rdi),%esi
   1a52c:	add    %r14d,%esi
   1a52f:	shl    $0x8,%esi
   1a532:	or     %r13d,%esi
   1a535:	mov    %esi,0x28(%rcx,%rax,1)
   1a539:	movzwl 0x16(%rdi),%esi
   1a53d:	add    %r14d,%esi
   1a540:	shl    $0x8,%esi
   1a543:	or     %r13d,%esi
   1a546:	mov    %esi,0x2c(%rcx,%rax,1)
   1a54a:	movzwl 0x18(%rdi),%esi
   1a54e:	add    %r14d,%esi
   1a551:	shl    $0x8,%esi
   1a554:	or     %r13d,%esi
   1a557:	mov    %esi,0x30(%rcx,%rax,1)
   1a55b:	movzwl 0x1a(%rdi),%esi
   1a55f:	add    %r14d,%esi
   1a562:	shl    $0x8,%esi
   1a565:	or     %r13d,%esi
   1a568:	mov    %esi,0x34(%rcx,%rax,1)
   1a56c:	movzwl 0x1c(%rdi),%esi
   1a570:	add    %r14d,%esi
   1a573:	shl    $0x8,%esi
   1a576:	or     %r13d,%esi
   1a579:	mov    %esi,0x38(%rcx,%rax,1)
   1a57d:	movzwl 0x1e(%rdi),%esi
   1a581:	add    %r14d,%esi
   1a584:	shl    $0x8,%esi
   1a587:	or     %r13d,%esi
   1a58a:	mov    %esi,0x3c(%rcx,%rax,1)
   1a58e:	movzwl 0x20(%rdi),%esi
   1a592:	add    %r14d,%esi
   1a595:	shl    $0x8,%esi
   1a598:	or     %r13d,%esi
   1a59b:	mov    %esi,0x40(%rcx,%rax,1)
   1a59f:	movzwl 0x22(%rdi),%esi
   1a5a3:	add    %r14d,%esi
   1a5a6:	shl    $0x8,%esi
   1a5a9:	or     %r13d,%esi
   1a5ac:	mov    %esi,0x44(%rcx,%rax,1)
   1a5b0:	movzwl 0x24(%rdi),%esi
   1a5b4:	add    %r14d,%esi
   1a5b7:	shl    $0x8,%esi
   1a5ba:	or     %r13d,%esi
   1a5bd:	mov    %esi,0x48(%rcx,%rax,1)
   1a5c1:	movzwl 0x26(%rdi),%esi
   1a5c5:	add    %r14d,%esi
   1a5c8:	shl    $0x8,%esi
   1a5cb:	or     %r13d,%esi
   1a5ce:	mov    %esi,0x4c(%rcx,%rax,1)
   1a5d2:	movzwl 0x28(%rdi),%esi
   1a5d6:	add    %r14d,%esi
   1a5d9:	shl    $0x8,%esi
   1a5dc:	or     %r13d,%esi
   1a5df:	mov    %esi,0x50(%rcx,%rax,1)
   1a5e3:	movzwl 0x2a(%rdi),%esi
   1a5e7:	add    %r14d,%esi
   1a5ea:	shl    $0x8,%esi
   1a5ed:	or     %r13d,%esi
   1a5f0:	mov    %esi,0x54(%rcx,%rax,1)
   1a5f4:	movzwl 0x2c(%rdi),%esi
   1a5f8:	add    %r14d,%esi
   1a5fb:	shl    $0x8,%esi
   1a5fe:	or     %r13d,%esi
   1a601:	mov    %esi,0x58(%rcx,%rax,1)
   1a605:	movzwl 0x2e(%rdi),%esi
   1a609:	add    %r14d,%esi
   1a60c:	shl    $0x8,%esi
   1a60f:	or     %r13d,%esi
   1a612:	mov    %esi,0x5c(%rcx,%rax,1)
   1a616:	movzwl 0x30(%rdi),%esi
   1a61a:	add    %r14d,%esi
   1a61d:	shl    $0x8,%esi
   1a620:	or     %r13d,%esi
   1a623:	mov    %esi,0x60(%rcx,%rax,1)
   1a627:	movzwl 0x32(%rdi),%esi
   1a62b:	add    %r14d,%esi
   1a62e:	shl    $0x8,%esi
   1a631:	or     %r13d,%esi
   1a634:	mov    %esi,0x64(%rcx,%rax,1)
   1a638:	movzwl 0x34(%rdi),%esi
   1a63c:	add    %r14d,%esi
   1a63f:	shl    $0x8,%esi
   1a642:	or     %r13d,%esi
   1a645:	mov    %esi,0x68(%rcx,%rax,1)
   1a649:	movzwl 0x36(%rdi),%esi
   1a64d:	add    %r14d,%esi
   1a650:	shl    $0x8,%esi
   1a653:	or     %r13d,%esi
   1a656:	mov    %esi,0x6c(%rcx,%rax,1)
   1a65a:	movzwl 0x38(%rdi),%esi
   1a65e:	add    %r14d,%esi
   1a661:	shl    $0x8,%esi
   1a664:	or     %r13d,%esi
   1a667:	mov    %esi,0x70(%rcx,%rax,1)
   1a66b:	movzwl 0x3a(%rdi),%esi
   1a66f:	add    %r14d,%esi
   1a672:	shl    $0x8,%esi
   1a675:	or     %r13d,%esi
   1a678:	mov    %esi,0x74(%rcx,%rax,1)
   1a67c:	lea    (%r10,%rbp,1),%eax
   1a680:	add    $0x20,%eax
   1a683:	mov    %eax,0x28e0(%rsp)
   1a68a:	add    $0x20,%rbp
   1a68e:	inc    %r9
   1a691:	add    $0x2000,%r15d
   1a698:	dec    %rdx
   1a69b:	je     1a89c <<c30walk::ctor2::Ctor2>::build::<false>+0x117c>
   1a6a1:	mov    %r9,%rax
   1a6a4:	shr    $0x6,%rax
   1a6a8:	cmp    (%rsp),%rax
   1a6ac:	jae    1af0b <<c30walk::ctor2::Ctor2>::build::<false>+0x17eb>
   1a6b2:	mov    0x10(%rsp),%rcx
   1a6b7:	mov    (%rcx,%rax,8),%rax
   1a6bb:	bt     %r9,%rax
   1a6bf:	jae    1a6f0 <<c30walk::ctor2::Ctor2>::build::<false>+0xfd0>
   1a6c1:	cmp    $0x1e,%rbx
   1a6c5:	jae    1af30 <<c30walk::ctor2::Ctor2>::build::<false>+0x1810>
   1a6cb:	mov    (%r12,%rbp,2),%eax
   1a6cf:	and    $0xfffff,%eax
   1a6d4:	mov    0x10(%r11),%rcx
   1a6d8:	cmp    %rax,%rcx
   1a6db:	ja     1a480 <<c30walk::ctor2::Ctor2>::build::<false>+0xd60>
   1a6e1:	jmp    1af1e <<c30walk::ctor2::Ctor2>::build::<false>+0x17fe>
   1a6e6:	cs nopw 0x0(%rax,%rax,1)
   1a6f0:	cmp    $0x1e,%rbx
   1a6f4:	jae    1af44 <<c30walk::ctor2::Ctor2>::build::<false>+0x1824>
   1a6fa:	movups 0x2c(%rdi),%xmm0
   1a6fe:	movups %xmm0,-0x10(%r12,%rbp,2)
   1a704:	movdqa (%rdi),%xmm0
   1a708:	movdqa 0x10(%rdi),%xmm1
   1a70d:	movdqa 0x20(%rdi),%xmm2
   1a712:	movdqa %xmm2,-0x1c(%r12,%rbp,2)
   1a719:	movdqa %xmm1,-0x2c(%r12,%rbp,2)
   1a720:	movdqa %xmm0,-0x3c(%r12,%rbp,2)
   1a727:	mov    %r15d,(%r12,%rbp,2)
   1a72b:	jmp    1a67c <<c30walk::ctor2::Ctor2>::build::<false>+0xf5c>
   1a730:	mov    0x28d8(%rsp),%rdi
   1a738:	cmp    $0x1d,%rdi
   1a73c:	ja     1afd9 <<c30walk::ctor2::Ctor2>::build::<false>+0x18b9>
   1a742:	shl    $0x6,%rdi
   1a746:	add    %r15,%rdi
   1a749:	mov    0x28e0(%rsp),%eax
   1a750:	mov    0xc0(%rsp),%rcx
   1a758:	shl    $0x6,%r9
   1a75c:	mov    %eax,%r14d
   1a75f:	shl    $0x8,%r14d
   1a763:	or     %r13d,%r14d
   1a766:	cmp    $0x3c,%r12
   1a76a:	jae    1a7d5 <<c30walk::ctor2::Ctor2>::build::<false>+0x10b5>
   1a76c:	xor    %esi,%esi
   1a76e:	jmp    1a85a <<c30walk::ctor2::Ctor2>::build::<false>+0x113a>
   1a773:	shr    $1,%r9
   1a776:	inc    %r9
   1a779:	mov    %r9,%r10
   1a77c:	and    $0xfffffffffffffff8,%r10
   1a780:	lea    (%rdx,%r10,2),%r8
   1a784:	movd   %ecx,%xmm0
   1a788:	pshuflw $0x0,%xmm0,%xmm0
   1a78d:	add    %r15,%r11
   1a790:	add    $0x8,%r11
   1a794:	xor    %ebx,%ebx
   1a796:	cs nopw 0x0(%rax,%rax,1)
   1a7a0:	movq   -0x8(%r11,%rbx,2),%xmm1
   1a7a7:	movq   (%r11,%rbx,2),%xmm2
   1a7ad:	paddw  %xmm0,%xmm1
   1a7b1:	paddw  %xmm0,%xmm2
   1a7b5:	punpcklqdq %xmm2,%xmm1
   1a7b9:	movdqu %xmm1,(%rax,%rbx,2)
   1a7be:	add    $0x8,%rbx
   1a7c2:	cmp    %rbx,%r10
   1a7c5:	jne    1a7a0 <<c30walk::ctor2::Ctor2>::build::<false>+0x1080>
   1a7c7:	cmp    %r10,%r9
   1a7ca:	jne    1a312 <<c30walk::ctor2::Ctor2>::build::<false>+0xbf2>
   1a7d0:	jmp    1a339 <<c30walk::ctor2::Ctor2>::build::<false>+0xc19>
   1a7d5:	mov    %rdx,%r10
   1a7d8:	movabs $0xffffffffffffffe,%rsi
   1a7e2:	and    %rsi,%r10
   1a7e5:	lea    (%rcx,%r9,1),%r11
   1a7e9:	add    $0x7c,%r11
   1a7ed:	xor    %esi,%esi
   1a7ef:	nop
   1a7f0:	movdqu 0x2c(%rdi),%xmm0
   1a7f5:	movdqu %xmm0,-0x50(%r11)
   1a7fb:	movdqa (%rdi),%xmm1
   1a7ff:	movdqa 0x10(%rdi),%xmm2
   1a804:	movdqa 0x20(%rdi),%xmm3
   1a809:	movdqa %xmm3,-0x5c(%r11)
   1a80f:	movdqa %xmm2,-0x6c(%r11)
   1a815:	movdqa %xmm1,-0x7c(%r11)
   1a81b:	mov    %r14d,-0x40(%r11)
   1a81f:	add    $0x2,%rsi
   1a823:	movdqa %xmm1,-0x3c(%r11)
   1a829:	movdqa %xmm2,-0x2c(%r11)
   1a82f:	movdqa %xmm3,-0x1c(%r11)
   1a835:	movdqu %xmm0,-0x10(%r11)
   1a83b:	lea    0x2000(%r14),%ebx
   1a842:	mov    %ebx,(%r11)
   1a845:	add    $0x4000,%r14d
   1a84c:	sub    $0xffffffffffffff80,%r11
   1a850:	cmp    %rsi,%r10
   1a853:	jne    1a7f0 <<c30walk::ctor2::Ctor2>::build::<false>+0x10d0>
   1a855:	test   $0x1,%dl
   1a858:	je     1a88e <<c30walk::ctor2::Ctor2>::build::<false>+0x116e>
   1a85a:	add    %r9,%rcx
   1a85d:	shl    $0x6,%rsi
   1a861:	movups 0x2c(%rdi),%xmm0
   1a865:	movups %xmm0,0x2c(%rcx,%rsi,1)
   1a86a:	movdqa (%rdi),%xmm0
   1a86e:	movdqa 0x10(%rdi),%xmm1
   1a873:	movdqa 0x20(%rdi),%xmm2
   1a878:	movdqa %xmm2,0x20(%rcx,%rsi,1)
   1a87e:	movdqa %xmm1,0x10(%rcx,%rsi,1)
   1a884:	movdqa %xmm0,(%rcx,%rsi,1)
   1a889:	mov    %r14d,0x3c(%rcx,%rsi,1)
   1a88e:	mov    %edx,%ecx
   1a890:	shl    $0x5,%ecx
   1a893:	add    %ecx,%eax
   1a895:	mov    %eax,0x28e0(%rsp)
   1a89c:	mov    0x48(%rsp),%rdx
   1a8a1:	mov    %rdx,%rax
   1a8a4:	shl    $0x5,%rax
   1a8a8:	lea    (%rdx,%rdx,1),%rcx
   1a8ac:	sub    %rax,%rcx
   1a8af:	mov    0x50(%rsp),%r12
   1a8b4:	add    %rcx,%r12
   1a8b7:	lea    (%rdx,%rdx,1),%eax
   1a8ba:	shl    $0x5,%edx
   1a8bd:	sub    %eax,%edx
   1a8bf:	add    %edx,%r8d
   1a8c2:	mov    0x88(%rsp),%rbp
   1a8ca:	mov    %r8d,0x18(%rbp)
   1a8ce:	test   %r12,%r12
   1a8d1:	mov    $0x88888889,%r14d
   1a8d7:	lea    0xcaa62(%rip),%r15        # e5340 <c30walk::ctor2::PATTERNS>
   1a8de:	je     1aa59 <<c30walk::ctor2::Ctor2>::build::<false>+0x1339>
   1a8e4:	mov    0x1c(%rbp),%ecx
   1a8e7:	mov    %r8d,%edi
   1a8ea:	imul   %r14,%rdi
   1a8ee:	mov    %rdi,%rdx
   1a8f1:	shr    $0x24,%rdx
   1a8f5:	mov    %edx,%eax
   1a8f7:	shl    $0x5,%eax
   1a8fa:	sub    %edx,%eax
   1a8fc:	sub    %edx,%eax
   1a8fe:	lea    0x1e(%rax),%esi
   1a901:	cmp    %ecx,%esi
   1a903:	cmovb  %esi,%ecx
   1a906:	shr    $0x2a,%rdi
   1a90a:	mov    0xa8(%rsp),%rsi
   1a912:	cmp    %rsi,%rdi
   1a915:	jae    1afbc <<c30walk::ctor2::Ctor2>::build::<false>+0x189c>
   1a91b:	mov    %rdx,%rsi
   1a91e:	shl    $0x6,%rsi
   1a922:	add    0xc0(%rsp),%rsi
   1a92a:	mov    0xa0(%rsp),%r9
   1a932:	mov    (%r9,%rdi,8),%rdi
   1a936:	bt     %rdx,%rdi
   1a93a:	jb     1a270 <<c30walk::ctor2::Ctor2>::build::<false>+0xb50>
   1a940:	mov    $0xffffffff,%edi
   1a945:	jmp    1a27c <<c30walk::ctor2::Ctor2>::build::<false>+0xb5c>
   1a94a:	nopw   0x0(%rax,%rax,1)
   1a950:	mov    0x8(%rsp),%r13
   1a955:	jmp    1aa66 <<c30walk::ctor2::Ctor2>::build::<false>+0x1346>
   1a95a:	nopw   0x0(%rax,%rax,1)
   1a960:	add    0x28(%rsp),%r11
   1a965:	xor    %r13d,%r13d
   1a968:	nopl   0x0(%rax,%rax,1)
   1a970:	movzbl (%r11,%r13,1),%esi
   1a975:	lea    (%rsi,%rsi,4),%rcx
   1a979:	lea    (%r8,%rcx,8),%rbp
   1a97d:	mov    (%r8,%rcx,8),%rax
   1a981:	cmp    0x8(%r8,%rcx,8),%rax
   1a986:	je     1a99e <<c30walk::ctor2::Ctor2>::build::<false>+0x127e>
   1a988:	lea    (%r14,%r13,1),%rcx
   1a98c:	mov    %cx,(%rax)
   1a98f:	addq   $0x2,0x0(%rbp)
   1a994:	inc    %r13
   1a997:	cmp    %r13,%rbx
   1a99a:	jne    1a970 <<c30walk::ctor2::Ctor2>::build::<false>+0x1250>
   1a99c:	jmp    1a9d0 <<c30walk::ctor2::Ctor2>::build::<false>+0x12b0>
   1a99e:	mov    %r11,(%rsp)
   1a9a2:	lea    0x98(%rsp),%rdi
   1a9aa:	call   92e0 <<c30walk::ctor2::W<false>>::refill>
   1a9af:	lea    0xd8(%rsp),%r8
   1a9b7:	test   %al,%al
   1a9b9:	je     1ac87 <<c30walk::ctor2::Ctor2>::build::<false>+0x1567>
   1a9bf:	mov    0x0(%rbp),%rax
   1a9c3:	mov    0x20(%rsp),%r10
   1a9c8:	mov    (%rsp),%r11
   1a9cc:	jmp    1a988 <<c30walk::ctor2::Ctor2>::build::<false>+0x1268>
   1a9ce:	xchg   %ax,%ax
   1a9d0:	cmp    %r15,0x30(%rsp)
   1a9d5:	mov    0x8(%rsp),%r13
   1a9da:	jb     1aef4 <<c30walk::ctor2::Ctor2>::build::<false>+0x17d4>
   1a9e0:	cmp    $0xf,%r12
   1a9e4:	ja     1a0b0 <<c30walk::ctor2::Ctor2>::build::<false>+0x990>
   1a9ea:	add    0x28(%rsp),%r15
   1a9ef:	mov    %r15,%r12
   1a9f2:	sub    %rbx,%r12
   1a9f5:	add    $0x10,%r12
   1a9f9:	add    %r14d,%ebx
   1a9fc:	add    $0x2,%ebx
   1a9ff:	nop
   1aa00:	movzbl (%r15),%esi
   1aa04:	lea    (%rsi,%rsi,4),%rcx
   1aa08:	lea    (%r8,%rcx,8),%r14
   1aa0c:	mov    (%r8,%rcx,8),%rax
   1aa10:	cmp    0x8(%r8,%rcx,8),%rax
   1aa15:	je     1aa2d <<c30walk::ctor2::Ctor2>::build::<false>+0x130d>
   1aa17:	mov    %bx,(%rax)
   1aa1a:	addq   $0x2,(%r14)
   1aa1e:	inc    %r15
   1aa21:	inc    %ebx
   1aa23:	cmp    %r12,%r15
   1aa26:	jne    1aa00 <<c30walk::ctor2::Ctor2>::build::<false>+0x12e0>
   1aa28:	jmp    1a0b0 <<c30walk::ctor2::Ctor2>::build::<false>+0x990>
   1aa2d:	lea    0x98(%rsp),%rdi
   1aa35:	call   92e0 <<c30walk::ctor2::W<false>>::refill>
   1aa3a:	lea    0xd8(%rsp),%r8
   1aa42:	test   %al,%al
   1aa44:	je     1ac87 <<c30walk::ctor2::Ctor2>::build::<false>+0x1567>
   1aa4a:	mov    (%r14),%rax
   1aa4d:	mov    0x8(%rsp),%r13
   1aa52:	mov    0x20(%rsp),%r10
   1aa57:	jmp    1aa17 <<c30walk::ctor2::Ctor2>::build::<false>+0x12f7>
   1aa59:	mov    0x8(%rsp),%r13
   1aa5e:	lea    0xd8(%rsp),%r8
   1aa66:	mov    0x20(%rsp),%r10
   1aa6b:	mov    0x68(%rsp),%r9
   1aa70:	mov    0x38(%rsp),%rcx
   1aa75:	mov    0x30(%rsp),%r11
   1aa7a:	mov    0x44(%rsp),%edx
   1aa7e:	mov    0x70(%rsp),%rsi
   1aa83:	jmp    1a0f2 <<c30walk::ctor2::Ctor2>::build::<false>+0x9d2>
   1aa88:	nopl   0x0(%rax,%rax,1)
   1aa90:	lea    (%r14,%r11,1),%rax
   1aa94:	cmp    %r10,%rax
   1aa97:	jne    1aae1 <<c30walk::ctor2::Ctor2>::build::<false>+0x13c1>
   1aa99:	cmp    $0x10,%rdx
   1aa9d:	jne    1ab57 <<c30walk::ctor2::Ctor2>::build::<false>+0x1437>
   1aaa3:	mov    0x28d8(%rsp),%rax
   1aaab:	lea    0x10(%rax),%rcx
   1aaaf:	cmp    $0x1d,%rcx
   1aab3:	mov    0x8(%rsp),%r13
   1aab8:	mov    0x28(%rsp),%r14
   1aabd:	mov    %rbp,%r9
   1aac0:	jbe    1abfb <<c30walk::ctor2::Ctor2>::build::<false>+0x14db>
   1aac6:	add    $0xfffffffffffffff2,%rax
   1aaca:	mov    %rax,0x28d8(%rsp)
   1aad2:	mov    0x28e0(%rsp),%eax
   1aad9:	add    $0x12,%eax
   1aadc:	jmp    1ac0d <<c30walk::ctor2::Ctor2>::build::<false>+0x14ed>
   1aae1:	add    $0x2,%r12d
   1aae5:	movzwl %r12w,%r12d
   1aae9:	nopl   0x0(%rax)
   1aaf0:	movzbl (%r15,%r14,1),%esi
   1aaf5:	lea    (%rsi,%rsi,4),%rcx
   1aaf9:	lea    (%r8,%rcx,8),%rbx
   1aafd:	mov    (%r8,%rcx,8),%rax
   1ab01:	cmp    0x8(%r8,%rcx,8),%rax
   1ab06:	je     1ab20 <<c30walk::ctor2::Ctor2>::build::<false>+0x1400>
   1ab08:	lea    (%r12,%r14,1),%rcx
   1ab0c:	mov    %cx,(%rax)
   1ab0f:	addq   $0x2,(%rbx)
   1ab13:	inc    %r14
   1ab16:	cmp    %r14,%rdx
   1ab19:	jne    1aaf0 <<c30walk::ctor2::Ctor2>::build::<false>+0x13d0>
   1ab1b:	jmp    1aa99 <<c30walk::ctor2::Ctor2>::build::<false>+0x1379>
   1ab20:	mov    %rdx,0x10(%rsp)
   1ab25:	mov    %r11,%r13
   1ab28:	lea    0x98(%rsp),%rdi
   1ab30:	call   92e0 <<c30walk::ctor2::W<false>>::refill>
   1ab35:	lea    0xd8(%rsp),%r8
   1ab3d:	test   %al,%al
   1ab3f:	je     1ac87 <<c30walk::ctor2::Ctor2>::build::<false>+0x1567>
   1ab45:	mov    (%rbx),%rax
   1ab48:	mov    0x20(%rsp),%r10
   1ab4d:	mov    %r13,%r11
   1ab50:	mov    0x10(%rsp),%rdx
   1ab55:	jmp    1ab08 <<c30walk::ctor2::Ctor2>::build::<false>+0x13e8>
   1ab57:	mov    0x28e0(%rsp),%eax
   1ab5e:	mov    0x28d8(%rsp),%rcx
   1ab66:	inc    %r11
   1ab69:	cmp    %r11,%r10
   1ab6c:	mov    0x8(%rsp),%r13
   1ab71:	mov    0x28(%rsp),%r14
   1ab76:	mov    %rbp,%r9
   1ab79:	je     1abd6 <<c30walk::ctor2::Ctor2>::build::<false>+0x14b6>
   1ab7b:	mov    %rdx,%r10
   1ab7e:	and    $0xffffe,%edx
   1ab84:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   1ab90:	lea    0x1(%rcx),%rsi
   1ab94:	add    $0xffffffffffffffe3,%rcx
   1ab98:	xor    %edi,%edi
   1ab9a:	cmp    $0x1e,%rsi
   1ab9e:	setae  %dil
   1aba2:	cmovb  %rsi,%rcx
   1aba6:	lea    (%rax,%rdi,2),%eax
   1aba9:	lea    0x1(%rcx),%rsi
   1abad:	add    $0xffffffffffffffe3,%rcx
   1abb1:	xor    %edi,%edi
   1abb3:	cmp    $0x1e,%rsi
   1abb7:	setae  %dil
   1abbb:	cmovb  %rsi,%rcx
   1abbf:	lea    (%rax,%rdi,2),%eax
   1abc2:	add    $0x2,%eax
   1abc5:	add    $0xfffffffffffffffe,%rdx
   1abc9:	jne    1ab90 <<c30walk::ctor2::Ctor2>::build::<false>+0x1470>
   1abcb:	test   $0x1,%r10b
   1abcf:	mov    0x20(%rsp),%r10
   1abd4:	je     1abf1 <<c30walk::ctor2::Ctor2>::build::<false>+0x14d1>
   1abd6:	lea    0x1(%rcx),%rdx
   1abda:	add    $0xffffffffffffffe3,%rcx
   1abde:	xor    %esi,%esi
   1abe0:	cmp    $0x1e,%rdx
   1abe4:	setae  %sil
   1abe8:	cmovb  %rdx,%rcx
   1abec:	lea    (%rax,%rsi,2),%eax
   1abef:	inc    %eax
   1abf1:	mov    %rcx,0x28d8(%rsp)
   1abf9:	jmp    1ac0d <<c30walk::ctor2::Ctor2>::build::<false>+0x14ed>
   1abfb:	mov    %rcx,0x28d8(%rsp)
   1ac03:	mov    0x28e0(%rsp),%eax
   1ac0a:	add    $0x10,%eax
   1ac0d:	mov    %eax,0x28e0(%rsp)
   1ac14:	mov    %r10,%r11
   1ac17:	cmp    %r13,%r10
   1ac1a:	jb     19efc <<c30walk::ctor2::Ctor2>::build::<false>+0x7dc>
   1ac20:	jmp    1ac2f <<c30walk::ctor2::Ctor2>::build::<false>+0x150f>
   1ac22:	mov    %r15,%rdi
   1ac25:	call   b630 <<alloc::raw_vec::RawVec<[u32; 256]>>::grow_one>
   1ac2a:	jmp    19f7f <<c30walk::ctor2::Ctor2>::build::<false>+0x85f>
   1ac2f:	mov    $0x84,%eax
   1ac34:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   1ac40:	lea    0x50(%rax),%rcx
   1ac44:	cmp    $0x28d4,%rcx
   1ac4b:	je     1acab <<c30walk::ctor2::Ctor2>::build::<false>+0x158b>
   1ac4d:	mov    0x54(%rsp,%rax,1),%rdx
   1ac52:	sub    0x64(%rsp,%rax,1),%rdx
   1ac57:	shr    $1,%rdx
   1ac5a:	add    0x6c(%rsp,%rax,1),%edx
   1ac5e:	cmp    0x70(%rsp,%rax,1),%edx
   1ac62:	jne    1ac87 <<c30walk::ctor2::Ctor2>::build::<false>+0x1567>
   1ac64:	mov    0x7c(%rsp,%rax,1),%rdx
   1ac69:	sub    0x8c(%rsp,%rax,1),%rdx
   1ac71:	shr    $1,%rdx
   1ac74:	add    0x94(%rsp,%rax,1),%edx
   1ac7b:	cmp    0x98(%rsp,%rax,1),%edx
   1ac82:	mov    %rcx,%rax
   1ac85:	je     1ac40 <<c30walk::ctor2::Ctor2>::build::<false>+0x1520>
   1ac87:	mov    0x5520(%rsp),%rax
   1ac8f:	movq   $0x0,0x10(%rax)
   1ac97:	xor    %eax,%eax
   1ac99:	add    $0x54e8,%rsp
   1aca0:	pop    %rbx
   1aca1:	pop    %r12
   1aca3:	pop    %r13
   1aca5:	pop    %r14
   1aca7:	pop    %r15
   1aca9:	pop    %rbp
   1acaa:	ret
   1acab:	xor    %r14d,%r14d
   1acae:	lea    0x98(%rsp),%r15
   1acb6:	mov    0x78(%rsp),%r12
   1acbb:	mov    0x8(%rsp),%r13
   1acc0:	mov    0x60(%rsp),%rbp
   1acc5:	jmp    1acfb <<c30walk::ctor2::Ctor2>::build::<false>+0x15db>
   1acc7:	nopw   0x0(%rax,%rax,1)
   1acd0:	sub    %rcx,%rax
   1acd3:	inc    %r14
   1acd6:	shr    $1,%rax
   1acd9:	add    %eax,0x18(%r8)
   1acdd:	pxor   %xmm0,%xmm0
   1ace1:	movdqu %xmm0,(%r8)
   1ace6:	movq   $0x0,0x10(%r8)
   1acee:	add    $0x28,%r8
   1acf2:	cmp    $0x100,%r14
   1acf9:	je     1ad21 <<c30walk::ctor2::Ctor2>::build::<false>+0x1601>
   1acfb:	mov    (%r8),%rcx
   1acfe:	mov    %rcx,%rax
   1ad01:	cmp    0x10(%r8),%rcx
   1ad05:	je     1acd0 <<c30walk::ctor2::Ctor2>::build::<false>+0x15b0>
   1ad07:	mov    %r15,%rdi
   1ad0a:	mov    %r14,%rsi
   1ad0d:	mov    %r8,%rbx
   1ad10:	call   5a210 <<c30walk::ctor2::W<false>>::finish>
   1ad15:	mov    %rbx,%r8
   1ad18:	mov    (%rbx),%rax
   1ad1b:	mov    0x10(%rbx),%rcx
   1ad1f:	jmp    1acd0 <<c30walk::ctor2::Ctor2>::build::<false>+0x15b0>
   1ad21:	xor    %ecx,%ecx
   1ad23:	mov    0x8(%r12),%rbx
   1ad28:	test   %rbp,%rbp
   1ad2b:	setne  %al
   1ad2e:	je     1ad72 <<c30walk::ctor2::Ctor2>::build::<false>+0x1652>
   1ad30:	mov    %al,%cl
   1ad32:	mov    %rbp,%rax
   1ad35:	sub    %rcx,%rax
   1ad38:	imul   $0xffffffffffffffe2,%rax,%rcx
   1ad3c:	add    %r13,%rcx
   1ad3f:	cmp    $0x1e,%rcx
   1ad43:	jae    1ad72 <<c30walk::ctor2::Ctor2>::build::<false>+0x1652>
   1ad45:	lea    (%rbx,%rbp,4),%rcx
   1ad49:	lea    (%rcx,%r13,2),%rdi
   1ad4d:	add    $0xfffffffffffffffc,%rdi
   1ad51:	lea    (%rax,%rax,1),%rcx
   1ad55:	shl    $0x5,%rax
   1ad59:	sub    %rcx,%rax
   1ad5c:	sub    %r13,%rax
   1ad5f:	lea    0x3c(,%rax,2),%rdx
   1ad67:	mov    $0xff,%esi
   1ad6c:	call   *0xeb0c6(%rip)        # 105e38 <memset@GLIBC_2.2.5>
   1ad72:	shl    $0x6,%rbp
   1ad76:	pcmpeqd %xmm0,%xmm0
   1ad7a:	movdqu %xmm0,0x2c(%rbx,%rbp,1)
   1ad80:	movdqa %xmm0,0x20(%rbx,%rbp,1)
   1ad86:	movdqa %xmm0,0x10(%rbx,%rbp,1)
   1ad8c:	movdqa %xmm0,(%rbx,%rbp,1)
   1ad91:	movl   $0x100fffff,0x3c(%rbx,%rbp,1)
   1ad99:	mov    0x58(%rsp),%rax
   1ad9e:	mov    0x8(%rax),%rdx
   1ada2:	mov    0x10(%rax),%rcx
   1ada6:	mov    0x5520(%rsp),%rax
   1adae:	mov    0x8(%rax),%r8
   1adb2:	mov    0x10(%rax),%r9
   1adb6:	lea    0x98(%rsp),%rdi
   1adbe:	mov    %rbx,%rsi
   1adc1:	call   67990 <c30walk::ctor::canonicalise>
   1adc6:	mov    0x80(%rsp),%rax
   1adce:	mov    %rax,0x10(%r12)
   1add3:	mov    $0x1,%al
   1add5:	jmp    1ac99 <<c30walk::ctor2::Ctor2>::build::<false>+0x1579>
   1adda:	lea    0xe852f(%rip),%rcx        # 103310 <__do_global_dtors_aux_fini_array_entry+0x2890>
   1ade1:	mov    %r12,%rdi
   1ade4:	mov    %r13,%rdx
   1ade7:	call   aff0 <core::slice::index::slice_index_fail>
   1adec:	lea    0xe76c5(%rip),%rcx        # 1024b8 <__do_global_dtors_aux_fini_array_entry+0x1a38>
   1adf3:	mov    $0x1e,%edx
   1adf8:	xor    %edi,%edi
   1adfa:	call   aff0 <core::slice::index::slice_index_fail>
   1adff:	mov    %rdi,%r12
   1ae02:	test   %rax,%rax
   1ae05:	je     1ae17 <<c30walk::ctor2::Ctor2>::build::<false>+0x16f7>
   1ae07:	mov    0x8(%r9),%rdi
   1ae0b:	mov    %r9,%r14
   1ae0e:	call   *0xeaf5c(%rip)        # 105d70 <free@GLIBC_2.2.5>
   1ae14:	mov    %r14,%r9
   1ae17:	movq   $0x0,(%r9)
   1ae1e:	movq   $0x40,0x8(%r9)
   1ae26:	movq   $0x0,0x10(%r9)
   1ae2e:	mov    $0x40,%edx
   1ae33:	mov    %r9,%rdi
   1ae36:	lea    0x1(%rbp),%rsi
   1ae3a:	mov    %r9,%r14
   1ae3d:	call   9500 <<alloc::raw_vec::RawVecInner>::grow_exact>
   1ae42:	mov    %r14,%r9
   1ae45:	cmp    $0xffffffffffffffff,%rax
   1ae49:	mov    %r12,%rdi
   1ae4c:	je     19945 <<c30walk::ctor2::Ctor2>::build::<false>+0x225>
   1ae52:	jmp    1aead <<c30walk::ctor2::Ctor2>::build::<false>+0x178d>
   1ae54:	mov    %rdi,%r12
   1ae57:	mov    %r9,%r14
   1ae5a:	test   %rax,%rax
   1ae5d:	je     1ae71 <<c30walk::ctor2::Ctor2>::build::<false>+0x1751>
   1ae5f:	mov    0x5520(%rsp),%rax
   1ae67:	mov    0x8(%rax),%rdi
   1ae6b:	call   *0xeaeff(%rip)        # 105d70 <free@GLIBC_2.2.5>
   1ae71:	mov    0x5520(%rsp),%rdi
   1ae79:	movq   $0x0,(%rdi)
   1ae80:	movq   $0x40,0x8(%rdi)
   1ae88:	movq   $0x0,0x10(%rdi)
   1ae90:	mov    $0x80,%edx
   1ae95:	mov    %rbx,%rsi
   1ae98:	call   9500 <<alloc::raw_vec::RawVecInner>::grow_exact>
   1ae9d:	cmp    $0xffffffffffffffff,%rax
   1aea1:	mov    %r14,%r9
   1aea4:	mov    %r12,%rdi
   1aea7:	je     19959 <<c30walk::ctor2::Ctor2>::build::<false>+0x239>
   1aead:	mov    %rax,%rdi
   1aeb0:	mov    %rdx,%rsi
   1aeb3:	call   ac41 <alloc::raw_vec::handle_error>
   1aeb8:	lea    0xe8451(%rip),%rcx        # 103310 <__do_global_dtors_aux_fini_array_entry+0x2890>
   1aebf:	mov    %r11,%rdi
   1aec2:	mov    %r13,%rdx
   1aec5:	call   aff0 <core::slice::index::slice_index_fail>
   1aeca:	lea    0xe7617(%rip),%rcx        # 1024e8 <__do_global_dtors_aux_fini_array_entry+0x1a68>
   1aed1:	mov    %r11,%rdi
   1aed4:	mov    %r15,%rsi
   1aed7:	mov    %r13,%rdx
   1aeda:	call   aff0 <core::slice::index::slice_index_fail>
   1aedf:	lea    0xe842a(%rip),%rcx        # 103310 <__do_global_dtors_aux_fini_array_entry+0x2890>
   1aee6:	mov    %rsi,%rdi
   1aee9:	mov    %rax,%rsi
   1aeec:	mov    %r13,%rdx
   1aeef:	call   aff0 <core::slice::index::slice_index_fail>
   1aef4:	lea    0xe75d5(%rip),%rcx        # 1024d0 <__do_global_dtors_aux_fini_array_entry+0x1a50>
   1aefb:	mov    %r15,%rdi
   1aefe:	mov    0x30(%rsp),%rsi
   1af03:	mov    %r13,%rdx
   1af06:	call   aff0 <core::slice::index::slice_index_fail>
   1af0b:	lea    0xe5dae(%rip),%rdx        # 100cc0 <__do_global_dtors_aux_fini_array_entry+0x240>
   1af12:	mov    %rax,%rdi
   1af15:	mov    (%rsp),%rsi
   1af19:	call   af3b <core::panicking::panic_bounds_check>
   1af1e:	lea    0xe7653(%rip),%rdx        # 102578 <__do_global_dtors_aux_fini_array_entry+0x1af8>
   1af25:	mov    %rax,%rdi
   1af28:	mov    %rcx,%rsi
   1af2b:	call   af3b <core::panicking::panic_bounds_check>
   1af30:	lea    0xe7629(%rip),%rdx        # 102560 <__do_global_dtors_aux_fini_array_entry+0x1ae0>
   1af37:	mov    $0x1e,%esi
   1af3c:	mov    %rbx,%rdi
   1af3f:	call   af3b <core::panicking::panic_bounds_check>
   1af44:	lea    0xe75fd(%rip),%rdx        # 102548 <__do_global_dtors_aux_fini_array_entry+0x1ac8>
   1af4b:	mov    $0x1e,%esi
   1af50:	mov    %rbx,%rdi
   1af53:	call   af3b <core::panicking::panic_bounds_check>
   1af58:	mov    $0x10,%edx
   1af5d:	mov    $0x4,%ecx
   1af62:	mov    $0x400,%r8d
   1af68:	mov    %rdi,%r14
   1af6b:	mov    %r12,%rdi
   1af6e:	xor    %esi,%esi
   1af70:	mov    %r9,%rbx
   1af73:	call   81e0 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
   1af78:	mov    %r14,%rdi
   1af7b:	mov    %rbx,%r9
   1af7e:	jmp    199f0 <<c30walk::ctor2::Ctor2>::build::<false>+0x2d0>
   1af83:	mov    %r9,%r13
   1af86:	mov    $0x8,%ecx
   1af8b:	mov    $0x8,%r8d
   1af91:	mov    %rdi,%r14
   1af94:	xor    %esi,%esi
   1af96:	mov    %rbx,%rdx
   1af99:	call   81e0 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
   1af9e:	mov    %r14,%rdi
   1afa1:	mov    0x10(%r14),%r14
   1afa5:	mov    0x8(%rdi),%r12
   1afa9:	lea    (%r12,%r14,8),%rdi
   1afad:	cmp    $0x1,%rbx
   1afb1:	jne    19997 <<c30walk::ctor2::Ctor2>::build::<false>+0x277>
   1afb7:	jmp    199b9 <<c30walk::ctor2::Ctor2>::build::<false>+0x299>
   1afbc:	lea    0xe5cfd(%rip),%rdx        # 100cc0 <__do_global_dtors_aux_fini_array_entry+0x240>
   1afc3:	call   af3b <core::panicking::panic_bounds_check>
   1afc8:	lea    0xe74d1(%rip),%rdx        # 1024a0 <__do_global_dtors_aux_fini_array_entry+0x1a20>
   1afcf:	mov    $0x1e,%esi
   1afd4:	call   af3b <core::panicking::panic_bounds_check>
   1afd9:	lea    0xe7550(%rip),%rdx        # 102530 <__do_global_dtors_aux_fini_array_entry+0x1ab0>
   1afe0:	mov    $0x1e,%esi
   1afe5:	call   af3b <core::panicking::panic_bounds_check>
   1afea:	lea    0xe7437(%rip),%rdx        # 102428 <__do_global_dtors_aux_fini_array_entry+0x19a8>
   1aff1:	call   af3b <core::panicking::panic_bounds_check>
   1aff6:	lea    0xe5cc3(%rip),%rdx        # 100cc0 <__do_global_dtors_aux_fini_array_entry+0x240>
   1affd:	mov    %rbp,%rdi
   1b000:	call   af3b <core::panicking::panic_bounds_check>
