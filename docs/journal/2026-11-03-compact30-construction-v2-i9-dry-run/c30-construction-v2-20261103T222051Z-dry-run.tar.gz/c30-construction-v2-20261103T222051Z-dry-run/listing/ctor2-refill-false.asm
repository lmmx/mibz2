# <c30walk::ctor2::W<false>>::refill
# size 0xec

/home/louis/dev/mibz2/target/c30-construction-v2-pin/target/rust-1.97.0/release/examples/c30walk:     file format elf64-x86-64


Disassembly of section .text:

00000000000092e0 <<c30walk::ctor2::W<false>>::refill>:
    92e0:	push   %r15
    92e2:	push   %r14
    92e4:	push   %rbx
    92e5:	mov    %rdi,%rbx
    92e8:	lea    (%rsi,%rsi,4),%rax
    92ec:	lea    (%rdi,%rax,8),%r15
    92f0:	add    $0x40,%r15
    92f4:	mov    0x40(%rdi,%rax,8),%r14
    92f9:	sub    0x50(%rdi,%rax,8),%r14
    92fe:	je     9308 <<c30walk::ctor2::W<false>>::refill+0x28>
    9300:	mov    %rbx,%rdi
    9303:	call   5a210 <<c30walk::ctor2::W<false>>::finish>
    9308:	shr    $1,%r14
    930b:	add    0x18(%r15),%r14d
    930f:	mov    %r14d,0x18(%r15)
    9313:	xorps  %xmm0,%xmm0
    9316:	movups %xmm0,(%r15)
    931a:	movq   $0x0,0x10(%r15)
    9322:	mov    0x1c(%r15),%eax
    9326:	cmp    %eax,%r14d
    9329:	jae    93b4 <<c30walk::ctor2::W<false>>::refill+0xd4>
    932f:	mov    %r14d,%ecx
    9332:	mov    $0x88888889,%edi
    9337:	imul   %rcx,%rdi
    933b:	mov    %rdi,%rcx
    933e:	shr    $0x24,%rcx
    9342:	mov    %ecx,%r9d
    9345:	shl    $0x5,%r9d
    9349:	sub    %ecx,%r9d
    934c:	sub    %ecx,%r9d
    934f:	lea    0x1e(%r9),%edx
    9353:	cmp    %eax,%edx
    9355:	cmovae %eax,%edx
    9358:	shr    $0x2a,%rdi
    935c:	mov    0x10(%rbx),%rsi
    9360:	cmp    %rsi,%rdi
    9363:	jae    93c0 <<c30walk::ctor2::W<false>>::refill+0xe0>
    9365:	mov    %r14d,%esi
    9368:	mov    %rcx,%r8
    936b:	shl    $0x6,%r8
    936f:	add    0x28(%rbx),%r8
    9373:	sub    %r9d,%esi
    9376:	mov    0x8(%rbx),%r9
    937a:	mov    (%r9,%rdi,8),%rdi
    937e:	bt     %rcx,%rdi
    9382:	jae    938f <<c30walk::ctor2::W<false>>::refill+0xaf>
    9384:	mov    $0xfffff,%edi
    9389:	and    0x3c(%r8),%edi
    938d:	jmp    9394 <<c30walk::ctor2::W<false>>::refill+0xb4>
    938f:	mov    $0xffffffff,%edi
    9394:	mov    %esi,%esi
    9396:	lea    (%r8,%rsi,2),%rsi
    939a:	mov    %rsi,0x10(%r15)
    939e:	mov    %rsi,(%r15)
    93a1:	sub    %r14d,%edx
    93a4:	lea    (%rsi,%rdx,2),%rdx
    93a8:	mov    %rdx,0x8(%r15)
    93ac:	mov    %ecx,0x20(%r15)
    93b0:	mov    %edi,0x24(%r15)
    93b4:	cmp    %eax,%r14d
    93b7:	setb   %al
    93ba:	pop    %rbx
    93bb:	pop    %r14
    93bd:	pop    %r15
    93bf:	ret
    93c0:	lea    0xf78f9(%rip),%rdx        # 100cc0 <__do_global_dtors_aux_fini_array_entry+0x240>
    93c7:	call   af3b <core::panicking::panic_bounds_check>
