# <c30walk::ctor2::W<false>>::finish
# size 0x5fa

/home/louis/dev/mibz2/target/c30-construction-v2-pin/target/rust-1.97.0/release/examples/c30walk:     file format elf64-x86-64


Disassembly of section .text:

000000000005a210 <<c30walk::ctor2::W<false>>::finish>:
   5a210:	push   %rbp
   5a211:	push   %r15
   5a213:	push   %r14
   5a215:	push   %r13
   5a217:	push   %r12
   5a219:	push   %rbx
   5a21a:	sub    $0x38,%rsp
   5a21e:	mov    0x18(%rdi),%rbp
   5a222:	mov    0x10(%rbp),%r8
   5a226:	mov    %r8,%r13
   5a229:	sub    $0x1,%r13
   5a22d:	jb     5a79a <<c30walk::ctor2::W<false>>::finish+0x58a>
   5a233:	mov    %rdi,%r11
   5a236:	lea    (%rsi,%rsi,4),%rax
   5a23a:	mov    0x40(%rdi,%rax,8),%r14
   5a23f:	mov    0x50(%rdi,%rax,8),%rdi
   5a244:	mov    0x58(%r11,%rax,8),%r12d
   5a249:	mov    0x60(%r11,%rax,8),%ecx
   5a24e:	mov    0x64(%r11,%rax,8),%eax
   5a253:	sub    %rdi,%r14
   5a256:	mov    %r14,0x8(%rsp)
   5a25b:	shr    $1,%r14
   5a25e:	mov    0x8(%rbp),%r10
   5a262:	mov    %r13,%rdx
   5a265:	shl    $0xa,%rdx
   5a269:	add    %r10,%rdx
   5a26c:	mov    %r13,%rbx
   5a26f:	cmp    %r12d,(%rdx,%rsi,4)
   5a273:	jbe    5a2e8 <<c30walk::ctor2::W<false>>::finish+0xd8>
   5a275:	mov    %r11,%r15
   5a278:	lea    (%r12,%r14,1),%edx
   5a27c:	dec    %edx
   5a27e:	mov    %r8,%r9
   5a281:	shl    $0xa,%r9
   5a285:	lea    (%r9,%rsi,4),%r9
   5a289:	lea    (%r10,%r9,1),%r11
   5a28d:	add    $0xfffffffffffffc00,%r11
   5a294:	mov    %r8,%rbx
   5a297:	nopw   0x0(%rax,%rax,1)
   5a2a0:	dec    %rbx
   5a2a3:	cmp    %r8,%rbx
   5a2a6:	jae    5a74e <<c30walk::ctor2::W<false>>::finish+0x53e>
   5a2ac:	cmp    %r12d,(%r11)
   5a2af:	lea    -0x400(%r11),%r11
   5a2b6:	ja     5a2a0 <<c30walk::ctor2::W<false>>::finish+0x90>
   5a2b8:	add    %r10,%r9
   5a2bb:	add    $0xfffffffffffffc00,%r9
   5a2c2:	mov    %r8,%r13
   5a2c5:	mov    %r15,%r11
   5a2c8:	nopl   0x0(%rax,%rax,1)
   5a2d0:	dec    %r13
   5a2d3:	cmp    %r8,%r13
   5a2d6:	jae    5a760 <<c30walk::ctor2::W<false>>::finish+0x550>
   5a2dc:	cmp    %edx,(%r9)
   5a2df:	lea    -0x400(%r9),%r9
   5a2e6:	ja     5a2d0 <<c30walk::ctor2::W<false>>::finish+0xc0>
   5a2e8:	imul   $0xffffffffffffffe2,%rcx,%r15
   5a2ec:	add    %r12,%r15
   5a2ef:	cmp    $0xffffffff,%eax
   5a2f2:	mov    %r14,0x10(%rsp)
   5a2f7:	je     5a3fb <<c30walk::ctor2::W<false>>::finish+0x1eb>
   5a2fd:	mov    $0xffffffff,%r9d
   5a303:	cmp    %r13,%rbx
   5a306:	jae    5a320 <<c30walk::ctor2::W<false>>::finish+0x110>
   5a308:	lea    0x1(%rbx),%rcx
   5a30c:	cmp    %r8,%rcx
   5a30f:	jae    5a7bd <<c30walk::ctor2::W<false>>::finish+0x5ad>
   5a315:	shl    $0xa,%rcx
   5a319:	add    %rcx,%r10
   5a31c:	mov    (%r10,%rsi,4),%r9d
   5a320:	mov    (%r11),%rdx
   5a323:	mov    0x10(%rdx),%rcx
   5a327:	cmp    %rax,%rcx
   5a32a:	jbe    5a7ab <<c30walk::ctor2::W<false>>::finish+0x59b>
   5a330:	test   %r14,%r14
   5a333:	je     5a7fb <<c30walk::ctor2::W<false>>::finish+0x5eb>
   5a339:	shl    $0x7,%rax
   5a33d:	add    0x8(%rdx),%rax
   5a341:	lea    0x800(,%rsi,4),%rdx
   5a349:	xor    %r11d,%r11d
   5a34c:	nopl   0x0(%rax)
   5a350:	lea    (%r12,%r11,1),%r10d
   5a354:	cmp    %r9d,%r10d
   5a357:	jae    5a390 <<c30walk::ctor2::W<false>>::finish+0x180>
   5a359:	lea    (%r11,%r15,1),%rcx
   5a35d:	cmp    $0x20,%rcx
   5a361:	jae    5a772 <<c30walk::ctor2::W<false>>::finish+0x562>
   5a367:	movzwl (%rdi,%r11,2),%r8d
   5a36c:	inc    %r11
   5a36f:	mov    %ebx,%r10d
   5a372:	shl    $0x18,%r10d
   5a376:	shl    $0x8,%r8d
   5a37a:	or     %r10d,%r8d
   5a37d:	or     %esi,%r8d
   5a380:	mov    %r8d,(%rax,%rcx,4)
   5a384:	cmp    0x10(%rsp),%r11
   5a389:	jne    5a350 <<c30walk::ctor2::W<false>>::finish+0x140>
   5a38b:	jmp    5a3d9 <<c30walk::ctor2::W<false>>::finish+0x1c9>
   5a38d:	nopl   (%rax)
   5a390:	mov    %rbx,%r14
   5a393:	shl    $0xa,%r14
   5a397:	add    %rdx,%r14
   5a39a:	mov    %rbx,%rcx
   5a39d:	jmp    5a3af <<c30walk::ctor2::W<false>>::finish+0x19f>
   5a39f:	nop
   5a3a0:	add    $0x400,%r14
   5a3a7:	mov    %rbx,%rcx
   5a3aa:	cmp    %r9d,%r10d
   5a3ad:	jb     5a359 <<c30walk::ctor2::W<false>>::finish+0x149>
   5a3af:	lea    0x1(%rcx),%rbx
   5a3b3:	mov    $0xffffffff,%r9d
   5a3b9:	cmp    %r13,%rbx
   5a3bc:	jae    5a3a0 <<c30walk::ctor2::W<false>>::finish+0x190>
   5a3be:	add    $0x2,%rcx
   5a3c2:	mov    0x10(%rbp),%r8
   5a3c6:	cmp    %r8,%rcx
   5a3c9:	jae    5a73c <<c30walk::ctor2::W<false>>::finish+0x52c>
   5a3cf:	mov    0x8(%rbp),%rcx
   5a3d3:	mov    (%rcx,%r14,1),%r9d
   5a3d7:	jmp    5a3a0 <<c30walk::ctor2::W<false>>::finish+0x190>
   5a3d9:	mov    0x8(%rsp),%rdx
   5a3de:	and    $0xfffffffffffffffe,%rdx
   5a3e2:	mov    $0xff,%esi
   5a3e7:	add    $0x38,%rsp
   5a3eb:	pop    %rbx
   5a3ec:	pop    %r12
   5a3ee:	pop    %r13
   5a3f0:	pop    %r14
   5a3f2:	pop    %r15
   5a3f4:	pop    %rbp
   5a3f5:	jmp    *0xaba3d(%rip)        # 105e38 <memset@GLIBC_2.2.5>
   5a3fb:	movzwl (%rdi),%eax
   5a3fe:	movzwl -0x2(%rdi,%r14,2),%r8d
   5a404:	mov    %ebx,%edx
   5a406:	shl    $0x10,%edx
   5a409:	or     %eax,%edx
   5a40b:	mov    %r13d,%r9d
   5a40e:	shl    $0x10,%r9d
   5a412:	or     %r8d,%r9d
   5a415:	sub    %edx,%r9d
   5a418:	cmp    $0xfffe,%r9d
   5a41f:	jae    5a49d <<c30walk::ctor2::W<false>>::finish+0x28d>
   5a421:	mov    0x28(%r11),%r8
   5a425:	shl    $0x6,%rcx
   5a429:	shl    $0x8,%edx
   5a42c:	or     %edx,%esi
   5a42e:	mov    %esi,0x3c(%r8,%rcx,1)
   5a433:	test   %r14,%r14
   5a436:	je     5a7fb <<c30walk::ctor2::W<false>>::finish+0x5eb>
   5a43c:	cmp    $0x1e,%r14
   5a440:	jne    5a636 <<c30walk::ctor2::W<false>>::finish+0x426>
   5a446:	movd   %eax,%xmm0
   5a44a:	pshuflw $0x0,%xmm0,%xmm0
   5a44f:	pshufd $0x44,%xmm0,%xmm1
   5a454:	movdqu (%rdi),%xmm2
   5a458:	movdqu 0x10(%rdi),%xmm3
   5a45d:	movdqu 0x20(%rdi),%xmm4
   5a462:	psubw  %xmm1,%xmm2
   5a466:	movdqu %xmm2,(%rdi)
   5a46a:	psubw  %xmm1,%xmm3
   5a46e:	movdqu %xmm3,0x10(%rdi)
   5a473:	psubw  %xmm1,%xmm4
   5a477:	movdqu %xmm4,0x20(%rdi)
   5a47c:	movq   0x30(%rdi),%xmm1
   5a481:	psubw  %xmm0,%xmm1
   5a485:	movq   %xmm1,0x30(%rdi)
   5a48a:	movd   0x38(%rdi),%xmm1
   5a48f:	psubw  %xmm0,%xmm1
   5a493:	movd   %xmm1,0x38(%rdi)
   5a498:	jmp    5a7fb <<c30walk::ctor2::W<false>>::finish+0x5eb>
   5a49d:	mov    (%r11),%r10
   5a4a0:	mov    0x10(%r10),%r9
   5a4a4:	cmp    (%r10),%r9
   5a4a7:	mov    %r11,0x30(%rsp)
   5a4ac:	je     5a6fc <<c30walk::ctor2::W<false>>::finish+0x4ec>
   5a4b2:	mov    0x8(%r10),%rax
   5a4b6:	mov    %r9,%rdx
   5a4b9:	shl    $0x7,%rdx
   5a4bd:	pxor   %xmm0,%xmm0
   5a4c1:	movdqa %xmm0,0x70(%rax,%rdx,1)
   5a4c7:	movdqa %xmm0,0x60(%rax,%rdx,1)
   5a4cd:	movdqa %xmm0,0x50(%rax,%rdx,1)
   5a4d3:	movdqa %xmm0,0x40(%rax,%rdx,1)
   5a4d9:	movdqa %xmm0,0x30(%rax,%rdx,1)
   5a4df:	movdqa %xmm0,0x20(%rax,%rdx,1)
   5a4e5:	movdqa %xmm0,0x10(%rax,%rdx,1)
   5a4eb:	movdqa %xmm0,(%rax,%rdx,1)
   5a4f0:	lea    0x1(%r9),%rax
   5a4f4:	mov    %rax,0x10(%r10)
   5a4f8:	mov    $0xffffffff,%r8d
   5a4fe:	cmp    %r13,%rbx
   5a501:	jae    5a520 <<c30walk::ctor2::W<false>>::finish+0x310>
   5a503:	lea    0x1(%rbx),%rax
   5a507:	mov    0x10(%rbp),%r8
   5a50b:	cmp    %r8,%rax
   5a50e:	jae    5a7db <<c30walk::ctor2::W<false>>::finish+0x5cb>
   5a514:	shl    $0xa,%rax
   5a518:	add    0x8(%rbp),%rax
   5a51c:	mov    (%rax,%rsi,4),%r8d
   5a520:	mov    %r9,0x8(%rsp)
   5a525:	test   %r14,%r14
   5a528:	je     5a5d5 <<c30walk::ctor2::W<false>>::finish+0x3c5>
   5a52e:	add    0x8(%r10),%rdx
   5a532:	lea    0x800(,%rsi,4),%r9
   5a53a:	xor    %r10d,%r10d
   5a53d:	nopl   (%rax)
   5a540:	lea    (%r12,%r10,1),%r11d
   5a544:	cmp    %r8d,%r11d
   5a547:	jae    5a580 <<c30walk::ctor2::W<false>>::finish+0x370>
   5a549:	lea    (%r10,%r15,1),%rax
   5a54d:	cmp    $0x20,%rax
   5a551:	jae    5a786 <<c30walk::ctor2::W<false>>::finish+0x576>
   5a557:	movzwl (%rdi,%r10,2),%r11d
   5a55c:	inc    %r10
   5a55f:	mov    %ebx,%r14d
   5a562:	shl    $0x18,%r14d
   5a566:	shl    $0x8,%r11d
   5a56a:	or     %r14d,%r11d
   5a56d:	or     %esi,%r11d
   5a570:	mov    %r11d,(%rdx,%rax,4)
   5a574:	cmp    0x10(%rsp),%r10
   5a579:	jne    5a540 <<c30walk::ctor2::W<false>>::finish+0x330>
   5a57b:	jmp    5a5d5 <<c30walk::ctor2::W<false>>::finish+0x3c5>
   5a57d:	nopl   (%rax)
   5a580:	mov    %rbx,%r14
   5a583:	shl    $0xa,%r14
   5a587:	add    %r9,%r14
   5a58a:	mov    %rbx,%rax
   5a58d:	jmp    5a5a7 <<c30walk::ctor2::W<false>>::finish+0x397>
   5a58f:	nop
   5a590:	mov    0x8(%rbp),%rax
   5a594:	mov    (%rax,%r14,1),%r8d
   5a598:	add    $0x400,%r14
   5a59f:	mov    %rbx,%rax
   5a5a2:	cmp    %r8d,%r11d
   5a5a5:	jb     5a549 <<c30walk::ctor2::W<false>>::finish+0x339>
   5a5a7:	lea    0x1(%rax),%rbx
   5a5ab:	mov    $0xffffffff,%r8d
   5a5b1:	cmp    %r13,%rbx
   5a5b4:	jae    5a598 <<c30walk::ctor2::W<false>>::finish+0x388>
   5a5b6:	add    $0x2,%rax
   5a5ba:	mov    0x10(%rbp),%r8
   5a5be:	cmp    %r8,%rax
   5a5c1:	jb     5a590 <<c30walk::ctor2::W<false>>::finish+0x380>
   5a5c3:	lea    0xa7ebe(%rip),%rdx        # 102488 <__do_global_dtors_aux_fini_array_entry+0x1a08>
   5a5ca:	mov    %rax,%rdi
   5a5cd:	mov    %r8,%rsi
   5a5d0:	call   af3b <core::panicking::panic_bounds_check>
   5a5d5:	mov    0x30(%rsp),%r8
   5a5da:	mov    0x28(%r8),%rax
   5a5de:	mov    %rcx,%rdx
   5a5e1:	shl    $0x6,%rdx
   5a5e5:	mov    0x8(%rsp),%rsi
   5a5ea:	or     $0x10000000,%esi
   5a5f0:	pcmpeqd %xmm0,%xmm0
   5a5f4:	movdqu %xmm0,0x2c(%rax,%rdx,1)
   5a5fa:	movdqa %xmm0,0x20(%rax,%rdx,1)
   5a600:	movdqa %xmm0,0x10(%rax,%rdx,1)
   5a606:	movdqa %xmm0,(%rax,%rdx,1)
   5a60b:	mov    %esi,0x3c(%rax,%rdx,1)
   5a60f:	mov    %ecx,%edi
   5a611:	shr    $0x6,%edi
   5a614:	mov    0x10(%r8),%rsi
   5a618:	cmp    %rsi,%rdi
   5a61b:	jae    5a7cf <<c30walk::ctor2::W<false>>::finish+0x5bf>
   5a621:	mov    $0x1,%eax
   5a626:	shl    %cl,%rax
   5a629:	mov    0x8(%r8),%rcx
   5a62d:	or     %rax,(%rcx,%rdi,8)
   5a631:	jmp    5a7fb <<c30walk::ctor2::W<false>>::finish+0x5eb>
   5a636:	mov    0x8(%rsp),%rcx
   5a63b:	cmp    $0x8,%rcx
   5a63f:	jae    5a648 <<c30walk::ctor2::W<false>>::finish+0x438>
   5a641:	xor    %ecx,%ecx
   5a643:	jmp    5a7f2 <<c30walk::ctor2::W<false>>::finish+0x5e2>
   5a648:	movabs $0x7ffffffffffffff0,%rsi
   5a652:	cmp    $0x20,%rcx
   5a656:	jae    5a65c <<c30walk::ctor2::W<false>>::finish+0x44c>
   5a658:	xor    %ecx,%ecx
   5a65a:	jmp    5a6bb <<c30walk::ctor2::W<false>>::finish+0x4ab>
   5a65c:	mov    %r14,%rcx
   5a65f:	and    %rsi,%rcx
   5a662:	movd   %eax,%xmm0
   5a666:	pshuflw $0x0,%xmm0,%xmm0
   5a66b:	pshufd $0x44,%xmm0,%xmm0
   5a670:	xor    %edx,%edx
   5a672:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   5a680:	movdqu (%rdi,%rdx,2),%xmm1
   5a685:	movdqu 0x10(%rdi,%rdx,2),%xmm2
   5a68b:	psubw  %xmm0,%xmm1
   5a68f:	psubw  %xmm0,%xmm2
   5a693:	movdqu %xmm1,(%rdi,%rdx,2)
   5a698:	movdqu %xmm2,0x10(%rdi,%rdx,2)
   5a69e:	add    $0x10,%rdx
   5a6a2:	cmp    %rdx,%rcx
   5a6a5:	jne    5a680 <<c30walk::ctor2::W<false>>::finish+0x470>
   5a6a7:	cmp    %rcx,%r14
   5a6aa:	je     5a7fb <<c30walk::ctor2::W<false>>::finish+0x5eb>
   5a6b0:	testb  $0x18,0x8(%rsp)
   5a6b5:	je     5a7f2 <<c30walk::ctor2::W<false>>::finish+0x5e2>
   5a6bb:	mov    %rcx,%rdx
   5a6be:	add    $0xc,%rsi
   5a6c2:	mov    %rsi,%rcx
   5a6c5:	and    %r14,%rcx
   5a6c8:	movd   %eax,%xmm0
   5a6cc:	pshuflw $0x0,%xmm0,%xmm0
   5a6d1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   5a6e0:	movq   (%rdi,%rdx,2),%xmm1
   5a6e5:	psubw  %xmm0,%xmm1
   5a6e9:	movq   %xmm1,(%rdi,%rdx,2)
   5a6ee:	add    $0x4,%rdx
   5a6f2:	cmp    %rdx,%rcx
   5a6f5:	jne    5a6e0 <<c30walk::ctor2::W<false>>::finish+0x4d0>
   5a6f7:	jmp    5a7ed <<c30walk::ctor2::W<false>>::finish+0x5dd>
   5a6fc:	mov    %rdi,0x8(%rsp)
   5a701:	mov    %r10,%rdi
   5a704:	mov    %rsi,0x20(%rsp)
   5a709:	mov    %rcx,0x28(%rsp)
   5a70e:	mov    %r9,%r14
   5a711:	mov    %r10,0x18(%rsp)
   5a716:	call   95d0 <<alloc::raw_vec::RawVec<c30walk::RawG>>::grow_one>
   5a71b:	mov    0x18(%rsp),%r10
   5a720:	mov    %r14,%r9
   5a723:	mov    0x28(%rsp),%rcx
   5a728:	mov    0x20(%rsp),%rsi
   5a72d:	mov    0x10(%rsp),%r14
   5a732:	mov    0x8(%rsp),%rdi
   5a737:	jmp    5a4b2 <<c30walk::ctor2::W<false>>::finish+0x2a2>
   5a73c:	lea    0xa7d45(%rip),%rdx        # 102488 <__do_global_dtors_aux_fini_array_entry+0x1a08>
   5a743:	mov    %rcx,%rdi
   5a746:	mov    %r8,%rsi
   5a749:	call   af3b <core::panicking::panic_bounds_check>
   5a74e:	lea    0xa7e3b(%rip),%rdx        # 102590 <__do_global_dtors_aux_fini_array_entry+0x1b10>
   5a755:	mov    %rbx,%rdi
   5a758:	mov    %r8,%rsi
   5a75b:	call   af3b <core::panicking::panic_bounds_check>
   5a760:	lea    0xa7e29(%rip),%rdx        # 102590 <__do_global_dtors_aux_fini_array_entry+0x1b10>
   5a767:	mov    %r13,%rdi
   5a76a:	mov    %r8,%rsi
   5a76d:	call   af3b <core::panicking::panic_bounds_check>
   5a772:	lea    0xa7cf7(%rip),%rdx        # 102470 <__do_global_dtors_aux_fini_array_entry+0x19f0>
   5a779:	mov    $0x20,%esi
   5a77e:	mov    %rcx,%rdi
   5a781:	call   af3b <core::panicking::panic_bounds_check>
   5a786:	lea    0xa7ce3(%rip),%rdx        # 102470 <__do_global_dtors_aux_fini_array_entry+0x19f0>
   5a78d:	mov    $0x20,%esi
   5a792:	mov    %rax,%rdi
   5a795:	call   af3b <core::panicking::panic_bounds_check>
   5a79a:	lea    0xa7d5f(%rip),%rdx        # 102500 <__do_global_dtors_aux_fini_array_entry+0x1a80>
   5a7a1:	mov    %r13,%rdi
   5a7a4:	xor    %esi,%esi
   5a7a6:	call   af3b <core::panicking::panic_bounds_check>
   5a7ab:	lea    0xa7ca6(%rip),%rdx        # 102458 <__do_global_dtors_aux_fini_array_entry+0x19d8>
   5a7b2:	mov    %rax,%rdi
   5a7b5:	mov    %rcx,%rsi
   5a7b8:	call   af3b <core::panicking::panic_bounds_check>
   5a7bd:	lea    0xa7c7c(%rip),%rdx        # 102440 <__do_global_dtors_aux_fini_array_entry+0x19c0>
   5a7c4:	mov    %rcx,%rdi
   5a7c7:	mov    %r8,%rsi
   5a7ca:	call   af3b <core::panicking::panic_bounds_check>
   5a7cf:	lea    0xa7d42(%rip),%rdx        # 102518 <__do_global_dtors_aux_fini_array_entry+0x1a98>
   5a7d6:	call   af3b <core::panicking::panic_bounds_check>
   5a7db:	lea    0xa7c5e(%rip),%rdx        # 102440 <__do_global_dtors_aux_fini_array_entry+0x19c0>
   5a7e2:	mov    %rax,%rdi
   5a7e5:	mov    %r8,%rsi
   5a7e8:	call   af3b <core::panicking::panic_bounds_check>
   5a7ed:	cmp    %rcx,%r14
   5a7f0:	je     5a7fb <<c30walk::ctor2::W<false>>::finish+0x5eb>
   5a7f2:	sub    %ax,(%rdi,%rcx,2)
   5a7f6:	inc    %rcx
   5a7f9:	jmp    5a7ed <<c30walk::ctor2::W<false>>::finish+0x5dd>
   5a7fb:	add    $0x38,%rsp
   5a7ff:	pop    %rbx
   5a800:	pop    %r12
   5a802:	pop    %r13
   5a804:	pop    %r14
   5a806:	pop    %r15
   5a808:	pop    %rbp
   5a809:	ret
