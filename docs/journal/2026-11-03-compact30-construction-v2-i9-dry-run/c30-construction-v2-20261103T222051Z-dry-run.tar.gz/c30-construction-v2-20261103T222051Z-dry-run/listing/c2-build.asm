# c30walk::cbuild::c2_build
# size 0x15

/home/louis/dev/mibz2/target/c30-construction-v2-pin/target/rust-1.97.0/release/examples/c30walk:     file format elf64-x86-64


Disassembly of section .text:

000000000007efd0 <c30walk::cbuild::c2_build>:
   7efd0:	push   %rax
   7efd1:	mov    %r8,%rax
   7efd4:	mov    %r9,(%rsp)
   7efd8:	xor    %r8d,%r8d
   7efdb:	mov    %rax,%r9
   7efde:	call   19720 <<c30walk::ctor2::Ctor2>::build::<false>>
   7efe3:	pop    %rcx
   7efe4:	ret
