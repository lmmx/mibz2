
/home/louis/dev/mibz2/target/c30-construction-v2-pin/target/rust-1.97.0/release/examples/c30walk:     file format elf64-x86-64


Disassembly of section .text:

000000000007e6b0 <c30walk::cbuild::p_build>:
c30walk::cbuild::p_build:
/home/louis/dev/mibz2/target/c30-construction-v2-pin/examples/c30walk/cbuild.rs:98
   7e6b0:	jmp    99120 <mibz2::bwt::build>
