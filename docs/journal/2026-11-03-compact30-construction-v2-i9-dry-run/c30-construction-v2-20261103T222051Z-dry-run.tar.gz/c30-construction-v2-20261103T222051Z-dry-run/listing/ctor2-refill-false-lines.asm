
/home/louis/dev/mibz2/target/c30-construction-v2-pin/target/rust-1.97.0/release/examples/c30walk:     file format elf64-x86-64


Disassembly of section .text:

00000000000092e0 <<c30walk::ctor2::W<false>>::refill>:
<c30walk::ctor2::W<false>>::refill:
/home/louis/dev/mibz2/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:387
    92e0:	push   %r15
    92e2:	push   %r14
    92e4:	push   %rbx
    92e5:	mov    %rdi,%rbx
/home/louis/dev/mibz2/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:372
    92e8:	lea    (%rsi,%rsi,4),%rax
close<false>():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:372
    92ec:	lea    (%rdi,%rax,8),%r15
    92f0:	add    $0x40,%r15
    92f4:	mov    0x40(%rdi,%rax,8),%r14
/home/louis/dev/mibz2/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:373
    92f9:	sub    0x50(%rdi,%rax,8),%r14
    92fe:	je     9308 <<c30walk::ctor2::W<false>>::refill+0x28>
/home/louis/dev/mibz2/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:374
    9300:	mov    %rbx,%rdi
    9303:	call   5a210 <<c30walk::ctor2::W<false>>::finish>
<c30walk::ctor2::W<false>>::refill:
/home/louis/dev/mibz2/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:247
    9308:	shr    $1,%r14
rank():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:247
    930b:	add    0x18(%r15),%r14d
close<false>():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:377
    930f:	mov    %r14d,0x18(%r15)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:379
    9313:	xorps  %xmm0,%xmm0
    9316:	movups %xmm0,(%r15)
    931a:	movq   $0x0,0x10(%r15)
<c30walk::ctor2::W<false>>::refill:
/home/louis/dev/mibz2/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:390
    9322:	mov    0x1c(%r15),%eax
    9326:	cmp    %eax,%r14d
    9329:	jae    93b4 <<c30walk::ctor2::W<false>>::refill+0xd4>
/home/louis/dev/mibz2/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:291
    932f:	mov    %r14d,%ecx
field<false>():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:291
    9332:	mov    $0x88888889,%edi
    9337:	imul   %rcx,%rdi
    933b:	mov    %rdi,%rcx
    933e:	shr    $0x24,%rcx
    9342:	mov    %ecx,%r9d
    9345:	shl    $0x5,%r9d
    9349:	sub    %ecx,%r9d
    934c:	sub    %ecx,%r9d
<c30walk::ctor2::W<false>>::refill:
/home/louis/dev/mibz2/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:350
    934f:	lea    0x1e(%r9),%edx
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/cmp.rs:1077
    9353:	cmp    %eax,%edx
min<u32>():
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/cmp.rs:1077
    9355:	cmovae %eax,%edx
<c30walk::ctor2::W<false>>::refill:
/home/louis/dev/mibz2/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:285
    9358:	shr    $0x2a,%rdi
is_raw<false>():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:285
    935c:	mov    0x10(%rbx),%rsi
    9360:	cmp    %rsi,%rdi
    9363:	jae    93c0 <<c30walk::ctor2::W<false>>::refill+0xe0>
open<false>():
    9365:	mov    %r14d,%esi
    9368:	mov    %rcx,%r8
    936b:	shl    $0x6,%r8
    936f:	add    0x28(%rbx),%r8
    9373:	sub    %r9d,%esi
is_raw<false>():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:285
    9376:	mov    0x8(%rbx),%r9
    937a:	mov    (%r9,%rdi,8),%rdi
open<false>():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:352
    937e:	bt     %rcx,%rdi
    9382:	jae    938f <<c30walk::ctor2::W<false>>::refill+0xaf>
    9384:	mov    $0xfffff,%edi
/home/louis/dev/mibz2/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:353
    9389:	and    0x3c(%r8),%edi
    938d:	jmp    9394 <<c30walk::ctor2::W<false>>::refill+0xb4>
    938f:	mov    $0xffffffff,%edi
field<false>():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:291
    9394:	mov    %esi,%esi
<c30walk::ctor2::W<false>>::refill:
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mut_ptr.rs:961
    9396:	lea    (%r8,%rsi,2),%rsi
open<false>():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:361
    939a:	mov    %rsi,0x10(%r15)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:362
    939e:	mov    %rsi,(%r15)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:363
    93a1:	sub    %r14d,%edx
<c30walk::ctor2::W<false>>::refill:
/rustc/2d8144b7880597b6e6d3dfd63a9a9efae3f533d3/library/core/src/ptr/mut_ptr.rs:961
    93a4:	lea    (%rsi,%rdx,2),%rdx
open<false>():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:363
    93a8:	mov    %rdx,0x8(%r15)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:365
    93ac:	mov    %ecx,0x20(%r15)
/home/louis/dev/mibz2/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:366
    93b0:	mov    %edi,0x24(%r15)
<c30walk::ctor2::W<false>>::refill:
/home/louis/dev/mibz2/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:390
    93b4:	cmp    %eax,%r14d
    93b7:	setb   %al
/home/louis/dev/mibz2/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:395
    93ba:	pop    %rbx
    93bb:	pop    %r14
    93bd:	pop    %r15
    93bf:	ret
is_raw<false>():
/home/louis/dev/mibz2/target/c30-construction-v2-pin/examples/c30walk/ctor2.rs:285
    93c0:	lea    0xf78f9(%rip),%rdx        # 100cc0 <__do_global_dtors_aux_fini_array_entry+0x240>
    93c7:	call   af3b <core::panicking::panic_bounds_check>
