# The two modes' discriminator: DRY (not evidence): GAP BLOCK (primary): INSUFFICIENT: 2 timed gap and 4 timed no-gap runs, not 30 each; PROBE TABLE (secondary): INSUFFICIENT CLASS SUPPORT: 0 fast and 2 slow probed runs (a floor of 5 a class); the rows are described and no signature is assessed; sustained block: too short

Label: **DRY**. Fast: wall < 0.21 s. Diagnostic only; the row cutoffs are unvalidated descriptive thresholds.

## pass1: P-idle alone

| reading | fast | slow |
|---|--:|--:|
| n | 0 | 2 |
| wall | - | 0.457 |
| cpu | - | 1.214 |
| p_idle | - | 2.484 |
| p_idle_active | - | 2.839 |
| p_idle_coverage | - | 0.999 |
| p_idle_longest_ms | - | 10.433 |
| p_idle_early | - | 2.439 |
| p_idle_late | - | 2.493 |
| p_idle_cpu_share | - | 0.952 |
| p_sib | - | - |
| clock_ghz | - | - |
| clock_early | - | - |
| clock_late | - | - |
| sibling_running | - | 0.000 |
| sibling_last_cpu | - | 0.000 |
| running_obs | - | 1072.500 |
| core_throttle | - | - |
| package_throttle | - | - |
| core_throttle_ms | - | - |
| package_throttle_ms | - | - |
| core_power_limit | - | - |
| package_power_limit | - | - |
| thp_fault_alloc_global | - | 0.000 |
| anon_huge_kb | - | 0.000 |
| minflt | - | 21257.000 |
| utime_s | - | 1.164 |
| stime_s | - | 0.058 |
| sys_share | - | 0.048 |
| throttle_rose | - | - |
| power_limit_rose | - | - |
| thp_held | - | 0.000 |
| p_idle_rise | - | 0.978 |
| clock_rise | - | - |
| observations per row | p_idle 0, clock 0, sibling 0, throttle 0, power_limit 0, thp 0, sys_share 0 | p_idle 2, clock 0, sibling 2, throttle 0, power_limit 0, thp 2, sys_share 2 |

| row | observed | H1 | H2 | H3 | H4 | H5 |
|---|---|---|---|---|---|---|
| P-idle's elapsed-time progress in slow runs | **insufficient** | full or rising | full | half **(decisive)** | full | reduced **(decisive)** |
| the decoder CPUs' clock during slow runs (supporting) | **unread** | low, then rising **(decisive)** | full | full | full | reduced **(decisive)** |
| running decoder threads with a running sibling (a proxy) | **insufficient** | same | most **(decisive)** | same | same | same |
| throttle counts rise | **unread** | no | no | yes **(decisive)** | no | no |
| power-limit counts rise | **unread** | no | no | no | no | yes **(decisive)** |
| the child's huge pages in fast runs only | **insufficient** | no | no | no | yes **(decisive)** | no |
| system time's share grows | **insufficient** | no | no | no | yes **(decisive)** | no |

- H1 (the governor's ramp): untestable, ['clock']
- H2 (sibling packing): untestable, ['sibling']
- H3 (stop-clock throttling): untestable, ['p_idle', 'throttle']
- H4 (huge pages): untestable, ['sys_share', 'thp']
- H5 (the package power limit): untestable, ['clock', 'p_idle', 'power_limit']

Fast runs with the probe: 0 of 2; without it: 0 of 1 (a randomised schedule, seed 20261110; descriptive, with persistence widening its uncertainty).

Run order: `sss`

Fast after fast: 0 of 0 (-), against 0.000 overall.
Gap between runs (ab's exit to next spawn), median: 0.251 s.

## The gap block (first, no probe): the primary cheap discriminator

Outcome: **INSUFFICIENT: 2 timed gap and 4 timed no-gap runs, not 30 each**
- after a 0.25 s gap: 2 slow of 2; CPU per block 0.002821 s (fast -, slow 0.002821); gap median 0.2503 s
- no gap: 4 slow of 4; CPU per block 0.002860 s (fast -, slow 0.002860); gap median 0.0001 s
- order `GZGZZZ`, modes `ssssss`
- slow runs by transition: {'G->Z': [2, 2], 'Z->G': [1, 1], 'Z->Z': [2, 2]}

## The sustained block (first, no probe): input consumption

Shape: **too short**; 1 s windows (bytes/s) [], error bound -, chunk 0 bytes.
