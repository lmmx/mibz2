# The service core's admission threshold: the workstation run's report

## Validity

- the registered 20 rounds (seen: 20): **yes**
- a clean tree (`git-status.txt` present and empty): **yes**
- no `NOT-FROZEN.txt` (the frozen inputs unchanged): **yes**
- no `DRY-RUN.txt` (not a dry run): **yes**
- `commit.txt` (8a0fc8e099f932c14cd746c4c5d81aaef8dcc75d) is the checkout's head (8a0fc8e099f932c14cd746c4c5d81aaef8dcc75d): **yes**
- the ten-core topology, so `mibz2` is the pipelined default (lscpu: 1 socket, 10 cores, L3 20 MiB (1 instance)): **yes**
- every run's record usable: a hex output digest, the registered 209700196 bytes out, finite positive wall, CPU and peak RSS, the registered corpus `wikidata` (0 unusable, 0 unparsed): **yes**
- every run the same bytes as the reference `mibz2@10`'s, none failed (digests: a8830caee5c511a6): **yes**
- `corpus.sha256` the registered corpus's (82f65ace0731..., bench/wikidata.json; seen: 82f65ace0731...): **yes**
- `mibz2@10`: rounds 0-19 once each, every run 3 leaders, 6 helpers, 0 service threads (seen: 3 leaders, 6 helpers, 0 service): **yes**
- `mibz2-svc2@10`: rounds 0-19 once each, every run 2 leaders, 4 helpers, 2 service threads (seen: 2 leaders, 4 helpers, 2 service): **yes**
- `mibz2-svc2-a3@10`: rounds 0-19 once each, every run 2 leaders, 4 helpers, 2 service threads (seen: 2 leaders, 4 helpers, 2 service): **yes**
- `mibz2-svc2-a4@10`: rounds 0-19 once each, every run 2 leaders, 4 helpers, 2 service threads (seen: 2 leaders, 4 helpers, 2 service): **yes**
- `mibz2-svc2-w12@10`: rounds 0-19 once each, every run 2 leaders, 4 helpers, 2 service threads (seen: 2 leaders, 4 helpers, 2 service): **yes**
- `mibz2-svc2-a4-w12@10`: rounds 0-19 once each, every run 2 leaders, 4 helpers, 2 service threads (seen: 2 leaders, 4 helpers, 2 service): **yes**
- `mibz2-team3@10`: rounds 0-19 once each, every run 3 leaders, 6 helpers, 0 service threads (seen: 3 leaders, 6 helpers, 0 service): **yes**
- `mibz2-team3-twin@10`: rounds 0-19 once each, every run 3 leaders, 6 helpers, 0 service threads (seen: 3 leaders, 6 helpers, 0 service): **yes**
- no cell beyond the registered ones (seen: none): **yes**
- the trace `occupancy-t10-svc2-a2-w8` complete and as registered (10 threads, the service core, mibz2-svc2's plan, 2 service threads, slots 40 (a window of 8), admission teams (the service core's own), the run's commit, every scheduled child once with exit status 0, every complete round's prepared count within 1 <= median <= max <= 3 and 431 blocks, the summary the median of those rounds, parity, the registered output, every metric read finite and in range; rounds: 6): **yes**
- saturation resolved from `occupancy-t10-svc2-a2-w8` (seen: not saturated): **yes**
- the trace `occupancy-t10-svc2-a3-w8` complete and as registered (10 threads, the service core, mibz2-svc2's plan, 2 service threads, slots 40 (a window of 8), admission 3, the run's commit, every scheduled child once with exit status 0, every complete round's prepared count within 1 <= median <= max <= 4 and 431 blocks, the summary the median of those rounds, parity, the registered output, every metric read finite and in range; rounds: 6): **yes**
- saturation resolved from `occupancy-t10-svc2-a3-w8` (seen: not saturated): **yes**
- the trace `occupancy-t10-svc2-a4-w8` complete and as registered (10 threads, the service core, mibz2-svc2's plan, 2 service threads, slots 40 (a window of 8), admission 4, the run's commit, every scheduled child once with exit status 0, every complete round's prepared count within 1 <= median <= max <= 5 and 431 blocks, the summary the median of those rounds, parity, the registered output, every metric read finite and in range; rounds: 6): **yes**
- saturation resolved from `occupancy-t10-svc2-a4-w8` (seen: not saturated): **yes**
- the trace `occupancy-t10-svc2-a2-w12` complete and as registered (10 threads, the service core, mibz2-svc2's plan, 2 service threads, slots 60 (a window of 12), admission teams (the service core's own), the run's commit, every scheduled child once with exit status 0, every complete round's prepared count within 1 <= median <= max <= 3 and 431 blocks, the summary the median of those rounds, parity, the registered output, every metric read finite and in range; rounds: 6): **yes**
- saturation resolved from `occupancy-t10-svc2-a2-w12` (seen: not saturated): **yes**
- the trace `occupancy-t10-svc2-a4-w12` complete and as registered (10 threads, the service core, mibz2-svc2's plan, 2 service threads, slots 60 (a window of 12), admission 4, the run's commit, every scheduled child once with exit status 0, every complete round's prepared count within 1 <= median <= max <= 5 and 431 blocks, the summary the median of those rounds, parity, the registered output, every metric read finite and in range; rounds: 6): **yes**
- saturation resolved from `occupancy-t10-svc2-a4-w12` (seen: not saturated): **yes**
- the noise control N1, `mibz2-team3-twin@10` against `mibz2-team3@10` (the same plan): 0.994 [0.975, 1.014] over 20 rounds, within 1 ± 0.03: **yes**

Run: **VALID**

## The registered comparisons (svc2 at 2 × 3 + 2 on 10, window 8: a higher admission threshold against 2; judged; speed and CPU co-primary)

| | arm | against | threshold, window | speed [95% CI] | speed outcome | CPU [95% CI] | CPU outcome |
|---|---|---|---|---|---|---|---|
| LA3 | `mibz2-svc2-a3@10` | `mibz2-svc2@10` | a3 w8 against a2 w8 | 0.992 [0.968, 1.016] | INCONCLUSIVE (the interval spans gain and harm) | 1.006 [0.987, 1.025] | NULL |
| LA4 | `mibz2-svc2-a4@10` | `mibz2-svc2@10` | a4 w8 against a2 w8 | 0.979 [0.951, 1.008] | INCONCLUSIVE (the interval spans gain and harm) | 0.983 [0.958, 1.009] | INCONCLUSIVE (the interval spans gain and harm) |

**The reading, by the registered order:** **INCONCLUSIVE (registered step 3: LA3 0.992 [0.968, 1.016], INCONCLUSIVE (the interval spans gain and harm); CPU NULL (within ±3%: a small difference is not excluded); LA4 0.979 [0.951, 1.008], INCONCLUSIVE (the interval spans gain and harm); no CPU cost detected (CPU INCONCLUSIVE: not shown to cost nothing))**

NULL is an interval inside [0.97, 1.03]: bounded uncertainty, not an effect shown to be zero. CPU INCONCLUSIVE is no detected CPU cost, not a CPU cost shown to be absent.

**The best svc2 arm against the default (reported, never judged):** a4 w12 (`mibz2-svc2-a4-w12@10`): speed 1.102 [1.070, 1.135], GAIN; CPU 1.140 [1.112, 1.169], CPU SAVING against the default. Reported, never judged: the best of five chosen after the run, so its interval is optimistic

**The traces beside it (reported, never judged):** PREP STARVATION at a2 w8, a3 w8, a4 w8, a2 w12: reported, not read. Gaining: none. Relieved of prep starvation (starved at a2 w8): none.

## Reported, never judged

| | arm | against | decode threads | threshold, window | speed [95% CI] | speed outcome | CPU [95% CI] |
|---|---|---|---|---|---|---|---|
| W12 | `mibz2-svc2-w12@10` | `mibz2-svc2@10` | 8 against 8 | a2 w12 against a2 w8 | 1.000 [0.972, 1.029] | NULL | 0.978 [0.957, 0.999] |
| J | `mibz2-svc2-a4-w12@10` | `mibz2-svc2@10` | 8 against 8 | a4 w12 against a2 w8 | 1.027 [0.993, 1.063] | INCONCLUSIVE (the interval spans gain and harm) | 0.976 [0.952, 1.000] |
| J4 | `mibz2-svc2-a4-w12@10` | `mibz2-svc2-a4@10` | 8 against 8 | a4 w12 against a4 w8 | 1.049 [1.017, 1.082] | SMALL GAIN (above 1, not above the threshold) | 0.992 [0.971, 1.014] |
| D-a2w8 | `mibz2-svc2@10` | `mibz2@10` | 8 against 9 | a2 w8 against w12 | 1.073 [1.041, 1.106] | GAIN | 1.169 [1.135, 1.204] |
| D-a3w8 | `mibz2-svc2-a3@10` | `mibz2@10` | 8 against 9 | a3 w8 against w12 | 1.064 [1.042, 1.086] | GAIN | 1.175 [1.145, 1.207] |
| D-a4w8 | `mibz2-svc2-a4@10` | `mibz2@10` | 8 against 9 | a4 w8 against w12 | 1.050 [1.022, 1.080] | GAIN | 1.149 [1.117, 1.182] |
| D-a2w12 | `mibz2-svc2-w12@10` | `mibz2@10` | 8 against 9 | a2 w12 against w12 | 1.073 [1.052, 1.094] | GAIN | 1.143 [1.122, 1.164] |
| D-a4w12 | `mibz2-svc2-a4-w12@10` | `mibz2@10` | 8 against 9 | a4 w12 against w12 | 1.102 [1.070, 1.135] | GAIN | 1.140 [1.112, 1.169] |
| R1 | `mibz2@10` | `mibz2-team3@10` | 9 against 9 | w12 against w12 | 1.047 [1.024, 1.071] | GAIN | 0.935 [0.912, 0.959] |

(Speed: the reference's wall over the arm's, > 1 the arm is faster. CPU: the reference's CPU over the arm's, > 1 the arm spends less.)

## Every cell (medians)

| cell | decode threads (leaders + helpers + service) | threshold, window | wall s | CPU s | peak RSS MB | rounds |
|---|---|---|---|---|---|---|
| `mibz2-svc2-a3@10` | 2+4+2 | a3 w8 | 0.137 | 0.884 | 65 | 20 |
| `mibz2-svc2-a4-w12@10` | 2+4+2 | a4 w12 | 0.134 | 0.916 | 68 | 20 |
| `mibz2-svc2-a4@10` | 2+4+2 | a4 w8 | 0.138 | 0.895 | 67 | 20 |
| `mibz2-svc2-w12@10` | 2+4+2 | a2 w12 | 0.137 | 0.918 | 66 | 20 |
| `mibz2-svc2@10` | 2+4+2 | a2 w8 | 0.137 | 0.898 | 64 | 20 |
| `mibz2-team3-twin@10` | 3+6+0 | w12 | 0.153 | 0.979 | 67 | 20 |
| `mibz2-team3@10` | 3+6+0 | w12 | 0.151 | 0.971 | 67 | 20 |
| `mibz2@10` | 3+6+0 | w12 | 0.145 | 1.032 | 74 | 20 |

## The traces (occupancy, svc2 at 10 threads, one per arm; medians over complete rounds)

The prepared count P is what each preparation's push left; it can exceed the admission threshold by up to 1 (overlapping preparations), so its ceiling is threshold + services - 1, checked in every complete round. P max is the most any complete round reached; the trace's own summaries are the median of the rounds' maxima and the median of the rounds' push medians (not a pooled median, and it may be half-integral). Reaching the ceiling shows it is reachable, not that it binds often.

| trace | threshold, window | P: max over rounds / median of round maxima / median of round medians (ceiling) | complete rounds of requested | blocks | util (each; max) | prep wait median / p90 ms | finish wait median / p90 ms | job wait median ms | backlog prep / finish (mean; max) | teams idle: prep / back share | run wait ms | saturation | prep starvation | finish backlog |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| occupancy-t10-svc2-a2-w8 | a2 w8 | 3 / 3.0 / 1.0 (3) | 6 of 6 | 431 | 0.68, 0.69; max 0.69 | 0.151 / 0.571 | 0.051 / 0.359 | 0.138 | 0.79 / 0.46 (3; 4) | 0.158 / 0.018 | 81.3 | not saturated | PREP STARVATION | no finish backlog |
| occupancy-t10-svc2-a3-w8 | a3 w8 | 4 / 4.0 / 1.5 (4) | 6 of 6 | 431 | 0.66, 0.69; max 0.69 | 0.222 / 0.746 | 0.059 / 0.323 | 0.069 | 1.05 / 0.46 (4; 4) | 0.133 / 0.046 | 79.9 | not saturated | PREP STARVATION | no finish backlog |
| occupancy-t10-svc2-a4-w8 | a4 w8 | 5 / 5.0 / 1.5 (5) | 6 of 6 | 431 | 0.66, 0.67; max 0.69 | 0.242 / 0.675 | 0.052 / 0.315 | 0.051 | 1.07 / 0.43 (5; 4) | 0.138 / 0.036 | 85.3 | not saturated | PREP STARVATION | no finish backlog |
| occupancy-t10-svc2-a2-w12 | a2 w12 | 3 / 3.0 / 1.0 (3) | 6 of 6 | 431 | 0.71, 0.68; max 0.72 | 0.249 / 0.657 | 0.056 / 0.366 | 1.048 | 1.05 / 0.49 (3; 4) | 0.117 / 0.025 | 79.6 | not saturated | PREP STARVATION | no finish backlog |
| occupancy-t10-svc2-a4-w12 | a4 w12 | 5 / 5.0 / 3.0 (5) | 6 of 6 | 431 | 0.75, 0.73; max 0.75 | 0.622 / 1.012 | 0.043 / 0.299 | 0.692 | 2.42 / 0.35 (5; 3) | 0.057 / 0.053 | 83.7 | not saturated | no prep starvation | FINISH BACKLOG |
