# The Cells memory-dose experiment (#145, LOG 6879466310)

- runs: /home/louis/dev/mibz2/target/cells-dose/run-20261114T162336Z/runs.jsonl (200 records)
- grid: threads 1,4,6,8,10, 10 rounds, wikidata
- P0 (stream 0 MB): `mibz2-workers@/home/louis/dev/mibz2/target/cells-dose/target-p0/release/examples/ab`
- P8 (stream 8 MB): `mibz2-workers@/home/louis/dev/mibz2/target/cells-dose/target-p8/release/examples/ab`
- P16 (stream 16 MB): `mibz2-workers@/home/louis/dev/mibz2/target/cells-dose/target-p16/release/examples/ab`
- C16 (chase 16 MB): `mibz2-workers@/home/louis/dev/mibz2/target/cells-dose/target-c16/release/examples/ab`

## Validity: passed

a complete roster, no duplicates, every child successful, one output hash, each build at its dose

## Engagement: blocks Cells admitted and dosed a run (fewest..most)

| arm \ t | 1 | 4 | 6 | 8 | 10 |
|---|---|---|---|---|---|
| P0 | 196..196 | 196..196 | 196..196 | 196..196 | 196..196 |
| P8 | 196..196 | 196..196 | 196..196 | 196..196 | 196..196 |
| P16 | 196..196 | 196..196 | 196..196 | 196..196 | 196..196 |
| C16 | 196..196 | 196..196 | 196..196 | 196..196 | 196..196 |

## P16 (stream 16 MB) against P0 (gating)

| t | c(t) = wall(P16)/wall(P0) [95% CI] | CPU(P16)/CPU(P0) [95% CI] |
|---|---|---|
| 1 | 1.3810 [1.3185, 1.4464] | 1.3806 [1.3185, 1.4456] |
| 4 | 1.8590 [1.8248, 1.8939] | 2.1076 [2.0823, 2.1332] |
| 6 | 2.1508 [2.1297, 2.1721] | 2.4555 [2.4240, 2.4874] |
| 8 | 2.1987 [2.1651, 2.2329] | 2.5061 [2.4529, 2.5605] |
| 10 | 2.1866 [2.1504, 2.2233] | 2.3755 [2.3228, 2.4294] |

c(10)/c(1) = 1.5833 [1.5155, 1.6542]

## C16 (chase 16 MB) against P0 (reported, not gating)

| t | c(t) = wall(C16)/wall(P0) [95% CI] | CPU(C16)/CPU(P0) [95% CI] |
|---|---|---|
| 1 | 6.7449 [6.4614, 7.0409] | 6.7406 [6.4596, 7.0338] |
| 4 | 6.2461 [6.1431, 6.3509] | 7.4711 [7.4028, 7.5400] |
| 6 | 5.1839 [5.1258, 5.2427] | 6.0388 [5.9915, 6.0865] |
| 8 | 4.0827 [4.0201, 4.1464] | 4.6979 [4.6327, 4.7640] |
| 10 | 3.5745 [3.4909, 3.6600] | 3.8616 [3.8065, 3.9175] |

c(10)/c(1) = 0.5299 [0.5081, 0.5528]
the rule on it (reported, not gating): INCONCLUSIVE

## P8 (stream 8 MB) against P0 (reported, not gating)

| t | c(t) = wall(P8)/wall(P0) [95% CI] | CPU(P8)/CPU(P0) [95% CI] |
|---|---|---|
| 1 | 1.1628 [1.0954, 1.2344] | 1.1630 [1.0960, 1.2341] |
| 4 | 1.4158 [1.3945, 1.4374] | 1.4993 [1.4786, 1.5202] |
| 6 | 1.5695 [1.5543, 1.5848] | 1.6806 [1.6559, 1.7056] |
| 8 | 1.5725 [1.5466, 1.5988] | 1.7270 [1.6904, 1.7643] |
| 10 | 1.5816 [1.5483, 1.6156] | 1.6668 [1.6230, 1.7119] |

c(10)/c(1) = 1.3601 [1.2779, 1.4476]
the rule on it (reported, not gating): LEVER

dose response monotone (c(10)/c(1) at P=8 between 1 and P=16's): yes

## Verdict

VERDICT: LEVER: c(10)/c(1) at P=16 = 1.5833 [1.5155, 1.6542]
