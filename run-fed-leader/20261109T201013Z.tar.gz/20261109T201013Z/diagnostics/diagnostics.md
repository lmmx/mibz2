# The run-fed leader's workstation diagnostics (descriptive, never judged)

descriptive only: no pair is excluded, replaced or reweighted by anything here, and `admit`'s reading reads none of it (§R10).

Status: complete. Diagnostic objective: met (the diagnostics' completeness is descriptive: a VALID timing reading stands as the full-data result whatever it is, and an incomplete record marks the clock-diagnostic objective unmet, never the timing).

Endpoint label: post-exit snapshot: H if at least 10 of 20 CPUs read scaling_cur_freq >= 3700 MHz, L if every CPU was read and fewer did, else unknown; a pair's state is the incumbent's label then the arm's. An endpoint label, not the clock during the decode.

## Pair states, counts only

| arm | HH | HL | LH | LL | unknown |
|---|---|---|---|---|---|
| `mibz2-pipe3-both` | 11 | 6 | 2 | 1 | 0 |
| `mibz2-pipe3-runfed-ctl` | 15 | 2 | 2 | 1 | 0 |
| `mibz2-pipe3-runfed-reg` | 14 | 3 | 3 | 0 | 0 |
| `mibz2-pipe3-runfed-ls` | 16 | 1 | 3 | 0 | 0 |
| `mibz2-pipe3-runfed-hs` | 14 | 3 | 3 | 0 | 0 |
| `mibz2-pipe3-runfed-dir` | 17 | 0 | 3 | 0 | 0 |
| all | 87 | 15 | 16 | 2 | 0 |

## Post-exit endpoint labels, counts only

each record's post-exit endpoint label, counted (H, L or unknown): a snapshot of the 20 logical CPUs after the child exits (idle CPUs and siblings included), its raw readings, delay and read time beside it per record; no active-core or within-decode clock is inferred from it.

| arm | H | L | unknown |
|---|---|---|---|
| `mibz2-default33` | 17 | 3 | 0 |
| `mibz2-pipe3-both` | 13 | 7 | 0 |
| `mibz2-pipe3-runfed-ctl` | 17 | 3 | 0 |
| `mibz2-pipe3-runfed-reg` | 17 | 3 | 0 |
| `mibz2-pipe3-runfed-ls` | 19 | 1 | 0 |
| `mibz2-pipe3-runfed-hs` | 17 | 3 | 0 |
| `mibz2-pipe3-runfed-dir` | 20 | 0 | 0 |

## Lag-1 autocorrelation of each arm's ordered log ratios (descriptive)

descriptive lag-1 autocorrelation of each arm's ordered log ratios over the incumbent, in round order: sum_{r=1..n-1} (x_r - m)(x_{r-1} - m) / sum_{r=0..n-1} (x_r - m)^2, m the mean; undefined (null) for a constant series or any missing pair, never zero. No p-value, interval, effective sample size or rule follows from it; at n = 20 it is noisy, and the shared incumbent and the rotation can induce structure.

| arm | wall | CPU |
|---|---|---|
| `mibz2-pipe3-both` | -0.315 | -0.294 |
| `mibz2-pipe3-runfed-ctl` | +0.014 | +0.013 |
| `mibz2-pipe3-runfed-reg` | +0.075 | +0.080 |
| `mibz2-pipe3-runfed-ls` | -0.149 | -0.167 |
| `mibz2-pipe3-runfed-hs` | +0.052 | +0.039 |
| `mibz2-pipe3-runfed-dir` | +0.079 | +0.136 |

## Every record, in run order

| seq | round | pos | arm | predecessor | gap s | wall | cpu | MHz pre | MHz post | °C pre | °C post | label | post delay s | post read s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | 0 | 0 | `mibz2-default33` | - | - | 0.1300 | 0.9882 | 830 | 3671 | 34 | 41 | H | 0.0001 | 0.0024 |
| 1 | 0 | 1 | `mibz2-pipe3-both` | mibz2-default33 | 0.261 | 0.1569 | 1.0685 | 800 | 2010 | 34 | 40 | L | 0.0001 | 0.0023 |
| 2 | 0 | 2 | `mibz2-pipe3-runfed-ctl` | mibz2-pipe3-both | 0.260 | 0.1574 | 1.0754 | 1026 | 3671 | 34 | 43 | H | 0.0001 | 0.0022 |
| 3 | 0 | 3 | `mibz2-pipe3-runfed-reg` | mibz2-pipe3-runfed-ctl | 0.260 | 0.2967 | 2.1158 | 802 | 4336 | 34 | 40 | H | 0.0001 | 0.0025 |
| 4 | 0 | 4 | `mibz2-pipe3-runfed-ls` | mibz2-pipe3-runfed-reg | 0.261 | 0.3038 | 2.1646 | 821 | 3670 | 34 | 39 | H | 0.0001 | 0.0024 |
| 5 | 0 | 5 | `mibz2-pipe3-runfed-hs` | mibz2-pipe3-runfed-ls | 0.260 | 0.3353 | 2.4366 | 1107 | 3320 | 34 | 36 | H | 0.0001 | 0.0024 |
| 6 | 0 | 6 | `mibz2-pipe3-runfed-dir` | mibz2-pipe3-runfed-hs | 0.260 | 0.2895 | 2.1001 | 871 | 3465 | 34 | 39 | H | 0.0001 | 0.0024 |
| 7 | 1 | 0 | `mibz2-pipe3-both` | mibz2-pipe3-runfed-dir | 0.256 | 0.2724 | 2.1132 | 930 | 4082 | 34 | 39 | H | 0.0001 | 0.0024 |
| 8 | 1 | 1 | `mibz2-pipe3-runfed-ctl` | mibz2-pipe3-both | 0.261 | 0.2901 | 2.1150 | 800 | 3670 | 34 | 38 | H | 0.0001 | 0.0022 |
| 9 | 1 | 2 | `mibz2-pipe3-runfed-reg` | mibz2-pipe3-runfed-ctl | 0.260 | 0.3103 | 2.3499 | 904 | 3671 | 34 | 40 | H | 0.0001 | 0.0023 |
| 10 | 1 | 3 | `mibz2-pipe3-runfed-ls` | mibz2-pipe3-runfed-reg | 0.260 | 0.3258 | 2.3107 | 800 | 3871 | 35 | 38 | H | 0.0001 | 0.0023 |
| 11 | 1 | 4 | `mibz2-pipe3-runfed-hs` | mibz2-pipe3-runfed-ls | 0.260 | 0.3349 | 2.3989 | 800 | 3320 | 35 | 37 | H | 0.0001 | 0.0023 |
| 12 | 1 | 5 | `mibz2-pipe3-runfed-dir` | mibz2-pipe3-runfed-hs | 0.260 | 0.2729 | 1.9989 | 800 | 4042 | 34 | 39 | H | 0.0001 | 0.0023 |
| 13 | 1 | 6 | `mibz2-default33` | mibz2-pipe3-runfed-dir | 0.260 | 0.2916 | 2.1351 | 867 | 3668 | 34 | 38 | H | 0.0001 | 0.0023 |
| 14 | 2 | 0 | `mibz2-pipe3-runfed-ctl` | mibz2-default33 | 0.260 | 0.3082 | 2.2467 | 800 | 3702 | 34 | 39 | H | 0.0001 | 0.0023 |
| 15 | 2 | 1 | `mibz2-pipe3-runfed-reg` | mibz2-pipe3-runfed-ctl | 0.260 | 0.2975 | 2.1867 | 889 | 3946 | 34 | 41 | H | 0.0001 | 0.0024 |
| 16 | 2 | 2 | `mibz2-pipe3-runfed-ls` | mibz2-pipe3-runfed-reg | 0.260 | 0.3217 | 2.2922 | 972 | 3862 | 34 | 39 | H | 0.0001 | 0.0024 |
| 17 | 2 | 3 | `mibz2-pipe3-runfed-hs` | mibz2-pipe3-runfed-ls | 0.260 | 0.1830 | 1.2575 | 800 | 3230 | 34 | 36 | H | 0.0001 | 0.0024 |
| 18 | 2 | 4 | `mibz2-pipe3-runfed-dir` | mibz2-pipe3-runfed-hs | 0.260 | 0.3259 | 2.4288 | 871 | 3466 | 34 | 37 | H | 0.0001 | 0.0024 |
| 19 | 2 | 5 | `mibz2-default33` | mibz2-pipe3-runfed-dir | 0.260 | 0.2987 | 2.2103 | 800 | 3466 | 34 | 39 | H | 0.0001 | 0.0024 |
| 20 | 2 | 6 | `mibz2-pipe3-both` | mibz2-default33 | 0.260 | 0.3017 | 2.2012 | 800 | 3465 | 34 | 39 | H | 0.0001 | 0.0025 |
| 21 | 3 | 0 | `mibz2-pipe3-runfed-reg` | mibz2-pipe3-both | 0.260 | 0.1601 | 1.0918 | 800 | 3670 | 34 | 41 | H | 0.0001 | 0.0023 |
| 22 | 3 | 1 | `mibz2-pipe3-runfed-ls` | mibz2-pipe3-runfed-reg | 0.260 | 0.1498 | 1.0038 | 800 | 3876 | 34 | 41 | H | 0.0001 | 0.0022 |
| 23 | 3 | 2 | `mibz2-pipe3-runfed-hs` | mibz2-pipe3-runfed-ls | 0.260 | 0.1683 | 1.1104 | 800 | 2557 | 35 | 41 | L | 0.0001 | 0.0023 |
| 24 | 3 | 3 | `mibz2-pipe3-runfed-dir` | mibz2-pipe3-runfed-hs | 0.260 | 0.3101 | 2.3125 | 868 | 3673 | 35 | 39 | H | 0.0001 | 0.0023 |
| 25 | 3 | 4 | `mibz2-default33` | mibz2-pipe3-runfed-dir | 0.260 | 0.2940 | 2.1314 | 800 | 3671 | 34 | 41 | H | 0.0001 | 0.0024 |
| 26 | 3 | 5 | `mibz2-pipe3-both` | mibz2-default33 | 0.260 | 0.1548 | 1.0728 | 916 | 1818 | 34 | 42 | L | 0.0001 | 0.0020 |
| 27 | 3 | 6 | `mibz2-pipe3-runfed-ctl` | mibz2-pipe3-both | 0.259 | 0.2953 | 2.1704 | 800 | 3915 | 35 | 39 | H | 0.0001 | 0.0023 |
| 28 | 4 | 0 | `mibz2-pipe3-runfed-ls` | mibz2-pipe3-runfed-ctl | 0.260 | 0.3009 | 2.1512 | 800 | 3720 | 34 | 38 | H | 0.0001 | 0.0023 |
| 29 | 4 | 1 | `mibz2-pipe3-runfed-hs` | mibz2-pipe3-runfed-ls | 0.260 | 0.4022 | 2.9504 | 800 | 3041 | 34 | 37 | H | 0.0001 | 0.0024 |
| 30 | 4 | 2 | `mibz2-pipe3-runfed-dir` | mibz2-pipe3-runfed-hs | 0.260 | 0.1727 | 1.1631 | 845 | 3425 | 35 | 38 | H | 0.0001 | 0.0023 |
| 31 | 4 | 3 | `mibz2-default33` | mibz2-pipe3-runfed-dir | 0.260 | 0.2528 | 1.8666 | 1124 | 3870 | 34 | 41 | H | 0.0001 | 0.0024 |
| 32 | 4 | 4 | `mibz2-pipe3-both` | mibz2-default33 | 0.260 | 0.3062 | 2.2198 | 1034 | 4166 | 34 | 40 | H | 0.0001 | 0.0024 |
| 33 | 4 | 5 | `mibz2-pipe3-runfed-ctl` | mibz2-pipe3-both | 0.260 | 0.2874 | 2.0714 | 805 | 3466 | 34 | 39 | H | 0.0001 | 0.0023 |
| 34 | 4 | 6 | `mibz2-pipe3-runfed-reg` | mibz2-pipe3-runfed-ctl | 0.260 | 0.3676 | 2.7320 | 800 | 3671 | 35 | 39 | H | 0.0001 | 0.0023 |
| 35 | 5 | 0 | `mibz2-pipe3-runfed-hs` | mibz2-pipe3-runfed-reg | 0.260 | 0.3917 | 2.8863 | 800 | 3808 | 34 | 44 | H | 0.0001 | 0.0022 |
| 36 | 5 | 1 | `mibz2-pipe3-runfed-dir` | mibz2-pipe3-runfed-hs | 0.260 | 0.3142 | 2.2218 | 800 | 4064 | 34 | 39 | H | 0.0001 | 0.0023 |
| 37 | 5 | 2 | `mibz2-default33` | mibz2-pipe3-runfed-dir | 0.260 | 0.3076 | 2.3022 | 854 | 3822 | 34 | 39 | H | 0.0001 | 0.0023 |
| 38 | 5 | 3 | `mibz2-pipe3-both` | mibz2-default33 | 0.260 | 0.3008 | 2.1979 | 879 | 2510 | 34 | 40 | L | 0.0001 | 0.0023 |
| 39 | 5 | 4 | `mibz2-pipe3-runfed-ctl` | mibz2-pipe3-both | 0.260 | 0.2865 | 2.1124 | 800 | 3286 | 34 | 39 | L | 0.0001 | 0.0022 |
| 40 | 5 | 5 | `mibz2-pipe3-runfed-reg` | mibz2-pipe3-runfed-ctl | 0.260 | 0.3245 | 2.3853 | 955 | 2840 | 34 | 35 | L | 0.0001 | 0.0025 |
| 41 | 5 | 6 | `mibz2-pipe3-runfed-ls` | mibz2-pipe3-runfed-reg | 0.261 | 0.2877 | 2.0515 | 916 | 3870 | 34 | 41 | H | 0.0001 | 0.0024 |
| 42 | 6 | 0 | `mibz2-pipe3-runfed-dir` | mibz2-pipe3-runfed-ls | 0.260 | 0.2966 | 2.0991 | 800 | 3671 | 34 | 40 | H | 0.0001 | 0.0023 |
| 43 | 6 | 1 | `mibz2-default33` | mibz2-pipe3-runfed-dir | 0.260 | 0.3400 | 2.5039 | 812 | 3671 | 35 | 40 | H | 0.0001 | 0.0025 |
| 44 | 6 | 2 | `mibz2-pipe3-both` | mibz2-default33 | 0.260 | 0.2824 | 2.0881 | 800 | 3670 | 34 | 41 | H | 0.0001 | 0.0025 |
| 45 | 6 | 3 | `mibz2-pipe3-runfed-ctl` | mibz2-pipe3-both | 0.260 | 0.2900 | 2.1781 | 1017 | 3731 | 34 | 39 | H | 0.0001 | 0.0024 |
| 46 | 6 | 4 | `mibz2-pipe3-runfed-reg` | mibz2-pipe3-runfed-ctl | 0.261 | 0.1634 | 1.1091 | 800 | 3876 | 34 | 41 | H | 0.0001 | 0.0022 |
| 47 | 6 | 5 | `mibz2-pipe3-runfed-ls` | mibz2-pipe3-runfed-reg | 0.260 | 0.2860 | 2.0142 | 800 | 3875 | 35 | 39 | H | 0.0001 | 0.0022 |
| 48 | 6 | 6 | `mibz2-pipe3-runfed-hs` | mibz2-pipe3-runfed-ls | 0.260 | 0.1702 | 1.1332 | 912 | 3463 | 34 | 41 | H | 0.0001 | 0.0022 |
| 49 | 7 | 0 | `mibz2-pipe3-runfed-dir` | mibz2-pipe3-runfed-hs | 0.260 | 0.2527 | 1.7309 | 803 | 3670 | 34 | 40 | H | 0.0001 | 0.0024 |
| 50 | 7 | 1 | `mibz2-pipe3-runfed-hs` | mibz2-pipe3-runfed-dir | 0.264 | 0.1636 | 1.0806 | 845 | 3466 | 35 | 41 | H | 0.0001 | 0.0025 |
| 51 | 7 | 2 | `mibz2-pipe3-runfed-ls` | mibz2-pipe3-runfed-hs | 0.260 | 0.3013 | 2.1865 | 800 | 3672 | 35 | 40 | H | 0.0001 | 0.0025 |
| 52 | 7 | 3 | `mibz2-pipe3-runfed-reg` | mibz2-pipe3-runfed-ls | 0.261 | 0.3024 | 2.2595 | 800 | 3744 | 34 | 39 | H | 0.0001 | 0.0024 |
| 53 | 7 | 4 | `mibz2-pipe3-runfed-ctl` | mibz2-pipe3-runfed-reg | 0.261 | 0.3086 | 2.3442 | 800 | 3466 | 35 | 39 | H | 0.0001 | 0.0025 |
| 54 | 7 | 5 | `mibz2-pipe3-both` | mibz2-pipe3-runfed-ctl | 0.260 | 0.3550 | 2.6749 | 800 | 3309 | 34 | 40 | L | 0.0001 | 0.0025 |
| 55 | 7 | 6 | `mibz2-default33` | mibz2-pipe3-both | 0.260 | 0.3165 | 2.3541 | 800 | 3682 | 34 | 41 | H | 0.0001 | 0.0024 |
| 56 | 8 | 0 | `mibz2-default33` | mibz2-default33 | 0.260 | 0.2886 | 2.0803 | 861 | 3465 | 34 | 39 | H | 0.0001 | 0.0024 |
| 57 | 8 | 1 | `mibz2-pipe3-runfed-dir` | mibz2-default33 | 0.260 | 0.2871 | 2.1458 | 800 | 3876 | 34 | 40 | H | 0.0001 | 0.0024 |
| 58 | 8 | 2 | `mibz2-pipe3-runfed-hs` | mibz2-pipe3-runfed-dir | 0.260 | 0.2832 | 1.9761 | 854 | 3678 | 34 | 39 | H | 0.0001 | 0.0024 |
| 59 | 8 | 3 | `mibz2-pipe3-runfed-ls` | mibz2-pipe3-runfed-hs | 0.260 | 0.2699 | 1.9052 | 1069 | 3875 | 34 | 38 | H | 0.0001 | 0.0024 |
| 60 | 8 | 4 | `mibz2-pipe3-runfed-reg` | mibz2-pipe3-runfed-ls | 0.260 | 0.1666 | 1.1342 | 800 | 1834 | 35 | 42 | L | 0.0001 | 0.0022 |
| 61 | 8 | 5 | `mibz2-pipe3-runfed-ctl` | mibz2-pipe3-runfed-reg | 0.260 | 0.1694 | 1.1530 | 800 | 3670 | 35 | 41 | H | 0.0001 | 0.0023 |
| 62 | 8 | 6 | `mibz2-pipe3-both` | mibz2-pipe3-runfed-ctl | 0.260 | 0.1439 | 1.0446 | 800 | 3468 | 35 | 44 | H | 0.0001 | 0.0022 |
| 63 | 9 | 0 | `mibz2-pipe3-both` | mibz2-pipe3-both | 0.260 | 0.3035 | 2.2509 | 836 | 3875 | 35 | 40 | H | 0.0001 | 0.0023 |
| 64 | 9 | 1 | `mibz2-default33` | mibz2-pipe3-both | 0.260 | 0.3001 | 2.2102 | 897 | 3844 | 35 | 43 | H | 0.0001 | 0.0022 |
| 65 | 9 | 2 | `mibz2-pipe3-runfed-dir` | mibz2-default33 | 0.260 | 0.3403 | 2.5669 | 1000 | 3889 | 34 | 40 | H | 0.0001 | 0.0022 |
| 66 | 9 | 3 | `mibz2-pipe3-runfed-hs` | mibz2-pipe3-runfed-dir | 0.260 | 0.1675 | 1.0942 | 953 | 3671 | 35 | 41 | H | 0.0001 | 0.0023 |
| 67 | 9 | 4 | `mibz2-pipe3-runfed-ls` | mibz2-pipe3-runfed-hs | 0.257 | 0.1506 | 1.0619 | 1042 | 4080 | 35 | 41 | H | 0.0001 | 0.0022 |
| 68 | 9 | 5 | `mibz2-pipe3-runfed-reg` | mibz2-pipe3-runfed-ls | 0.260 | 0.1415 | 1.0349 | 944 | 3466 | 35 | 41 | H | 0.0001 | 0.0024 |
| 69 | 9 | 6 | `mibz2-pipe3-runfed-ctl` | mibz2-pipe3-runfed-reg | 0.260 | 0.2738 | 1.9912 | 888 | 2645 | 35 | 40 | L | 0.0001 | 0.0023 |
| 70 | 10 | 0 | `mibz2-pipe3-runfed-ctl` | mibz2-pipe3-runfed-ctl | 0.260 | 0.1861 | 1.2660 | 800 | 3709 | 35 | 40 | H | 0.0001 | 0.0022 |
| 71 | 10 | 1 | `mibz2-pipe3-both` | mibz2-pipe3-runfed-ctl | 0.260 | 0.1505 | 1.0596 | 870 | 2397 | 35 | 41 | L | 0.0001 | 0.0023 |
| 72 | 10 | 2 | `mibz2-default33` | mibz2-pipe3-both | 0.260 | 0.1596 | 1.0804 | 915 | 3876 | 35 | 42 | H | 0.0001 | 0.0023 |
| 73 | 10 | 3 | `mibz2-pipe3-runfed-dir` | mibz2-default33 | 0.260 | 0.3237 | 2.4484 | 898 | 3672 | 35 | 40 | H | 0.0001 | 0.0022 |
| 74 | 10 | 4 | `mibz2-pipe3-runfed-hs` | mibz2-pipe3-runfed-dir | 0.260 | 0.3420 | 2.5336 | 822 | 3671 | 35 | 38 | H | 0.0001 | 0.0023 |
| 75 | 10 | 5 | `mibz2-pipe3-runfed-ls` | mibz2-pipe3-runfed-hs | 0.260 | 0.3060 | 2.2463 | 818 | 3670 | 34 | 40 | H | 0.0001 | 0.0023 |
| 76 | 10 | 6 | `mibz2-pipe3-runfed-reg` | mibz2-pipe3-runfed-ls | 0.260 | 0.3247 | 2.4525 | 800 | 3670 | 34 | 42 | H | 0.0001 | 0.0025 |
| 77 | 11 | 0 | `mibz2-pipe3-runfed-reg` | mibz2-pipe3-runfed-reg | 0.261 | 0.3490 | 2.6217 | 800 | 3676 | 34 | 39 | H | 0.0001 | 0.0024 |
| 78 | 11 | 1 | `mibz2-pipe3-runfed-ctl` | mibz2-pipe3-runfed-reg | 0.260 | 0.2849 | 2.0705 | 871 | 4435 | 34 | 40 | H | 0.0001 | 0.0024 |
| 79 | 11 | 2 | `mibz2-pipe3-both` | mibz2-pipe3-runfed-ctl | 0.260 | 0.3250 | 2.4846 | 969 | 3876 | 34 | 39 | H | 0.0001 | 0.0025 |
| 80 | 11 | 3 | `mibz2-default33` | mibz2-pipe3-both | 0.260 | 0.3074 | 2.2724 | 800 | 4083 | 35 | 38 | H | 0.0001 | 0.0024 |
| 81 | 11 | 4 | `mibz2-pipe3-runfed-dir` | mibz2-default33 | 0.261 | 0.3478 | 2.6212 | 898 | 4024 | 34 | 40 | H | 0.0001 | 0.0024 |
| 82 | 11 | 5 | `mibz2-pipe3-runfed-hs` | mibz2-pipe3-runfed-dir | 0.260 | 0.3506 | 2.5459 | 800 | 4081 | 35 | 40 | H | 0.0001 | 0.0022 |
| 83 | 11 | 6 | `mibz2-pipe3-runfed-ls` | mibz2-pipe3-runfed-hs | 0.260 | 0.3029 | 2.1892 | 863 | 3875 | 34 | 40 | H | 0.0001 | 0.0023 |
| 84 | 12 | 0 | `mibz2-pipe3-runfed-ls` | mibz2-pipe3-runfed-ls | 0.260 | 0.3056 | 2.1660 | 800 | 3466 | 35 | 40 | H | 0.0001 | 0.0022 |
| 85 | 12 | 1 | `mibz2-pipe3-runfed-reg` | mibz2-pipe3-runfed-ls | 0.260 | 0.2984 | 2.1678 | 821 | 2719 | 35 | 40 | L | 0.0001 | 0.0022 |
| 86 | 12 | 2 | `mibz2-pipe3-runfed-ctl` | mibz2-pipe3-runfed-reg | 0.260 | 0.3147 | 2.3369 | 932 | 3466 | 34 | 39 | H | 0.0001 | 0.0023 |
| 87 | 12 | 3 | `mibz2-pipe3-both` | mibz2-pipe3-runfed-ctl | 0.260 | 0.3165 | 2.3843 | 853 | 3670 | 35 | 39 | H | 0.0001 | 0.0023 |
| 88 | 12 | 4 | `mibz2-default33` | mibz2-pipe3-both | 0.260 | 0.3190 | 2.4067 | 808 | 3671 | 34 | 39 | H | 0.0001 | 0.0023 |
| 89 | 12 | 5 | `mibz2-pipe3-runfed-dir` | mibz2-default33 | 0.260 | 0.3512 | 2.6271 | 812 | 3170 | 34 | 40 | H | 0.0001 | 0.0023 |
| 90 | 12 | 6 | `mibz2-pipe3-runfed-hs` | mibz2-pipe3-runfed-dir | 0.260 | 0.3172 | 2.2728 | 800 | 3670 | 34 | 39 | H | 0.0001 | 0.0024 |
| 91 | 13 | 0 | `mibz2-pipe3-runfed-hs` | mibz2-pipe3-runfed-hs | 0.260 | 0.3394 | 2.4423 | 800 | 3671 | 35 | 40 | H | 0.0001 | 0.0023 |
| 92 | 13 | 1 | `mibz2-pipe3-runfed-ls` | mibz2-pipe3-runfed-hs | 0.260 | 0.2829 | 2.0109 | 805 | 3466 | 34 | 40 | H | 0.0001 | 0.0023 |
| 93 | 13 | 2 | `mibz2-pipe3-runfed-reg` | mibz2-pipe3-runfed-ls | 0.260 | 0.1701 | 1.1948 | 800 | 3040 | 35 | 37 | H | 0.0001 | 0.0024 |
| 94 | 13 | 3 | `mibz2-pipe3-runfed-ctl` | mibz2-pipe3-runfed-reg | 0.260 | 0.2949 | 2.2018 | 810 | 3205 | 35 | 39 | L | 0.0001 | 0.0023 |
| 95 | 13 | 4 | `mibz2-pipe3-both` | mibz2-pipe3-runfed-ctl | 0.260 | 0.3356 | 2.5125 | 856 | 3876 | 35 | 40 | H | 0.0001 | 0.0023 |
| 96 | 13 | 5 | `mibz2-default33` | mibz2-pipe3-both | 0.260 | 0.3203 | 2.3911 | 926 | 2931 | 34 | 40 | L | 0.0001 | 0.0022 |
| 97 | 13 | 6 | `mibz2-pipe3-runfed-dir` | mibz2-default33 | 0.260 | 0.3204 | 2.3686 | 964 | 3876 | 35 | 40 | H | 0.0001 | 0.0024 |
| 98 | 14 | 0 | `mibz2-default33` | mibz2-pipe3-runfed-dir | 0.260 | 0.3424 | 2.5304 | 800 | 3670 | 34 | 39 | H | 0.0001 | 0.0024 |
| 99 | 14 | 1 | `mibz2-pipe3-both` | mibz2-default33 | 0.260 | 0.2014 | 1.4078 | 1034 | 1955 | 34 | 40 | L | 0.0001 | 0.0024 |
| 100 | 14 | 2 | `mibz2-pipe3-runfed-ctl` | mibz2-pipe3-both | 0.260 | 0.1566 | 1.0787 | 800 | 3671 | 35 | 42 | H | 0.0001 | 0.0024 |
| 101 | 14 | 3 | `mibz2-pipe3-runfed-reg` | mibz2-pipe3-runfed-ctl | 0.256 | 0.1403 | 1.0281 | 1149 | 3671 | 35 | 42 | H | 0.0001 | 0.0025 |
| 102 | 14 | 4 | `mibz2-pipe3-runfed-ls` | mibz2-pipe3-runfed-reg | 0.260 | 0.2727 | 1.9349 | 881 | 3483 | 35 | 41 | H | 0.0001 | 0.0025 |
| 103 | 14 | 5 | `mibz2-pipe3-runfed-hs` | mibz2-pipe3-runfed-ls | 0.260 | 0.3030 | 2.1245 | 817 | 3670 | 35 | 40 | H | 0.0001 | 0.0024 |
| 104 | 14 | 6 | `mibz2-pipe3-runfed-dir` | mibz2-pipe3-runfed-hs | 0.261 | 0.3427 | 2.5900 | 800 | 3823 | 35 | 39 | H | 0.0001 | 0.0024 |
| 105 | 15 | 0 | `mibz2-pipe3-both` | mibz2-pipe3-runfed-dir | 0.260 | 0.3159 | 2.3751 | 833 | 3465 | 34 | 40 | H | 0.0001 | 0.0023 |
| 106 | 15 | 1 | `mibz2-pipe3-runfed-ctl` | mibz2-pipe3-both | 0.260 | 0.3691 | 2.7829 | 800 | 3607 | 34 | 39 | H | 0.0001 | 0.0023 |
| 107 | 15 | 2 | `mibz2-pipe3-runfed-reg` | mibz2-pipe3-runfed-ctl | 0.260 | 0.2848 | 2.0702 | 800 | 3678 | 35 | 40 | H | 0.0001 | 0.0023 |
| 108 | 15 | 3 | `mibz2-pipe3-runfed-ls` | mibz2-pipe3-runfed-reg | 0.260 | 0.2879 | 2.0805 | 889 | 2716 | 35 | 41 | L | 0.0001 | 0.0022 |
| 109 | 15 | 4 | `mibz2-pipe3-runfed-hs` | mibz2-pipe3-runfed-ls | 0.260 | 0.3663 | 2.6692 | 800 | 2481 | 35 | 36 | L | 0.0001 | 0.0026 |
| 110 | 15 | 5 | `mibz2-pipe3-runfed-dir` | mibz2-pipe3-runfed-hs | 0.261 | 0.2939 | 2.1065 | 832 | 3160 | 34 | 40 | H | 0.0001 | 0.0023 |
| 111 | 15 | 6 | `mibz2-default33` | mibz2-pipe3-runfed-dir | 0.260 | 0.3075 | 2.2921 | 800 | 3466 | 34 | 41 | H | 0.0001 | 0.0024 |
| 112 | 16 | 0 | `mibz2-pipe3-runfed-ctl` | mibz2-default33 | 0.260 | 0.2907 | 2.1767 | 870 | 3875 | 34 | 40 | H | 0.0001 | 0.0023 |
| 113 | 16 | 1 | `mibz2-pipe3-runfed-reg` | mibz2-pipe3-runfed-ctl | 0.260 | 0.2926 | 2.1136 | 839 | 3802 | 35 | 39 | H | 0.0001 | 0.0022 |
| 114 | 16 | 2 | `mibz2-pipe3-runfed-ls` | mibz2-pipe3-runfed-reg | 0.260 | 0.2868 | 2.0582 | 800 | 4080 | 35 | 38 | H | 0.0001 | 0.0022 |
| 115 | 16 | 3 | `mibz2-pipe3-runfed-hs` | mibz2-pipe3-runfed-ls | 0.260 | 0.3841 | 2.8179 | 800 | 3671 | 35 | 51 | H | 0.0001 | 0.0020 |
| 116 | 16 | 4 | `mibz2-pipe3-runfed-dir` | mibz2-pipe3-runfed-hs | 0.260 | 0.2840 | 2.0479 | 800 | 3586 | 34 | 40 | H | 0.0001 | 0.0024 |
| 117 | 16 | 5 | `mibz2-default33` | mibz2-pipe3-runfed-dir | 0.261 | 0.2834 | 2.0919 | 974 | 2367 | 34 | 41 | L | 0.0001 | 0.0023 |
| 118 | 16 | 6 | `mibz2-pipe3-both` | mibz2-default33 | 0.260 | 0.3255 | 2.4537 | 800 | 3529 | 34 | 40 | L | 0.0001 | 0.0025 |
| 119 | 17 | 0 | `mibz2-pipe3-runfed-reg` | mibz2-pipe3-both | 0.261 | 0.3021 | 2.2715 | 800 | 3874 | 35 | 40 | H | 0.0001 | 0.0020 |
| 120 | 17 | 1 | `mibz2-pipe3-runfed-ls` | mibz2-pipe3-runfed-reg | 0.260 | 0.2715 | 1.9413 | 800 | 3876 | 35 | 40 | H | 0.0001 | 0.0024 |
| 121 | 17 | 2 | `mibz2-pipe3-runfed-hs` | mibz2-pipe3-runfed-ls | 0.261 | 0.3224 | 2.3015 | 800 | 3909 | 34 | 42 | H | 0.0001 | 0.0023 |
| 122 | 17 | 3 | `mibz2-pipe3-runfed-dir` | mibz2-pipe3-runfed-hs | 0.260 | 0.3097 | 2.2935 | 877 | 3670 | 34 | 40 | H | 0.0001 | 0.0024 |
| 123 | 17 | 4 | `mibz2-default33` | mibz2-pipe3-runfed-dir | 0.260 | 0.3133 | 2.3144 | 800 | 3671 | 34 | 40 | H | 0.0001 | 0.0025 |
| 124 | 17 | 5 | `mibz2-pipe3-both` | mibz2-default33 | 0.260 | 0.3350 | 2.4695 | 957 | 3876 | 34 | 39 | H | 0.0001 | 0.0024 |
| 125 | 17 | 6 | `mibz2-pipe3-runfed-ctl` | mibz2-pipe3-both | 0.260 | 0.2900 | 2.1854 | 1096 | 2992 | 34 | 40 | H | 0.0001 | 0.0022 |
| 126 | 18 | 0 | `mibz2-pipe3-runfed-ls` | mibz2-pipe3-runfed-ctl | 0.260 | 0.2988 | 2.1535 | 882 | 3671 | 35 | 39 | H | 0.0001 | 0.0024 |
| 127 | 18 | 1 | `mibz2-pipe3-runfed-hs` | mibz2-pipe3-runfed-ls | 0.260 | 0.1542 | 1.0341 | 800 | 3132 | 34 | 42 | L | 0.0001 | 0.0023 |
| 128 | 18 | 2 | `mibz2-pipe3-runfed-dir` | mibz2-pipe3-runfed-hs | 0.260 | 0.1341 | 0.9749 | 800 | 3260 | 35 | 42 | H | 0.0001 | 0.0024 |
| 129 | 18 | 3 | `mibz2-default33` | mibz2-pipe3-runfed-dir | 0.260 | 0.1586 | 1.0807 | 808 | 3877 | 35 | 41 | H | 0.0001 | 0.0025 |
| 130 | 18 | 4 | `mibz2-pipe3-both` | mibz2-default33 | 0.261 | 0.1498 | 1.0297 | 800 | 3465 | 35 | 42 | H | 0.0001 | 0.0023 |
| 131 | 18 | 5 | `mibz2-pipe3-runfed-ctl` | mibz2-pipe3-both | 0.260 | 0.3135 | 2.3624 | 851 | 3876 | 35 | 41 | H | 0.0001 | 0.0023 |
| 132 | 18 | 6 | `mibz2-pipe3-runfed-reg` | mibz2-pipe3-runfed-ctl | 0.260 | 0.2972 | 2.2031 | 800 | 3693 | 35 | 40 | H | 0.0001 | 0.0023 |
| 133 | 19 | 0 | `mibz2-pipe3-runfed-hs` | mibz2-pipe3-runfed-reg | 0.260 | 0.3025 | 2.1198 | 800 | 3671 | 35 | 39 | H | 0.0001 | 0.0023 |
| 134 | 19 | 1 | `mibz2-pipe3-runfed-dir` | mibz2-pipe3-runfed-hs | 0.260 | 0.3075 | 2.2399 | 816 | 3141 | 34 | 38 | H | 0.0001 | 0.0023 |
| 135 | 19 | 2 | `mibz2-default33` | mibz2-pipe3-runfed-dir | 0.260 | 0.2835 | 2.1195 | 800 | 2400 | 34 | 40 | L | 0.0001 | 0.0023 |
| 136 | 19 | 3 | `mibz2-pipe3-both` | mibz2-default33 | 0.260 | 0.3227 | 2.4425 | 800 | 3876 | 34 | 41 | H | 0.0001 | 0.0023 |
| 137 | 19 | 4 | `mibz2-pipe3-runfed-ctl` | mibz2-pipe3-both | 0.260 | 0.3368 | 2.5157 | 800 | 3465 | 34 | 40 | H | 0.0001 | 0.0023 |
| 138 | 19 | 5 | `mibz2-pipe3-runfed-reg` | mibz2-pipe3-runfed-ctl | 0.260 | 0.3100 | 2.2844 | 800 | 3701 | 34 | 38 | H | 0.0001 | 0.0023 |
| 139 | 19 | 6 | `mibz2-pipe3-runfed-ls` | mibz2-pipe3-runfed-reg | 0.262 | 0.3312 | 2.3671 | 800 | 3687 | 35 | 40 | H | 0.0001 | 0.0023 |

## Each pair's log ratios over the incumbent, in run order (descriptive)

| arm | round | state | log wall ratio | log CPU ratio |
|---|---|---|---|---|
| `mibz2-pipe3-both` | 0 | HL | +0.1881 | +0.0781 |
| `mibz2-pipe3-runfed-ctl` | 0 | HH | +0.1913 | +0.0846 |
| `mibz2-pipe3-runfed-reg` | 0 | HH | +0.8252 | +0.7613 |
| `mibz2-pipe3-runfed-ls` | 0 | HH | +0.8488 | +0.7841 |
| `mibz2-pipe3-runfed-hs` | 0 | HH | +0.9475 | +0.9025 |
| `mibz2-pipe3-runfed-dir` | 0 | HH | +0.8006 | +0.7539 |
| `mibz2-pipe3-both` | 1 | HH | -0.0681 | -0.0103 |
| `mibz2-pipe3-runfed-ctl` | 1 | HH | -0.0052 | -0.0095 |
| `mibz2-pipe3-runfed-reg` | 1 | HH | +0.0622 | +0.0959 |
| `mibz2-pipe3-runfed-ls` | 1 | HH | +0.1109 | +0.0790 |
| `mibz2-pipe3-runfed-hs` | 1 | HH | +0.1384 | +0.1165 |
| `mibz2-pipe3-runfed-dir` | 1 | HH | -0.0663 | -0.0659 |
| `mibz2-pipe3-runfed-ctl` | 2 | HH | +0.0313 | +0.0163 |
| `mibz2-pipe3-runfed-reg` | 2 | HH | -0.0040 | -0.0107 |
| `mibz2-pipe3-runfed-ls` | 2 | HH | +0.0742 | +0.0364 |
| `mibz2-pipe3-runfed-hs` | 2 | HH | -0.4900 | -0.5640 |
| `mibz2-pipe3-runfed-dir` | 2 | HH | +0.0872 | +0.0943 |
| `mibz2-pipe3-both` | 2 | HH | +0.0100 | -0.0041 |
| `mibz2-pipe3-runfed-reg` | 3 | HH | -0.6078 | -0.6690 |
| `mibz2-pipe3-runfed-ls` | 3 | HH | -0.6743 | -0.7530 |
| `mibz2-pipe3-runfed-hs` | 3 | HL | -0.5578 | -0.6521 |
| `mibz2-pipe3-runfed-dir` | 3 | HH | +0.0533 | +0.0816 |
| `mibz2-pipe3-both` | 3 | HL | -0.6414 | -0.6865 |
| `mibz2-pipe3-runfed-ctl` | 3 | HH | +0.0044 | +0.0181 |
| `mibz2-pipe3-runfed-ls` | 4 | HH | +0.1742 | +0.1419 |
| `mibz2-pipe3-runfed-hs` | 4 | HH | +0.4644 | +0.4578 |
| `mibz2-pipe3-runfed-dir` | 4 | HH | -0.3810 | -0.4730 |
| `mibz2-pipe3-both` | 4 | HH | +0.1916 | +0.1733 |
| `mibz2-pipe3-runfed-ctl` | 4 | HH | +0.1283 | +0.1041 |
| `mibz2-pipe3-runfed-reg` | 4 | HH | +0.3744 | +0.3809 |
| `mibz2-pipe3-runfed-hs` | 5 | HH | +0.2417 | +0.2261 |
| `mibz2-pipe3-runfed-dir` | 5 | HH | +0.0212 | -0.0355 |
| `mibz2-pipe3-both` | 5 | HL | -0.0224 | -0.0464 |
| `mibz2-pipe3-runfed-ctl` | 5 | HL | -0.0711 | -0.0860 |
| `mibz2-pipe3-runfed-reg` | 5 | HL | +0.0535 | +0.0355 |
| `mibz2-pipe3-runfed-ls` | 5 | HH | -0.0669 | -0.1153 |
| `mibz2-pipe3-runfed-dir` | 6 | HH | -0.1366 | -0.1763 |
| `mibz2-pipe3-both` | 6 | HH | -0.1856 | -0.1816 |
| `mibz2-pipe3-runfed-ctl` | 6 | HH | -0.1591 | -0.1394 |
| `mibz2-pipe3-runfed-reg` | 6 | HH | -0.7327 | -0.8143 |
| `mibz2-pipe3-runfed-ls` | 6 | HH | -0.1730 | -0.2176 |
| `mibz2-pipe3-runfed-hs` | 6 | HH | -0.6920 | -0.7928 |
| `mibz2-pipe3-runfed-dir` | 7 | HH | -0.2251 | -0.3075 |
| `mibz2-pipe3-runfed-hs` | 7 | HH | -0.6599 | -0.7786 |
| `mibz2-pipe3-runfed-ls` | 7 | HH | -0.0492 | -0.0739 |
| `mibz2-pipe3-runfed-reg` | 7 | HH | -0.0456 | -0.0410 |
| `mibz2-pipe3-runfed-ctl` | 7 | HH | -0.0253 | -0.0042 |
| `mibz2-pipe3-both` | 7 | HL | +0.1148 | +0.1278 |
| `mibz2-pipe3-runfed-dir` | 8 | HH | -0.0052 | +0.0310 |
| `mibz2-pipe3-runfed-hs` | 8 | HH | -0.0189 | -0.0514 |
| `mibz2-pipe3-runfed-ls` | 8 | HH | -0.0670 | -0.0879 |
| `mibz2-pipe3-runfed-reg` | 8 | HL | -0.5494 | -0.6066 |
| `mibz2-pipe3-runfed-ctl` | 8 | HH | -0.5328 | -0.5901 |
| `mibz2-pipe3-both` | 8 | HH | -0.6959 | -0.6889 |
| `mibz2-pipe3-both` | 9 | HH | +0.0113 | +0.0182 |
| `mibz2-pipe3-runfed-dir` | 9 | HH | +0.1257 | +0.1496 |
| `mibz2-pipe3-runfed-hs` | 9 | HH | -0.5831 | -0.7031 |
| `mibz2-pipe3-runfed-ls` | 9 | HH | -0.6895 | -0.7330 |
| `mibz2-pipe3-runfed-reg` | 9 | HH | -0.7518 | -0.7588 |
| `mibz2-pipe3-runfed-ctl` | 9 | HL | -0.0917 | -0.1043 |
| `mibz2-pipe3-runfed-ctl` | 10 | HH | +0.1536 | +0.1585 |
| `mibz2-pipe3-both` | 10 | HL | -0.0587 | -0.0194 |
| `mibz2-pipe3-runfed-dir` | 10 | HH | +0.7071 | +0.8181 |
| `mibz2-pipe3-runfed-hs` | 10 | HH | +0.7621 | +0.8523 |
| `mibz2-pipe3-runfed-ls` | 10 | HH | +0.6509 | +0.7320 |
| `mibz2-pipe3-runfed-reg` | 10 | HH | +0.7102 | +0.8198 |
| `mibz2-pipe3-runfed-reg` | 11 | HH | +0.1269 | +0.1430 |
| `mibz2-pipe3-runfed-ctl` | 11 | HH | -0.0760 | -0.0930 |
| `mibz2-pipe3-both` | 11 | HH | +0.0557 | +0.0893 |
| `mibz2-pipe3-runfed-dir` | 11 | HH | +0.1235 | +0.1428 |
| `mibz2-pipe3-runfed-hs` | 11 | HH | +0.1315 | +0.1136 |
| `mibz2-pipe3-runfed-ls` | 11 | HH | -0.0147 | -0.0373 |
| `mibz2-pipe3-runfed-ls` | 12 | HH | -0.0429 | -0.1054 |
| `mibz2-pipe3-runfed-reg` | 12 | HL | -0.0668 | -0.1045 |
| `mibz2-pipe3-runfed-ctl` | 12 | HH | -0.0136 | -0.0294 |
| `mibz2-pipe3-both` | 12 | HH | -0.0079 | -0.0094 |
| `mibz2-pipe3-runfed-dir` | 12 | HH | +0.0962 | +0.0876 |
| `mibz2-pipe3-runfed-hs` | 12 | HH | -0.0057 | -0.0572 |
| `mibz2-pipe3-runfed-hs` | 13 | LH | +0.0579 | +0.0212 |
| `mibz2-pipe3-runfed-ls` | 13 | LH | -0.1242 | -0.1732 |
| `mibz2-pipe3-runfed-reg` | 13 | LH | -0.6329 | -0.6938 |
| `mibz2-pipe3-runfed-ctl` | 13 | LL | -0.0826 | -0.0825 |
| `mibz2-pipe3-both` | 13 | LH | +0.0467 | +0.0495 |
| `mibz2-pipe3-runfed-dir` | 13 | LH | +0.0003 | -0.0095 |
| `mibz2-pipe3-both` | 14 | HL | -0.5307 | -0.5863 |
| `mibz2-pipe3-runfed-ctl` | 14 | HH | -0.7823 | -0.8526 |
| `mibz2-pipe3-runfed-reg` | 14 | HH | -0.8922 | -0.9007 |
| `mibz2-pipe3-runfed-ls` | 14 | HH | -0.2276 | -0.2683 |
| `mibz2-pipe3-runfed-hs` | 14 | HH | -0.1222 | -0.1748 |
| `mibz2-pipe3-runfed-dir` | 14 | HH | +0.0009 | +0.0233 |
| `mibz2-pipe3-both` | 15 | HH | +0.0270 | +0.0356 |
| `mibz2-pipe3-runfed-ctl` | 15 | HH | +0.1826 | +0.1940 |
| `mibz2-pipe3-runfed-reg` | 15 | HH | -0.0767 | -0.1018 |
| `mibz2-pipe3-runfed-ls` | 15 | HL | -0.0659 | -0.0969 |
| `mibz2-pipe3-runfed-hs` | 15 | HL | +0.1750 | +0.1523 |
| `mibz2-pipe3-runfed-dir` | 15 | HH | -0.0452 | -0.0844 |
| `mibz2-pipe3-runfed-ctl` | 16 | LH | +0.0254 | +0.0397 |
| `mibz2-pipe3-runfed-reg` | 16 | LH | +0.0319 | +0.0103 |
| `mibz2-pipe3-runfed-ls` | 16 | LH | +0.0119 | -0.0162 |
| `mibz2-pipe3-runfed-hs` | 16 | LH | +0.3040 | +0.2979 |
| `mibz2-pipe3-runfed-dir` | 16 | LH | +0.0021 | -0.0213 |
| `mibz2-pipe3-both` | 16 | LL | +0.1385 | +0.1595 |
| `mibz2-pipe3-runfed-reg` | 17 | HH | -0.0364 | -0.0187 |
| `mibz2-pipe3-runfed-ls` | 17 | HH | -0.1432 | -0.1758 |
| `mibz2-pipe3-runfed-hs` | 17 | HH | +0.0286 | -0.0056 |
| `mibz2-pipe3-runfed-dir` | 17 | HH | -0.0116 | -0.0091 |
| `mibz2-pipe3-both` | 17 | HH | +0.0670 | +0.0649 |
| `mibz2-pipe3-runfed-ctl` | 17 | HH | -0.0773 | -0.0574 |
| `mibz2-pipe3-runfed-ls` | 18 | HH | +0.6334 | +0.6895 |
| `mibz2-pipe3-runfed-hs` | 18 | HL | -0.0281 | -0.0441 |
| `mibz2-pipe3-runfed-dir` | 18 | HH | -0.1678 | -0.1030 |
| `mibz2-pipe3-both` | 18 | HH | -0.0571 | -0.0483 |
| `mibz2-pipe3-runfed-ctl` | 18 | HH | +0.6814 | +0.7821 |
| `mibz2-pipe3-runfed-reg` | 18 | HH | +0.6280 | +0.7123 |
| `mibz2-pipe3-runfed-hs` | 19 | LH | +0.0649 | +0.0001 |
| `mibz2-pipe3-runfed-dir` | 19 | LH | +0.0813 | +0.0553 |
| `mibz2-pipe3-both` | 19 | LH | +0.1295 | +0.1418 |
| `mibz2-pipe3-runfed-ctl` | 19 | LH | +0.1723 | +0.1714 |
| `mibz2-pipe3-runfed-reg` | 19 | LH | +0.0894 | +0.0749 |
| `mibz2-pipe3-runfed-ls` | 19 | LH | +0.1555 | +0.1105 |
