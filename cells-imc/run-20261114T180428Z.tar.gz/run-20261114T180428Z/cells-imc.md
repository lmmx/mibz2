# The working-set premise test (#145, LOG 6880984644)

- readings: /home/louis/dev/mibz2/target/cells-imc/run-20261114T180428Z/readings.jsonl (141 records)
- grid: threads 1,2,3,4,6,8,10, 10 repetitions, 15 decodes a reading, idle pairs of 3.0 s
- build: `/home/louis/dev/mibz2/target/cells-imc/target-p0/release/examples/ab` (P0: dose feature, MIBZ2_DOSE_MB=0, stream), arm mibz2-workers

## Validity: passed

a complete roster with its idle pairs, every decode successful, one output hash, dose_mb 0 and dose_blocks 196 in every decode, every net figure positive, every idle rate below 10% of its decode's

## b(t): DRAM bytes per output byte (idle-subtracted reads + writes)

| t | b(t) [95% CI] | reads/B | writes/B | decode wall s [95% CI] | L3 misses/B (process) | shortest reading s | idle/decode rate (max) |
|---|---|---|---|---|---|---|---|
| 1 | 1.2484 [1.2181, 1.2795] | 0.646 | 0.603 | 0.4500 [0.4475, 0.4524] | 0.0003 (n=10) | 6.68 | 9.7% |
| 2 | 5.8141 [5.7814, 5.8471] | 3.016 | 2.798 | 0.2515 [0.2502, 0.2528] | 0.0013 (n=10) | 3.86 | 1.2% |
| 3 | 11.5086 [11.4594, 11.5579] | 5.934 | 5.574 | 0.1931 [0.1922, 0.1940] | 0.0027 (n=10) | 2.99 | 0.4% |
| 4 | 15.5444 [15.4972, 15.5917] | 8.189 | 7.355 | 0.1616 [0.1609, 0.1623] | 0.0043 (n=10) | 2.53 | 0.3% |
| 6 | 20.4229 [20.4009, 20.4449] | 11.007 | 9.416 | 0.1622 [0.1595, 0.1650] | 0.0091 (n=10) | 2.54 | 0.1% |
| 8 | 22.7010 [22.6354, 22.7668] | 12.724 | 9.977 | 0.1715 [0.1655, 0.1776] | 0.0122 (n=10) | 2.65 | 0.2% |
| 10 | 24.1889 [24.1306, 24.2474] | 13.875 | 10.315 | 0.1801 [0.1797, 0.1806] | 0.0128 (n=10) | 2.89 | 0.2% |

## Reported, not gating

- b(10)/b(2) = 4.1604 [4.1328, 4.1881]
- b(10)/b(4) = 1.5561 [1.5497, 1.5626]
- b(1) = 1.25 B against the census's 25 B of heap traffic per output byte: 0.050x
- b(10) = 24.19 B against the dose LOG's estimate of 24 B: 1.008x

## Verdict

VERDICT: PREMISE HOLDS: R = b(10)/b(3) = 2.1018 [2.0910, 2.1127]
