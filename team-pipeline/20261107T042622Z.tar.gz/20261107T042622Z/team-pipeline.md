# The pipelined team: the workstation run's report

## Validity

- the registered 20 rounds (seen: 20): **yes**
- a clean tree (`git-status.txt` present and empty): **yes**
- no `NOT-FROZEN.txt` (the frozen inputs unchanged): **yes**
- no `DRY-RUN.txt` (not a dry run): **yes**
- `commit.txt` (7c59de46158786b49ab5bd7068c51e0ff1ae72a4) is the checkout's head (7c59de46158786b49ab5bd7068c51e0ff1ae72a4): **yes**
- every run the same bytes, none failed: **yes**
- `mibz2@10`: rounds 0-19 once each, every run 3 x 3 (seen: 3 × 3): **yes**
- `mibz2-team3@10`: rounds 0-19 once each, every run 3 x 3 (seen: 3 × 3): **yes**
- `mibz2-pipe3@10`: rounds 0-19 once each, every run 3 x 3 (seen: 3 × 3): **yes**
- `mibz2-team4@12`: rounds 0-19 once each, every run 3 x 4 (seen: 3 × 4): **yes**
- `mibz2-pipe4@12`: rounds 0-19 once each, every run 3 x 4 (seen: 3 × 4): **yes**
- the noise control N1, `mibz2-team3@10` against `mibz2@10` (the same plan): 1.008 [0.992, 1.026] over 20 rounds, within 1 ± 0.03: **yes**

Run: **VALID**

## The registered comparisons

| | arm | against | speed ratio [95% CI] | CPU ratio [95% CI] | outcome | α implied (H = 0) |
|---|---|---|---|---|---|---|
| C1 (causal) | `mibz2-pipe3@10` | `mibz2-team3@10` | 1.042 [1.016, 1.068] | 0.918 [0.895, 0.942] | SMALL GAIN (above 1, not above the threshold) | 1.55 |
| C2 (causal) | `mibz2-pipe4@12` | `mibz2-team4@12` | 1.032 [1.020, 1.044] | 0.897 [0.884, 0.910] | GAIN |  |
| P1 (product) | `mibz2-pipe4@12` | `mibz2@10` | 1.054 [1.039, 1.069] | 0.769 [0.758, 0.780] | GAIN |  |

(CPU ratio: the reference's CPU over the arm's; < 1, the arm spends more.)

## Every cell (medians)

| cell | plan | wall s | CPU s | peak RSS MB | rounds |
|---|---|---|---|---|---|
| `mibz2-pipe3@10` | 3 × 3 | 0.146 | 1.060 | 75 | 20 |
| `mibz2-pipe3@12` (unregistered) | 4 × 3 | 0.158 | 1.499 | 90 | 20 |
| `mibz2-pipe4@10` (unregistered) | 2 × 4 | 0.159 | 0.949 | 57 | 20 |
| `mibz2-pipe4@12` | 3 × 4 | 0.146 | 1.264 | 75 | 20 |
| `mibz2-team3@10` | 3 × 3 | 0.151 | 0.959 | 67 | 20 |
| `mibz2-team3@12` (unregistered) | 4 × 3 | 0.162 | 1.361 | 81 | 20 |
| `mibz2-team4@10` (unregistered) | 2 × 4 | 0.181 | 0.930 | 52 | 20 |
| `mibz2-team4@12` | 3 × 4 | 0.149 | 1.137 | 67 | 20 |
| `mibz2@10` | 3 × 3 | 0.154 | 0.976 | 67 | 20 |
| `mibz2@12` (unregistered) | 3 × 3 | 0.152 | 0.960 | 67 | 20 |

## The traces (occupancy, medians over complete rounds)

| trace | complete rounds | MTF overlapped (same thread) | MTF overlapped (cross thread) | RLE overlapped (cross thread) | blocks |
|---|---|---|---|---|---|
| occupancy-t10-teams3.json t=10 | 6 | nan | nan | nan | 431 |
| occupancy-t10-pipe3.json t=10 | 6 | 225.5 | 147 | 153 | 431 |
| occupancy-t12-teams4.json t=12 | 6 | nan | nan | nan | 431 |
| occupancy-t12-pipe4.json t=12 | 6 | 217.5 | 140.5 | 145 | 431 |

No cross-block overlap in a pipelined trace (cross thread 0) means no mechanism verdict (the registration's outcome map).
