# The service core at two teams: the workstation run's report

## Validity

- the registered 20 rounds (seen: 20): **yes**
- a clean tree (`git-status.txt` present and empty): **yes**
- no `NOT-FROZEN.txt` (the frozen inputs unchanged): **yes**
- no `DRY-RUN.txt` (not a dry run): **yes**
- `commit.txt` (3e201246cf1266d4b2a984cb19eb9fdba5b9835d) is the checkout's head (3e201246cf1266d4b2a984cb19eb9fdba5b9835d): **yes**
- the ten-core topology, so `mibz2` is the pipelined default (lscpu: 1 socket, 10 cores, L3 20 MiB (1 instance)): **yes**
- every run's record usable: a hex output digest, the registered 209700196 bytes out, finite positive wall, CPU and peak RSS, the registered corpus `wikidata` (0 unusable, 0 unparsed): **yes**
- every run the same bytes as the reference `mibz2@10`'s, none failed (digests: a8830caee5c511a6): **yes**
- `corpus.sha256` the registered corpus's (82f65ace0731..., bench/wikidata.json; seen: 82f65ace0731...): **yes**
- `mibz2@10`: rounds 0-19 once each, every run 3 leaders, 6 helpers, 0 service threads (seen: 3 leaders, 6 helpers, 0 service): **yes**
- `mibz2-svc2@10`: rounds 0-19 once each, every run 2 leaders, 4 helpers, 2 service threads (seen: 2 leaders, 4 helpers, 2 service): **yes**
- `mibz2-team2x3@10`: rounds 0-19 once each, every run 2 leaders, 4 helpers, 0 service threads (seen: 2 leaders, 4 helpers, 0 service): **yes**
- `mibz2-pipe2x3@10`: rounds 0-19 once each, every run 2 leaders, 4 helpers, 0 service threads (seen: 2 leaders, 4 helpers, 0 service): **yes**
- `mibz2-team3@10`: rounds 0-19 once each, every run 3 leaders, 6 helpers, 0 service threads (seen: 3 leaders, 6 helpers, 0 service): **yes**
- `mibz2-team3-twin@10`: rounds 0-19 once each, every run 3 leaders, 6 helpers, 0 service threads (seen: 3 leaders, 6 helpers, 0 service): **yes**
- no cell beyond the registered ones (seen: none): **yes**
- the trace `occupancy-t10-svc2` complete and as registered (10 threads, the service core, mibz2-svc2's plan, 2 service threads, the run's commit, parity, the registered output, every metric read finite and in range; rounds: 6): **yes**
- saturation resolved from the trace (seen: not saturated): **yes**
- the noise control N1, `mibz2-team3-twin@10` against `mibz2-team3@10` (the same plan): 0.997 [0.971, 1.023] over 20 rounds, within 1 ± 0.03: **yes**

Run: **VALID**

## The registered comparisons (equal budget of 10; judged; speed and CPU co-primary)

| | arm | against | decode threads | speed [95% CI] | speed outcome | CPU [95% CI] | CPU outcome | the extra threads |
|---|---|---|---|---|---|---|---|---|
| P1 | `mibz2-svc2@10` | `mibz2@10` | 8 against 9 | 1.045 [1.017, 1.073] | SMALL GAIN (above 1, not above the threshold) | 1.146 [1.123, 1.170] | CPU SAVING | no more decode threads than the reference |
| C1 | `mibz2-svc2@10` | `mibz2-team2x3@10` | 8 against 6 | 1.402 [1.368, 1.437] | GAIN | 0.941 [0.924, 0.959] | CPU COST | BEYOND ITS THREADS (lower bound above 1.333) |
| P2 | `mibz2-pipe2x3@10` | `mibz2@10` | 6 against 9 | 0.866 [0.851, 0.881] | REGRESSION | 1.214 [1.196, 1.233] | CPU SAVING | (no gain) |

**The findings** (P1, C1 and P2 judged as registered; S1 reported, never judged; each its own finding):

- the product (P1, svc2@10 against the default): **SVC2@10 BEATS THE DEFAULT (P1 SMALL GAIN (above 1, not above the threshold); CPU SAVING)**
- the service bundle (C1, svc2@10 against the plain 2 × 3 at the same teams and window): **THE SERVICE BUNDLE BEATS THE PLAIN 2 × 3 (C1 GAIN, at the same teams and window; no one mechanism isolated)** (C1's extra decode threads are the service threads themselves: its label is reported, not required. C1 measures the bundle, the two service threads with the serial work they take, the feeding, the hub's synchronisation and hand-offs, not any one of them)
- two teams under today's decoder (P2): **TWO PIPELINED TEAMS DON'T BEAT THE DEFAULT (P2 REGRESSION)**
- the two candidates head to head (S1, svc2@10 against pipe2x3@10): **SVC2@10 FASTER THAN PIPE2X3@10 (S1 1.207 [1.171, 1.243], GAIN; reported, not judged)**
- overall, by the registered order: **FOR SVC2@10 (registered step 6: P1 SMALL GAIN (above 1, not above the threshold), CPU SAVING, C1 GAIN; and SVC2@10 FASTER THAN PIPE2X3@10 (S1 1.207 [1.171, 1.243], GAIN; reported, not judged)). C1 is the service bundle's gain over the plain 2 × 3, not a single cause**

NULL is an interval inside [0.97, 1.03]: bounded uncertainty, not an effect shown to be zero. CPU INCONCLUSIVE is no detected CPU cost, not a CPU cost shown to be absent.

**The decomposition** (geometric means over the 20 common paired rounds; P1 = S1 × P2 = C1 × S2 holds round by round, so on these means exactly; the intervals' endpoints don't multiply, since the shared rounds correlate them):

| | P1 | S1 | P2 | S1 × P2 | C1 | S2 | C1 × S2 |
|---|---|---|---|---|---|---|---|
| speed | 1.0448 | 1.2066 | 0.8659 | 1.0448 | 1.4021 | 0.7451 | 1.0448 |
| CPU | 1.1459 | 0.9438 | 1.2141 | 1.1459 | 0.9413 | 1.2174 | 1.1459 |

## Reported, never judged

| | arm | against | decode threads | speed [95% CI] | CPU [95% CI] |
|---|---|---|---|---|---|
| S1 | `mibz2-svc2@10` | `mibz2-pipe2x3@10` | 8 against 6 | 1.207 [1.171, 1.243] | 0.944 [0.921, 0.967] |
| S2 | `mibz2-team2x3@10` | `mibz2@10` | 6 against 9 | 0.745 [0.733, 0.757] | 1.217 [1.199, 1.236] |
| S3 | `mibz2-pipe2x3@10` | `mibz2-team2x3@10` | 6 against 6 | 1.162 [1.148, 1.177] | 0.997 [0.984, 1.010] |
| S4 | `mibz2-team2x3@10` | `mibz2-team3@10` | 6 against 9 | 0.801 [0.784, 0.819] | 1.173 [1.144, 1.203] |
| S5 | `mibz2-svc2@10` | `mibz2-team3@10` | 8 against 9 | 1.124 [1.086, 1.162] | 1.104 [1.071, 1.138] |
| R1 | `mibz2@10` | `mibz2-team3@10` | 9 against 9 | 1.076 [1.060, 1.092] | 0.964 [0.948, 0.980] |

(Speed: the reference's wall over the arm's, > 1 the arm is faster. CPU: the reference's CPU over the arm's, > 1 the arm spends less.)

## Every cell (medians)

| cell | decode threads (leaders + helpers + service) | wall s | CPU s | peak RSS MB | rounds | service utilisation (each; max) |
|---|---|---|---|---|---|---|
| `mibz2-pipe2x3@10` | 2+4+0 | 0.166 | 0.850 | 57 | 20 | – |
| `mibz2-svc2@10` | 2+4+2 | 0.137 | 0.895 | 64 | 20 | 0.70, 0.67; max 0.70 |
| `mibz2-team2x3@10` | 2+4+0 | 0.193 | 0.847 | 52 | 20 | – |
| `mibz2-team3-twin@10` | 3+6+0 | 0.154 | 0.983 | 67 | 20 | – |
| `mibz2-team3@10` | 3+6+0 | 0.153 | 0.985 | 67 | 20 | – |
| `mibz2@10` | 3+6+0 | 0.144 | 1.026 | 74 | 20 | – |

## The trace (occupancy, medians over complete rounds)

| trace | rounds | blocks | util max | prep wait median / p90 ms | finish wait median / p90 ms | job wait median ms | backlog prep / finish (mean; max) | teams idle: prep / back share | run wait ms | saturation | prep starvation | finish backlog |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| occupancy-t10-svc2 | 6 | 431 | 0.70 | 0.139 / 0.594 | 0.056 / 0.381 | 0.158 | 0.76 / 0.48 (3; 4) | 0.165 / 0.015 | 87.3 | not saturated | PREP STARVATION | no finish backlog |

**The registered counterexample, service saturation at 2 × 3 + 2:** **NOT SATURATED at 2 × 3 + 2 (PREP STARVATION without saturation: consistent with the prepared queue's lookahead binding, not shown to be it)**
