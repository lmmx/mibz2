| workers | scan MB/s | find MB/s | scan CPU s | find CPU s | find / scan (paired) | min–max |
|--:|--:|--:|--:|--:|--:|--:|
| 1 | 116 | 89 | 0.221 | 0.221 | 0.764 | 0.746–0.833 |
| 2 | 205 | 170 | 0.237 | 0.228 | 0.830 | 0.788–0.843 |
| 4 | 283 | 285 | 0.257 | 0.252 | 0.992 | 0.957–1.034 |
| 6 | 294 | 375 | 0.255 | 0.272 | 1.303 | 1.234–1.338 |
| 8 | 288 | 423 | 0.255 | 0.312 | 1.460 | 1.392–1.557 |
| 10 | 254 | 426 | 0.293 | 0.344 | 1.780 | 1.454–1.987 |

Medians over 5 rounds. scan: a scanner thread and the workers; find: a finder thread and workers that read their own blocks. The ratio is find's MB/s over scan's, round by round.

**Reading: FASTER: at 10 workers find ran at 1.780 of scan's rate, at least 1.15**
