| workers | scan MB/s | find MB/s | scan CPU s | find CPU s | find / scan (paired) | min–max |
|--:|--:|--:|--:|--:|--:|--:|
| 1 | 413 | 348 | 0.705 | 0.662 | 0.833 | 0.817–0.890 |
| 2 | 792 | 659 | 0.720 | 0.698 | 0.839 | 0.792–0.845 |
| 4 | 1524 | 1255 | 0.737 | 0.728 | 0.813 | 0.804–0.887 |
| 6 | 1628 | 1842 | 0.747 | 0.740 | 1.132 | 1.127–1.143 |
| 8 | 1600 | 2429 | 0.787 | 0.745 | 1.525 | 1.489–1.678 |
| 10 | 1598 | 2563 | 0.818 | 0.840 | 1.615 | 1.597–1.958 |

Medians over 5 rounds. scan: a scanner thread and the workers; find: a finder thread and workers that read their own blocks. The ratio is find's MB/s over scan's, round by round.

**Reading: FASTER: at 10 workers find ran at 1.615 of scan's rate, at least 1.15**
