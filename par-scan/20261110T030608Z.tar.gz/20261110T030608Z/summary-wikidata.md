| workers | scan MB/s | find MB/s | scan CPU s | find CPU s | find / scan (paired) | min–max |
|--:|--:|--:|--:|--:|--:|--:|
| 1 | 455 | 409 | 0.575 | 0.568 | 0.892 | 0.822–0.981 |
| 2 | 812 | 765 | 0.636 | 0.605 | 0.927 | 0.892–1.088 |
| 4 | 1145 | 1127 | 0.853 | 0.803 | 0.978 | 0.923–1.018 |
| 6 | 956 | 968 | 1.468 | 1.380 | 1.006 | 1.001–1.023 |
| 8 | 741 | 744 | 2.457 | 2.358 | 1.006 | 0.993–1.037 |
| 10 | 631 | 619 | 3.693 | 3.627 | 0.981 | 0.880–1.028 |

Medians over 5 rounds. scan: a scanner thread and the workers; find: a finder thread and workers that read their own blocks. The ratio is find's MB/s over scan's, round by round.

**Reading: NOT FASTER: at 10 workers find ran at 0.981 of scan's rate, at most 1.05**
