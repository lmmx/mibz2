# The guarded service default against the current default

Speed and CPU are the base's over the head's (above 1: the head is faster, or spends less); peak RSS is the head's over the base's (above 1: more memory), each run its own process. Paired geometric means over 20 rounds, 95% t-intervals.

| threads | role | plans, base → head | speed | head/base wall, upper bound | CPU | peak RSS (reported) | twin over base |
|--:|---|---|--:|--:|--:|--:|--:|
| 8 | identity (reported) | 4×2 plain → 4×2 plain | 1.015 [1.004, 1.027] | 0.998 | 1.013 [1.000, 1.026] | 1.000 [0.992, 1.008] | 1.006 [0.995, 1.016] |
| 9 | identity (reported) | 4×2 plain → 4×2 plain | 1.001 [0.992, 1.011] | 1.010 | 0.999 [0.988, 1.009] | 1.003 [0.999, 1.007] | 0.995 [0.984, 1.006] |
| 10 | P1 (judged); N1 (validity) | 3×3 pipelined → 2×3 plain + 2 service | 1.068 [1.043, 1.095] | 0.963 | 1.173 [1.153, 1.193] | 0.863 [0.857, 0.870] | 1.007 [0.988, 1.027] |
| 11 | no harm (judged) | 3×3 pipelined → 3×3 pipelined | 1.012 [0.991, 1.033] | 1.013 | 1.004 [0.988, 1.021] | 1.005 [0.995, 1.016] | 0.999 [0.985, 1.013] |
| 12 | no harm (judged) | 3×3 pipelined → 3×3 pipelined | 0.992 [0.978, 1.006] | 1.025 | 0.996 [0.984, 1.008] | 1.004 [0.993, 1.016] | 1.001 [0.979, 1.023] |
| 16 | no harm (judged) | 3×3 pipelined → 3×3 pipelined | 0.996 [0.975, 1.017] | 1.029 | 0.992 [0.975, 1.008] | 1.000 [0.993, 1.008] | 0.993 [0.976, 1.011] |
| 20 | no harm (judged) | 3×3 pipelined → 3×3 pipelined | 0.999 [0.984, 1.015] | 1.019 | 0.998 [0.989, 1.008] | 1.002 [0.988, 1.016] | 0.996 [0.984, 1.009] |

**The preflight:** TARGET.

**Valid:** yes

**P1:** speed GAIN 1.068 [1.043, 1.095]; CPU CPU SAVING 1.173 [1.153, 1.193]: **THE SERVICE DEFAULT BEATS THE CURRENT DEFAULT**.
**No harm at 11, 12, 16 and 20** (each head/base wall upper bound at most 1.02, Bonferroni over the four): **not shown at 12, 16** (an interval too wide to show it counts as not shown).
- Speed and CPU are co-primary, each with its own 95% interval: together they are not a simultaneous 95% statement.
- A product gain does not identify the service threads as its cause: svc2 against the current default changes the plan, the teams, the window and the decoding threads together.
- The plans are the sampled thread counts, not a proof of the window or the kernels; equal plans at the other budgets are a fallback check, not binary identity; no harm there is its own predicate, above.
- Peak RSS is reported, not judged: no memory condition was registered, and none is met here.
- One i9 result does not qualify the predicate's class, and CI's off-path bench does not qualify the service default's gain.
