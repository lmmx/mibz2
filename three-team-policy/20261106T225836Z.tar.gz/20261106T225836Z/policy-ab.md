# The three-team policy: head default against base default

Speed is the base build's wall over the head's, paired by round (above 1 is faster); CPU and RSS are the head's median over the base's.

| threads | role | plans run, base → head | speed (95%) | head/base wall, upper bound | CPU | RSS |
|--:|---|---|--:|--:|--:|--:|
| 8 | control | 4×2 → 4×2 | 1.005 (0.992–1.019) | 1.010 | 1.00 | 1.00 |
| 9 | control | 4×2 → 4×2 | 1.007 (0.997–1.017) | 1.004 | 0.99 | 0.99 |
| 10 | primary | 4×2 → 3×3 | 1.088 (1.076–1.101) | 0.931 | 0.89 | 0.81 |
| 11 | no harm | 4×2 → 3×3 | 1.072 (1.053–1.091) | 0.953 | 0.89 | 0.81 |
| 12 | no harm | 4×2 → 3×3 | 1.085 (1.071–1.100) | 0.936 | 0.88 | 0.82 |
| 16 | no harm | 4×2 → 3×3 | 1.082 (1.065–1.099) | 0.941 | 0.90 | 0.82 |
| 20 | no harm | 4×2 → 3×3 | 1.081 (1.069–1.093) | 0.937 | 0.89 | 0.82 |

## The predicates

- Valid (rounds, outputs, plans): **yes**
- Control at 8: 95% interval not wholly beyond ±2%: **yes**
- Control at 9: 95% interval not wholly beyond ±2%: **yes**
- Primary at 10, speed: **yes**
- Primary at 10, lower bound: **yes**
- Primary at 10, cpu: **yes**
- Primary at 10, rss: **yes**
- No harm at 11: upper bound ≤ 1.02: **yes**
- No harm at 12: upper bound ≤ 1.02: **yes**
- No harm at 16: upper bound ≤ 1.02: **yes**
- No harm at 20: upper bound ≤ 1.02: **yes**

**This run: PASS.** The policy is admitted only if one run and its predeclared confirmation both pass.
