# The three-team policy: head default against base default

Speed is the base build's wall over the head's, paired by round (above 1 is faster); CPU and RSS are the head's median over the base's.

| threads | role | plans run, base → head | speed (95%) | head/base wall, upper bound | CPU | RSS |
|--:|---|---|--:|--:|--:|--:|
| 8 | control | 4×2 → 4×2 | 0.986 (0.977–0.995) | 1.025 | 1.01 | 1.00 |
| 9 | control | 4×2 → 4×2 | 1.000 (0.991–1.009) | 1.010 | 1.00 | 1.00 |
| 10 | primary | 4×2 → 3×3 | 1.089 (1.075–1.103) | 0.932 | 0.88 | 0.82 |
| 11 | no harm | 4×2 → 3×3 | 1.081 (1.066–1.098) | 0.941 | 0.90 | 0.81 |
| 12 | no harm | 4×2 → 3×3 | 1.065 (1.048–1.082) | 0.957 | 0.90 | 0.82 |
| 16 | no harm | 4×2 → 3×3 | 1.076 (1.060–1.092) | 0.946 | 0.89 | 0.82 |
| 20 | no harm | 4×2 → 3×3 | 1.092 (1.079–1.104) | 0.928 | 0.87 | 0.82 |

## The predicates

- Valid (rounds, outputs, plans): **yes**
- Control at 8: 95% interval not wholly beyond ±2%: **yes**
- Control at 9: 95% interval not wholly beyond ±2%: **yes**
- Primary at 10, speed: **yes**
- Primary at 10, lower bound: **yes**
- Primary at 10, cpu: **yes**
- Primary at 10, rss: **yes**
- No harm at 11: upper bound ≤ 1.02: **yes**
- No harm at 12: upper bound ≤ 1.02: **yes**
- No harm at 16: upper bound ≤ 1.02: **yes**
- No harm at 20: upper bound ≤ 1.02: **yes**

**This run: PASS.** The policy is admitted only if one run and its predeclared confirmation both pass.
