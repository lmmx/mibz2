# The phase attribution of Cells' memory traffic (#145, LOG 6884716103, amended 6884895257 and 6884975709)

- readings: /home/louis/dev/mibz2/target/cells-phase/run-20261114T235407Z/readings.jsonl (101 records)
- grid: threads 1,4, 10 repetitions, 15 decodes a reading, passes A1, A2, B1, B2 and the baseline
- placement: {'1': [1], '4': [0, 1, 2, 3]} (distinct physical cores; sibling idleness arranged, not verifiable from inside the run)
- scopes: whole = each worker's decode_block; induction = induce_cells; writer = write_cells; rest = whole less those (Cells' slots() included). The scanner thread's bit reading and Huffman stage are outside every worker scope: IMC ledger only. Phase boundaries are approximate: requests in flight cross them.

## Validity: passed

## The core ledger (an estimate): A1's demand-data local-DRAM reads, 64 B each, per output byte

| phase | B_p(1) | B_p(4) | U_p = B_p(4)/B_p(1), observed co-running uplift | s_p at 4 |
|---|---|---|---|---|
| induction | 0.0010 [0.0010, 0.0011] | 0.0673 [0.0664, 0.0683] | 66.0549 [63.9466, 68.2326] | 0.2703 [0.2686, 0.2720] |
| writer | 0.0001 [0.0001, 0.0001] | 0.0096 [0.0094, 0.0098] | 73.9826 [69.9773, 78.2172] | 0.0385 [0.0381, 0.0389] |
| rest | 0.0035 [0.0034, 0.0036] | 0.1719 [0.1687, 0.1750] | 49.6299 [48.2197, 51.0814] | 0.6897 [0.6879, 0.6914] |
| core (whole) | 0.0047 [0.0045, 0.0048] | 0.2492 [0.2450, 0.2533] | | |

paired U_wr / U_ind = 1.1200 [1.0669, 1.1758]

## The IMC ledger (physical), per output byte, from the A1 readings

| t | reads | writes (total only) | unattributed (IMC reads - demand-DRAM reads) | demand-DRAM reads / IMC reads |
|---|---|---|---|---|
| 1 | 0.5627 [0.5462, 0.5793] | 0.4740 [0.4664, 0.4815] | 0.5581 [0.5416, 0.5745] | 0.0083 [0.0080, 0.0085] |
| 4 | 6.6848 [6.6562, 6.7134] | 6.0492 [6.0213, 6.0771] | 6.4356 [6.4069, 6.4644] | 0.0373 [0.0366, 0.0379] |

b(1) = IMC reads + writes at 1 worker: 1.037 B against bench-cells-imc's 1.25 B

## Reported, not gating

- A1 demand-data local-DRAM responses: induction t=1 0.0010, t=4 0.0673; writer t=1 0.0001, t=4 0.0096; rest t=1 0.0035, t=4 0.1719 (B a line per output byte)
- A1 L3-miss demand data requests: induction t=1 0.0008, t=4 0.0370; writer t=1 0.0001, t=4 0.0046; rest t=1 0.0032, t=4 0.0752 (B a line per output byte)
- A2 RFO local-DRAM responses (CML058): induction t=1 0.0473, t=4 0.4959; writer t=1 0.0119, t=4 0.4513; rest t=1 0.1264, t=4 1.6514 (B a line per output byte)
- B1 L2 prefetch misses: induction t=1 18.3206, t=4 17.7336; writer t=1 4.0609, t=4 3.9160; rest t=1 22.4744, t=4 21.9438 (B a line per output byte)
- B1 all data reads offcore: induction t=1 14.6250, t=4 14.5863; writer t=1 1.9096, t=4 1.8817; rest t=1 16.0755, t=4 16.0178 (B a line per output byte)
- B2 demand data reads offcore: induction t=1 0.7152, t=4 1.1919; writer t=1 0.3045, t=4 0.5300; rest t=1 0.2906, t=4 0.8700 (B a line per output byte)
- the empty-scope overhead (A1 demand-DRAM, B per output byte): t=1 0.0000 [0.0000, 0.0000], t=4 0.0000 [0.0000, 0.0000]
- the baseline arm (Segmented T-vector walk), IMC reads + writes per output byte: t=1 0.5641 [0.5337, 0.5944] (Cells 1.0367), t=4 14.1588 [14.1168, 14.2008] (Cells 12.7340)
- baseline (not gating): idle rate 17.1% of the decode's: base t=1 rep 3
- baseline (not gating): idle rate 17.9% of the decode's: base t=1 rep 4
- A2's RFO local-DRAM responses are flagged CML058: they may overcount.

## Verdict

VERDICT: UNATTRIBUTED-DOMINATED, HELD: explained at t=4 0.037; s_ind 0.270, s_wr 0.038, s_rest 0.690; U_ind 66.055, U_wr 73.983, U_rest 49.630
