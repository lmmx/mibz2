# The phase attribution of Cells' memory traffic (#145, LOG 6884716103, amended 6884895257 and 6884975709)

- readings: /home/louis/dev/mibz2/target/cells-phase/run-20261114T232758Z/readings.jsonl (101 records)
- grid: threads 1,4, 10 repetitions, 15 decodes a reading, passes A1, A2, B1, B2 and the baseline
- placement: {'1': [1], '4': [0, 1, 2, 3]} (distinct physical cores; sibling idleness arranged, not verifiable from inside the run)
- scopes: whole = each worker's decode_block; induction = induce_cells; writer = write_cells; rest = whole less those (Cells' slots() included). The scanner thread's bit reading and Huffman stage are outside every worker scope: IMC ledger only. Phase boundaries are approximate: requests in flight cross them.

## Validity: FAILED (1)

- idle rate 10.2% of the decode's: B1 t=1 rep 9

## Verdict

VERDICT: INVALID (1 validity problems)
