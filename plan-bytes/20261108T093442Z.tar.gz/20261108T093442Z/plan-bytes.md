# bench-plan-bytes: does the table's size move the three-team advantage? (diagnostic)

Registration 2 of docs/journal/2026-11-07-general-plan-policy.md (docs/journal/2026-11-07-plan-bytes-registration.md). Diagnostic only (RULES C1).

## Validity

- every line of the runs files JSON (unreadable: none): **yes**
- a clean tree (`git-status.txt` present and empty): **yes**
- no `NOT-FROZEN.txt` (the frozen inputs unchanged): **yes**
- no `DRY-RUN.txt` (not a dry run): **yes**
- `commit.txt` (a5dcaebda28fecaa8165e81604bb2824d3842c71) is the checkout's head (a5dcaebda28fecaa8165e81604bb2824d3842c71): **yes**
- the ten-core topology: 1 socket, 10 cores, 2 threads a core, a 20 MiB L3 (lscpu: 1 socket, 10 cores, 2 threads a core, L3 20 MiB (1 instance)): **yes**
- the corpus `wikidata-l6` is the registered one (SHA-256 f3bbccf5d914280a...): **yes**
- the corpus `wikidata-l7` is the registered one (SHA-256 58c8897f3da919c9...): **yes**
- the corpus `wikidata-l9` is the registered one (SHA-256 817e6d89f4ab7df8...): **yes**
- every run the same bytes, none failed (180 runs, 0 failed, 1 outputs): **yes**
- `B10`: the registered mask (every CPU: all), recorded `all`, every run under it: **yes**
- `B10`: no arm, thread count or corpus beyond the registered (seen: none): **yes**
- `B10` `mibz2-plan-4x2` on `wikidata-l6`: rounds 0-19 once each (seen 20): **yes**
- `B10` `mibz2-plan-4x2` on `wikidata-l6`: every run's observed plan 4x2 (seen: 4x2): **yes**
- `B10` `mibz2-plan-4x2` on `wikidata-l7`: rounds 0-19 once each (seen 20): **yes**
- `B10` `mibz2-plan-4x2` on `wikidata-l7`: every run's observed plan 4x2 (seen: 4x2): **yes**
- `B10` `mibz2-plan-4x2` on `wikidata-l9`: rounds 0-19 once each (seen 20): **yes**
- `B10` `mibz2-plan-4x2` on `wikidata-l9`: every run's observed plan 4x2 (seen: 4x2): **yes**
- `B10` `mibz2-plan-3x3` on `wikidata-l6`: rounds 0-19 once each (seen 20): **yes**
- `B10` `mibz2-plan-3x3` on `wikidata-l6`: every run's observed plan 3x3 (seen: 3x3): **yes**
- `B10` `mibz2-plan-3x3` on `wikidata-l7`: rounds 0-19 once each (seen 20): **yes**
- `B10` `mibz2-plan-3x3` on `wikidata-l7`: every run's observed plan 3x3 (seen: 3x3): **yes**
- `B10` `mibz2-plan-3x3` on `wikidata-l9`: rounds 0-19 once each (seen 20): **yes**
- `B10` `mibz2-plan-3x3` on `wikidata-l9`: every run's observed plan 3x3 (seen: 3x3): **yes**
- `B10` `mibz2-plan-3x3p` on `wikidata-l6`: rounds 0-19 once each (seen 20): **yes**
- `B10` `mibz2-plan-3x3p` on `wikidata-l6`: every run's observed plan 3x3p (seen: 3x3p): **yes**
- `B10` `mibz2-plan-3x3p` on `wikidata-l7`: rounds 0-19 once each (seen 20): **yes**
- `B10` `mibz2-plan-3x3p` on `wikidata-l7`: every run's observed plan 3x3p (seen: 3x3p): **yes**
- `B10` `mibz2-plan-3x3p` on `wikidata-l9`: rounds 0-19 once each (seen 20): **yes**
- `B10` `mibz2-plan-3x3p` on `wikidata-l9`: every run's observed plan 3x3p (seen: 3x3p): **yes**

Run: **VALID**

## The family: 6 comparisons against 4x2 at 10 threads (Bonferroni, each interval at 1 - 0.05/12 a tail, t19 = 2.9439)

| level | arm | speed [interval] word, CPU | MHz, 4x2 → arm | role |
|---|---|---|---|---|
| 6 | `mibz2-plan-3x3` | 0.916 [0.890, 0.943] **SLOWER**, CPU 1.086 | 2081 → 2133 | the decision rule |
| 6 | `mibz2-plan-3x3p` | 1.163 [1.136, 1.191] **FASTER**, CPU 1.089 | 2081 → 2235 | reported |
| 7 | `mibz2-plan-3x3` | 0.957 [0.942, 0.972] **SLOWER**, CPU 1.036 | 2034 → 2197 | the boundary: reported, not judged |
| 7 | `mibz2-plan-3x3p` | 1.204 [1.172, 1.236] **FASTER**, CPU 1.057 | 2034 → 2235 | reported |
| 9 | `mibz2-plan-3x3` | 1.087 [1.067, 1.108] **FASTER**, CPU 0.879 | 2132 → 2197 | the decision rule |
| 9 | `mibz2-plan-3x3p` | 1.264 [1.242, 1.287] **FASTER**, CPU 0.976 | 2132 → 2237 | reported |

## Reading (plain 3x3 against 4x2)

PREMISE SUPPORTED: level 6's upper bound below 1.03, and its estimate below level 9's by more than both intervals' half-widths combined; this fails to refute the premise on one machine, and validates no extrapolation
