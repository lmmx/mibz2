/home/louis/dev/mibz2/target/scanner-a2-fast/tmpgm7xw5ll/head-real:     file format elf64-x86-64


Disassembly of section .fini:

Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000004c980 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2>:
   4c980:	55                   	push   %rbp
   4c981:	41 57                	push   %r15
   4c983:	41 56                	push   %r14
   4c985:	41 55                	push   %r13
   4c987:	41 54                	push   %r12
   4c989:	53                   	push   %rbx
   4c98a:	48 81 ec 68 01 00 00 	sub    $0x168,%rsp
   4c991:	4c 89 84 24 90 00 00 	mov    %r8,0x90(%rsp)
   4c998:	00 
   4c999:	48 89 bc 24 b8 00 00 	mov    %rdi,0xb8(%rsp)
   4c9a0:	00 
   4c9a1:	48 85 c9             	test   %rcx,%rcx
   4c9a4:	0f 84 28 26 00 00    	je     4efd2 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2652>
   4c9aa:	4d 89 ca             	mov    %r9,%r10
   4c9ad:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4c9b4:	00 
   4c9b5:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4c9bc:	00 
   4c9bd:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4c9c4:	00 
   4c9c5:	48 8d 04 8a          	lea    (%rdx,%rcx,4),%rax
   4c9c9:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
   4c9d0:	00 
   4c9d1:	4a 8d 04 dd 00 00 00 	lea    0x0(,%r11,8),%rax
   4c9d8:	00 
   4c9d9:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
   4c9e0:	00 
   4c9e1:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
   4c9e8:	00 00 
   4c9ea:	89 84 24 8c 00 00 00 	mov    %eax,0x8c(%rsp)
   4c9f1:	4c 89 54 24 40       	mov    %r10,0x40(%rsp)
   4c9f6:	48 89 b4 24 e0 00 00 	mov    %rsi,0xe0(%rsp)
   4c9fd:	00 
   4c9fe:	0f b6 3a             	movzbl (%rdx),%edi
   4ca01:	48 83 ff 06          	cmp    $0x6,%rdi
   4ca05:	0f 83 c0 28 00 00    	jae    4f2cb <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x294b>
   4ca0b:	48 89 94 24 e8 00 00 	mov    %rdx,0xe8(%rsp)
   4ca12:	00 
   4ca13:	0f b7 5a 02          	movzwl 0x2(%rdx),%ebx
   4ca17:	48 85 db             	test   %rbx,%rbx
   4ca1a:	0f 84 90 25 00 00    	je     4efb0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2630>
   4ca20:	48 69 ff c8 1a 00 00 	imul   $0x1ac8,%rdi,%rdi
   4ca27:	48 01 f7             	add    %rsi,%rdi
   4ca2a:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
   4ca31:	00 
   4ca32:	4c 8b 20             	mov    (%rax),%r12
   4ca35:	48 89 7c 24 48       	mov    %rdi,0x48(%rsp)
   4ca3a:	48 6b c3 7d          	imul   $0x7d,%rbx,%rax
   4ca3e:	48 83 c0 10          	add    $0x10,%rax
   4ca42:	4c 01 e0             	add    %r12,%rax
   4ca45:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
   4ca4c:	48 0f 42 c1          	cmovb  %rcx,%rax
   4ca50:	48 89 da             	mov    %rbx,%rdx
   4ca53:	4c 39 d8             	cmp    %r11,%rax
   4ca56:	48 89 9c 24 f0 00 00 	mov    %rbx,0xf0(%rsp)
   4ca5d:	00 
   4ca5e:	0f 86 48 07 00 00    	jbe    4d1ac <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x82c>
   4ca64:	4c 89 e0             	mov    %r12,%rax
   4ca67:	48 83 c0 10          	add    $0x10,%rax
   4ca6b:	48 0f 42 c1          	cmovb  %rcx,%rax
   4ca6f:	4c 89 d9             	mov    %r11,%rcx
   4ca72:	48 29 c1             	sub    %rax,%rcx
   4ca75:	ba 00 00 00 00       	mov    $0x0,%edx
   4ca7a:	48 0f 43 d1          	cmovae %rcx,%rdx
   4ca7e:	48 83 fa 7c          	cmp    $0x7c,%rdx
   4ca82:	0f 87 08 07 00 00    	ja     4d190 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x810>
   4ca88:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
   4ca8f:	00 
   4ca90:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
   4ca94:	8b 42 10             	mov    0x10(%rdx),%eax
   4ca97:	8b 52 14             	mov    0x14(%rdx),%edx
   4ca9a:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4ca9e:	0f b7 97 c4 1a 00 00 	movzwl 0x1ac4(%rdi),%edx
   4caa5:	66 89 94 24 98 00 00 	mov    %dx,0x98(%rsp)
   4caac:	00 
   4caad:	49 83 fc f7          	cmp    $0xfffffffffffffff7,%r12
   4cab1:	0f 87 6a 18 00 00    	ja     4e321 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x19a1>
   4cab7:	49 8d 54 24 08       	lea    0x8(%r12),%rdx
   4cabc:	4c 39 da             	cmp    %r11,%rdx
   4cabf:	0f 87 5c 18 00 00    	ja     4e321 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x19a1>
   4cac5:	4b 8b 14 22          	mov    (%r10,%r12,1),%rdx
   4cac9:	48 0f ca             	bswap  %rdx
   4cacc:	c4 e2 fb f7 ea       	shrx   %rax,%rdx,%rbp
   4cad1:	48 09 cd             	or     %rcx,%rbp
   4cad4:	41 bd 3f 00 00 00    	mov    $0x3f,%r13d
   4cada:	41 29 c5             	sub    %eax,%r13d
   4cadd:	44 89 e9             	mov    %r13d,%ecx
   4cae0:	c1 e9 03             	shr    $0x3,%ecx
   4cae3:	49 01 cc             	add    %rcx,%r12
   4cae6:	41 83 e5 f8          	and    $0xfffffff8,%r13d
   4caea:	41 01 c5             	add    %eax,%r13d
   4caed:	b8 32 00 00 00       	mov    $0x32,%eax
   4caf2:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
   4caf7:	eb 65                	jmp    4cb5e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1de>
   4caf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   4cb00:	48 8d 3c 1b          	lea    (%rbx,%rbx,1),%rdi
   4cb04:	49 03 79 08          	add    0x8(%r9),%rdi
   4cb08:	4b 8d 14 36          	lea    (%r14,%r14,1),%rdx
   4cb0c:	4c 89 c6             	mov    %r8,%rsi
   4cb0f:	ff 15 33 67 05 00    	call   *0x56733(%rip)        # a3248 <memcpy@GLIBC_2.14>
   4cb15:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4cb1c:	00 
   4cb1d:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4cb24:	00 
   4cb25:	4c 01 f3             	add    %r14,%rbx
   4cb28:	49 89 59 10          	mov    %rbx,0x10(%r9)
   4cb2c:	45 31 ff             	xor    %r15d,%r15d
   4cb2f:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4cb34:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4cb3b:	00 
   4cb3c:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4cb41:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
   4cb48:	00 
   4cb49:	48 03 44 24 30       	add    0x30(%rsp),%rax
   4cb4e:	4c 29 f0             	sub    %r14,%rax
   4cb51:	4c 89 f9             	mov    %r15,%rcx
   4cb54:	48 83 f8 09          	cmp    $0x9,%rax
   4cb58:	0f 86 9a 09 00 00    	jbe    4d4f8 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xb78>
   4cb5e:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
   4cb65:	00 
   4cb66:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
   4cb6a:	48 83 c2 f6          	add    $0xfffffffffffffff6,%rdx
   4cb6e:	48 81 fa e8 03 00 00 	cmp    $0x3e8,%rdx
   4cb75:	b8 e8 03 00 00       	mov    $0x3e8,%eax
   4cb7a:	48 0f 43 d0          	cmovae %rax,%rdx
   4cb7e:	49 89 ce             	mov    %rcx,%r14
   4cb81:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
   4cb86:	48 89 94 24 c8 00 00 	mov    %rdx,0xc8(%rsp)
   4cb8d:	00 
   4cb8e:	48 39 d1             	cmp    %rdx,%rcx
   4cb91:	76 6d                	jbe    4cc00 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x280>
   4cb93:	4d 89 f7             	mov    %r14,%r15
   4cb96:	49 81 fe e8 03 00 00 	cmp    $0x3e8,%r14
   4cb9d:	76 a2                	jbe    4cb41 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1c1>
   4cb9f:	49 81 fe 13 04 00 00 	cmp    $0x413,%r14
   4cba6:	0f 83 29 25 00 00    	jae    4f0d5 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2755>
   4cbac:	49 8b 01             	mov    (%r9),%rax
   4cbaf:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4cbb3:	48 29 d8             	sub    %rbx,%rax
   4cbb6:	49 39 c6             	cmp    %rax,%r14
   4cbb9:	0f 86 41 ff ff ff    	jbe    4cb00 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x180>
   4cbbf:	b9 02 00 00 00       	mov    $0x2,%ecx
   4cbc4:	41 b8 02 00 00 00    	mov    $0x2,%r8d
   4cbca:	4c 89 cf             	mov    %r9,%rdi
   4cbcd:	48 89 de             	mov    %rbx,%rsi
   4cbd0:	4c 89 f2             	mov    %r14,%rdx
   4cbd3:	e8 b8 ae fe ff       	call   37a90 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs7Z5HuLIcqFl_5mibz2>
   4cbd8:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4cbdf:	00 
   4cbe0:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4cbe7:	00 
   4cbe8:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4cbec:	e9 0f ff ff ff       	jmp    4cb00 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x180>
   4cbf1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   4cbf8:	0f 1f 84 00 00 00 00 
   4cbff:	00 
   4cc00:	49 8d 76 12          	lea    0x12(%r14),%rsi
   4cc04:	48 81 fe 13 04 00 00 	cmp    $0x413,%rsi
   4cc0b:	0f 83 13 24 00 00    	jae    4f024 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x26a4>
   4cc11:	4c 89 e6             	mov    %r12,%rsi
   4cc14:	4f 8d 24 70          	lea    (%r8,%r14,2),%r12
   4cc18:	48 89 e8             	mov    %rbp,%rax
   4cc1b:	48 c1 e8 36          	shr    $0x36,%rax
   4cc1f:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4cc22:	41 89 d7             	mov    %edx,%r15d
   4cc25:	41 c1 ef 1e          	shr    $0x1e,%r15d
   4cc29:	0f 84 57 01 00 00    	je     4cd86 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x406>
   4cc2f:	c4 e2 e9 f7 dd       	shlx   %rdx,%rbp,%rbx
   4cc34:	0f b6 c2             	movzbl %dl,%eax
   4cc37:	41 29 c5             	sub    %eax,%r13d
   4cc3a:	0f b6 c6             	movzbl %dh,%eax
   4cc3d:	66 41 89 04 24       	mov    %ax,(%r12)
   4cc42:	c1 ea 10             	shr    $0x10,%edx
   4cc45:	0f b6 c2             	movzbl %dl,%eax
   4cc48:	66 41 89 44 24 02    	mov    %ax,0x2(%r12)
   4cc4e:	48 89 d8             	mov    %rbx,%rax
   4cc51:	48 c1 e8 36          	shr    $0x36,%rax
   4cc55:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4cc58:	89 d0                	mov    %edx,%eax
   4cc5a:	c1 e8 1e             	shr    $0x1e,%eax
   4cc5d:	0f 84 d9 01 00 00    	je     4ce3c <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x4bc>
   4cc63:	c4 e2 e9 f7 db       	shlx   %rdx,%rbx,%rbx
   4cc68:	0f b6 ca             	movzbl %dl,%ecx
   4cc6b:	41 29 cd             	sub    %ecx,%r13d
   4cc6e:	0f b6 ce             	movzbl %dh,%ecx
   4cc71:	66 43 89 0c 7c       	mov    %cx,(%r12,%r15,2)
   4cc76:	c1 ea 10             	shr    $0x10,%edx
   4cc79:	0f b6 ca             	movzbl %dl,%ecx
   4cc7c:	66 43 89 4c 7c 02    	mov    %cx,0x2(%r12,%r15,2)
   4cc82:	49 01 c7             	add    %rax,%r15
   4cc85:	48 89 d8             	mov    %rbx,%rax
   4cc88:	48 c1 e8 36          	shr    $0x36,%rax
   4cc8c:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4cc8f:	89 d0                	mov    %edx,%eax
   4cc91:	c1 e8 1e             	shr    $0x1e,%eax
   4cc94:	0f 84 55 02 00 00    	je     4ceef <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x56f>
   4cc9a:	c4 e2 e9 f7 db       	shlx   %rdx,%rbx,%rbx
   4cc9f:	0f b6 ca             	movzbl %dl,%ecx
   4cca2:	41 29 cd             	sub    %ecx,%r13d
   4cca5:	0f b6 ce             	movzbl %dh,%ecx
   4cca8:	66 43 89 0c 7c       	mov    %cx,(%r12,%r15,2)
   4ccad:	c1 ea 10             	shr    $0x10,%edx
   4ccb0:	0f b6 ca             	movzbl %dl,%ecx
   4ccb3:	66 43 89 4c 7c 02    	mov    %cx,0x2(%r12,%r15,2)
   4ccb9:	49 01 c7             	add    %rax,%r15
   4ccbc:	48 89 d8             	mov    %rbx,%rax
   4ccbf:	48 c1 e8 36          	shr    $0x36,%rax
   4ccc3:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4ccc6:	89 d0                	mov    %edx,%eax
   4ccc8:	c1 e8 1e             	shr    $0x1e,%eax
   4cccb:	0f 84 d1 02 00 00    	je     4cfa2 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x622>
   4ccd1:	c4 e2 e9 f7 db       	shlx   %rdx,%rbx,%rbx
   4ccd6:	0f b6 ca             	movzbl %dl,%ecx
   4ccd9:	41 29 cd             	sub    %ecx,%r13d
   4ccdc:	0f b6 ce             	movzbl %dh,%ecx
   4ccdf:	66 43 89 0c 7c       	mov    %cx,(%r12,%r15,2)
   4cce4:	c1 ea 10             	shr    $0x10,%edx
   4cce7:	0f b6 ca             	movzbl %dl,%ecx
   4ccea:	66 43 89 4c 7c 02    	mov    %cx,0x2(%r12,%r15,2)
   4ccf0:	49 01 c7             	add    %rax,%r15
   4ccf3:	48 89 d8             	mov    %rbx,%rax
   4ccf6:	48 c1 e8 36          	shr    $0x36,%rax
   4ccfa:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4ccfd:	89 d0                	mov    %edx,%eax
   4ccff:	c1 e8 1e             	shr    $0x1e,%eax
   4cd02:	0f 84 4d 03 00 00    	je     4d055 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x6d5>
   4cd08:	c4 e2 e9 f7 db       	shlx   %rdx,%rbx,%rbx
   4cd0d:	0f b6 ca             	movzbl %dl,%ecx
   4cd10:	41 29 cd             	sub    %ecx,%r13d
   4cd13:	0f b6 ce             	movzbl %dh,%ecx
   4cd16:	66 43 89 0c 7c       	mov    %cx,(%r12,%r15,2)
   4cd1b:	c1 ea 10             	shr    $0x10,%edx
   4cd1e:	0f b6 ca             	movzbl %dl,%ecx
   4cd21:	66 43 89 4c 7c 02    	mov    %cx,0x2(%r12,%r15,2)
   4cd27:	49 01 c7             	add    %rax,%r15
   4cd2a:	44 89 ea             	mov    %r13d,%edx
   4cd2d:	49 89 f4             	mov    %rsi,%r12
   4cd30:	48 83 fe f7          	cmp    $0xfffffffffffffff7,%rsi
   4cd34:	0f 87 d5 03 00 00    	ja     4d10f <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x78f>
   4cd3a:	49 8d 44 24 08       	lea    0x8(%r12),%rax
   4cd3f:	4c 39 d8             	cmp    %r11,%rax
   4cd42:	0f 87 c7 03 00 00    	ja     4d10f <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x78f>
   4cd48:	4b 8b 04 22          	mov    (%r10,%r12,1),%rax
   4cd4c:	48 0f c8             	bswap  %rax
   4cd4f:	c4 e2 eb f7 e8       	shrx   %rdx,%rax,%rbp
   4cd54:	48 09 dd             	or     %rbx,%rbp
   4cd57:	41 bd 3f 00 00 00    	mov    $0x3f,%r13d
   4cd5d:	41 29 d5             	sub    %edx,%r13d
   4cd60:	44 89 e8             	mov    %r13d,%eax
   4cd63:	c1 e8 03             	shr    $0x3,%eax
   4cd66:	49 01 c4             	add    %rax,%r12
   4cd69:	41 83 e5 f8          	and    $0xfffffff8,%r13d
   4cd6d:	41 01 d5             	add    %edx,%r13d
   4cd70:	4d 01 fe             	add    %r15,%r14
   4cd73:	4c 3b b4 24 c8 00 00 	cmp    0xc8(%rsp),%r14
   4cd7a:	00 
   4cd7b:	0f 86 7f fe ff ff    	jbe    4cc00 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x280>
   4cd81:	e9 0d fe ff ff       	jmp    4cb93 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x213>
   4cd86:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4cd8b:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4cd90:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4cd95:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4cd99:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4cd9d:	48 89 fe             	mov    %rdi,%rsi
   4cda0:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   4cda5:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4cdaa:	4d 89 d0             	mov    %r10,%r8
   4cdad:	4d 89 d9             	mov    %r11,%r9
   4cdb0:	e8 eb f7 ff ff       	call   4c5a0 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4cdb5:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   4cdba:	0f b7 44 24 58       	movzwl 0x58(%rsp),%eax
   4cdbf:	48 8d 54 24 5a       	lea    0x5a(%rsp),%rdx
   4cdc4:	0f 10 02             	movups (%rdx),%xmm0
   4cdc7:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4cdcc:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4cdd0:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4cdd5:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
   4cdda:	48 8b 5c 24 78       	mov    0x78(%rsp),%rbx
   4cddf:	44 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13d
   4cde6:	00 
   4cde7:	8b ac 24 84 00 00 00 	mov    0x84(%rsp),%ebp
   4cdee:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4cdf2:	0f 85 13 0c 00 00    	jne    4da0b <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x108b>
   4cdf8:	66 41 89 04 24       	mov    %ax,(%r12)
   4cdfd:	66 3b 84 24 98 00 00 	cmp    0x98(%rsp),%ax
   4ce04:	00 
   4ce05:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4ce0c:	00 
   4ce0d:	0f 84 53 0c 00 00    	je     4da66 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x10e6>
   4ce13:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4ce17:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   4ce1d:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4ce24:	00 
   4ce25:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4ce2a:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4ce31:	00 
   4ce32:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4ce37:	e9 12 fe ff ff       	jmp    4cc4e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2ce>
   4ce3c:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4ce41:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   4ce46:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4ce4b:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4ce4f:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4ce53:	48 89 fe             	mov    %rdi,%rsi
   4ce56:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   4ce5b:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4ce60:	4d 89 d0             	mov    %r10,%r8
   4ce63:	4d 89 d9             	mov    %r11,%r9
   4ce66:	e8 35 f7 ff ff       	call   4c5a0 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4ce6b:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   4ce70:	0f b7 44 24 58       	movzwl 0x58(%rsp),%eax
   4ce75:	48 8d 54 24 5a       	lea    0x5a(%rsp),%rdx
   4ce7a:	0f 10 02             	movups (%rdx),%xmm0
   4ce7d:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4ce82:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4ce86:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4ce8b:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
   4ce90:	48 8b 5c 24 78       	mov    0x78(%rsp),%rbx
   4ce95:	44 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13d
   4ce9c:	00 
   4ce9d:	8b ac 24 84 00 00 00 	mov    0x84(%rsp),%ebp
   4cea4:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4cea8:	0f 85 65 0b 00 00    	jne    4da13 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1093>
   4ceae:	66 43 89 04 7c       	mov    %ax,(%r12,%r15,2)
   4ceb3:	49 ff c7             	inc    %r15
   4ceb6:	66 3b 84 24 98 00 00 	cmp    0x98(%rsp),%ax
   4cebd:	00 
   4cebe:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4cec5:	00 
   4cec6:	0f 84 a5 0b 00 00    	je     4da71 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x10f1>
   4cecc:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4ced0:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4ced7:	00 
   4ced8:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4cedd:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4cee4:	00 
   4cee5:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4ceea:	e9 96 fd ff ff       	jmp    4cc85 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x305>
   4ceef:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4cef4:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   4cef9:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4cefe:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4cf02:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4cf06:	48 89 fe             	mov    %rdi,%rsi
   4cf09:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   4cf0e:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4cf13:	4d 89 d0             	mov    %r10,%r8
   4cf16:	4d 89 d9             	mov    %r11,%r9
   4cf19:	e8 82 f6 ff ff       	call   4c5a0 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4cf1e:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   4cf23:	0f b7 44 24 58       	movzwl 0x58(%rsp),%eax
   4cf28:	48 8d 54 24 5a       	lea    0x5a(%rsp),%rdx
   4cf2d:	0f 10 02             	movups (%rdx),%xmm0
   4cf30:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4cf35:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4cf39:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4cf3e:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
   4cf43:	48 8b 5c 24 78       	mov    0x78(%rsp),%rbx
   4cf48:	44 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13d
   4cf4f:	00 
   4cf50:	8b ac 24 84 00 00 00 	mov    0x84(%rsp),%ebp
   4cf57:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4cf5b:	0f 85 b2 0a 00 00    	jne    4da13 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1093>
   4cf61:	66 43 89 04 7c       	mov    %ax,(%r12,%r15,2)
   4cf66:	49 ff c7             	inc    %r15
   4cf69:	66 3b 84 24 98 00 00 	cmp    0x98(%rsp),%ax
   4cf70:	00 
   4cf71:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4cf78:	00 
   4cf79:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4cf80:	00 
   4cf81:	0f 84 f2 0a 00 00    	je     4da79 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x10f9>
   4cf87:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4cf8b:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4cf90:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4cf97:	00 
   4cf98:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4cf9d:	e9 1a fd ff ff       	jmp    4ccbc <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x33c>
   4cfa2:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4cfa7:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   4cfac:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4cfb1:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4cfb5:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4cfb9:	48 89 fe             	mov    %rdi,%rsi
   4cfbc:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   4cfc1:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4cfc6:	4d 89 d0             	mov    %r10,%r8
   4cfc9:	4d 89 d9             	mov    %r11,%r9
   4cfcc:	e8 cf f5 ff ff       	call   4c5a0 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4cfd1:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   4cfd6:	0f b7 44 24 58       	movzwl 0x58(%rsp),%eax
   4cfdb:	48 8d 54 24 5a       	lea    0x5a(%rsp),%rdx
   4cfe0:	0f 10 02             	movups (%rdx),%xmm0
   4cfe3:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4cfe8:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4cfec:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4cff1:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
   4cff6:	48 8b 5c 24 78       	mov    0x78(%rsp),%rbx
   4cffb:	44 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13d
   4d002:	00 
   4d003:	8b ac 24 84 00 00 00 	mov    0x84(%rsp),%ebp
   4d00a:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4d00e:	0f 85 ff 09 00 00    	jne    4da13 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1093>
   4d014:	66 43 89 04 7c       	mov    %ax,(%r12,%r15,2)
   4d019:	49 ff c7             	inc    %r15
   4d01c:	66 3b 84 24 98 00 00 	cmp    0x98(%rsp),%ax
   4d023:	00 
   4d024:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d02b:	00 
   4d02c:	0f 84 3f 0a 00 00    	je     4da71 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x10f1>
   4d032:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4d036:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d03d:	00 
   4d03e:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4d043:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4d04a:	00 
   4d04b:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4d050:	e9 9e fc ff ff       	jmp    4ccf3 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x373>
   4d055:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4d05a:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   4d05f:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4d064:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4d068:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4d06c:	48 89 fe             	mov    %rdi,%rsi
   4d06f:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   4d074:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4d079:	4d 89 d0             	mov    %r10,%r8
   4d07c:	4d 89 d9             	mov    %r11,%r9
   4d07f:	e8 1c f5 ff ff       	call   4c5a0 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4d084:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   4d089:	0f b7 44 24 58       	movzwl 0x58(%rsp),%eax
   4d08e:	48 8d 54 24 5a       	lea    0x5a(%rsp),%rdx
   4d093:	0f 10 02             	movups (%rdx),%xmm0
   4d096:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4d09b:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4d09f:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4d0a4:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
   4d0a9:	48 8b 5c 24 78       	mov    0x78(%rsp),%rbx
   4d0ae:	8b 94 24 80 00 00 00 	mov    0x80(%rsp),%edx
   4d0b5:	8b ac 24 84 00 00 00 	mov    0x84(%rsp),%ebp
   4d0bc:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4d0c0:	0f 85 4a 09 00 00    	jne    4da10 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1090>
   4d0c6:	66 43 89 04 7c       	mov    %ax,(%r12,%r15,2)
   4d0cb:	49 ff c7             	inc    %r15
   4d0ce:	66 3b 84 24 98 00 00 	cmp    0x98(%rsp),%ax
   4d0d5:	00 
   4d0d6:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d0dd:	00 
   4d0de:	0f 84 8a 09 00 00    	je     4da6e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x10ee>
   4d0e4:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4d0e8:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d0ef:	00 
   4d0f0:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4d0f5:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4d0fc:	00 
   4d0fd:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4d102:	49 89 f4             	mov    %rsi,%r12
   4d105:	48 83 fe f7          	cmp    $0xfffffffffffffff7,%rsi
   4d109:	0f 86 2b fc ff ff    	jbe    4cd3a <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x3ba>
   4d10f:	4c 89 64 24 50       	mov    %r12,0x50(%rsp)
   4d114:	48 89 5c 24 58       	mov    %rbx,0x58(%rsp)
   4d119:	89 54 24 60          	mov    %edx,0x60(%rsp)
   4d11d:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4d121:	89 44 24 64          	mov    %eax,0x64(%rsp)
   4d125:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   4d12a:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
   4d12f:	4c 89 d2             	mov    %r10,%rdx
   4d132:	4c 89 d9             	mov    %r11,%rcx
   4d135:	e8 96 95 ff ff       	call   466d0 <_RNvMNtCs7Z5HuLIcqFl_5mibz24bitsNtB2_3Reg11refill_slow>
   4d13a:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4d13f:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4d146:	00 
   4d147:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4d14c:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d153:	00 
   4d154:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d15b:	00 
   4d15c:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   4d161:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   4d166:	44 8b 6c 24 20       	mov    0x20(%rsp),%r13d
   4d16b:	8b 44 24 24          	mov    0x24(%rsp),%eax
   4d16f:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   4d173:	4d 01 fe             	add    %r15,%r14
   4d176:	4c 3b b4 24 c8 00 00 	cmp    0xc8(%rsp),%r14
   4d17d:	00 
   4d17e:	0f 86 7c fa ff ff    	jbe    4cc00 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x280>
   4d184:	e9 0a fa ff ff       	jmp    4cb93 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x213>
   4d189:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   4d190:	48 b8 77 be 9f 1a 2f 	movabs $0x624dd2f1a9fbe77,%rax
   4d197:	dd 24 06 
   4d19a:	c4 e2 fb f6 c0       	mulx   %rax,%rax,%rax
   4d19f:	48 29 c2             	sub    %rax,%rdx
   4d1a2:	48 d1 ea             	shr    $1,%rdx
   4d1a5:	48 01 c2             	add    %rax,%rdx
   4d1a8:	48 c1 ea 06          	shr    $0x6,%rdx
   4d1ac:	48 89 94 24 98 00 00 	mov    %rdx,0x98(%rsp)
   4d1b3:	00 
   4d1b4:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
   4d1bb:	00 
   4d1bc:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
   4d1c0:	8b 42 10             	mov    0x10(%rdx),%eax
   4d1c3:	8b 52 14             	mov    0x14(%rdx),%edx
   4d1c6:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4d1ca:	0f b7 97 c4 1a 00 00 	movzwl 0x1ac4(%rdi),%edx
   4d1d1:	66 89 54 24 3e       	mov    %dx,0x3e(%rsp)
   4d1d6:	49 83 fc f7          	cmp    $0xfffffffffffffff7,%r12
   4d1da:	0f 87 40 09 00 00    	ja     4db20 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x11a0>
   4d1e0:	49 8d 54 24 08       	lea    0x8(%r12),%rdx
   4d1e5:	4c 39 da             	cmp    %r11,%rdx
   4d1e8:	0f 87 32 09 00 00    	ja     4db20 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x11a0>
   4d1ee:	4b 8b 14 22          	mov    (%r10,%r12,1),%rdx
   4d1f2:	48 0f ca             	bswap  %rdx
   4d1f5:	c4 e2 fb f7 ea       	shrx   %rax,%rdx,%rbp
   4d1fa:	48 09 cd             	or     %rcx,%rbp
   4d1fd:	41 bd 3f 00 00 00    	mov    $0x3f,%r13d
   4d203:	41 29 c5             	sub    %eax,%r13d
   4d206:	44 89 e9             	mov    %r13d,%ecx
   4d209:	c1 e9 03             	shr    $0x3,%ecx
   4d20c:	49 01 cc             	add    %rcx,%r12
   4d20f:	41 83 e5 f8          	and    $0xfffffff8,%r13d
   4d213:	41 01 c5             	add    %eax,%r13d
   4d216:	48 6b 94 24 98 00 00 	imul   $0x32,0x98(%rsp),%rdx
   4d21d:	00 32 
   4d21f:	48 83 fa 0a          	cmp    $0xa,%rdx
   4d223:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
   4d228:	0f 83 cf 09 00 00    	jae    4dbfd <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x127d>
   4d22e:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
   4d233:	48 85 d2             	test   %rdx,%rdx
   4d236:	0f 84 84 02 00 00    	je     4d4c0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xb40>
   4d23c:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   4d241:	48 8d 1c 02          	lea    (%rdx,%rax,1),%rbx
   4d245:	48 83 fa 01          	cmp    $0x1,%rdx
   4d249:	0f 84 57 01 00 00    	je     4d3a6 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xa26>
   4d24f:	4c 8d 73 fe          	lea    -0x2(%rbx),%r14
   4d253:	4c 39 f0             	cmp    %r14,%rax
   4d256:	0f 87 3f 01 00 00    	ja     4d39b <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xa1b>
   4d25c:	48 89 e8             	mov    %rbp,%rax
   4d25f:	48 c1 e8 36          	shr    $0x36,%rax
   4d263:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4d266:	89 d0                	mov    %edx,%eax
   4d268:	c1 e8 1e             	shr    $0x1e,%eax
   4d26b:	0f 84 ba 12 00 00    	je     4e52b <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1bab>
   4d271:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4d276:	0f b6 ca             	movzbl %dl,%ecx
   4d279:	41 29 cd             	sub    %ecx,%r13d
   4d27c:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
   4d281:	44 89 f9             	mov    %r15d,%ecx
   4d284:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4d28a:	0f b6 f6             	movzbl %dh,%esi
   4d28d:	66 41 89 34 48       	mov    %si,(%r8,%rcx,2)
   4d292:	c1 ea 10             	shr    $0x10,%edx
   4d295:	0f b6 d2             	movzbl %dl,%edx
   4d298:	66 41 89 54 48 02    	mov    %dx,0x2(%r8,%rcx,2)
   4d29e:	49 01 c7             	add    %rax,%r15
   4d2a1:	4c 89 7c 24 30       	mov    %r15,0x30(%rsp)
   4d2a6:	4d 39 f7             	cmp    %r14,%r15
   4d2a9:	0f 87 ec 00 00 00    	ja     4d39b <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xa1b>
   4d2af:	48 89 e8             	mov    %rbp,%rax
   4d2b2:	48 c1 e8 36          	shr    $0x36,%rax
   4d2b6:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4d2b9:	89 d0                	mov    %edx,%eax
   4d2bb:	c1 e8 1e             	shr    $0x1e,%eax
   4d2be:	0f 84 93 15 00 00    	je     4e857 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1ed7>
   4d2c4:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4d2c9:	0f b6 ca             	movzbl %dl,%ecx
   4d2cc:	41 29 cd             	sub    %ecx,%r13d
   4d2cf:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
   4d2d4:	44 89 f9             	mov    %r15d,%ecx
   4d2d7:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4d2dd:	0f b6 f6             	movzbl %dh,%esi
   4d2e0:	66 41 89 34 48       	mov    %si,(%r8,%rcx,2)
   4d2e5:	c1 ea 10             	shr    $0x10,%edx
   4d2e8:	0f b6 d2             	movzbl %dl,%edx
   4d2eb:	66 41 89 54 48 02    	mov    %dx,0x2(%r8,%rcx,2)
   4d2f1:	49 01 c7             	add    %rax,%r15
   4d2f4:	4c 89 7c 24 30       	mov    %r15,0x30(%rsp)
   4d2f9:	4d 39 f7             	cmp    %r14,%r15
   4d2fc:	0f 87 99 00 00 00    	ja     4d39b <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xa1b>
   4d302:	48 89 e8             	mov    %rbp,%rax
   4d305:	48 c1 e8 36          	shr    $0x36,%rax
   4d309:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4d30c:	89 d0                	mov    %edx,%eax
   4d30e:	c1 e8 1e             	shr    $0x1e,%eax
   4d311:	0f 84 e0 16 00 00    	je     4e9f7 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2077>
   4d317:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4d31c:	0f b6 ca             	movzbl %dl,%ecx
   4d31f:	41 29 cd             	sub    %ecx,%r13d
   4d322:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
   4d327:	44 89 f9             	mov    %r15d,%ecx
   4d32a:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4d330:	0f b6 f6             	movzbl %dh,%esi
   4d333:	66 41 89 34 48       	mov    %si,(%r8,%rcx,2)
   4d338:	c1 ea 10             	shr    $0x10,%edx
   4d33b:	0f b6 d2             	movzbl %dl,%edx
   4d33e:	66 41 89 54 48 02    	mov    %dx,0x2(%r8,%rcx,2)
   4d344:	49 01 c7             	add    %rax,%r15
   4d347:	4c 89 7c 24 30       	mov    %r15,0x30(%rsp)
   4d34c:	4d 39 f7             	cmp    %r14,%r15
   4d34f:	77 4a                	ja     4d39b <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xa1b>
   4d351:	48 89 e8             	mov    %rbp,%rax
   4d354:	48 c1 e8 36          	shr    $0x36,%rax
   4d358:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4d35b:	89 d0                	mov    %edx,%eax
   4d35d:	c1 e8 1e             	shr    $0x1e,%eax
   4d360:	0f 84 67 18 00 00    	je     4ebcd <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x224d>
   4d366:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4d36b:	0f b6 ca             	movzbl %dl,%ecx
   4d36e:	41 29 cd             	sub    %ecx,%r13d
   4d371:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
   4d376:	44 89 f9             	mov    %r15d,%ecx
   4d379:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4d37f:	0f b6 f6             	movzbl %dh,%esi
   4d382:	66 41 89 34 48       	mov    %si,(%r8,%rcx,2)
   4d387:	c1 ea 10             	shr    $0x10,%edx
   4d38a:	0f b6 d2             	movzbl %dl,%edx
   4d38d:	66 41 89 54 48 02    	mov    %dx,0x2(%r8,%rcx,2)
   4d393:	49 01 c7             	add    %rax,%r15
   4d396:	4c 89 7c 24 30       	mov    %r15,0x30(%rsp)
   4d39b:	4c 39 74 24 30       	cmp    %r14,0x30(%rsp)
   4d3a0:	0f 86 b6 03 00 00    	jbe    4d75c <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xddc>
   4d3a6:	48 ff cb             	dec    %rbx
   4d3a9:	48 39 5c 24 30       	cmp    %rbx,0x30(%rsp)
   4d3ae:	0f 85 93 00 00 00    	jne    4d447 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xac7>
   4d3b4:	41 83 fd 09          	cmp    $0x9,%r13d
   4d3b8:	77 3e                	ja     4d3f8 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xa78>
   4d3ba:	49 83 fc f7          	cmp    $0xfffffffffffffff7,%r12
   4d3be:	0f 87 c6 10 00 00    	ja     4e48a <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1b0a>
   4d3c4:	49 8d 44 24 08       	lea    0x8(%r12),%rax
   4d3c9:	4c 39 d8             	cmp    %r11,%rax
   4d3cc:	0f 87 b8 10 00 00    	ja     4e48a <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1b0a>
   4d3d2:	4b 8b 04 22          	mov    (%r10,%r12,1),%rax
   4d3d6:	48 0f c8             	bswap  %rax
   4d3d9:	c4 e2 93 f7 c0       	shrx   %r13,%rax,%rax
   4d3de:	48 09 c5             	or     %rax,%rbp
   4d3e1:	44 89 e8             	mov    %r13d,%eax
   4d3e4:	83 f0 3f             	xor    $0x3f,%eax
   4d3e7:	89 c1                	mov    %eax,%ecx
   4d3e9:	c1 e9 03             	shr    $0x3,%ecx
   4d3ec:	49 01 cc             	add    %rcx,%r12
   4d3ef:	83 e0 38             	and    $0x38,%eax
   4d3f2:	44 01 e8             	add    %r13d,%eax
   4d3f5:	41 89 c5             	mov    %eax,%r13d
   4d3f8:	48 89 e8             	mov    %rbp,%rax
   4d3fb:	48 c1 e8 36          	shr    $0x36,%rax
   4d3ff:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4d402:	48 81 fa 00 00 00 40 	cmp    $0x40000000,%rdx
   4d409:	0f 82 7b 0f 00 00    	jb     4e38a <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1a0a>
   4d40f:	89 d0                	mov    %edx,%eax
   4d411:	c1 e8 18             	shr    $0x18,%eax
   4d414:	83 e0 1f             	and    $0x1f,%eax
   4d417:	c4 e2 f9 f7 ed       	shlx   %rax,%rbp,%rbp
   4d41c:	41 29 c5             	sub    %eax,%r13d
   4d41f:	0f b6 c6             	movzbl %dh,%eax
   4d422:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
   4d427:	89 d1                	mov    %edx,%ecx
   4d429:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4d42f:	66 41 89 04 48       	mov    %ax,(%r8,%rcx,2)
   4d434:	48 ff c2             	inc    %rdx
   4d437:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
   4d43c:	66 3b 44 24 3e       	cmp    0x3e(%rsp),%ax
   4d441:	0f 84 f1 1b 00 00    	je     4f038 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x26b8>
   4d447:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   4d44c:	48 3d e8 03 00 00    	cmp    $0x3e8,%rax
   4d452:	76 6c                	jbe    4d4c0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xb40>
   4d454:	48 3d 13 04 00 00    	cmp    $0x413,%rax
   4d45a:	49 89 c2             	mov    %rax,%r10
   4d45d:	0f 83 e3 1c 00 00    	jae    4f146 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x27c6>
   4d463:	49 8b 01             	mov    (%r9),%rax
   4d466:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4d46a:	48 29 d8             	sub    %rbx,%rax
   4d46d:	49 39 c2             	cmp    %rax,%r10
   4d470:	0f 87 7e 10 00 00    	ja     4e4f4 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1b74>
   4d476:	48 8d 3c 1b          	lea    (%rbx,%rbx,1),%rdi
   4d47a:	49 03 79 08          	add    0x8(%r9),%rdi
   4d47e:	4b 8d 14 12          	lea    (%r10,%r10,1),%rdx
   4d482:	4c 89 c6             	mov    %r8,%rsi
   4d485:	4d 89 d6             	mov    %r10,%r14
   4d488:	ff 15 ba 5d 05 00    	call   *0x55dba(%rip)        # a3248 <memcpy@GLIBC_2.14>
   4d48e:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d495:	00 
   4d496:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d49d:	00 
   4d49e:	4c 01 f3             	add    %r14,%rbx
   4d4a1:	49 89 59 10          	mov    %rbx,0x10(%r9)
   4d4a5:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
   4d4ac:	00 00 
   4d4ae:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4d4b3:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4d4ba:	00 
   4d4bb:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4d4c0:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
   4d4c7:	00 
   4d4c8:	4c 89 20             	mov    %r12,(%rax)
   4d4cb:	48 89 68 08          	mov    %rbp,0x8(%rax)
   4d4cf:	44 89 68 10          	mov    %r13d,0x10(%rax)
   4d4d3:	8b 4c 24 0c          	mov    0xc(%rsp),%ecx
   4d4d7:	89 48 14             	mov    %ecx,0x14(%rax)
   4d4da:	48 8b 94 24 98 00 00 	mov    0x98(%rsp),%rdx
   4d4e1:	00 
   4d4e2:	48 8b 9c 24 f0 00 00 	mov    0xf0(%rsp),%rbx
   4d4e9:	00 
   4d4ea:	48 29 d3             	sub    %rdx,%rbx
   4d4ed:	0f 85 47 f5 ff ff    	jne    4ca3a <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xba>
   4d4f3:	e9 b8 1a 00 00       	jmp    4efb0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2630>
   4d4f8:	48 85 c0             	test   %rax,%rax
   4d4fb:	0f 84 0d 02 00 00    	je     4d70e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xd8e>
   4d501:	4a 8d 1c 38          	lea    (%rax,%r15,1),%rbx
   4d505:	48 83 f8 01          	cmp    $0x1,%rax
   4d509:	0f 84 05 01 00 00    	je     4d614 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xc94>
   4d50f:	4c 8d 73 fe          	lea    -0x2(%rbx),%r14
   4d513:	4d 39 f7             	cmp    %r14,%r15
   4d516:	0f 87 ef 00 00 00    	ja     4d60b <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xc8b>
   4d51c:	48 89 e8             	mov    %rbp,%rax
   4d51f:	48 c1 e8 36          	shr    $0x36,%rax
   4d523:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4d526:	89 d0                	mov    %edx,%eax
   4d528:	c1 e8 1e             	shr    $0x1e,%eax
   4d52b:	0f 84 02 14 00 00    	je     4e933 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1fb3>
   4d531:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4d536:	0f b6 ca             	movzbl %dl,%ecx
   4d539:	41 29 cd             	sub    %ecx,%r13d
   4d53c:	0f b6 ce             	movzbl %dh,%ecx
   4d53f:	66 43 89 0c 78       	mov    %cx,(%r8,%r15,2)
   4d544:	c1 ea 10             	shr    $0x10,%edx
   4d547:	0f b6 ca             	movzbl %dl,%ecx
   4d54a:	66 43 89 4c 78 02    	mov    %cx,0x2(%r8,%r15,2)
   4d550:	49 01 c7             	add    %rax,%r15
   4d553:	4d 39 f7             	cmp    %r14,%r15
   4d556:	0f 87 af 00 00 00    	ja     4d60b <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xc8b>
   4d55c:	48 89 e8             	mov    %rbp,%rax
   4d55f:	48 c1 e8 36          	shr    $0x36,%rax
   4d563:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4d566:	89 d0                	mov    %edx,%eax
   4d568:	c1 e8 1e             	shr    $0x1e,%eax
   4d56b:	0f 84 98 15 00 00    	je     4eb09 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2189>
   4d571:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4d576:	0f b6 ca             	movzbl %dl,%ecx
   4d579:	41 29 cd             	sub    %ecx,%r13d
   4d57c:	0f b6 ce             	movzbl %dh,%ecx
   4d57f:	66 43 89 0c 78       	mov    %cx,(%r8,%r15,2)
   4d584:	c1 ea 10             	shr    $0x10,%edx
   4d587:	0f b6 ca             	movzbl %dl,%ecx
   4d58a:	66 43 89 4c 78 02    	mov    %cx,0x2(%r8,%r15,2)
   4d590:	49 01 c7             	add    %rax,%r15
   4d593:	4d 39 f7             	cmp    %r14,%r15
   4d596:	77 73                	ja     4d60b <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xc8b>
   4d598:	48 89 e8             	mov    %rbp,%rax
   4d59b:	48 c1 e8 36          	shr    $0x36,%rax
   4d59f:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4d5a2:	89 d0                	mov    %edx,%eax
   4d5a4:	c1 e8 1e             	shr    $0x1e,%eax
   4d5a7:	0f 84 03 17 00 00    	je     4ecb0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2330>
   4d5ad:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4d5b2:	0f b6 ca             	movzbl %dl,%ecx
   4d5b5:	41 29 cd             	sub    %ecx,%r13d
   4d5b8:	0f b6 ce             	movzbl %dh,%ecx
   4d5bb:	66 43 89 0c 78       	mov    %cx,(%r8,%r15,2)
   4d5c0:	c1 ea 10             	shr    $0x10,%edx
   4d5c3:	0f b6 ca             	movzbl %dl,%ecx
   4d5c6:	66 43 89 4c 78 02    	mov    %cx,0x2(%r8,%r15,2)
   4d5cc:	49 01 c7             	add    %rax,%r15
   4d5cf:	4d 39 f7             	cmp    %r14,%r15
   4d5d2:	77 37                	ja     4d60b <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xc8b>
   4d5d4:	48 89 e8             	mov    %rbp,%rax
   4d5d7:	48 c1 e8 36          	shr    $0x36,%rax
   4d5db:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4d5de:	89 d0                	mov    %edx,%eax
   4d5e0:	c1 e8 1e             	shr    $0x1e,%eax
   4d5e3:	0f 84 61 18 00 00    	je     4ee4a <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x24ca>
   4d5e9:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4d5ee:	0f b6 ca             	movzbl %dl,%ecx
   4d5f1:	41 29 cd             	sub    %ecx,%r13d
   4d5f4:	0f b6 ce             	movzbl %dh,%ecx
   4d5f7:	66 43 89 0c 78       	mov    %cx,(%r8,%r15,2)
   4d5fc:	c1 ea 10             	shr    $0x10,%edx
   4d5ff:	0f b6 ca             	movzbl %dl,%ecx
   4d602:	66 43 89 4c 78 02    	mov    %cx,0x2(%r8,%r15,2)
   4d608:	49 01 c7             	add    %rax,%r15
   4d60b:	4d 39 f7             	cmp    %r14,%r15
   4d60e:	0f 86 a8 02 00 00    	jbe    4d8bc <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xf3c>
   4d614:	48 ff cb             	dec    %rbx
   4d617:	49 39 df             	cmp    %rbx,%r15
   4d61a:	0f 85 84 00 00 00    	jne    4d6a4 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xd24>
   4d620:	41 83 fd 09          	cmp    $0x9,%r13d
   4d624:	77 3e                	ja     4d664 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xce4>
   4d626:	49 83 fc f7          	cmp    $0xfffffffffffffff7,%r12
   4d62a:	0f 87 8b 11 00 00    	ja     4e7bb <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1e3b>
   4d630:	49 8d 44 24 08       	lea    0x8(%r12),%rax
   4d635:	4c 39 d8             	cmp    %r11,%rax
   4d638:	0f 87 7d 11 00 00    	ja     4e7bb <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1e3b>
   4d63e:	4b 8b 04 22          	mov    (%r10,%r12,1),%rax
   4d642:	48 0f c8             	bswap  %rax
   4d645:	c4 e2 93 f7 c0       	shrx   %r13,%rax,%rax
   4d64a:	48 09 c5             	or     %rax,%rbp
   4d64d:	44 89 e8             	mov    %r13d,%eax
   4d650:	83 f0 3f             	xor    $0x3f,%eax
   4d653:	89 c1                	mov    %eax,%ecx
   4d655:	c1 e9 03             	shr    $0x3,%ecx
   4d658:	49 01 cc             	add    %rcx,%r12
   4d65b:	83 e0 38             	and    $0x38,%eax
   4d65e:	44 01 e8             	add    %r13d,%eax
   4d661:	41 89 c5             	mov    %eax,%r13d
   4d664:	48 89 e8             	mov    %rbp,%rax
   4d667:	48 c1 e8 36          	shr    $0x36,%rax
   4d66b:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4d66e:	48 81 fa 00 00 00 40 	cmp    $0x40000000,%rdx
   4d675:	0f 82 2a 10 00 00    	jb     4e6a5 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1d25>
   4d67b:	89 d0                	mov    %edx,%eax
   4d67d:	c1 e8 18             	shr    $0x18,%eax
   4d680:	83 e0 1f             	and    $0x1f,%eax
   4d683:	c4 e2 f9 f7 ed       	shlx   %rax,%rbp,%rbp
   4d688:	41 29 c5             	sub    %eax,%r13d
   4d68b:	0f b6 c6             	movzbl %dh,%eax
   4d68e:	66 43 89 04 78       	mov    %ax,(%r8,%r15,2)
   4d693:	49 ff c7             	inc    %r15
   4d696:	66 3b 84 24 98 00 00 	cmp    0x98(%rsp),%ax
   4d69d:	00 
   4d69e:	0f 84 47 1a 00 00    	je     4f0eb <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x276b>
   4d6a4:	49 81 ff e8 03 00 00 	cmp    $0x3e8,%r15
   4d6ab:	76 61                	jbe    4d70e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xd8e>
   4d6ad:	49 81 ff 13 04 00 00 	cmp    $0x413,%r15
   4d6b4:	0f 83 a2 1a 00 00    	jae    4f15c <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x27dc>
   4d6ba:	49 8b 01             	mov    (%r9),%rax
   4d6bd:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4d6c1:	48 29 d8             	sub    %rbx,%rax
   4d6c4:	49 39 c7             	cmp    %rax,%r15
   4d6c7:	0f 87 58 11 00 00    	ja     4e825 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1ea5>
   4d6cd:	48 8d 3c 1b          	lea    (%rbx,%rbx,1),%rdi
   4d6d1:	49 03 79 08          	add    0x8(%r9),%rdi
   4d6d5:	4b 8d 14 3f          	lea    (%r15,%r15,1),%rdx
   4d6d9:	4c 89 c6             	mov    %r8,%rsi
   4d6dc:	ff 15 66 5b 05 00    	call   *0x55b66(%rip)        # a3248 <memcpy@GLIBC_2.14>
   4d6e2:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d6e9:	00 
   4d6ea:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d6f1:	00 
   4d6f2:	4c 01 fb             	add    %r15,%rbx
   4d6f5:	49 89 59 10          	mov    %rbx,0x10(%r9)
   4d6f9:	45 31 ff             	xor    %r15d,%r15d
   4d6fc:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4d701:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4d708:	00 
   4d709:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4d70e:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
   4d715:	00 
   4d716:	4c 89 20             	mov    %r12,(%rax)
   4d719:	48 89 68 08          	mov    %rbp,0x8(%rax)
   4d71d:	44 89 68 10          	mov    %r13d,0x10(%rax)
   4d721:	8b 4c 24 0c          	mov    0xc(%rsp),%ecx
   4d725:	89 48 14             	mov    %ecx,0x14(%rax)
   4d728:	4c 89 7c 24 30       	mov    %r15,0x30(%rsp)
   4d72d:	ba 01 00 00 00       	mov    $0x1,%edx
   4d732:	4d 39 dc             	cmp    %r11,%r12
   4d735:	0f 86 a7 fd ff ff    	jbe    4d4e2 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xb62>
   4d73b:	4a 8d 04 e5 00 00 00 	lea    0x0(,%r12,8),%rax
   4d742:	00 
   4d743:	44 89 e9             	mov    %r13d,%ecx
   4d746:	48 29 c8             	sub    %rcx,%rax
   4d749:	48 3b 84 24 d0 00 00 	cmp    0xd0(%rsp),%rax
   4d750:	00 
   4d751:	0f 86 8b fd ff ff    	jbe    4d4e2 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xb62>
   4d757:	e9 47 19 00 00       	jmp    4f0a3 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2723>
   4d75c:	49 83 fc f7          	cmp    $0xfffffffffffffff7,%r12
   4d760:	0f 87 ba 0c 00 00    	ja     4e420 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1aa0>
   4d766:	49 8d 44 24 08       	lea    0x8(%r12),%rax
   4d76b:	4c 39 d8             	cmp    %r11,%rax
   4d76e:	0f 87 ac 0c 00 00    	ja     4e420 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1aa0>
   4d774:	4b 8b 04 22          	mov    (%r10,%r12,1),%rax
   4d778:	48 0f c8             	bswap  %rax
   4d77b:	c4 e2 93 f7 c0       	shrx   %r13,%rax,%rax
   4d780:	48 09 c5             	or     %rax,%rbp
   4d783:	b8 3f 00 00 00       	mov    $0x3f,%eax
   4d788:	44 29 e8             	sub    %r13d,%eax
   4d78b:	89 c1                	mov    %eax,%ecx
   4d78d:	c1 e9 03             	shr    $0x3,%ecx
   4d790:	49 01 cc             	add    %rcx,%r12
   4d793:	83 e0 f8             	and    $0xfffffff8,%eax
   4d796:	44 01 e8             	add    %r13d,%eax
   4d799:	41 89 c5             	mov    %eax,%r13d
   4d79c:	0f 1f 40 00          	nopl   0x0(%rax)
   4d7a0:	48 89 e8             	mov    %rbp,%rax
   4d7a3:	48 c1 e8 36          	shr    $0x36,%rax
   4d7a7:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4d7aa:	89 d0                	mov    %edx,%eax
   4d7ac:	c1 e8 1e             	shr    $0x1e,%eax
   4d7af:	74 3f                	je     4d7f0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xe70>
   4d7b1:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4d7b6:	0f b6 ca             	movzbl %dl,%ecx
   4d7b9:	41 29 cd             	sub    %ecx,%r13d
   4d7bc:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
   4d7c1:	44 89 f9             	mov    %r15d,%ecx
   4d7c4:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4d7ca:	0f b6 f6             	movzbl %dh,%esi
   4d7cd:	66 41 89 34 48       	mov    %si,(%r8,%rcx,2)
   4d7d2:	c1 ea 10             	shr    $0x10,%edx
   4d7d5:	0f b6 d2             	movzbl %dl,%edx
   4d7d8:	66 41 89 54 48 02    	mov    %dx,0x2(%r8,%rcx,2)
   4d7de:	49 01 c7             	add    %rax,%r15
   4d7e1:	4c 89 7c 24 30       	mov    %r15,0x30(%rsp)
   4d7e6:	4d 39 f7             	cmp    %r14,%r15
   4d7e9:	76 b5                	jbe    4d7a0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xe20>
   4d7eb:	e9 b6 fb ff ff       	jmp    4d3a6 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xa26>
   4d7f0:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4d7f5:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4d7fa:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4d7ff:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4d803:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4d807:	48 89 fe             	mov    %rdi,%rsi
   4d80a:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   4d80f:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4d814:	4d 89 d0             	mov    %r10,%r8
   4d817:	4d 89 d9             	mov    %r11,%r9
   4d81a:	e8 81 ed ff ff       	call   4c5a0 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4d81f:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   4d824:	0f b7 44 24 58       	movzwl 0x58(%rsp),%eax
   4d829:	48 8d 54 24 5a       	lea    0x5a(%rsp),%rdx
   4d82e:	0f 10 02             	movups (%rdx),%xmm0
   4d831:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4d836:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4d83a:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4d83f:	4c 8b 64 24 70       	mov    0x70(%rsp),%r12
   4d844:	48 8b 6c 24 78       	mov    0x78(%rsp),%rbp
   4d849:	44 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13d
   4d850:	00 
   4d851:	8b b4 24 84 00 00 00 	mov    0x84(%rsp),%esi
   4d858:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4d85c:	0f 85 a5 0d 00 00    	jne    4e607 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1c87>
   4d862:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
   4d867:	44 89 f9             	mov    %r15d,%ecx
   4d86a:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4d870:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d877:	00 
   4d878:	66 41 89 04 48       	mov    %ax,(%r8,%rcx,2)
   4d87d:	49 ff c7             	inc    %r15
   4d880:	66 3b 44 24 3e       	cmp    0x3e(%rsp),%ax
   4d885:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d88c:	00 
   4d88d:	0f 84 a4 0d 00 00    	je     4e637 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1cb7>
   4d893:	89 74 24 0c          	mov    %esi,0xc(%rsp)
   4d897:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4d89c:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4d8a3:	00 
   4d8a4:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4d8a9:	4c 89 7c 24 30       	mov    %r15,0x30(%rsp)
   4d8ae:	4d 39 f7             	cmp    %r14,%r15
   4d8b1:	0f 86 e9 fe ff ff    	jbe    4d7a0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xe20>
   4d8b7:	e9 ea fa ff ff       	jmp    4d3a6 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xa26>
   4d8bc:	49 83 fc f7          	cmp    $0xfffffffffffffff7,%r12
   4d8c0:	0f 87 8b 0e 00 00    	ja     4e751 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1dd1>
   4d8c6:	49 8d 44 24 08       	lea    0x8(%r12),%rax
   4d8cb:	4c 39 d8             	cmp    %r11,%rax
   4d8ce:	0f 87 7d 0e 00 00    	ja     4e751 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1dd1>
   4d8d4:	4b 8b 04 22          	mov    (%r10,%r12,1),%rax
   4d8d8:	48 0f c8             	bswap  %rax
   4d8db:	c4 e2 93 f7 c0       	shrx   %r13,%rax,%rax
   4d8e0:	48 09 c5             	or     %rax,%rbp
   4d8e3:	b8 3f 00 00 00       	mov    $0x3f,%eax
   4d8e8:	44 29 e8             	sub    %r13d,%eax
   4d8eb:	89 c1                	mov    %eax,%ecx
   4d8ed:	c1 e9 03             	shr    $0x3,%ecx
   4d8f0:	49 01 cc             	add    %rcx,%r12
   4d8f3:	83 e0 f8             	and    $0xfffffff8,%eax
   4d8f6:	44 01 e8             	add    %r13d,%eax
   4d8f9:	41 89 c5             	mov    %eax,%r13d
   4d8fc:	0f 1f 40 00          	nopl   0x0(%rax)
   4d900:	48 89 e8             	mov    %rbp,%rax
   4d903:	48 c1 e8 36          	shr    $0x36,%rax
   4d907:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4d90a:	89 d0                	mov    %edx,%eax
   4d90c:	c1 e8 1e             	shr    $0x1e,%eax
   4d90f:	74 35                	je     4d946 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xfc6>
   4d911:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4d916:	0f b6 ca             	movzbl %dl,%ecx
   4d919:	41 29 cd             	sub    %ecx,%r13d
   4d91c:	44 89 f9             	mov    %r15d,%ecx
   4d91f:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4d925:	0f b6 f6             	movzbl %dh,%esi
   4d928:	66 41 89 34 48       	mov    %si,(%r8,%rcx,2)
   4d92d:	c1 ea 10             	shr    $0x10,%edx
   4d930:	0f b6 d2             	movzbl %dl,%edx
   4d933:	66 41 89 54 48 02    	mov    %dx,0x2(%r8,%rcx,2)
   4d939:	49 01 c7             	add    %rax,%r15
   4d93c:	4d 39 f7             	cmp    %r14,%r15
   4d93f:	76 bf                	jbe    4d900 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xf80>
   4d941:	e9 ce fc ff ff       	jmp    4d614 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xc94>
   4d946:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4d94b:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4d950:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4d955:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4d959:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4d95d:	48 89 fe             	mov    %rdi,%rsi
   4d960:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   4d965:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4d96a:	4d 89 d0             	mov    %r10,%r8
   4d96d:	4d 89 d9             	mov    %r11,%r9
   4d970:	e8 2b ec ff ff       	call   4c5a0 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4d975:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   4d97a:	0f b7 44 24 58       	movzwl 0x58(%rsp),%eax
   4d97f:	48 8d 54 24 5a       	lea    0x5a(%rsp),%rdx
   4d984:	0f 10 02             	movups (%rdx),%xmm0
   4d987:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4d98c:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4d990:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4d995:	4c 8b 64 24 70       	mov    0x70(%rsp),%r12
   4d99a:	48 8b 6c 24 78       	mov    0x78(%rsp),%rbp
   4d99f:	44 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13d
   4d9a6:	00 
   4d9a7:	8b 94 24 84 00 00 00 	mov    0x84(%rsp),%edx
   4d9ae:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4d9b2:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4d9b6:	0f 85 04 15 00 00    	jne    4eec0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2540>
   4d9bc:	44 89 f9             	mov    %r15d,%ecx
   4d9bf:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4d9c5:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d9cc:	00 
   4d9cd:	66 41 89 04 48       	mov    %ax,(%r8,%rcx,2)
   4d9d2:	49 ff c7             	inc    %r15
   4d9d5:	66 3b 84 24 98 00 00 	cmp    0x98(%rsp),%ax
   4d9dc:	00 
   4d9dd:	0f 84 f0 10 00 00    	je     4ead3 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2153>
   4d9e3:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d9ea:	00 
   4d9eb:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4d9f0:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4d9f7:	00 
   4d9f8:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4d9fd:	4d 39 f7             	cmp    %r14,%r15
   4da00:	0f 86 fa fe ff ff    	jbe    4d900 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xf80>
   4da06:	e9 09 fc ff ff       	jmp    4d614 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xc94>
   4da0b:	45 31 ff             	xor    %r15d,%r15d
   4da0e:	eb 03                	jmp    4da13 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1093>
   4da10:	41 89 d5             	mov    %edx,%r13d
   4da13:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4da1a:	00 
   4da1b:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4da22:	00 
   4da23:	89 c2                	mov    %eax,%edx
   4da25:	c1 ea 08             	shr    $0x8,%edx
   4da28:	89 94 24 8c 00 00 00 	mov    %edx,0x8c(%rsp)
   4da2f:	48 8b 54 24 1e       	mov    0x1e(%rsp),%rdx
   4da34:	48 89 94 24 ae 00 00 	mov    %rdx,0xae(%rsp)
   4da3b:	00 
   4da3c:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
   4da41:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   4da48:	00 
   4da49:	4d 01 f7             	add    %r14,%r15
   4da4c:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4da51:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4da58:	00 
   4da59:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4da5e:	49 89 f4             	mov    %rsi,%r12
   4da61:	e9 88 00 00 00       	jmp    4daee <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x116e>
   4da66:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   4da6c:	eb 03                	jmp    4da71 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x10f1>
   4da6e:	41 89 d5             	mov    %edx,%r13d
   4da71:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4da78:	00 
   4da79:	49 89 f4             	mov    %rsi,%r12
   4da7c:	4d 01 f7             	add    %r14,%r15
   4da7f:	49 81 ff 13 04 00 00 	cmp    $0x413,%r15
   4da86:	0f 83 fc 16 00 00    	jae    4f188 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2808>
   4da8c:	49 8b 01             	mov    (%r9),%rax
   4da8f:	4d 8b 71 10          	mov    0x10(%r9),%r14
   4da93:	4c 29 f0             	sub    %r14,%rax
   4da96:	49 39 c7             	cmp    %rax,%r15
   4da99:	0f 87 d5 12 00 00    	ja     4ed74 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x23f4>
   4da9f:	4d 85 ff             	test   %r15,%r15
   4daa2:	74 25                	je     4dac9 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1149>
   4daa4:	4b 8d 3c 36          	lea    (%r14,%r14,1),%rdi
   4daa8:	49 03 79 08          	add    0x8(%r9),%rdi
   4daac:	4b 8d 14 3f          	lea    (%r15,%r15,1),%rdx
   4dab0:	4c 89 c6             	mov    %r8,%rsi
   4dab3:	ff 15 8f 57 05 00    	call   *0x5578f(%rip)        # a3248 <memcpy@GLIBC_2.14>
   4dab9:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4dac0:	00 
   4dac1:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4dac8:	00 
   4dac9:	4d 01 fe             	add    %r15,%r14
   4dacc:	4d 89 71 10          	mov    %r14,0x10(%r9)
   4dad0:	b0 01                	mov    $0x1,%al
   4dad2:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
   4dad9:	45 31 ff             	xor    %r15d,%r15d
   4dadc:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4dae1:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4dae8:	00 
   4dae9:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4daee:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
   4daf5:	00 
   4daf6:	4c 89 22             	mov    %r12,(%rdx)
   4daf9:	48 89 5a 08          	mov    %rbx,0x8(%rdx)
   4dafd:	44 89 6a 10          	mov    %r13d,0x10(%rdx)
   4db01:	89 6a 14             	mov    %ebp,0x14(%rdx)
   4db04:	4c 89 7c 24 30       	mov    %r15,0x30(%rsp)
   4db09:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4db0d:	0f 85 64 17 00 00    	jne    4f277 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x28f7>
   4db13:	a8 01                	test   $0x1,%al
   4db15:	0f 84 12 fc ff ff    	je     4d72d <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xdad>
   4db1b:	e9 f3 15 00 00       	jmp    4f113 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2793>
   4db20:	4c 89 64 24 50       	mov    %r12,0x50(%rsp)
   4db25:	48 89 4c 24 58       	mov    %rcx,0x58(%rsp)
   4db2a:	89 44 24 60          	mov    %eax,0x60(%rsp)
   4db2e:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4db32:	89 44 24 64          	mov    %eax,0x64(%rsp)
   4db36:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   4db3b:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
   4db40:	4c 89 d2             	mov    %r10,%rdx
   4db43:	4c 89 d9             	mov    %r11,%rcx
   4db46:	e8 85 8b ff ff       	call   466d0 <_RNvMNtCs7Z5HuLIcqFl_5mibz24bitsNtB2_3Reg11refill_slow>
   4db4b:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4db50:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4db57:	00 
   4db58:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4db5d:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4db64:	00 
   4db65:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4db6c:	00 
   4db6d:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   4db72:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   4db77:	44 8b 6c 24 20       	mov    0x20(%rsp),%r13d
   4db7c:	8b 44 24 24          	mov    0x24(%rsp),%eax
   4db80:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   4db84:	48 6b 94 24 98 00 00 	imul   $0x32,0x98(%rsp),%rdx
   4db8b:	00 32 
   4db8d:	48 83 fa 0a          	cmp    $0xa,%rdx
   4db91:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
   4db96:	73 65                	jae    4dbfd <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x127d>
   4db98:	e9 91 f6 ff ff       	jmp    4d22e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x8ae>
   4db9d:	0f 1f 00             	nopl   (%rax)
   4dba0:	48 8d 3c 1b          	lea    (%rbx,%rbx,1),%rdi
   4dba4:	49 03 79 08          	add    0x8(%r9),%rdi
   4dba8:	4b 8d 14 3f          	lea    (%r15,%r15,1),%rdx
   4dbac:	4c 89 c6             	mov    %r8,%rsi
   4dbaf:	ff 15 93 56 05 00    	call   *0x55693(%rip)        # a3248 <memcpy@GLIBC_2.14>
   4dbb5:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4dbbc:	00 
   4dbbd:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4dbc4:	00 
   4dbc5:	4c 01 fb             	add    %r15,%rbx
   4dbc8:	49 89 59 10          	mov    %rbx,0x10(%r9)
   4dbcc:	31 c0                	xor    %eax,%eax
   4dbce:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4dbd3:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4dbda:	00 
   4dbdb:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4dbe0:	48 8b 94 24 c0 00 00 	mov    0xc0(%rsp),%rdx
   4dbe7:	00 
   4dbe8:	48 03 54 24 30       	add    0x30(%rsp),%rdx
   4dbed:	4c 29 fa             	sub    %r15,%rdx
   4dbf0:	48 89 c1             	mov    %rax,%rcx
   4dbf3:	48 83 fa 09          	cmp    $0x9,%rdx
   4dbf7:	0f 86 31 f6 ff ff    	jbe    4d22e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x8ae>
   4dbfd:	48 89 94 24 c0 00 00 	mov    %rdx,0xc0(%rsp)
   4dc04:	00 
   4dc05:	48 01 ca             	add    %rcx,%rdx
   4dc08:	48 83 c2 f6          	add    $0xfffffffffffffff6,%rdx
   4dc0c:	48 81 fa e8 03 00 00 	cmp    $0x3e8,%rdx
   4dc13:	b8 e8 03 00 00       	mov    $0x3e8,%eax
   4dc18:	48 0f 43 d0          	cmovae %rax,%rdx
   4dc1c:	49 89 cf             	mov    %rcx,%r15
   4dc1f:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
   4dc24:	48 89 94 24 c8 00 00 	mov    %rdx,0xc8(%rsp)
   4dc2b:	00 
   4dc2c:	48 39 d1             	cmp    %rdx,%rcx
   4dc2f:	76 5f                	jbe    4dc90 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1310>
   4dc31:	4c 89 f8             	mov    %r15,%rax
   4dc34:	49 81 ff e8 03 00 00 	cmp    $0x3e8,%r15
   4dc3b:	76 a3                	jbe    4dbe0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1260>
   4dc3d:	49 81 ff 13 04 00 00 	cmp    $0x413,%r15
   4dc44:	0f 83 43 14 00 00    	jae    4f08d <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x270d>
   4dc4a:	49 8b 01             	mov    (%r9),%rax
   4dc4d:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4dc51:	48 29 d8             	sub    %rbx,%rax
   4dc54:	49 39 c7             	cmp    %rax,%r15
   4dc57:	0f 86 43 ff ff ff    	jbe    4dba0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1220>
   4dc5d:	b9 02 00 00 00       	mov    $0x2,%ecx
   4dc62:	41 b8 02 00 00 00    	mov    $0x2,%r8d
   4dc68:	4c 89 cf             	mov    %r9,%rdi
   4dc6b:	48 89 de             	mov    %rbx,%rsi
   4dc6e:	4c 89 fa             	mov    %r15,%rdx
   4dc71:	e8 1a 9e fe ff       	call   37a90 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs7Z5HuLIcqFl_5mibz2>
   4dc76:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4dc7d:	00 
   4dc7e:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4dc85:	00 
   4dc86:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4dc8a:	e9 11 ff ff ff       	jmp    4dba0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1220>
   4dc8f:	90                   	nop
   4dc90:	49 8d 77 12          	lea    0x12(%r15),%rsi
   4dc94:	48 81 fe 13 04 00 00 	cmp    $0x413,%rsi
   4dc9b:	0f 83 6f 13 00 00    	jae    4f010 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2690>
   4dca1:	4c 89 e6             	mov    %r12,%rsi
   4dca4:	4f 8d 24 78          	lea    (%r8,%r15,2),%r12
   4dca8:	48 89 e8             	mov    %rbp,%rax
   4dcab:	48 c1 e8 36          	shr    $0x36,%rax
   4dcaf:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4dcb2:	89 d3                	mov    %edx,%ebx
   4dcb4:	c1 eb 1e             	shr    $0x1e,%ebx
   4dcb7:	0f 84 57 01 00 00    	je     4de14 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1494>
   4dcbd:	c4 62 e9 f7 f5       	shlx   %rdx,%rbp,%r14
   4dcc2:	0f b6 c2             	movzbl %dl,%eax
   4dcc5:	41 29 c5             	sub    %eax,%r13d
   4dcc8:	0f b6 c6             	movzbl %dh,%eax
   4dccb:	66 41 89 04 24       	mov    %ax,(%r12)
   4dcd0:	c1 ea 10             	shr    $0x10,%edx
   4dcd3:	0f b6 c2             	movzbl %dl,%eax
   4dcd6:	66 41 89 44 24 02    	mov    %ax,0x2(%r12)
   4dcdc:	4c 89 f0             	mov    %r14,%rax
   4dcdf:	48 c1 e8 36          	shr    $0x36,%rax
   4dce3:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4dce6:	89 d0                	mov    %edx,%eax
   4dce8:	c1 e8 1e             	shr    $0x1e,%eax
   4dceb:	0f 84 d5 01 00 00    	je     4dec6 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1546>
   4dcf1:	c4 42 e9 f7 f6       	shlx   %rdx,%r14,%r14
   4dcf6:	0f b6 ca             	movzbl %dl,%ecx
   4dcf9:	41 29 cd             	sub    %ecx,%r13d
   4dcfc:	0f b6 ce             	movzbl %dh,%ecx
   4dcff:	66 41 89 0c 5c       	mov    %cx,(%r12,%rbx,2)
   4dd04:	c1 ea 10             	shr    $0x10,%edx
   4dd07:	0f b6 ca             	movzbl %dl,%ecx
   4dd0a:	66 41 89 4c 5c 02    	mov    %cx,0x2(%r12,%rbx,2)
   4dd10:	48 01 c3             	add    %rax,%rbx
   4dd13:	4c 89 f0             	mov    %r14,%rax
   4dd16:	48 c1 e8 36          	shr    $0x36,%rax
   4dd1a:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4dd1d:	89 d0                	mov    %edx,%eax
   4dd1f:	c1 e8 1e             	shr    $0x1e,%eax
   4dd22:	0f 84 4e 02 00 00    	je     4df76 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x15f6>
   4dd28:	c4 42 e9 f7 f6       	shlx   %rdx,%r14,%r14
   4dd2d:	0f b6 ca             	movzbl %dl,%ecx
   4dd30:	41 29 cd             	sub    %ecx,%r13d
   4dd33:	0f b6 ce             	movzbl %dh,%ecx
   4dd36:	66 41 89 0c 5c       	mov    %cx,(%r12,%rbx,2)
   4dd3b:	c1 ea 10             	shr    $0x10,%edx
   4dd3e:	0f b6 ca             	movzbl %dl,%ecx
   4dd41:	66 41 89 4c 5c 02    	mov    %cx,0x2(%r12,%rbx,2)
   4dd47:	48 01 c3             	add    %rax,%rbx
   4dd4a:	4c 89 f0             	mov    %r14,%rax
   4dd4d:	48 c1 e8 36          	shr    $0x36,%rax
   4dd51:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4dd54:	89 d0                	mov    %edx,%eax
   4dd56:	c1 e8 1e             	shr    $0x1e,%eax
   4dd59:	0f 84 c7 02 00 00    	je     4e026 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x16a6>
   4dd5f:	c4 42 e9 f7 f6       	shlx   %rdx,%r14,%r14
   4dd64:	0f b6 ca             	movzbl %dl,%ecx
   4dd67:	41 29 cd             	sub    %ecx,%r13d
   4dd6a:	0f b6 ce             	movzbl %dh,%ecx
   4dd6d:	66 41 89 0c 5c       	mov    %cx,(%r12,%rbx,2)
   4dd72:	c1 ea 10             	shr    $0x10,%edx
   4dd75:	0f b6 ca             	movzbl %dl,%ecx
   4dd78:	66 41 89 4c 5c 02    	mov    %cx,0x2(%r12,%rbx,2)
   4dd7e:	48 01 c3             	add    %rax,%rbx
   4dd81:	4c 89 f0             	mov    %r14,%rax
   4dd84:	48 c1 e8 36          	shr    $0x36,%rax
   4dd88:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4dd8b:	89 d0                	mov    %edx,%eax
   4dd8d:	c1 e8 1e             	shr    $0x1e,%eax
   4dd90:	0f 84 40 03 00 00    	je     4e0d6 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1756>
   4dd96:	c4 42 e9 f7 f6       	shlx   %rdx,%r14,%r14
   4dd9b:	0f b6 ca             	movzbl %dl,%ecx
   4dd9e:	41 29 cd             	sub    %ecx,%r13d
   4dda1:	0f b6 ce             	movzbl %dh,%ecx
   4dda4:	66 41 89 0c 5c       	mov    %cx,(%r12,%rbx,2)
   4dda9:	c1 ea 10             	shr    $0x10,%edx
   4ddac:	0f b6 ca             	movzbl %dl,%ecx
   4ddaf:	66 41 89 4c 5c 02    	mov    %cx,0x2(%r12,%rbx,2)
   4ddb5:	48 01 c3             	add    %rax,%rbx
   4ddb8:	44 89 ea             	mov    %r13d,%edx
   4ddbb:	49 89 f4             	mov    %rsi,%r12
   4ddbe:	48 83 fe f7          	cmp    $0xfffffffffffffff7,%rsi
   4ddc2:	0f 87 c5 03 00 00    	ja     4e18d <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x180d>
   4ddc8:	49 8d 44 24 08       	lea    0x8(%r12),%rax
   4ddcd:	4c 39 d8             	cmp    %r11,%rax
   4ddd0:	0f 87 b7 03 00 00    	ja     4e18d <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x180d>
   4ddd6:	4b 8b 04 22          	mov    (%r10,%r12,1),%rax
   4ddda:	48 0f c8             	bswap  %rax
   4dddd:	c4 e2 eb f7 e8       	shrx   %rdx,%rax,%rbp
   4dde2:	4c 09 f5             	or     %r14,%rbp
   4dde5:	41 bd 3f 00 00 00    	mov    $0x3f,%r13d
   4ddeb:	41 29 d5             	sub    %edx,%r13d
   4ddee:	44 89 e8             	mov    %r13d,%eax
   4ddf1:	c1 e8 03             	shr    $0x3,%eax
   4ddf4:	49 01 c4             	add    %rax,%r12
   4ddf7:	41 83 e5 f8          	and    $0xfffffff8,%r13d
   4ddfb:	41 01 d5             	add    %edx,%r13d
   4ddfe:	49 01 df             	add    %rbx,%r15
   4de01:	4c 3b bc 24 c8 00 00 	cmp    0xc8(%rsp),%r15
   4de08:	00 
   4de09:	0f 86 81 fe ff ff    	jbe    4dc90 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1310>
   4de0f:	e9 1d fe ff ff       	jmp    4dc31 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x12b1>
   4de14:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4de19:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4de1e:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4de23:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4de27:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4de2b:	48 89 fe             	mov    %rdi,%rsi
   4de2e:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   4de33:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4de38:	4d 89 d0             	mov    %r10,%r8
   4de3b:	4d 89 d9             	mov    %r11,%r9
   4de3e:	e8 5d e7 ff ff       	call   4c5a0 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4de43:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   4de48:	0f b7 44 24 58       	movzwl 0x58(%rsp),%eax
   4de4d:	48 8d 54 24 5a       	lea    0x5a(%rsp),%rdx
   4de52:	0f 10 02             	movups (%rdx),%xmm0
   4de55:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4de5a:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4de5e:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4de63:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
   4de68:	4c 8b 74 24 78       	mov    0x78(%rsp),%r14
   4de6d:	44 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13d
   4de74:	00 
   4de75:	8b ac 24 84 00 00 00 	mov    0x84(%rsp),%ebp
   4de7c:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4de80:	0f 85 81 03 00 00    	jne    4e207 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1887>
   4de86:	66 41 89 04 24       	mov    %ax,(%r12)
   4de8b:	66 3b 44 24 3e       	cmp    0x3e(%rsp),%ax
   4de90:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4de97:	00 
   4de98:	0f 84 c3 03 00 00    	je     4e261 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x18e1>
   4de9e:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4dea2:	bb 01 00 00 00       	mov    $0x1,%ebx
   4dea7:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4deae:	00 
   4deaf:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4deb4:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4debb:	00 
   4debc:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4dec1:	e9 16 fe ff ff       	jmp    4dcdc <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x135c>
   4dec6:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4decb:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   4ded0:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4ded5:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4ded9:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4dedd:	48 89 fe             	mov    %rdi,%rsi
   4dee0:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   4dee5:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4deea:	4d 89 d0             	mov    %r10,%r8
   4deed:	4d 89 d9             	mov    %r11,%r9
   4def0:	e8 ab e6 ff ff       	call   4c5a0 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4def5:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   4defa:	0f b7 44 24 58       	movzwl 0x58(%rsp),%eax
   4deff:	48 8d 54 24 5a       	lea    0x5a(%rsp),%rdx
   4df04:	0f 10 02             	movups (%rdx),%xmm0
   4df07:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4df0c:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4df10:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4df15:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
   4df1a:	4c 8b 74 24 78       	mov    0x78(%rsp),%r14
   4df1f:	44 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13d
   4df26:	00 
   4df27:	8b ac 24 84 00 00 00 	mov    0x84(%rsp),%ebp
   4df2e:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4df32:	0f 85 d6 02 00 00    	jne    4e20e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x188e>
   4df38:	66 41 89 04 5c       	mov    %ax,(%r12,%rbx,2)
   4df3d:	48 ff c3             	inc    %rbx
   4df40:	66 3b 44 24 3e       	cmp    0x3e(%rsp),%ax
   4df45:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4df4c:	00 
   4df4d:	0f 84 18 03 00 00    	je     4e26b <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x18eb>
   4df53:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4df57:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4df5e:	00 
   4df5f:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4df64:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4df6b:	00 
   4df6c:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4df71:	e9 9d fd ff ff       	jmp    4dd13 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1393>
   4df76:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4df7b:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   4df80:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4df85:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4df89:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4df8d:	48 89 fe             	mov    %rdi,%rsi
   4df90:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   4df95:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4df9a:	4d 89 d0             	mov    %r10,%r8
   4df9d:	4d 89 d9             	mov    %r11,%r9
   4dfa0:	e8 fb e5 ff ff       	call   4c5a0 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4dfa5:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   4dfaa:	0f b7 44 24 58       	movzwl 0x58(%rsp),%eax
   4dfaf:	48 8d 54 24 5a       	lea    0x5a(%rsp),%rdx
   4dfb4:	0f 10 02             	movups (%rdx),%xmm0
   4dfb7:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4dfbc:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4dfc0:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4dfc5:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
   4dfca:	4c 8b 74 24 78       	mov    0x78(%rsp),%r14
   4dfcf:	44 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13d
   4dfd6:	00 
   4dfd7:	8b ac 24 84 00 00 00 	mov    0x84(%rsp),%ebp
   4dfde:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4dfe2:	0f 85 26 02 00 00    	jne    4e20e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x188e>
   4dfe8:	66 41 89 04 5c       	mov    %ax,(%r12,%rbx,2)
   4dfed:	48 ff c3             	inc    %rbx
   4dff0:	66 3b 44 24 3e       	cmp    0x3e(%rsp),%ax
   4dff5:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4dffc:	00 
   4dffd:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4e004:	00 
   4e005:	0f 84 68 02 00 00    	je     4e273 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x18f3>
   4e00b:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4e00f:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4e014:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4e01b:	00 
   4e01c:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4e021:	e9 24 fd ff ff       	jmp    4dd4a <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x13ca>
   4e026:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4e02b:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   4e030:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4e035:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4e039:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4e03d:	48 89 fe             	mov    %rdi,%rsi
   4e040:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   4e045:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4e04a:	4d 89 d0             	mov    %r10,%r8
   4e04d:	4d 89 d9             	mov    %r11,%r9
   4e050:	e8 4b e5 ff ff       	call   4c5a0 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4e055:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   4e05a:	0f b7 44 24 58       	movzwl 0x58(%rsp),%eax
   4e05f:	48 8d 54 24 5a       	lea    0x5a(%rsp),%rdx
   4e064:	0f 10 02             	movups (%rdx),%xmm0
   4e067:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4e06c:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4e070:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4e075:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
   4e07a:	4c 8b 74 24 78       	mov    0x78(%rsp),%r14
   4e07f:	44 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13d
   4e086:	00 
   4e087:	8b ac 24 84 00 00 00 	mov    0x84(%rsp),%ebp
   4e08e:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4e092:	0f 85 76 01 00 00    	jne    4e20e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x188e>
   4e098:	66 41 89 04 5c       	mov    %ax,(%r12,%rbx,2)
   4e09d:	48 ff c3             	inc    %rbx
   4e0a0:	66 3b 44 24 3e       	cmp    0x3e(%rsp),%ax
   4e0a5:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4e0ac:	00 
   4e0ad:	0f 84 b8 01 00 00    	je     4e26b <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x18eb>
   4e0b3:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4e0b7:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4e0be:	00 
   4e0bf:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4e0c4:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4e0cb:	00 
   4e0cc:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4e0d1:	e9 ab fc ff ff       	jmp    4dd81 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1401>
   4e0d6:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4e0db:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   4e0e0:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4e0e5:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4e0e9:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4e0ed:	48 89 fe             	mov    %rdi,%rsi
   4e0f0:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   4e0f5:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4e0fa:	4d 89 d0             	mov    %r10,%r8
   4e0fd:	4d 89 d9             	mov    %r11,%r9
   4e100:	e8 9b e4 ff ff       	call   4c5a0 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4e105:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   4e10a:	0f b7 44 24 58       	movzwl 0x58(%rsp),%eax
   4e10f:	48 8d 54 24 5a       	lea    0x5a(%rsp),%rdx
   4e114:	0f 10 02             	movups (%rdx),%xmm0
   4e117:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4e11c:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4e120:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4e125:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
   4e12a:	4c 8b 74 24 78       	mov    0x78(%rsp),%r14
   4e12f:	8b 94 24 80 00 00 00 	mov    0x80(%rsp),%edx
   4e136:	8b ac 24 84 00 00 00 	mov    0x84(%rsp),%ebp
   4e13d:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4e141:	0f 85 c4 00 00 00    	jne    4e20b <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x188b>
   4e147:	66 41 89 04 5c       	mov    %ax,(%r12,%rbx,2)
   4e14c:	48 ff c3             	inc    %rbx
   4e14f:	66 3b 44 24 3e       	cmp    0x3e(%rsp),%ax
   4e154:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4e15b:	00 
   4e15c:	0f 84 06 01 00 00    	je     4e268 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x18e8>
   4e162:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4e166:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4e16d:	00 
   4e16e:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4e173:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4e17a:	00 
   4e17b:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4e180:	49 89 f4             	mov    %rsi,%r12
   4e183:	48 83 fe f7          	cmp    $0xfffffffffffffff7,%rsi
   4e187:	0f 86 3b fc ff ff    	jbe    4ddc8 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1448>
   4e18d:	4c 89 64 24 50       	mov    %r12,0x50(%rsp)
   4e192:	4c 89 74 24 58       	mov    %r14,0x58(%rsp)
   4e197:	89 54 24 60          	mov    %edx,0x60(%rsp)
   4e19b:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4e19f:	89 44 24 64          	mov    %eax,0x64(%rsp)
   4e1a3:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   4e1a8:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
   4e1ad:	4c 89 d2             	mov    %r10,%rdx
   4e1b0:	4c 89 d9             	mov    %r11,%rcx
   4e1b3:	e8 18 85 ff ff       	call   466d0 <_RNvMNtCs7Z5HuLIcqFl_5mibz24bitsNtB2_3Reg11refill_slow>
   4e1b8:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4e1bd:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4e1c4:	00 
   4e1c5:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4e1ca:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4e1d1:	00 
   4e1d2:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4e1d9:	00 
   4e1da:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   4e1df:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   4e1e4:	44 8b 6c 24 20       	mov    0x20(%rsp),%r13d
   4e1e9:	8b 44 24 24          	mov    0x24(%rsp),%eax
   4e1ed:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   4e1f1:	49 01 df             	add    %rbx,%r15
   4e1f4:	4c 3b bc 24 c8 00 00 	cmp    0xc8(%rsp),%r15
   4e1fb:	00 
   4e1fc:	0f 86 8e fa ff ff    	jbe    4dc90 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1310>
   4e202:	e9 2a fa ff ff       	jmp    4dc31 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x12b1>
   4e207:	31 db                	xor    %ebx,%ebx
   4e209:	eb 03                	jmp    4e20e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x188e>
   4e20b:	41 89 d5             	mov    %edx,%r13d
   4e20e:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4e215:	00 
   4e216:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4e21d:	00 
   4e21e:	89 c2                	mov    %eax,%edx
   4e220:	c1 ea 08             	shr    $0x8,%edx
   4e223:	89 94 24 8c 00 00 00 	mov    %edx,0x8c(%rsp)
   4e22a:	48 8b 54 24 1e       	mov    0x1e(%rsp),%rdx
   4e22f:	48 89 94 24 ae 00 00 	mov    %rdx,0xae(%rsp)
   4e236:	00 
   4e237:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
   4e23c:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   4e243:	00 
   4e244:	4c 01 fb             	add    %r15,%rbx
   4e247:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4e24c:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4e253:	00 
   4e254:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4e259:	49 89 f4             	mov    %rsi,%r12
   4e25c:	e9 86 00 00 00       	jmp    4e2e7 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1967>
   4e261:	bb 01 00 00 00       	mov    $0x1,%ebx
   4e266:	eb 03                	jmp    4e26b <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x18eb>
   4e268:	41 89 d5             	mov    %edx,%r13d
   4e26b:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4e272:	00 
   4e273:	49 89 f4             	mov    %rsi,%r12
   4e276:	4c 01 fb             	add    %r15,%rbx
   4e279:	48 81 fb 13 04 00 00 	cmp    $0x413,%rbx
   4e280:	0f 83 ec 0e 00 00    	jae    4f172 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x27f2>
   4e286:	49 8b 01             	mov    (%r9),%rax
   4e289:	4d 8b 79 10          	mov    0x10(%r9),%r15
   4e28d:	4c 29 f8             	sub    %r15,%rax
   4e290:	48 39 c3             	cmp    %rax,%rbx
   4e293:	0f 87 e5 09 00 00    	ja     4ec7e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x22fe>
   4e299:	48 85 db             	test   %rbx,%rbx
   4e29c:	74 25                	je     4e2c3 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1943>
   4e29e:	4b 8d 3c 3f          	lea    (%r15,%r15,1),%rdi
   4e2a2:	49 03 79 08          	add    0x8(%r9),%rdi
   4e2a6:	48 8d 14 1b          	lea    (%rbx,%rbx,1),%rdx
   4e2aa:	4c 89 c6             	mov    %r8,%rsi
   4e2ad:	ff 15 95 4f 05 00    	call   *0x54f95(%rip)        # a3248 <memcpy@GLIBC_2.14>
   4e2b3:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4e2ba:	00 
   4e2bb:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4e2c2:	00 
   4e2c3:	49 01 df             	add    %rbx,%r15
   4e2c6:	4d 89 79 10          	mov    %r15,0x10(%r9)
   4e2ca:	b0 01                	mov    $0x1,%al
   4e2cc:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
   4e2d3:	31 db                	xor    %ebx,%ebx
   4e2d5:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4e2da:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4e2e1:	00 
   4e2e2:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4e2e7:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
   4e2ee:	00 
   4e2ef:	4c 89 22             	mov    %r12,(%rdx)
   4e2f2:	4c 89 72 08          	mov    %r14,0x8(%rdx)
   4e2f6:	44 89 6a 10          	mov    %r13d,0x10(%rdx)
   4e2fa:	89 6a 14             	mov    %ebp,0x14(%rdx)
   4e2fd:	48 89 5c 24 30       	mov    %rbx,0x30(%rsp)
   4e302:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4e306:	48 8b 94 24 98 00 00 	mov    0x98(%rsp),%rdx
   4e30d:	00 
   4e30e:	0f 85 63 0f 00 00    	jne    4f277 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x28f7>
   4e314:	a8 01                	test   $0x1,%al
   4e316:	0f 84 c6 f1 ff ff    	je     4d4e2 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xb62>
   4e31c:	e9 f2 0d 00 00       	jmp    4f113 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2793>
   4e321:	4c 89 64 24 50       	mov    %r12,0x50(%rsp)
   4e326:	48 89 4c 24 58       	mov    %rcx,0x58(%rsp)
   4e32b:	89 44 24 60          	mov    %eax,0x60(%rsp)
   4e32f:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4e333:	89 44 24 64          	mov    %eax,0x64(%rsp)
   4e337:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   4e33c:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
   4e341:	4c 89 d2             	mov    %r10,%rdx
   4e344:	4c 89 d9             	mov    %r11,%rcx
   4e347:	e8 84 83 ff ff       	call   466d0 <_RNvMNtCs7Z5HuLIcqFl_5mibz24bitsNtB2_3Reg11refill_slow>
   4e34c:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4e351:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4e358:	00 
   4e359:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4e35e:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4e365:	00 
   4e366:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4e36d:	00 
   4e36e:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   4e373:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   4e378:	44 8b 6c 24 20       	mov    0x20(%rsp),%r13d
   4e37d:	8b 44 24 24          	mov    0x24(%rsp),%eax
   4e381:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   4e385:	e9 63 e7 ff ff       	jmp    4caed <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x16d>
   4e38a:	4c 89 64 24 50       	mov    %r12,0x50(%rsp)
   4e38f:	48 89 6c 24 58       	mov    %rbp,0x58(%rsp)
   4e394:	44 89 6c 24 60       	mov    %r13d,0x60(%rsp)
   4e399:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4e39d:	89 44 24 64          	mov    %eax,0x64(%rsp)
   4e3a1:	48 89 fe             	mov    %rdi,%rsi
   4e3a4:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   4e3ab:	00 
   4e3ac:	48 8d 4c 24 50       	lea    0x50(%rsp),%rcx
   4e3b1:	4d 89 d0             	mov    %r10,%r8
   4e3b4:	4d 89 d9             	mov    %r11,%r9
   4e3b7:	e8 e4 e1 ff ff       	call   4c5a0 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4e3bc:	48 8b 8c 24 30 01 00 	mov    0x130(%rsp),%rcx
   4e3c3:	00 
   4e3c4:	0f b7 84 24 38 01 00 	movzwl 0x138(%rsp),%eax
   4e3cb:	00 
   4e3cc:	4c 8b a4 24 50 01 00 	mov    0x150(%rsp),%r12
   4e3d3:	00 
   4e3d4:	48 8b ac 24 58 01 00 	mov    0x158(%rsp),%rbp
   4e3db:	00 
   4e3dc:	44 8b ac 24 60 01 00 	mov    0x160(%rsp),%r13d
   4e3e3:	00 
   4e3e4:	8b 94 24 64 01 00 00 	mov    0x164(%rsp),%edx
   4e3eb:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4e3ef:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4e3f3:	0f 85 bb 0d 00 00    	jne    4f1b4 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2834>
   4e3f9:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4e400:	00 
   4e401:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4e408:	00 
   4e409:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4e40e:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4e415:	00 
   4e416:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4e41b:	e9 02 f0 ff ff       	jmp    4d422 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xaa2>
   4e420:	4c 89 64 24 50       	mov    %r12,0x50(%rsp)
   4e425:	48 89 6c 24 58       	mov    %rbp,0x58(%rsp)
   4e42a:	44 89 6c 24 60       	mov    %r13d,0x60(%rsp)
   4e42f:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4e433:	89 44 24 64          	mov    %eax,0x64(%rsp)
   4e437:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   4e43c:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
   4e441:	4c 89 d2             	mov    %r10,%rdx
   4e444:	4c 89 d9             	mov    %r11,%rcx
   4e447:	e8 84 82 ff ff       	call   466d0 <_RNvMNtCs7Z5HuLIcqFl_5mibz24bitsNtB2_3Reg11refill_slow>
   4e44c:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4e451:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4e458:	00 
   4e459:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4e45e:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4e465:	00 
   4e466:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4e46d:	00 
   4e46e:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   4e473:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   4e478:	44 8b 6c 24 20       	mov    0x20(%rsp),%r13d
   4e47d:	8b 44 24 24          	mov    0x24(%rsp),%eax
   4e481:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   4e485:	e9 16 f3 ff ff       	jmp    4d7a0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xe20>
   4e48a:	4c 89 64 24 50       	mov    %r12,0x50(%rsp)
   4e48f:	48 89 6c 24 58       	mov    %rbp,0x58(%rsp)
   4e494:	44 89 6c 24 60       	mov    %r13d,0x60(%rsp)
   4e499:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4e49d:	89 44 24 64          	mov    %eax,0x64(%rsp)
   4e4a1:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   4e4a6:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
   4e4ab:	4c 89 d2             	mov    %r10,%rdx
   4e4ae:	4c 89 d9             	mov    %r11,%rcx
   4e4b1:	e8 1a 82 ff ff       	call   466d0 <_RNvMNtCs7Z5HuLIcqFl_5mibz24bitsNtB2_3Reg11refill_slow>
   4e4b6:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4e4bb:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4e4c2:	00 
   4e4c3:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4e4c8:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4e4cf:	00 
   4e4d0:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4e4d7:	00 
   4e4d8:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   4e4dd:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   4e4e2:	44 8b 6c 24 20       	mov    0x20(%rsp),%r13d
   4e4e7:	8b 44 24 24          	mov    0x24(%rsp),%eax
   4e4eb:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   4e4ef:	e9 04 ef ff ff       	jmp    4d3f8 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xa78>
   4e4f4:	b9 02 00 00 00       	mov    $0x2,%ecx
   4e4f9:	41 b8 02 00 00 00    	mov    $0x2,%r8d
   4e4ff:	4c 89 cf             	mov    %r9,%rdi
   4e502:	48 89 de             	mov    %rbx,%rsi
   4e505:	4c 89 d2             	mov    %r10,%rdx
   4e508:	e8 83 95 fe ff       	call   37a90 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs7Z5HuLIcqFl_5mibz2>
   4e50d:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4e512:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4e519:	00 
   4e51a:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4e521:	00 
   4e522:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4e526:	e9 4b ef ff ff       	jmp    4d476 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xaf6>
   4e52b:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4e530:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4e535:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4e53a:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4e53e:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4e542:	48 89 fe             	mov    %rdi,%rsi
   4e545:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   4e54a:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4e54f:	4d 89 d0             	mov    %r10,%r8
   4e552:	4d 89 d9             	mov    %r11,%r9
   4e555:	e8 46 e0 ff ff       	call   4c5a0 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4e55a:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   4e55f:	0f b7 44 24 58       	movzwl 0x58(%rsp),%eax
   4e564:	48 8d 54 24 5a       	lea    0x5a(%rsp),%rdx
   4e569:	0f 10 02             	movups (%rdx),%xmm0
   4e56c:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4e571:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4e575:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4e57a:	4c 8b 64 24 70       	mov    0x70(%rsp),%r12
   4e57f:	48 8b 6c 24 78       	mov    0x78(%rsp),%rbp
   4e584:	44 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13d
   4e58b:	00 
   4e58c:	8b 94 24 84 00 00 00 	mov    0x84(%rsp),%edx
   4e593:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4e597:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4e59b:	0f 85 a2 06 00 00    	jne    4ec43 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x22c3>
   4e5a1:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
   4e5a6:	89 f1                	mov    %esi,%ecx
   4e5a8:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4e5ae:	48 8b 94 24 a8 01 00 	mov    0x1a8(%rsp),%rdx
   4e5b5:	00 
   4e5b6:	66 89 04 4a          	mov    %ax,(%rdx,%rcx,2)
   4e5ba:	48 ff c6             	inc    %rsi
   4e5bd:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
   4e5c2:	66 3b 44 24 3e       	cmp    0x3e(%rsp),%ax
   4e5c7:	0f 84 05 08 00 00    	je     4edd2 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2452>
   4e5cd:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4e5d4:	00 
   4e5d5:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4e5dc:	00 
   4e5dd:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4e5e2:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4e5e9:	00 
   4e5ea:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4e5ef:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
   4e5f4:	4c 89 7c 24 30       	mov    %r15,0x30(%rsp)
   4e5f9:	4d 39 f7             	cmp    %r14,%r15
   4e5fc:	0f 86 ad ec ff ff    	jbe    4d2af <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x92f>
   4e602:	e9 94 ed ff ff       	jmp    4d39b <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xa1b>
   4e607:	89 c2                	mov    %eax,%edx
   4e609:	c1 ea 08             	shr    $0x8,%edx
   4e60c:	89 94 24 8c 00 00 00 	mov    %edx,0x8c(%rsp)
   4e613:	48 8b 54 24 1e       	mov    0x1e(%rsp),%rdx
   4e618:	48 89 94 24 ae 00 00 	mov    %rdx,0xae(%rsp)
   4e61f:	00 
   4e620:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
   4e625:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   4e62c:	00 
   4e62d:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4e634:	00 
   4e635:	eb 39                	jmp    4e670 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1cf0>
   4e637:	49 81 ff 13 04 00 00 	cmp    $0x413,%r15
   4e63e:	0f 83 98 0c 00 00    	jae    4f2dc <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x295c>
   4e644:	89 f3                	mov    %esi,%ebx
   4e646:	4c 89 cf             	mov    %r9,%rdi
   4e649:	4c 89 c6             	mov    %r8,%rsi
   4e64c:	4c 89 fa             	mov    %r15,%rdx
   4e64f:	e8 bc e2 ff ff       	call   4c910 <_RNvMs_NtCsgFX3jaOk65H_5alloc3vecINtB4_3VectE15append_elementsCs7Z5HuLIcqFl_5mibz2>
   4e654:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4e65b:	00 
   4e65c:	b0 01                	mov    $0x1,%al
   4e65e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
   4e665:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
   4e66c:	00 00 
   4e66e:	89 de                	mov    %ebx,%esi
   4e670:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
   4e677:	00 
   4e678:	4c 89 22             	mov    %r12,(%rdx)
   4e67b:	48 89 6a 08          	mov    %rbp,0x8(%rdx)
   4e67f:	44 89 6a 10          	mov    %r13d,0x10(%rdx)
   4e683:	89 72 14             	mov    %esi,0x14(%rdx)
   4e686:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4e68d:	00 
   4e68e:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4e693:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4e69a:	00 
   4e69b:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4e6a0:	e9 5d fc ff ff       	jmp    4e302 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1982>
   4e6a5:	4c 89 64 24 50       	mov    %r12,0x50(%rsp)
   4e6aa:	48 89 6c 24 58       	mov    %rbp,0x58(%rsp)
   4e6af:	44 89 6c 24 60       	mov    %r13d,0x60(%rsp)
   4e6b4:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4e6b8:	89 44 24 64          	mov    %eax,0x64(%rsp)
   4e6bc:	48 89 fe             	mov    %rdi,%rsi
   4e6bf:	48 8d bc 24 f8 00 00 	lea    0xf8(%rsp),%rdi
   4e6c6:	00 
   4e6c7:	48 8d 4c 24 50       	lea    0x50(%rsp),%rcx
   4e6cc:	4d 89 d0             	mov    %r10,%r8
   4e6cf:	4d 89 d9             	mov    %r11,%r9
   4e6d2:	e8 c9 de ff ff       	call   4c5a0 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4e6d7:	48 8b 8c 24 f8 00 00 	mov    0xf8(%rsp),%rcx
   4e6de:	00 
   4e6df:	0f b7 84 24 00 01 00 	movzwl 0x100(%rsp),%eax
   4e6e6:	00 
   4e6e7:	4c 8b a4 24 18 01 00 	mov    0x118(%rsp),%r12
   4e6ee:	00 
   4e6ef:	48 8b ac 24 20 01 00 	mov    0x120(%rsp),%rbp
   4e6f6:	00 
   4e6f7:	44 8b ac 24 28 01 00 	mov    0x128(%rsp),%r13d
   4e6fe:	00 
   4e6ff:	8b 94 24 2c 01 00 00 	mov    0x12c(%rsp),%edx
   4e706:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4e70a:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4e70e:	0f 85 1e 0b 00 00    	jne    4f232 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x28b2>
   4e714:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4e71b:	00 
   4e71c:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4e723:	00 
   4e724:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4e729:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4e730:	00 
   4e731:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4e736:	66 43 89 04 78       	mov    %ax,(%r8,%r15,2)
   4e73b:	49 ff c7             	inc    %r15
   4e73e:	66 3b 84 24 98 00 00 	cmp    0x98(%rsp),%ax
   4e745:	00 
   4e746:	0f 85 58 ef ff ff    	jne    4d6a4 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xd24>
   4e74c:	e9 9a 09 00 00       	jmp    4f0eb <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x276b>
   4e751:	4c 89 64 24 50       	mov    %r12,0x50(%rsp)
   4e756:	48 89 6c 24 58       	mov    %rbp,0x58(%rsp)
   4e75b:	44 89 6c 24 60       	mov    %r13d,0x60(%rsp)
   4e760:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4e764:	89 44 24 64          	mov    %eax,0x64(%rsp)
   4e768:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   4e76d:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
   4e772:	4c 89 d2             	mov    %r10,%rdx
   4e775:	4c 89 d9             	mov    %r11,%rcx
   4e778:	e8 53 7f ff ff       	call   466d0 <_RNvMNtCs7Z5HuLIcqFl_5mibz24bitsNtB2_3Reg11refill_slow>
   4e77d:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4e782:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4e789:	00 
   4e78a:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4e78f:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4e796:	00 
   4e797:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4e79e:	00 
   4e79f:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   4e7a4:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   4e7a9:	44 8b 6c 24 20       	mov    0x20(%rsp),%r13d
   4e7ae:	8b 44 24 24          	mov    0x24(%rsp),%eax
   4e7b2:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   4e7b6:	e9 45 f1 ff ff       	jmp    4d900 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xf80>
   4e7bb:	4c 89 64 24 50       	mov    %r12,0x50(%rsp)
   4e7c0:	48 89 6c 24 58       	mov    %rbp,0x58(%rsp)
   4e7c5:	44 89 6c 24 60       	mov    %r13d,0x60(%rsp)
   4e7ca:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4e7ce:	89 44 24 64          	mov    %eax,0x64(%rsp)
   4e7d2:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   4e7d7:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
   4e7dc:	4c 89 d2             	mov    %r10,%rdx
   4e7df:	4c 89 d9             	mov    %r11,%rcx
   4e7e2:	e8 e9 7e ff ff       	call   466d0 <_RNvMNtCs7Z5HuLIcqFl_5mibz24bitsNtB2_3Reg11refill_slow>
   4e7e7:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4e7ec:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4e7f3:	00 
   4e7f4:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4e7f9:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4e800:	00 
   4e801:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4e808:	00 
   4e809:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   4e80e:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   4e813:	44 8b 6c 24 20       	mov    0x20(%rsp),%r13d
   4e818:	8b 44 24 24          	mov    0x24(%rsp),%eax
   4e81c:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   4e820:	e9 3f ee ff ff       	jmp    4d664 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xce4>
   4e825:	b9 02 00 00 00       	mov    $0x2,%ecx
   4e82a:	41 b8 02 00 00 00    	mov    $0x2,%r8d
   4e830:	4c 89 cf             	mov    %r9,%rdi
   4e833:	48 89 de             	mov    %rbx,%rsi
   4e836:	4c 89 fa             	mov    %r15,%rdx
   4e839:	e8 52 92 fe ff       	call   37a90 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs7Z5HuLIcqFl_5mibz2>
   4e83e:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4e845:	00 
   4e846:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4e84d:	00 
   4e84e:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4e852:	e9 76 ee ff ff       	jmp    4d6cd <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xd4d>
   4e857:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4e85c:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4e861:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4e866:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4e86a:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4e86e:	48 89 fe             	mov    %rdi,%rsi
   4e871:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   4e876:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4e87b:	4d 89 d0             	mov    %r10,%r8
   4e87e:	4d 89 d9             	mov    %r11,%r9
   4e881:	e8 1a dd ff ff       	call   4c5a0 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4e886:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   4e88b:	0f b7 44 24 58       	movzwl 0x58(%rsp),%eax
   4e890:	48 8d 54 24 5a       	lea    0x5a(%rsp),%rdx
   4e895:	0f 10 02             	movups (%rdx),%xmm0
   4e898:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4e89d:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4e8a1:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4e8a6:	4c 8b 64 24 70       	mov    0x70(%rsp),%r12
   4e8ab:	48 8b 6c 24 78       	mov    0x78(%rsp),%rbp
   4e8b0:	44 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13d
   4e8b7:	00 
   4e8b8:	8b 94 24 84 00 00 00 	mov    0x84(%rsp),%edx
   4e8bf:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4e8c3:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4e8c7:	0f 85 76 03 00 00    	jne    4ec43 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x22c3>
   4e8cd:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
   4e8d2:	89 f1                	mov    %esi,%ecx
   4e8d4:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4e8da:	48 8b 94 24 a8 01 00 	mov    0x1a8(%rsp),%rdx
   4e8e1:	00 
   4e8e2:	66 89 04 4a          	mov    %ax,(%rdx,%rcx,2)
   4e8e6:	48 ff c6             	inc    %rsi
   4e8e9:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
   4e8ee:	66 3b 44 24 3e       	cmp    0x3e(%rsp),%ax
   4e8f3:	0f 84 d9 04 00 00    	je     4edd2 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2452>
   4e8f9:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4e900:	00 
   4e901:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4e908:	00 
   4e909:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4e90e:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4e915:	00 
   4e916:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4e91b:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
   4e920:	4c 89 7c 24 30       	mov    %r15,0x30(%rsp)
   4e925:	4d 39 f7             	cmp    %r14,%r15
   4e928:	0f 86 d4 e9 ff ff    	jbe    4d302 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x982>
   4e92e:	e9 68 ea ff ff       	jmp    4d39b <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xa1b>
   4e933:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4e938:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4e93d:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4e942:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4e946:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4e94a:	48 89 fe             	mov    %rdi,%rsi
   4e94d:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   4e952:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4e957:	4d 89 d0             	mov    %r10,%r8
   4e95a:	4d 89 d9             	mov    %r11,%r9
   4e95d:	e8 3e dc ff ff       	call   4c5a0 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4e962:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   4e967:	0f b7 44 24 58       	movzwl 0x58(%rsp),%eax
   4e96c:	48 8d 54 24 5a       	lea    0x5a(%rsp),%rdx
   4e971:	0f 10 02             	movups (%rdx),%xmm0
   4e974:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4e979:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4e97d:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4e982:	4c 8b 64 24 70       	mov    0x70(%rsp),%r12
   4e987:	48 8b 6c 24 78       	mov    0x78(%rsp),%rbp
   4e98c:	44 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13d
   4e993:	00 
   4e994:	8b 94 24 84 00 00 00 	mov    0x84(%rsp),%edx
   4e99b:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4e99f:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4e9a3:	0f 85 17 05 00 00    	jne    4eec0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2540>
   4e9a9:	48 8b 8c 24 a8 01 00 	mov    0x1a8(%rsp),%rcx
   4e9b0:	00 
   4e9b1:	66 42 89 04 79       	mov    %ax,(%rcx,%r15,2)
   4e9b6:	49 ff c7             	inc    %r15
   4e9b9:	66 3b 84 24 98 00 00 	cmp    0x98(%rsp),%ax
   4e9c0:	00 
   4e9c1:	0f 84 19 01 00 00    	je     4eae0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2160>
   4e9c7:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4e9ce:	00 
   4e9cf:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4e9d6:	00 
   4e9d7:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4e9dc:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4e9e3:	00 
   4e9e4:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4e9e9:	4d 39 f7             	cmp    %r14,%r15
   4e9ec:	0f 86 6a eb ff ff    	jbe    4d55c <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xbdc>
   4e9f2:	e9 14 ec ff ff       	jmp    4d60b <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xc8b>
   4e9f7:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4e9fc:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4ea01:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4ea06:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4ea0a:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4ea0e:	48 89 fe             	mov    %rdi,%rsi
   4ea11:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   4ea16:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4ea1b:	4d 89 d0             	mov    %r10,%r8
   4ea1e:	4d 89 d9             	mov    %r11,%r9
   4ea21:	e8 7a db ff ff       	call   4c5a0 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4ea26:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   4ea2b:	0f b7 44 24 58       	movzwl 0x58(%rsp),%eax
   4ea30:	48 8d 54 24 5a       	lea    0x5a(%rsp),%rdx
   4ea35:	0f 10 02             	movups (%rdx),%xmm0
   4ea38:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4ea3d:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4ea41:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4ea46:	4c 8b 64 24 70       	mov    0x70(%rsp),%r12
   4ea4b:	48 8b 6c 24 78       	mov    0x78(%rsp),%rbp
   4ea50:	44 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13d
   4ea57:	00 
   4ea58:	8b 94 24 84 00 00 00 	mov    0x84(%rsp),%edx
   4ea5f:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4ea63:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4ea67:	0f 85 d6 01 00 00    	jne    4ec43 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x22c3>
   4ea6d:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
   4ea72:	89 f1                	mov    %esi,%ecx
   4ea74:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4ea7a:	48 8b 94 24 a8 01 00 	mov    0x1a8(%rsp),%rdx
   4ea81:	00 
   4ea82:	66 89 04 4a          	mov    %ax,(%rdx,%rcx,2)
   4ea86:	48 ff c6             	inc    %rsi
   4ea89:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
   4ea8e:	66 3b 44 24 3e       	cmp    0x3e(%rsp),%ax
   4ea93:	0f 84 39 03 00 00    	je     4edd2 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2452>
   4ea99:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4eaa0:	00 
   4eaa1:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4eaa8:	00 
   4eaa9:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4eaae:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4eab5:	00 
   4eab6:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4eabb:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
   4eac0:	4c 89 7c 24 30       	mov    %r15,0x30(%rsp)
   4eac5:	4d 39 f7             	cmp    %r14,%r15
   4eac8:	0f 86 83 e8 ff ff    	jbe    4d351 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x9d1>
   4eace:	e9 c8 e8 ff ff       	jmp    4d39b <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xa1b>
   4ead3:	49 81 ff 13 04 00 00 	cmp    $0x413,%r15
   4eada:	0f 83 fc 07 00 00    	jae    4f2dc <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x295c>
   4eae0:	48 8b bc 24 b0 01 00 	mov    0x1b0(%rsp),%rdi
   4eae7:	00 
   4eae8:	48 8b b4 24 a8 01 00 	mov    0x1a8(%rsp),%rsi
   4eaef:	00 
   4eaf0:	4c 89 fa             	mov    %r15,%rdx
   4eaf3:	e8 18 de ff ff       	call   4c910 <_RNvMs_NtCsgFX3jaOk65H_5alloc3vecINtB4_3VectE15append_elementsCs7Z5HuLIcqFl_5mibz2>
   4eaf8:	b0 01                	mov    $0x1,%al
   4eafa:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
   4eb01:	45 31 ff             	xor    %r15d,%r15d
   4eb04:	e9 dd 03 00 00       	jmp    4eee6 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2566>
   4eb09:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4eb0e:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4eb13:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4eb18:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4eb1c:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4eb20:	48 89 fe             	mov    %rdi,%rsi
   4eb23:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   4eb28:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4eb2d:	4d 89 d0             	mov    %r10,%r8
   4eb30:	4d 89 d9             	mov    %r11,%r9
   4eb33:	e8 68 da ff ff       	call   4c5a0 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4eb38:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   4eb3d:	0f b7 44 24 58       	movzwl 0x58(%rsp),%eax
   4eb42:	48 8d 54 24 5a       	lea    0x5a(%rsp),%rdx
   4eb47:	0f 10 02             	movups (%rdx),%xmm0
   4eb4a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4eb4f:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4eb53:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4eb58:	4c 8b 64 24 70       	mov    0x70(%rsp),%r12
   4eb5d:	48 8b 6c 24 78       	mov    0x78(%rsp),%rbp
   4eb62:	44 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13d
   4eb69:	00 
   4eb6a:	8b 94 24 84 00 00 00 	mov    0x84(%rsp),%edx
   4eb71:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4eb75:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4eb79:	0f 85 41 03 00 00    	jne    4eec0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2540>
   4eb7f:	48 8b 8c 24 a8 01 00 	mov    0x1a8(%rsp),%rcx
   4eb86:	00 
   4eb87:	66 42 89 04 79       	mov    %ax,(%rcx,%r15,2)
   4eb8c:	49 ff c7             	inc    %r15
   4eb8f:	66 3b 84 24 98 00 00 	cmp    0x98(%rsp),%ax
   4eb96:	00 
   4eb97:	0f 84 43 ff ff ff    	je     4eae0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2160>
   4eb9d:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4eba4:	00 
   4eba5:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4ebac:	00 
   4ebad:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4ebb2:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4ebb9:	00 
   4ebba:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4ebbf:	4d 39 f7             	cmp    %r14,%r15
   4ebc2:	0f 86 d0 e9 ff ff    	jbe    4d598 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xc18>
   4ebc8:	e9 3e ea ff ff       	jmp    4d60b <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xc8b>
   4ebcd:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4ebd2:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4ebd7:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4ebdc:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4ebe0:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4ebe4:	48 89 fe             	mov    %rdi,%rsi
   4ebe7:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   4ebec:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4ebf1:	4d 89 d0             	mov    %r10,%r8
   4ebf4:	4d 89 d9             	mov    %r11,%r9
   4ebf7:	e8 a4 d9 ff ff       	call   4c5a0 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4ebfc:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   4ec01:	0f b7 44 24 58       	movzwl 0x58(%rsp),%eax
   4ec06:	48 8d 54 24 5a       	lea    0x5a(%rsp),%rdx
   4ec0b:	0f 10 02             	movups (%rdx),%xmm0
   4ec0e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4ec13:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4ec17:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4ec1c:	4c 8b 64 24 70       	mov    0x70(%rsp),%r12
   4ec21:	48 8b 6c 24 78       	mov    0x78(%rsp),%rbp
   4ec26:	44 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13d
   4ec2d:	00 
   4ec2e:	8b 94 24 84 00 00 00 	mov    0x84(%rsp),%edx
   4ec35:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4ec39:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4ec3d:	0f 84 63 01 00 00    	je     4eda6 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2426>
   4ec43:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4ec4a:	00 
   4ec4b:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4ec52:	00 
   4ec53:	89 c2                	mov    %eax,%edx
   4ec55:	c1 ea 08             	shr    $0x8,%edx
   4ec58:	89 94 24 8c 00 00 00 	mov    %edx,0x8c(%rsp)
   4ec5f:	48 8b 54 24 1e       	mov    0x1e(%rsp),%rdx
   4ec64:	48 89 94 24 ae 00 00 	mov    %rdx,0xae(%rsp)
   4ec6b:	00 
   4ec6c:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
   4ec71:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   4ec78:	00 
   4ec79:	e9 9b 01 00 00       	jmp    4ee19 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2499>
   4ec7e:	b9 02 00 00 00       	mov    $0x2,%ecx
   4ec83:	41 b8 02 00 00 00    	mov    $0x2,%r8d
   4ec89:	4c 89 cf             	mov    %r9,%rdi
   4ec8c:	4c 89 fe             	mov    %r15,%rsi
   4ec8f:	48 89 da             	mov    %rbx,%rdx
   4ec92:	e8 f9 8d fe ff       	call   37a90 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs7Z5HuLIcqFl_5mibz2>
   4ec97:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4ec9e:	00 
   4ec9f:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4eca6:	00 
   4eca7:	4d 8b 79 10          	mov    0x10(%r9),%r15
   4ecab:	e9 ee f5 ff ff       	jmp    4e29e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x191e>
   4ecb0:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4ecb5:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4ecba:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4ecbf:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4ecc3:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4ecc7:	48 89 fe             	mov    %rdi,%rsi
   4ecca:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   4eccf:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4ecd4:	4d 89 d0             	mov    %r10,%r8
   4ecd7:	4d 89 d9             	mov    %r11,%r9
   4ecda:	e8 c1 d8 ff ff       	call   4c5a0 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4ecdf:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   4ece4:	0f b7 44 24 58       	movzwl 0x58(%rsp),%eax
   4ece9:	48 8d 54 24 5a       	lea    0x5a(%rsp),%rdx
   4ecee:	0f 10 02             	movups (%rdx),%xmm0
   4ecf1:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4ecf6:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4ecfa:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4ecff:	4c 8b 64 24 70       	mov    0x70(%rsp),%r12
   4ed04:	48 8b 6c 24 78       	mov    0x78(%rsp),%rbp
   4ed09:	44 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13d
   4ed10:	00 
   4ed11:	8b 94 24 84 00 00 00 	mov    0x84(%rsp),%edx
   4ed18:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4ed1c:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4ed20:	0f 85 9a 01 00 00    	jne    4eec0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2540>
   4ed26:	48 8b 8c 24 a8 01 00 	mov    0x1a8(%rsp),%rcx
   4ed2d:	00 
   4ed2e:	66 42 89 04 79       	mov    %ax,(%rcx,%r15,2)
   4ed33:	49 ff c7             	inc    %r15
   4ed36:	66 3b 84 24 98 00 00 	cmp    0x98(%rsp),%ax
   4ed3d:	00 
   4ed3e:	0f 84 9c fd ff ff    	je     4eae0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2160>
   4ed44:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4ed4b:	00 
   4ed4c:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4ed53:	00 
   4ed54:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4ed59:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4ed60:	00 
   4ed61:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4ed66:	4d 39 f7             	cmp    %r14,%r15
   4ed69:	0f 86 65 e8 ff ff    	jbe    4d5d4 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xc54>
   4ed6f:	e9 97 e8 ff ff       	jmp    4d60b <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xc8b>
   4ed74:	b9 02 00 00 00       	mov    $0x2,%ecx
   4ed79:	41 b8 02 00 00 00    	mov    $0x2,%r8d
   4ed7f:	4c 89 cf             	mov    %r9,%rdi
   4ed82:	4c 89 f6             	mov    %r14,%rsi
   4ed85:	4c 89 fa             	mov    %r15,%rdx
   4ed88:	e8 03 8d fe ff       	call   37a90 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs7Z5HuLIcqFl_5mibz2>
   4ed8d:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4ed94:	00 
   4ed95:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4ed9c:	00 
   4ed9d:	4d 8b 71 10          	mov    0x10(%r9),%r14
   4eda1:	e9 fe ec ff ff       	jmp    4daa4 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1124>
   4eda6:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
   4edab:	89 f1                	mov    %esi,%ecx
   4edad:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4edb3:	48 8b 94 24 a8 01 00 	mov    0x1a8(%rsp),%rdx
   4edba:	00 
   4edbb:	66 89 04 4a          	mov    %ax,(%rdx,%rcx,2)
   4edbf:	48 ff c6             	inc    %rsi
   4edc2:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
   4edc7:	66 3b 44 24 3e       	cmp    0x3e(%rsp),%ax
   4edcc:	0f 85 64 01 00 00    	jne    4ef36 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x25b6>
   4edd2:	48 81 7c 24 30 13 04 	cmpq   $0x413,0x30(%rsp)
   4edd9:	00 00 
   4eddb:	0f 83 11 05 00 00    	jae    4f2f2 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2972>
   4ede1:	48 8b 9c 24 b0 01 00 	mov    0x1b0(%rsp),%rbx
   4ede8:	00 
   4ede9:	48 89 df             	mov    %rbx,%rdi
   4edec:	4c 8b b4 24 a8 01 00 	mov    0x1a8(%rsp),%r14
   4edf3:	00 
   4edf4:	4c 89 f6             	mov    %r14,%rsi
   4edf7:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
   4edfc:	e8 0f db ff ff       	call   4c910 <_RNvMs_NtCsgFX3jaOk65H_5alloc3vecINtB4_3VectE15append_elementsCs7Z5HuLIcqFl_5mibz2>
   4ee01:	4d 89 f0             	mov    %r14,%r8
   4ee04:	49 89 d9             	mov    %rbx,%r9
   4ee07:	b0 01                	mov    $0x1,%al
   4ee09:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
   4ee10:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
   4ee17:	00 00 
   4ee19:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4ee1e:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4ee25:	00 
   4ee26:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4ee2b:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
   4ee32:	00 
   4ee33:	4c 89 22             	mov    %r12,(%rdx)
   4ee36:	48 89 6a 08          	mov    %rbp,0x8(%rdx)
   4ee3a:	44 89 6a 10          	mov    %r13d,0x10(%rdx)
   4ee3e:	8b 74 24 0c          	mov    0xc(%rsp),%esi
   4ee42:	89 72 14             	mov    %esi,0x14(%rdx)
   4ee45:	e9 b8 f4 ff ff       	jmp    4e302 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1982>
   4ee4a:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4ee4f:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4ee54:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4ee59:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4ee5d:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4ee61:	48 89 fe             	mov    %rdi,%rsi
   4ee64:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   4ee69:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4ee6e:	4d 89 d0             	mov    %r10,%r8
   4ee71:	4d 89 d9             	mov    %r11,%r9
   4ee74:	e8 27 d7 ff ff       	call   4c5a0 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4ee79:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   4ee7e:	0f b7 44 24 58       	movzwl 0x58(%rsp),%eax
   4ee83:	48 8d 54 24 5a       	lea    0x5a(%rsp),%rdx
   4ee88:	0f 10 02             	movups (%rdx),%xmm0
   4ee8b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4ee90:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4ee94:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4ee99:	4c 8b 64 24 70       	mov    0x70(%rsp),%r12
   4ee9e:	48 8b 6c 24 78       	mov    0x78(%rsp),%rbp
   4eea3:	44 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13d
   4eeaa:	00 
   4eeab:	8b 94 24 84 00 00 00 	mov    0x84(%rsp),%edx
   4eeb2:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4eeb6:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4eeba:	0f 84 9d 00 00 00    	je     4ef5d <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x25dd>
   4eec0:	89 c2                	mov    %eax,%edx
   4eec2:	c1 ea 08             	shr    $0x8,%edx
   4eec5:	89 94 24 8c 00 00 00 	mov    %edx,0x8c(%rsp)
   4eecc:	48 8b 54 24 1e       	mov    0x1e(%rsp),%rdx
   4eed1:	48 89 94 24 ae 00 00 	mov    %rdx,0xae(%rsp)
   4eed8:	00 
   4eed9:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
   4eede:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   4eee5:	00 
   4eee6:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
   4eeed:	00 
   4eeee:	4c 89 22             	mov    %r12,(%rdx)
   4eef1:	48 89 6a 08          	mov    %rbp,0x8(%rdx)
   4eef5:	44 89 6a 10          	mov    %r13d,0x10(%rdx)
   4eef9:	8b 74 24 0c          	mov    0xc(%rsp),%esi
   4eefd:	89 72 14             	mov    %esi,0x14(%rdx)
   4ef00:	4c 89 7c 24 30       	mov    %r15,0x30(%rsp)
   4ef05:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4ef0c:	00 
   4ef0d:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4ef14:	00 
   4ef15:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4ef1a:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4ef21:	00 
   4ef22:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4ef27:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4ef2b:	0f 84 e2 eb ff ff    	je     4db13 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1193>
   4ef31:	e9 41 03 00 00       	jmp    4f277 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x28f7>
   4ef36:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4ef3d:	00 
   4ef3e:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4ef45:	00 
   4ef46:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4ef4b:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4ef52:	00 
   4ef53:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4ef58:	e9 3e e4 ff ff       	jmp    4d39b <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xa1b>
   4ef5d:	48 8b 8c 24 a8 01 00 	mov    0x1a8(%rsp),%rcx
   4ef64:	00 
   4ef65:	66 42 89 04 79       	mov    %ax,(%rcx,%r15,2)
   4ef6a:	49 ff c7             	inc    %r15
   4ef6d:	66 3b 84 24 98 00 00 	cmp    0x98(%rsp),%ax
   4ef74:	00 
   4ef75:	0f 84 65 fb ff ff    	je     4eae0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2160>
   4ef7b:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4ef82:	00 
   4ef83:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4ef8a:	00 
   4ef8b:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   4ef90:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4ef97:	00 
   4ef98:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
   4ef9d:	e9 69 e6 ff ff       	jmp    4d60b <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xc8b>
   4efa2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   4efa9:	1f 84 00 00 00 00 00 
   4efb0:	48 8b 94 24 e8 00 00 	mov    0xe8(%rsp),%rdx
   4efb7:	00 
   4efb8:	48 83 c2 04          	add    $0x4,%rdx
   4efbc:	48 3b 94 24 d8 00 00 	cmp    0xd8(%rsp),%rdx
   4efc3:	00 
   4efc4:	48 8b b4 24 e0 00 00 	mov    0xe0(%rsp),%rsi
   4efcb:	00 
   4efcc:	0f 85 2c da ff ff    	jne    4c9fe <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x7e>
   4efd2:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
   4efd9:	00 
   4efda:	48 8b 42 10          	mov    0x10(%rdx),%rax
   4efde:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
   4efe5:	00 
   4efe6:	48 89 41 30          	mov    %rax,0x30(%rcx)
   4efea:	0f 10 02             	movups (%rdx),%xmm0
   4efed:	0f 11 41 20          	movups %xmm0,0x20(%rcx)
   4eff1:	48 b8 0b 00 00 00 00 	movabs $0x800000000000000b,%rax
   4eff8:	00 00 80 
   4effb:	48 89 01             	mov    %rax,(%rcx)
   4effe:	48 81 c4 68 01 00 00 	add    $0x168,%rsp
   4f005:	5b                   	pop    %rbx
   4f006:	41 5c                	pop    %r12
   4f008:	41 5d                	pop    %r13
   4f00a:	41 5e                	pop    %r14
   4f00c:	41 5f                	pop    %r15
   4f00e:	5d                   	pop    %rbp
   4f00f:	c3                   	ret
   4f010:	48 8d 0d e9 1c 05 00 	lea    0x51ce9(%rip),%rcx        # a0d00 <_TLS_MODULE_BASE_+0x17a0>
   4f017:	ba 12 04 00 00       	mov    $0x412,%edx
   4f01c:	4c 89 ff             	mov    %r15,%rdi
   4f01f:	e8 6c eb fd ff       	call   2db90 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4f024:	48 8d 0d d5 1c 05 00 	lea    0x51cd5(%rip),%rcx        # a0d00 <_TLS_MODULE_BASE_+0x17a0>
   4f02b:	ba 12 04 00 00       	mov    $0x412,%edx
   4f030:	4c 89 f7             	mov    %r14,%rdi
   4f033:	e8 58 eb fd ff       	call   2db90 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4f038:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4f03d:	49 81 fa 13 04 00 00 	cmp    $0x413,%r10
   4f044:	0f 83 54 01 00 00    	jae    4f19e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x281e>
   4f04a:	49 8b 01             	mov    (%r9),%rax
   4f04d:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4f051:	48 29 d8             	sub    %rbx,%rax
   4f054:	49 39 c2             	cmp    %rax,%r10
   4f057:	0f 87 9e 01 00 00    	ja     4f1fb <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x287b>
   4f05d:	4d 85 d2             	test   %r10,%r10
   4f060:	74 22                	je     4f084 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2704>
   4f062:	48 8d 3c 1b          	lea    (%rbx,%rbx,1),%rdi
   4f066:	49 03 79 08          	add    0x8(%r9),%rdi
   4f06a:	4b 8d 14 12          	lea    (%r10,%r10,1),%rdx
   4f06e:	4c 89 c6             	mov    %r8,%rsi
   4f071:	ff 15 d1 41 05 00    	call   *0x541d1(%rip)        # a3248 <memcpy@GLIBC_2.14>
   4f077:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4f07c:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4f083:	00 
   4f084:	4c 01 d3             	add    %r10,%rbx
   4f087:	49 89 59 10          	mov    %rbx,0x10(%r9)
   4f08b:	eb 6c                	jmp    4f0f9 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2779>
   4f08d:	48 8d 0d 3c 1c 05 00 	lea    0x51c3c(%rip),%rcx        # a0cd0 <_TLS_MODULE_BASE_+0x1770>
   4f094:	ba 12 04 00 00       	mov    $0x412,%edx
   4f099:	31 ff                	xor    %edi,%edi
   4f09b:	4c 89 fe             	mov    %r15,%rsi
   4f09e:	e8 ed ea fd ff       	call   2db90 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4f0a3:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
   4f0aa:	00 
   4f0ab:	48 8b 42 10          	mov    0x10(%rdx),%rax
   4f0af:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
   4f0b6:	00 
   4f0b7:	48 89 41 30          	mov    %rax,0x30(%rcx)
   4f0bb:	0f 10 02             	movups (%rdx),%xmm0
   4f0be:	0f 11 41 20          	movups %xmm0,0x20(%rcx)
   4f0c2:	48 b8 0b 00 00 00 00 	movabs $0x800000000000000b,%rax
   4f0c9:	00 00 80 
   4f0cc:	48 83 c0 06          	add    $0x6,%rax
   4f0d0:	e9 26 ff ff ff       	jmp    4effb <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x267b>
   4f0d5:	48 8d 0d f4 1b 05 00 	lea    0x51bf4(%rip),%rcx        # a0cd0 <_TLS_MODULE_BASE_+0x1770>
   4f0dc:	ba 12 04 00 00       	mov    $0x412,%edx
   4f0e1:	31 ff                	xor    %edi,%edi
   4f0e3:	4c 89 f6             	mov    %r14,%rsi
   4f0e6:	e8 a5 ea fd ff       	call   2db90 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4f0eb:	4c 89 cf             	mov    %r9,%rdi
   4f0ee:	4c 89 c6             	mov    %r8,%rsi
   4f0f1:	4c 89 fa             	mov    %r15,%rdx
   4f0f4:	e8 17 d8 ff ff       	call   4c910 <_RNvMs_NtCsgFX3jaOk65H_5alloc3vecINtB4_3VectE15append_elementsCs7Z5HuLIcqFl_5mibz2>
   4f0f9:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
   4f100:	00 
   4f101:	4c 89 20             	mov    %r12,(%rax)
   4f104:	48 89 68 08          	mov    %rbp,0x8(%rax)
   4f108:	44 89 68 10          	mov    %r13d,0x10(%rax)
   4f10c:	8b 4c 24 0c          	mov    0xc(%rsp),%ecx
   4f110:	89 48 14             	mov    %ecx,0x14(%rax)
   4f113:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
   4f11a:	00 
   4f11b:	48 8b 42 10          	mov    0x10(%rdx),%rax
   4f11f:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
   4f126:	00 
   4f127:	48 89 41 30          	mov    %rax,0x30(%rcx)
   4f12b:	48 8b 02             	mov    (%rdx),%rax
   4f12e:	48 89 41 20          	mov    %rax,0x20(%rcx)
   4f132:	48 8b 42 08          	mov    0x8(%rdx),%rax
   4f136:	48 89 41 28          	mov    %rax,0x28(%rcx)
   4f13a:	48 c7 01 ff ff ff ff 	movq   $0xffffffffffffffff,(%rcx)
   4f141:	e9 b8 fe ff ff       	jmp    4effe <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x267e>
   4f146:	48 8d 0d 3b 1b 05 00 	lea    0x51b3b(%rip),%rcx        # a0c88 <_TLS_MODULE_BASE_+0x1728>
   4f14d:	ba 12 04 00 00       	mov    $0x412,%edx
   4f152:	31 ff                	xor    %edi,%edi
   4f154:	4c 89 d6             	mov    %r10,%rsi
   4f157:	e8 34 ea fd ff       	call   2db90 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4f15c:	48 8d 0d 25 1b 05 00 	lea    0x51b25(%rip),%rcx        # a0c88 <_TLS_MODULE_BASE_+0x1728>
   4f163:	ba 12 04 00 00       	mov    $0x412,%edx
   4f168:	31 ff                	xor    %edi,%edi
   4f16a:	4c 89 fe             	mov    %r15,%rsi
   4f16d:	e8 1e ea fd ff       	call   2db90 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4f172:	48 8d 0d 6f 1b 05 00 	lea    0x51b6f(%rip),%rcx        # a0ce8 <_TLS_MODULE_BASE_+0x1788>
   4f179:	ba 12 04 00 00       	mov    $0x412,%edx
   4f17e:	31 ff                	xor    %edi,%edi
   4f180:	48 89 de             	mov    %rbx,%rsi
   4f183:	e8 08 ea fd ff       	call   2db90 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4f188:	48 8d 0d 59 1b 05 00 	lea    0x51b59(%rip),%rcx        # a0ce8 <_TLS_MODULE_BASE_+0x1788>
   4f18f:	ba 12 04 00 00       	mov    $0x412,%edx
   4f194:	31 ff                	xor    %edi,%edi
   4f196:	4c 89 fe             	mov    %r15,%rsi
   4f199:	e8 f2 e9 fd ff       	call   2db90 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4f19e:	48 8d 0d fb 1a 05 00 	lea    0x51afb(%rip),%rcx        # a0ca0 <_TLS_MODULE_BASE_+0x1740>
   4f1a5:	ba 12 04 00 00       	mov    $0x412,%edx
   4f1aa:	31 ff                	xor    %edi,%edi
   4f1ac:	4c 89 d6             	mov    %r10,%rsi
   4f1af:	e8 dc e9 fd ff       	call   2db90 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4f1b4:	89 c2                	mov    %eax,%edx
   4f1b6:	c1 ea 08             	shr    $0x8,%edx
   4f1b9:	89 94 24 8c 00 00 00 	mov    %edx,0x8c(%rsp)
   4f1c0:	48 8d b4 24 3a 01 00 	lea    0x13a(%rsp),%rsi
   4f1c7:	00 
   4f1c8:	48 8b 56 0e          	mov    0xe(%rsi),%rdx
   4f1cc:	48 89 94 24 ae 00 00 	mov    %rdx,0xae(%rsp)
   4f1d3:	00 
   4f1d4:	0f 10 06             	movups (%rsi),%xmm0
   4f1d7:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   4f1de:	00 
   4f1df:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
   4f1e6:	00 
   4f1e7:	4c 89 22             	mov    %r12,(%rdx)
   4f1ea:	48 89 6a 08          	mov    %rbp,0x8(%rdx)
   4f1ee:	44 89 6a 10          	mov    %r13d,0x10(%rdx)
   4f1f2:	8b 74 24 0c          	mov    0xc(%rsp),%esi
   4f1f6:	89 72 14             	mov    %esi,0x14(%rdx)
   4f1f9:	eb 7c                	jmp    4f277 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x28f7>
   4f1fb:	b9 02 00 00 00       	mov    $0x2,%ecx
   4f200:	41 b8 02 00 00 00    	mov    $0x2,%r8d
   4f206:	4c 89 cf             	mov    %r9,%rdi
   4f209:	48 89 de             	mov    %rbx,%rsi
   4f20c:	4c 89 d2             	mov    %r10,%rdx
   4f20f:	e8 7c 88 fe ff       	call   37a90 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs7Z5HuLIcqFl_5mibz2>
   4f214:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4f219:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4f220:	00 
   4f221:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4f228:	00 
   4f229:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4f22d:	e9 30 fe ff ff       	jmp    4f062 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x26e2>
   4f232:	48 8d b4 24 02 01 00 	lea    0x102(%rsp),%rsi
   4f239:	00 
   4f23a:	48 8b 56 0e          	mov    0xe(%rsi),%rdx
   4f23e:	48 89 94 24 ae 00 00 	mov    %rdx,0xae(%rsp)
   4f245:	00 
   4f246:	0f 10 06             	movups (%rsi),%xmm0
   4f249:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   4f250:	00 
   4f251:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
   4f258:	00 
   4f259:	4c 89 22             	mov    %r12,(%rdx)
   4f25c:	48 89 6a 08          	mov    %rbp,0x8(%rdx)
   4f260:	44 89 6a 10          	mov    %r13d,0x10(%rdx)
   4f264:	8b 74 24 0c          	mov    0xc(%rsp),%esi
   4f268:	89 72 14             	mov    %esi,0x14(%rdx)
   4f26b:	89 c2                	mov    %eax,%edx
   4f26d:	c1 ea 08             	shr    $0x8,%edx
   4f270:	89 94 24 8c 00 00 00 	mov    %edx,0x8c(%rsp)
   4f277:	48 8b 94 24 ae 00 00 	mov    0xae(%rsp),%rdx
   4f27e:	00 
   4f27f:	48 8b b4 24 b8 00 00 	mov    0xb8(%rsp),%rsi
   4f286:	00 
   4f287:	48 89 56 18          	mov    %rdx,0x18(%rsi)
   4f28b:	0f 28 84 24 a0 00 00 	movaps 0xa0(%rsp),%xmm0
   4f292:	00 
   4f293:	0f 11 46 0a          	movups %xmm0,0xa(%rsi)
   4f297:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
   4f29e:	00 
   4f29f:	48 8b 17             	mov    (%rdi),%rdx
   4f2a2:	48 89 56 20          	mov    %rdx,0x20(%rsi)
   4f2a6:	48 8b 57 08          	mov    0x8(%rdi),%rdx
   4f2aa:	48 89 56 28          	mov    %rdx,0x28(%rsi)
   4f2ae:	48 8b 57 10          	mov    0x10(%rdi),%rdx
   4f2b2:	48 89 56 30          	mov    %rdx,0x30(%rsi)
   4f2b6:	48 89 0e             	mov    %rcx,(%rsi)
   4f2b9:	88 46 08             	mov    %al,0x8(%rsi)
   4f2bc:	8b 84 24 8c 00 00 00 	mov    0x8c(%rsp),%eax
   4f2c3:	88 46 09             	mov    %al,0x9(%rsi)
   4f2c6:	e9 33 fd ff ff       	jmp    4effe <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x267e>
   4f2cb:	48 8d 15 c6 21 05 00 	lea    0x521c6(%rip),%rdx        # a1498 <_TLS_MODULE_BASE_+0x1f38>
   4f2d2:	be 06 00 00 00       	mov    $0x6,%esi
   4f2d7:	e8 95 e9 fd ff       	call   2dc71 <_RNvNtCskADBYZwJmSU_4core9panicking18panic_bounds_check>
   4f2dc:	48 8d 0d d5 19 05 00 	lea    0x519d5(%rip),%rcx        # a0cb8 <_TLS_MODULE_BASE_+0x1758>
   4f2e3:	ba 12 04 00 00       	mov    $0x412,%edx
   4f2e8:	31 ff                	xor    %edi,%edi
   4f2ea:	4c 89 fe             	mov    %r15,%rsi
   4f2ed:	e8 9e e8 fd ff       	call   2db90 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4f2f2:	48 8d 0d 77 19 05 00 	lea    0x51977(%rip),%rcx        # a0c70 <_TLS_MODULE_BASE_+0x1710>
   4f2f9:	ba 12 04 00 00       	mov    $0x412,%edx
   4f2fe:	31 ff                	xor    %edi,%edi
   4f300:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
   4f305:	e8 86 e8 fd ff       	call   2db90 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
