/home/louis/dev/mibz2/target/scanner-a2-fast/tmpgm7xw5ll/base-real:     file format elf64-x86-64


Disassembly of section .fini:

Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000004b020 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2>:
   4b020:	55                   	push   %rbp
   4b021:	41 57                	push   %r15
   4b023:	41 56                	push   %r14
   4b025:	41 55                	push   %r13
   4b027:	41 54                	push   %r12
   4b029:	53                   	push   %rbx
   4b02a:	48 81 ec 68 01 00 00 	sub    $0x168,%rsp
   4b031:	4d 89 ca             	mov    %r9,%r10
   4b034:	4c 89 84 24 80 00 00 	mov    %r8,0x80(%rsp)
   4b03b:	00 
   4b03c:	48 89 b4 24 d8 00 00 	mov    %rsi,0xd8(%rsp)
   4b043:	00 
   4b044:	48 89 bc 24 b0 00 00 	mov    %rdi,0xb0(%rsp)
   4b04b:	00 
   4b04c:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4b053:	00 
   4b054:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4b05b:	00 
   4b05c:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4b063:	00 
   4b064:	4a 8d 04 dd 00 00 00 	lea    0x0(,%r11,8),%rax
   4b06b:	00 
   4b06c:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
   4b073:	00 
   4b074:	31 db                	xor    %ebx,%ebx
   4b076:	45 31 f6             	xor    %r14d,%r14d
   4b079:	89 44 24 7c          	mov    %eax,0x7c(%rsp)
   4b07d:	4c 89 54 24 30       	mov    %r10,0x30(%rsp)
   4b082:	48 89 8c 24 e8 00 00 	mov    %rcx,0xe8(%rsp)
   4b089:	00 
   4b08a:	48 89 94 24 e0 00 00 	mov    %rdx,0xe0(%rsp)
   4b091:	00 
   4b092:	0f b6 3c 1a          	movzbl (%rdx,%rbx,1),%edi
   4b096:	48 8d 43 01          	lea    0x1(%rbx),%rax
   4b09a:	48 39 c8             	cmp    %rcx,%rax
   4b09d:	73 31                	jae    4b0d0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xb0>
   4b09f:	48 89 ce             	mov    %rcx,%rsi
   4b0a2:	48 29 de             	sub    %rbx,%rsi
   4b0a5:	bb 01 00 00 00       	mov    $0x1,%ebx
   4b0aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   4b0b0:	40 38 3c 02          	cmp    %dil,(%rdx,%rax,1)
   4b0b4:	75 1f                	jne    4b0d5 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xb5>
   4b0b6:	48 ff c3             	inc    %rbx
   4b0b9:	48 ff c0             	inc    %rax
   4b0bc:	48 39 c1             	cmp    %rax,%rcx
   4b0bf:	75 ef                	jne    4b0b0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x90>
   4b0c1:	48 89 f3             	mov    %rsi,%rbx
   4b0c4:	48 89 c8             	mov    %rcx,%rax
   4b0c7:	eb 0c                	jmp    4b0d5 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xb5>
   4b0c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   4b0d0:	bb 01 00 00 00       	mov    $0x1,%ebx
   4b0d5:	40 80 ff 06          	cmp    $0x6,%dil
   4b0d9:	0f 83 94 27 00 00    	jae    4d873 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2853>
   4b0df:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
   4b0e6:	00 
   4b0e7:	48 69 ff c8 1a 00 00 	imul   $0x1ac8,%rdi,%rdi
   4b0ee:	48 03 bc 24 d8 00 00 	add    0xd8(%rsp),%rdi
   4b0f5:	00 
   4b0f6:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   4b0fd:	00 
   4b0fe:	4c 8b 20             	mov    (%rax),%r12
   4b101:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
   4b106:	48 6b c3 7d          	imul   $0x7d,%rbx,%rax
   4b10a:	48 83 c0 10          	add    $0x10,%rax
   4b10e:	4c 01 e0             	add    %r12,%rax
   4b111:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
   4b118:	48 0f 42 c1          	cmovb  %rcx,%rax
   4b11c:	48 89 da             	mov    %rbx,%rdx
   4b11f:	4c 39 d8             	cmp    %r11,%rax
   4b122:	48 89 9c 24 f0 00 00 	mov    %rbx,0xf0(%rsp)
   4b129:	00 
   4b12a:	0f 86 2c 07 00 00    	jbe    4b85c <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x83c>
   4b130:	4c 89 e0             	mov    %r12,%rax
   4b133:	48 83 c0 10          	add    $0x10,%rax
   4b137:	48 0f 42 c1          	cmovb  %rcx,%rax
   4b13b:	4c 89 da             	mov    %r11,%rdx
   4b13e:	48 29 c2             	sub    %rax,%rdx
   4b141:	b8 00 00 00 00       	mov    $0x0,%eax
   4b146:	48 0f 42 d0          	cmovb  %rax,%rdx
   4b14a:	48 83 fa 7c          	cmp    $0x7c,%rdx
   4b14e:	0f 87 ec 06 00 00    	ja     4b840 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x820>
   4b154:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   4b15b:	00 
   4b15c:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
   4b160:	8b 42 10             	mov    0x10(%rdx),%eax
   4b163:	8b 52 14             	mov    0x14(%rdx),%edx
   4b166:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4b16a:	0f b7 97 c4 1a 00 00 	movzwl 0x1ac4(%rdi),%edx
   4b171:	66 89 94 24 88 00 00 	mov    %dx,0x88(%rsp)
   4b178:	00 
   4b179:	49 83 fc f7          	cmp    $0xfffffffffffffff7,%r12
   4b17d:	0f 87 fb 17 00 00    	ja     4c97e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x195e>
   4b183:	49 8d 54 24 08       	lea    0x8(%r12),%rdx
   4b188:	4c 39 da             	cmp    %r11,%rdx
   4b18b:	0f 87 ed 17 00 00    	ja     4c97e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x195e>
   4b191:	4b 8b 14 22          	mov    (%r10,%r12,1),%rdx
   4b195:	48 0f ca             	bswap  %rdx
   4b198:	c4 e2 fb f7 ea       	shrx   %rax,%rdx,%rbp
   4b19d:	48 09 cd             	or     %rcx,%rbp
   4b1a0:	41 bd 3f 00 00 00    	mov    $0x3f,%r13d
   4b1a6:	41 29 c5             	sub    %eax,%r13d
   4b1a9:	44 89 e9             	mov    %r13d,%ecx
   4b1ac:	c1 e9 03             	shr    $0x3,%ecx
   4b1af:	49 01 cc             	add    %rcx,%r12
   4b1b2:	41 83 e5 f8          	and    $0xfffffff8,%r13d
   4b1b6:	41 01 c5             	add    %eax,%r13d
   4b1b9:	b8 32 00 00 00       	mov    $0x32,%eax
   4b1be:	4c 89 f1             	mov    %r14,%rcx
   4b1c1:	eb 6e                	jmp    4b231 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x211>
   4b1c3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   4b1ca:	84 00 00 00 00 00 
   4b1d0:	48 8d 3c 1b          	lea    (%rbx,%rbx,1),%rdi
   4b1d4:	49 03 79 08          	add    0x8(%r9),%rdi
   4b1d8:	4b 8d 14 36          	lea    (%r14,%r14,1),%rdx
   4b1dc:	4c 89 c6             	mov    %r8,%rsi
   4b1df:	ff 15 63 65 05 00    	call   *0x56563(%rip)        # a1748 <memcpy@GLIBC_2.14>
   4b1e5:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4b1ec:	00 
   4b1ed:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4b1f4:	00 
   4b1f5:	4c 01 f3             	add    %r14,%rbx
   4b1f8:	49 89 59 10          	mov    %rbx,0x10(%r9)
   4b1fc:	45 31 ff             	xor    %r15d,%r15d
   4b1ff:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4b204:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4b20b:	00 
   4b20c:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4b211:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
   4b218:	00 
   4b219:	48 03 84 24 c0 00 00 	add    0xc0(%rsp),%rax
   4b220:	00 
   4b221:	4c 29 f0             	sub    %r14,%rax
   4b224:	4c 89 f9             	mov    %r15,%rcx
   4b227:	48 83 f8 09          	cmp    $0x9,%rax
   4b22b:	0f 86 5c 09 00 00    	jbe    4bb8d <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xb6d>
   4b231:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
   4b238:	00 
   4b239:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
   4b23d:	48 83 c2 f6          	add    $0xfffffffffffffff6,%rdx
   4b241:	48 81 fa e8 03 00 00 	cmp    $0x3e8,%rdx
   4b248:	b8 e8 03 00 00       	mov    $0x3e8,%eax
   4b24d:	48 0f 43 d0          	cmovae %rax,%rdx
   4b251:	49 89 ce             	mov    %rcx,%r14
   4b254:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
   4b25b:	00 
   4b25c:	48 89 94 24 a8 00 00 	mov    %rdx,0xa8(%rsp)
   4b263:	00 
   4b264:	48 39 d1             	cmp    %rdx,%rcx
   4b267:	76 67                	jbe    4b2d0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2b0>
   4b269:	4d 89 f7             	mov    %r14,%r15
   4b26c:	49 81 fe e8 03 00 00 	cmp    $0x3e8,%r14
   4b273:	76 9c                	jbe    4b211 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1f1>
   4b275:	49 81 fe 13 04 00 00 	cmp    $0x413,%r14
   4b27c:	0f 83 f9 23 00 00    	jae    4d67b <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x265b>
   4b282:	49 8b 01             	mov    (%r9),%rax
   4b285:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4b289:	48 29 d8             	sub    %rbx,%rax
   4b28c:	49 39 c6             	cmp    %rax,%r14
   4b28f:	0f 86 3b ff ff ff    	jbe    4b1d0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1b0>
   4b295:	b9 02 00 00 00       	mov    $0x2,%ecx
   4b29a:	41 b8 02 00 00 00    	mov    $0x2,%r8d
   4b2a0:	4c 89 cf             	mov    %r9,%rdi
   4b2a3:	48 89 de             	mov    %rbx,%rsi
   4b2a6:	4c 89 f2             	mov    %r14,%rdx
   4b2a9:	e8 c2 b7 fe ff       	call   36a70 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs7Z5HuLIcqFl_5mibz2>
   4b2ae:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4b2b5:	00 
   4b2b6:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4b2bd:	00 
   4b2be:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4b2c2:	e9 09 ff ff ff       	jmp    4b1d0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1b0>
   4b2c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   4b2ce:	00 00 
   4b2d0:	49 8d 76 12          	lea    0x12(%r14),%rsi
   4b2d4:	48 81 fe 13 04 00 00 	cmp    $0x413,%rsi
   4b2db:	0f 83 ed 22 00 00    	jae    4d5ce <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x25ae>
   4b2e1:	4c 89 e6             	mov    %r12,%rsi
   4b2e4:	4f 8d 24 70          	lea    (%r8,%r14,2),%r12
   4b2e8:	48 89 e8             	mov    %rbp,%rax
   4b2eb:	48 c1 e8 36          	shr    $0x36,%rax
   4b2ef:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4b2f2:	41 89 d7             	mov    %edx,%r15d
   4b2f5:	41 c1 ef 1e          	shr    $0x1e,%r15d
   4b2f9:	0f 84 57 01 00 00    	je     4b456 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x436>
   4b2ff:	c4 e2 e9 f7 dd       	shlx   %rdx,%rbp,%rbx
   4b304:	0f b6 c2             	movzbl %dl,%eax
   4b307:	41 29 c5             	sub    %eax,%r13d
   4b30a:	0f b6 c6             	movzbl %dh,%eax
   4b30d:	66 41 89 04 24       	mov    %ax,(%r12)
   4b312:	c1 ea 10             	shr    $0x10,%edx
   4b315:	0f b6 c2             	movzbl %dl,%eax
   4b318:	66 41 89 44 24 02    	mov    %ax,0x2(%r12)
   4b31e:	48 89 d8             	mov    %rbx,%rax
   4b321:	48 c1 e8 36          	shr    $0x36,%rax
   4b325:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4b328:	89 d0                	mov    %edx,%eax
   4b32a:	c1 e8 1e             	shr    $0x1e,%eax
   4b32d:	0f 84 d3 01 00 00    	je     4b506 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x4e6>
   4b333:	c4 e2 e9 f7 db       	shlx   %rdx,%rbx,%rbx
   4b338:	0f b6 ca             	movzbl %dl,%ecx
   4b33b:	41 29 cd             	sub    %ecx,%r13d
   4b33e:	0f b6 ce             	movzbl %dh,%ecx
   4b341:	66 43 89 0c 7c       	mov    %cx,(%r12,%r15,2)
   4b346:	c1 ea 10             	shr    $0x10,%edx
   4b349:	0f b6 ca             	movzbl %dl,%ecx
   4b34c:	66 43 89 4c 7c 02    	mov    %cx,0x2(%r12,%r15,2)
   4b352:	49 01 c7             	add    %rax,%r15
   4b355:	48 89 d8             	mov    %rbx,%rax
   4b358:	48 c1 e8 36          	shr    $0x36,%rax
   4b35c:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4b35f:	89 d0                	mov    %edx,%eax
   4b361:	c1 e8 1e             	shr    $0x1e,%eax
   4b364:	0f 84 49 02 00 00    	je     4b5b3 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x593>
   4b36a:	c4 e2 e9 f7 db       	shlx   %rdx,%rbx,%rbx
   4b36f:	0f b6 ca             	movzbl %dl,%ecx
   4b372:	41 29 cd             	sub    %ecx,%r13d
   4b375:	0f b6 ce             	movzbl %dh,%ecx
   4b378:	66 43 89 0c 7c       	mov    %cx,(%r12,%r15,2)
   4b37d:	c1 ea 10             	shr    $0x10,%edx
   4b380:	0f b6 ca             	movzbl %dl,%ecx
   4b383:	66 43 89 4c 7c 02    	mov    %cx,0x2(%r12,%r15,2)
   4b389:	49 01 c7             	add    %rax,%r15
   4b38c:	48 89 d8             	mov    %rbx,%rax
   4b38f:	48 c1 e8 36          	shr    $0x36,%rax
   4b393:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4b396:	89 d0                	mov    %edx,%eax
   4b398:	c1 e8 1e             	shr    $0x1e,%eax
   4b39b:	0f 84 bf 02 00 00    	je     4b660 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x640>
   4b3a1:	c4 e2 e9 f7 db       	shlx   %rdx,%rbx,%rbx
   4b3a6:	0f b6 ca             	movzbl %dl,%ecx
   4b3a9:	41 29 cd             	sub    %ecx,%r13d
   4b3ac:	0f b6 ce             	movzbl %dh,%ecx
   4b3af:	66 43 89 0c 7c       	mov    %cx,(%r12,%r15,2)
   4b3b4:	c1 ea 10             	shr    $0x10,%edx
   4b3b7:	0f b6 ca             	movzbl %dl,%ecx
   4b3ba:	66 43 89 4c 7c 02    	mov    %cx,0x2(%r12,%r15,2)
   4b3c0:	49 01 c7             	add    %rax,%r15
   4b3c3:	48 89 d8             	mov    %rbx,%rax
   4b3c6:	48 c1 e8 36          	shr    $0x36,%rax
   4b3ca:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4b3cd:	89 d0                	mov    %edx,%eax
   4b3cf:	c1 e8 1e             	shr    $0x1e,%eax
   4b3d2:	0f 84 35 03 00 00    	je     4b70d <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x6ed>
   4b3d8:	c4 e2 e9 f7 db       	shlx   %rdx,%rbx,%rbx
   4b3dd:	0f b6 ca             	movzbl %dl,%ecx
   4b3e0:	41 29 cd             	sub    %ecx,%r13d
   4b3e3:	0f b6 ce             	movzbl %dh,%ecx
   4b3e6:	66 43 89 0c 7c       	mov    %cx,(%r12,%r15,2)
   4b3eb:	c1 ea 10             	shr    $0x10,%edx
   4b3ee:	0f b6 ca             	movzbl %dl,%ecx
   4b3f1:	66 43 89 4c 7c 02    	mov    %cx,0x2(%r12,%r15,2)
   4b3f7:	49 01 c7             	add    %rax,%r15
   4b3fa:	44 89 ea             	mov    %r13d,%edx
   4b3fd:	49 89 f4             	mov    %rsi,%r12
   4b400:	48 83 fe f7          	cmp    $0xfffffffffffffff7,%rsi
   4b404:	0f 87 b7 03 00 00    	ja     4b7c1 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x7a1>
   4b40a:	49 8d 44 24 08       	lea    0x8(%r12),%rax
   4b40f:	4c 39 d8             	cmp    %r11,%rax
   4b412:	0f 87 a9 03 00 00    	ja     4b7c1 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x7a1>
   4b418:	4b 8b 04 22          	mov    (%r10,%r12,1),%rax
   4b41c:	48 0f c8             	bswap  %rax
   4b41f:	c4 e2 eb f7 e8       	shrx   %rdx,%rax,%rbp
   4b424:	48 09 dd             	or     %rbx,%rbp
   4b427:	41 bd 3f 00 00 00    	mov    $0x3f,%r13d
   4b42d:	41 29 d5             	sub    %edx,%r13d
   4b430:	44 89 e8             	mov    %r13d,%eax
   4b433:	c1 e8 03             	shr    $0x3,%eax
   4b436:	49 01 c4             	add    %rax,%r12
   4b439:	41 83 e5 f8          	and    $0xfffffff8,%r13d
   4b43d:	41 01 d5             	add    %edx,%r13d
   4b440:	4d 01 fe             	add    %r15,%r14
   4b443:	4c 3b b4 24 a8 00 00 	cmp    0xa8(%rsp),%r14
   4b44a:	00 
   4b44b:	0f 86 7f fe ff ff    	jbe    4b2d0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2b0>
   4b451:	e9 13 fe ff ff       	jmp    4b269 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x249>
   4b456:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4b45b:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4b460:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4b465:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4b469:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4b46d:	48 89 fe             	mov    %rdi,%rsi
   4b470:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4b475:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4b47a:	4d 89 d0             	mov    %r10,%r8
   4b47d:	4d 89 d9             	mov    %r11,%r9
   4b480:	e8 bb f7 ff ff       	call   4ac40 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4b485:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4b48a:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4b48f:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4b494:	0f 10 02             	movups (%rdx),%xmm0
   4b497:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4b49c:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4b4a0:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4b4a5:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   4b4aa:	48 8b 5c 24 68       	mov    0x68(%rsp),%rbx
   4b4af:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4b4b4:	8b 6c 24 74          	mov    0x74(%rsp),%ebp
   4b4b8:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4b4bc:	0f 85 c3 0b 00 00    	jne    4c085 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1065>
   4b4c2:	66 41 89 04 24       	mov    %ax,(%r12)
   4b4c7:	66 3b 84 24 88 00 00 	cmp    0x88(%rsp),%ax
   4b4ce:	00 
   4b4cf:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4b4d6:	00 
   4b4d7:	0f 84 00 0c 00 00    	je     4c0dd <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x10bd>
   4b4dd:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4b4e1:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   4b4e7:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4b4ee:	00 
   4b4ef:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4b4f4:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4b4fb:	00 
   4b4fc:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4b501:	e9 18 fe ff ff       	jmp    4b31e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2fe>
   4b506:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4b50b:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   4b510:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4b515:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4b519:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4b51d:	48 89 fe             	mov    %rdi,%rsi
   4b520:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4b525:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4b52a:	4d 89 d0             	mov    %r10,%r8
   4b52d:	4d 89 d9             	mov    %r11,%r9
   4b530:	e8 0b f7 ff ff       	call   4ac40 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4b535:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4b53a:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4b53f:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4b544:	0f 10 02             	movups (%rdx),%xmm0
   4b547:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4b54c:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4b550:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4b555:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   4b55a:	48 8b 5c 24 68       	mov    0x68(%rsp),%rbx
   4b55f:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4b564:	8b 6c 24 74          	mov    0x74(%rsp),%ebp
   4b568:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4b56c:	0f 85 1b 0b 00 00    	jne    4c08d <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x106d>
   4b572:	66 43 89 04 7c       	mov    %ax,(%r12,%r15,2)
   4b577:	49 ff c7             	inc    %r15
   4b57a:	66 3b 84 24 88 00 00 	cmp    0x88(%rsp),%ax
   4b581:	00 
   4b582:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4b589:	00 
   4b58a:	0f 84 58 0b 00 00    	je     4c0e8 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x10c8>
   4b590:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4b594:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4b59b:	00 
   4b59c:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4b5a1:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4b5a8:	00 
   4b5a9:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4b5ae:	e9 a2 fd ff ff       	jmp    4b355 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x335>
   4b5b3:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4b5b8:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   4b5bd:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4b5c2:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4b5c6:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4b5ca:	48 89 fe             	mov    %rdi,%rsi
   4b5cd:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4b5d2:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4b5d7:	4d 89 d0             	mov    %r10,%r8
   4b5da:	4d 89 d9             	mov    %r11,%r9
   4b5dd:	e8 5e f6 ff ff       	call   4ac40 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4b5e2:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4b5e7:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4b5ec:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4b5f1:	0f 10 02             	movups (%rdx),%xmm0
   4b5f4:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4b5f9:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4b5fd:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4b602:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   4b607:	48 8b 5c 24 68       	mov    0x68(%rsp),%rbx
   4b60c:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4b611:	8b 6c 24 74          	mov    0x74(%rsp),%ebp
   4b615:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4b619:	0f 85 6e 0a 00 00    	jne    4c08d <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x106d>
   4b61f:	66 43 89 04 7c       	mov    %ax,(%r12,%r15,2)
   4b624:	49 ff c7             	inc    %r15
   4b627:	66 3b 84 24 88 00 00 	cmp    0x88(%rsp),%ax
   4b62e:	00 
   4b62f:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4b636:	00 
   4b637:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4b63e:	00 
   4b63f:	0f 84 ab 0a 00 00    	je     4c0f0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x10d0>
   4b645:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4b649:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4b64e:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4b655:	00 
   4b656:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4b65b:	e9 2c fd ff ff       	jmp    4b38c <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x36c>
   4b660:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4b665:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   4b66a:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4b66f:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4b673:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4b677:	48 89 fe             	mov    %rdi,%rsi
   4b67a:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4b67f:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4b684:	4d 89 d0             	mov    %r10,%r8
   4b687:	4d 89 d9             	mov    %r11,%r9
   4b68a:	e8 b1 f5 ff ff       	call   4ac40 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4b68f:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4b694:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4b699:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4b69e:	0f 10 02             	movups (%rdx),%xmm0
   4b6a1:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4b6a6:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4b6aa:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4b6af:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   4b6b4:	48 8b 5c 24 68       	mov    0x68(%rsp),%rbx
   4b6b9:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4b6be:	8b 6c 24 74          	mov    0x74(%rsp),%ebp
   4b6c2:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4b6c6:	0f 85 c1 09 00 00    	jne    4c08d <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x106d>
   4b6cc:	66 43 89 04 7c       	mov    %ax,(%r12,%r15,2)
   4b6d1:	49 ff c7             	inc    %r15
   4b6d4:	66 3b 84 24 88 00 00 	cmp    0x88(%rsp),%ax
   4b6db:	00 
   4b6dc:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4b6e3:	00 
   4b6e4:	0f 84 fe 09 00 00    	je     4c0e8 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x10c8>
   4b6ea:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4b6ee:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4b6f5:	00 
   4b6f6:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4b6fb:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4b702:	00 
   4b703:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4b708:	e9 b6 fc ff ff       	jmp    4b3c3 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x3a3>
   4b70d:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4b712:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   4b717:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4b71c:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4b720:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4b724:	48 89 fe             	mov    %rdi,%rsi
   4b727:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4b72c:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4b731:	4d 89 d0             	mov    %r10,%r8
   4b734:	4d 89 d9             	mov    %r11,%r9
   4b737:	e8 04 f5 ff ff       	call   4ac40 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4b73c:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4b741:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4b746:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4b74b:	0f 10 02             	movups (%rdx),%xmm0
   4b74e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4b753:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4b757:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4b75c:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   4b761:	48 8b 5c 24 68       	mov    0x68(%rsp),%rbx
   4b766:	8b 54 24 70          	mov    0x70(%rsp),%edx
   4b76a:	8b 6c 24 74          	mov    0x74(%rsp),%ebp
   4b76e:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4b772:	0f 85 12 09 00 00    	jne    4c08a <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x106a>
   4b778:	66 43 89 04 7c       	mov    %ax,(%r12,%r15,2)
   4b77d:	49 ff c7             	inc    %r15
   4b780:	66 3b 84 24 88 00 00 	cmp    0x88(%rsp),%ax
   4b787:	00 
   4b788:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4b78f:	00 
   4b790:	0f 84 4f 09 00 00    	je     4c0e5 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x10c5>
   4b796:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4b79a:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4b7a1:	00 
   4b7a2:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4b7a7:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4b7ae:	00 
   4b7af:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4b7b4:	49 89 f4             	mov    %rsi,%r12
   4b7b7:	48 83 fe f7          	cmp    $0xfffffffffffffff7,%rsi
   4b7bb:	0f 86 49 fc ff ff    	jbe    4b40a <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x3ea>
   4b7c1:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
   4b7c6:	48 89 5c 24 48       	mov    %rbx,0x48(%rsp)
   4b7cb:	89 54 24 50          	mov    %edx,0x50(%rsp)
   4b7cf:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4b7d3:	89 44 24 54          	mov    %eax,0x54(%rsp)
   4b7d7:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   4b7dc:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   4b7e1:	4c 89 d2             	mov    %r10,%rdx
   4b7e4:	4c 89 d9             	mov    %r11,%rcx
   4b7e7:	e8 c4 9e ff ff       	call   456b0 <_RNvMNtCs7Z5HuLIcqFl_5mibz24bitsNtB2_3Reg11refill_slow>
   4b7ec:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4b7f1:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4b7f8:	00 
   4b7f9:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4b7fe:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4b805:	00 
   4b806:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4b80d:	00 
   4b80e:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   4b813:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   4b818:	44 8b 6c 24 20       	mov    0x20(%rsp),%r13d
   4b81d:	8b 44 24 24          	mov    0x24(%rsp),%eax
   4b821:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   4b825:	4d 01 fe             	add    %r15,%r14
   4b828:	4c 3b b4 24 a8 00 00 	cmp    0xa8(%rsp),%r14
   4b82f:	00 
   4b830:	0f 86 9a fa ff ff    	jbe    4b2d0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2b0>
   4b836:	e9 2e fa ff ff       	jmp    4b269 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x249>
   4b83b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   4b840:	48 b8 77 be 9f 1a 2f 	movabs $0x624dd2f1a9fbe77,%rax
   4b847:	dd 24 06 
   4b84a:	c4 e2 fb f6 c0       	mulx   %rax,%rax,%rax
   4b84f:	48 29 c2             	sub    %rax,%rdx
   4b852:	48 d1 ea             	shr    $1,%rdx
   4b855:	48 01 c2             	add    %rax,%rdx
   4b858:	48 c1 ea 06          	shr    $0x6,%rdx
   4b85c:	48 89 94 24 88 00 00 	mov    %rdx,0x88(%rsp)
   4b863:	00 
   4b864:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   4b86b:	00 
   4b86c:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
   4b870:	8b 42 10             	mov    0x10(%rdx),%eax
   4b873:	8b 52 14             	mov    0x14(%rdx),%edx
   4b876:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4b87a:	0f b7 97 c4 1a 00 00 	movzwl 0x1ac4(%rdi),%edx
   4b881:	66 89 54 24 2e       	mov    %dx,0x2e(%rsp)
   4b886:	49 83 fc f7          	cmp    $0xfffffffffffffff7,%r12
   4b88a:	0f 87 05 09 00 00    	ja     4c195 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1175>
   4b890:	49 8d 54 24 08       	lea    0x8(%r12),%rdx
   4b895:	4c 39 da             	cmp    %r11,%rdx
   4b898:	0f 87 f7 08 00 00    	ja     4c195 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1175>
   4b89e:	4b 8b 14 22          	mov    (%r10,%r12,1),%rdx
   4b8a2:	48 0f ca             	bswap  %rdx
   4b8a5:	c4 e2 fb f7 ea       	shrx   %rax,%rdx,%rbp
   4b8aa:	48 09 cd             	or     %rcx,%rbp
   4b8ad:	41 bd 3f 00 00 00    	mov    $0x3f,%r13d
   4b8b3:	41 29 c5             	sub    %eax,%r13d
   4b8b6:	44 89 e9             	mov    %r13d,%ecx
   4b8b9:	c1 e9 03             	shr    $0x3,%ecx
   4b8bc:	49 01 cc             	add    %rcx,%r12
   4b8bf:	41 83 e5 f8          	and    $0xfffffff8,%r13d
   4b8c3:	41 01 c5             	add    %eax,%r13d
   4b8c6:	48 6b 94 24 88 00 00 	imul   $0x32,0x88(%rsp),%rdx
   4b8cd:	00 32 
   4b8cf:	48 83 fa 0a          	cmp    $0xa,%rdx
   4b8d3:	0f 83 95 09 00 00    	jae    4c26e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x124e>
   4b8d9:	48 85 d2             	test   %rdx,%rdx
   4b8dc:	0f 84 63 02 00 00    	je     4bb45 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xb25>
   4b8e2:	4a 8d 0c 32          	lea    (%rdx,%r14,1),%rcx
   4b8e6:	48 83 fa 01          	cmp    $0x1,%rdx
   4b8ea:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
   4b8f1:	00 
   4b8f2:	0f 84 3f 01 00 00    	je     4ba37 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xa17>
   4b8f8:	48 8d 59 fe          	lea    -0x2(%rcx),%rbx
   4b8fc:	49 39 de             	cmp    %rbx,%r14
   4b8ff:	0f 87 29 01 00 00    	ja     4ba2e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xa0e>
   4b905:	48 89 e8             	mov    %rbp,%rax
   4b908:	48 c1 e8 36          	shr    $0x36,%rax
   4b90c:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4b90f:	89 d0                	mov    %edx,%eax
   4b911:	c1 e8 1e             	shr    $0x1e,%eax
   4b914:	0f 84 6c 12 00 00    	je     4cb86 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1b66>
   4b91a:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4b91f:	0f b6 ca             	movzbl %dl,%ecx
   4b922:	41 29 cd             	sub    %ecx,%r13d
   4b925:	4d 89 f7             	mov    %r14,%r15
   4b928:	44 89 f9             	mov    %r15d,%ecx
   4b92b:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4b931:	0f b6 f6             	movzbl %dh,%esi
   4b934:	66 41 89 34 48       	mov    %si,(%r8,%rcx,2)
   4b939:	c1 ea 10             	shr    $0x10,%edx
   4b93c:	0f b6 d2             	movzbl %dl,%edx
   4b93f:	66 41 89 54 48 02    	mov    %dx,0x2(%r8,%rcx,2)
   4b945:	49 01 c7             	add    %rax,%r15
   4b948:	4d 89 fe             	mov    %r15,%r14
   4b94b:	49 39 df             	cmp    %rbx,%r15
   4b94e:	0f 87 da 00 00 00    	ja     4ba2e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xa0e>
   4b954:	48 89 e8             	mov    %rbp,%rax
   4b957:	48 c1 e8 36          	shr    $0x36,%rax
   4b95b:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4b95e:	89 d0                	mov    %edx,%eax
   4b960:	c1 e8 1e             	shr    $0x1e,%eax
   4b963:	0f 84 26 15 00 00    	je     4ce8f <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1e6f>
   4b969:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4b96e:	0f b6 ca             	movzbl %dl,%ecx
   4b971:	41 29 cd             	sub    %ecx,%r13d
   4b974:	4d 89 f7             	mov    %r14,%r15
   4b977:	44 89 f9             	mov    %r15d,%ecx
   4b97a:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4b980:	0f b6 f6             	movzbl %dh,%esi
   4b983:	66 41 89 34 48       	mov    %si,(%r8,%rcx,2)
   4b988:	c1 ea 10             	shr    $0x10,%edx
   4b98b:	0f b6 d2             	movzbl %dl,%edx
   4b98e:	66 41 89 54 48 02    	mov    %dx,0x2(%r8,%rcx,2)
   4b994:	49 01 c7             	add    %rax,%r15
   4b997:	4d 89 fe             	mov    %r15,%r14
   4b99a:	49 39 df             	cmp    %rbx,%r15
   4b99d:	0f 87 8b 00 00 00    	ja     4ba2e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xa0e>
   4b9a3:	48 89 e8             	mov    %rbp,%rax
   4b9a6:	48 c1 e8 36          	shr    $0x36,%rax
   4b9aa:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4b9ad:	89 d0                	mov    %edx,%eax
   4b9af:	c1 e8 1e             	shr    $0x1e,%eax
   4b9b2:	0f 84 5e 16 00 00    	je     4d016 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1ff6>
   4b9b8:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4b9bd:	0f b6 ca             	movzbl %dl,%ecx
   4b9c0:	41 29 cd             	sub    %ecx,%r13d
   4b9c3:	4d 89 f7             	mov    %r14,%r15
   4b9c6:	44 89 f9             	mov    %r15d,%ecx
   4b9c9:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4b9cf:	0f b6 f6             	movzbl %dh,%esi
   4b9d2:	66 41 89 34 48       	mov    %si,(%r8,%rcx,2)
   4b9d7:	c1 ea 10             	shr    $0x10,%edx
   4b9da:	0f b6 d2             	movzbl %dl,%edx
   4b9dd:	66 41 89 54 48 02    	mov    %dx,0x2(%r8,%rcx,2)
   4b9e3:	49 01 c7             	add    %rax,%r15
   4b9e6:	4d 89 fe             	mov    %r15,%r14
   4b9e9:	49 39 df             	cmp    %rbx,%r15
   4b9ec:	77 40                	ja     4ba2e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xa0e>
   4b9ee:	48 89 e8             	mov    %rbp,%rax
   4b9f1:	48 c1 e8 36          	shr    $0x36,%rax
   4b9f5:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4b9f8:	89 d0                	mov    %edx,%eax
   4b9fa:	c1 e8 1e             	shr    $0x1e,%eax
   4b9fd:	0f 84 d0 17 00 00    	je     4d1d3 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x21b3>
   4ba03:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4ba08:	0f b6 ca             	movzbl %dl,%ecx
   4ba0b:	41 29 cd             	sub    %ecx,%r13d
   4ba0e:	44 89 f1             	mov    %r14d,%ecx
   4ba11:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4ba17:	0f b6 f6             	movzbl %dh,%esi
   4ba1a:	66 41 89 34 48       	mov    %si,(%r8,%rcx,2)
   4ba1f:	c1 ea 10             	shr    $0x10,%edx
   4ba22:	0f b6 d2             	movzbl %dl,%edx
   4ba25:	66 41 89 54 48 02    	mov    %dx,0x2(%r8,%rcx,2)
   4ba2b:	49 01 c6             	add    %rax,%r14
   4ba2e:	49 39 de             	cmp    %rbx,%r14
   4ba31:	0f 86 b8 03 00 00    	jbe    4bdef <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xdcf>
   4ba37:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
   4ba3e:	00 
   4ba3f:	48 ff c8             	dec    %rax
   4ba42:	49 39 c6             	cmp    %rax,%r14
   4ba45:	0f 85 8a 00 00 00    	jne    4bad5 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xab5>
   4ba4b:	41 83 fd 09          	cmp    $0x9,%r13d
   4ba4f:	77 3e                	ja     4ba8f <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xa6f>
   4ba51:	49 83 fc f7          	cmp    $0xfffffffffffffff7,%r12
   4ba55:	0f 87 8c 10 00 00    	ja     4cae7 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1ac7>
   4ba5b:	49 8d 44 24 08       	lea    0x8(%r12),%rax
   4ba60:	4c 39 d8             	cmp    %r11,%rax
   4ba63:	0f 87 7e 10 00 00    	ja     4cae7 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1ac7>
   4ba69:	4b 8b 04 22          	mov    (%r10,%r12,1),%rax
   4ba6d:	48 0f c8             	bswap  %rax
   4ba70:	c4 e2 93 f7 c0       	shrx   %r13,%rax,%rax
   4ba75:	48 09 c5             	or     %rax,%rbp
   4ba78:	44 89 e8             	mov    %r13d,%eax
   4ba7b:	83 f0 3f             	xor    $0x3f,%eax
   4ba7e:	89 c1                	mov    %eax,%ecx
   4ba80:	c1 e9 03             	shr    $0x3,%ecx
   4ba83:	49 01 cc             	add    %rcx,%r12
   4ba86:	83 e0 38             	and    $0x38,%eax
   4ba89:	44 01 e8             	add    %r13d,%eax
   4ba8c:	41 89 c5             	mov    %eax,%r13d
   4ba8f:	48 89 e8             	mov    %rbp,%rax
   4ba92:	48 c1 e8 36          	shr    $0x36,%rax
   4ba96:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4ba99:	48 81 fa 00 00 00 40 	cmp    $0x40000000,%rdx
   4baa0:	0f 82 41 0f 00 00    	jb     4c9e7 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x19c7>
   4baa6:	89 d0                	mov    %edx,%eax
   4baa8:	c1 e8 18             	shr    $0x18,%eax
   4baab:	83 e0 1f             	and    $0x1f,%eax
   4baae:	c4 e2 f9 f7 ed       	shlx   %rax,%rbp,%rbp
   4bab3:	41 29 c5             	sub    %eax,%r13d
   4bab6:	0f b6 c6             	movzbl %dh,%eax
   4bab9:	44 89 f1             	mov    %r14d,%ecx
   4babc:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4bac2:	66 41 89 04 48       	mov    %ax,(%r8,%rcx,2)
   4bac7:	49 ff c6             	inc    %r14
   4baca:	66 3b 44 24 2e       	cmp    0x2e(%rsp),%ax
   4bacf:	0f 84 0d 1b 00 00    	je     4d5e2 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x25c2>
   4bad5:	49 81 fe e8 03 00 00 	cmp    $0x3e8,%r14
   4badc:	76 67                	jbe    4bb45 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xb25>
   4bade:	49 81 fe 13 04 00 00 	cmp    $0x413,%r14
   4bae5:	4d 89 f2             	mov    %r14,%r10
   4bae8:	0f 83 0b 1c 00 00    	jae    4d6f9 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x26d9>
   4baee:	49 8b 01             	mov    (%r9),%rax
   4baf1:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4baf5:	48 29 d8             	sub    %rbx,%rax
   4baf8:	49 39 c2             	cmp    %rax,%r10
   4bafb:	0f 87 50 10 00 00    	ja     4cb51 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1b31>
   4bb01:	48 8d 3c 1b          	lea    (%rbx,%rbx,1),%rdi
   4bb05:	49 03 79 08          	add    0x8(%r9),%rdi
   4bb09:	4b 8d 14 12          	lea    (%r10,%r10,1),%rdx
   4bb0d:	4c 89 c6             	mov    %r8,%rsi
   4bb10:	4d 89 d6             	mov    %r10,%r14
   4bb13:	ff 15 2f 5c 05 00    	call   *0x55c2f(%rip)        # a1748 <memcpy@GLIBC_2.14>
   4bb19:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4bb20:	00 
   4bb21:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4bb28:	00 
   4bb29:	4c 01 f3             	add    %r14,%rbx
   4bb2c:	49 89 59 10          	mov    %rbx,0x10(%r9)
   4bb30:	45 31 f6             	xor    %r14d,%r14d
   4bb33:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4bb38:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4bb3f:	00 
   4bb40:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4bb45:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   4bb4c:	00 
   4bb4d:	4c 89 20             	mov    %r12,(%rax)
   4bb50:	48 89 68 08          	mov    %rbp,0x8(%rax)
   4bb54:	44 89 68 10          	mov    %r13d,0x10(%rax)
   4bb58:	8b 4c 24 0c          	mov    0xc(%rsp),%ecx
   4bb5c:	89 48 14             	mov    %ecx,0x14(%rax)
   4bb5f:	48 8b 94 24 88 00 00 	mov    0x88(%rsp),%rdx
   4bb66:	00 
   4bb67:	48 8b 9c 24 f0 00 00 	mov    0xf0(%rsp),%rbx
   4bb6e:	00 
   4bb6f:	48 29 d3             	sub    %rdx,%rbx
   4bb72:	48 8b 8c 24 e8 00 00 	mov    0xe8(%rsp),%rcx
   4bb79:	00 
   4bb7a:	48 8b 94 24 e0 00 00 	mov    0xe0(%rsp),%rdx
   4bb81:	00 
   4bb82:	0f 85 7e f5 ff ff    	jne    4b106 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xe6>
   4bb88:	e9 ee 19 00 00       	jmp    4d57b <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x255b>
   4bb8d:	48 85 c0             	test   %rax,%rax
   4bb90:	0f 84 0d 02 00 00    	je     4bda3 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xd83>
   4bb96:	4a 8d 1c 38          	lea    (%rax,%r15,1),%rbx
   4bb9a:	48 83 f8 01          	cmp    $0x1,%rax
   4bb9e:	0f 84 05 01 00 00    	je     4bca9 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xc89>
   4bba4:	4c 8d 73 fe          	lea    -0x2(%rbx),%r14
   4bba8:	4d 39 f7             	cmp    %r14,%r15
   4bbab:	0f 87 ef 00 00 00    	ja     4bca0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xc80>
   4bbb1:	48 89 e8             	mov    %rbp,%rax
   4bbb4:	48 c1 e8 36          	shr    $0x36,%rax
   4bbb8:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4bbbb:	89 d0                	mov    %edx,%eax
   4bbbd:	c1 e8 1e             	shr    $0x1e,%eax
   4bbc0:	0f 84 92 13 00 00    	je     4cf58 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1f38>
   4bbc6:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4bbcb:	0f b6 ca             	movzbl %dl,%ecx
   4bbce:	41 29 cd             	sub    %ecx,%r13d
   4bbd1:	0f b6 ce             	movzbl %dh,%ecx
   4bbd4:	66 43 89 0c 78       	mov    %cx,(%r8,%r15,2)
   4bbd9:	c1 ea 10             	shr    $0x10,%edx
   4bbdc:	0f b6 ca             	movzbl %dl,%ecx
   4bbdf:	66 43 89 4c 78 02    	mov    %cx,0x2(%r8,%r15,2)
   4bbe5:	49 01 c7             	add    %rax,%r15
   4bbe8:	4d 39 f7             	cmp    %r14,%r15
   4bbeb:	0f 87 af 00 00 00    	ja     4bca0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xc80>
   4bbf1:	48 89 e8             	mov    %rbp,%rax
   4bbf4:	48 c1 e8 36          	shr    $0x36,%rax
   4bbf8:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4bbfb:	89 d0                	mov    %edx,%eax
   4bbfd:	c1 e8 1e             	shr    $0x1e,%eax
   4bc00:	0f 84 0f 15 00 00    	je     4d115 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x20f5>
   4bc06:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4bc0b:	0f b6 ca             	movzbl %dl,%ecx
   4bc0e:	41 29 cd             	sub    %ecx,%r13d
   4bc11:	0f b6 ce             	movzbl %dh,%ecx
   4bc14:	66 43 89 0c 78       	mov    %cx,(%r8,%r15,2)
   4bc19:	c1 ea 10             	shr    $0x10,%edx
   4bc1c:	0f b6 ca             	movzbl %dl,%ecx
   4bc1f:	66 43 89 4c 78 02    	mov    %cx,0x2(%r8,%r15,2)
   4bc25:	49 01 c7             	add    %rax,%r15
   4bc28:	4d 39 f7             	cmp    %r14,%r15
   4bc2b:	77 73                	ja     4bca0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xc80>
   4bc2d:	48 89 e8             	mov    %rbp,%rax
   4bc30:	48 c1 e8 36          	shr    $0x36,%rax
   4bc34:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4bc37:	89 d0                	mov    %edx,%eax
   4bc39:	c1 e8 1e             	shr    $0x1e,%eax
   4bc3c:	0f 84 6b 16 00 00    	je     4d2ad <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x228d>
   4bc42:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4bc47:	0f b6 ca             	movzbl %dl,%ecx
   4bc4a:	41 29 cd             	sub    %ecx,%r13d
   4bc4d:	0f b6 ce             	movzbl %dh,%ecx
   4bc50:	66 43 89 0c 78       	mov    %cx,(%r8,%r15,2)
   4bc55:	c1 ea 10             	shr    $0x10,%edx
   4bc58:	0f b6 ca             	movzbl %dl,%ecx
   4bc5b:	66 43 89 4c 78 02    	mov    %cx,0x2(%r8,%r15,2)
   4bc61:	49 01 c7             	add    %rax,%r15
   4bc64:	4d 39 f7             	cmp    %r14,%r15
   4bc67:	77 37                	ja     4bca0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xc80>
   4bc69:	48 89 e8             	mov    %rbp,%rax
   4bc6c:	48 c1 e8 36          	shr    $0x36,%rax
   4bc70:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4bc73:	89 d0                	mov    %edx,%eax
   4bc75:	c1 e8 1e             	shr    $0x1e,%eax
   4bc78:	0f 84 b0 17 00 00    	je     4d42e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x240e>
   4bc7e:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4bc83:	0f b6 ca             	movzbl %dl,%ecx
   4bc86:	41 29 cd             	sub    %ecx,%r13d
   4bc89:	0f b6 ce             	movzbl %dh,%ecx
   4bc8c:	66 43 89 0c 78       	mov    %cx,(%r8,%r15,2)
   4bc91:	c1 ea 10             	shr    $0x10,%edx
   4bc94:	0f b6 ca             	movzbl %dl,%ecx
   4bc97:	66 43 89 4c 78 02    	mov    %cx,0x2(%r8,%r15,2)
   4bc9d:	49 01 c7             	add    %rax,%r15
   4bca0:	4d 39 f7             	cmp    %r14,%r15
   4bca3:	0f 86 95 02 00 00    	jbe    4bf3e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xf1e>
   4bca9:	48 ff cb             	dec    %rbx
   4bcac:	49 39 df             	cmp    %rbx,%r15
   4bcaf:	0f 85 84 00 00 00    	jne    4bd39 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xd19>
   4bcb5:	41 83 fd 09          	cmp    $0x9,%r13d
   4bcb9:	77 3e                	ja     4bcf9 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xcd9>
   4bcbb:	49 83 fc f7          	cmp    $0xfffffffffffffff7,%r12
   4bcbf:	0f 87 2e 11 00 00    	ja     4cdf3 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1dd3>
   4bcc5:	49 8d 44 24 08       	lea    0x8(%r12),%rax
   4bcca:	4c 39 d8             	cmp    %r11,%rax
   4bccd:	0f 87 20 11 00 00    	ja     4cdf3 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1dd3>
   4bcd3:	4b 8b 04 22          	mov    (%r10,%r12,1),%rax
   4bcd7:	48 0f c8             	bswap  %rax
   4bcda:	c4 e2 93 f7 c0       	shrx   %r13,%rax,%rax
   4bcdf:	48 09 c5             	or     %rax,%rbp
   4bce2:	44 89 e8             	mov    %r13d,%eax
   4bce5:	83 f0 3f             	xor    $0x3f,%eax
   4bce8:	89 c1                	mov    %eax,%ecx
   4bcea:	c1 e9 03             	shr    $0x3,%ecx
   4bced:	49 01 cc             	add    %rcx,%r12
   4bcf0:	83 e0 38             	and    $0x38,%eax
   4bcf3:	44 01 e8             	add    %r13d,%eax
   4bcf6:	41 89 c5             	mov    %eax,%r13d
   4bcf9:	48 89 e8             	mov    %rbp,%rax
   4bcfc:	48 c1 e8 36          	shr    $0x36,%rax
   4bd00:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4bd03:	48 81 fa 00 00 00 40 	cmp    $0x40000000,%rdx
   4bd0a:	0f 82 cd 0f 00 00    	jb     4ccdd <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1cbd>
   4bd10:	89 d0                	mov    %edx,%eax
   4bd12:	c1 e8 18             	shr    $0x18,%eax
   4bd15:	83 e0 1f             	and    $0x1f,%eax
   4bd18:	c4 e2 f9 f7 ed       	shlx   %rax,%rbp,%rbp
   4bd1d:	41 29 c5             	sub    %eax,%r13d
   4bd20:	0f b6 c6             	movzbl %dh,%eax
   4bd23:	66 43 89 04 78       	mov    %ax,(%r8,%r15,2)
   4bd28:	49 ff c7             	inc    %r15
   4bd2b:	66 3b 84 24 88 00 00 	cmp    0x88(%rsp),%ax
   4bd32:	00 
   4bd33:	0f 84 58 19 00 00    	je     4d691 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2671>
   4bd39:	49 81 ff e8 03 00 00 	cmp    $0x3e8,%r15
   4bd40:	76 61                	jbe    4bda3 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xd83>
   4bd42:	49 81 ff 13 04 00 00 	cmp    $0x413,%r15
   4bd49:	0f 83 c0 19 00 00    	jae    4d70f <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x26ef>
   4bd4f:	49 8b 01             	mov    (%r9),%rax
   4bd52:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4bd56:	48 29 d8             	sub    %rbx,%rax
   4bd59:	49 39 c7             	cmp    %rax,%r15
   4bd5c:	0f 87 fb 10 00 00    	ja     4ce5d <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1e3d>
   4bd62:	48 8d 3c 1b          	lea    (%rbx,%rbx,1),%rdi
   4bd66:	49 03 79 08          	add    0x8(%r9),%rdi
   4bd6a:	4b 8d 14 3f          	lea    (%r15,%r15,1),%rdx
   4bd6e:	4c 89 c6             	mov    %r8,%rsi
   4bd71:	ff 15 d1 59 05 00    	call   *0x559d1(%rip)        # a1748 <memcpy@GLIBC_2.14>
   4bd77:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4bd7e:	00 
   4bd7f:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4bd86:	00 
   4bd87:	4c 01 fb             	add    %r15,%rbx
   4bd8a:	49 89 59 10          	mov    %rbx,0x10(%r9)
   4bd8e:	45 31 ff             	xor    %r15d,%r15d
   4bd91:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4bd96:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4bd9d:	00 
   4bd9e:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4bda3:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   4bdaa:	00 
   4bdab:	4c 89 20             	mov    %r12,(%rax)
   4bdae:	48 89 68 08          	mov    %rbp,0x8(%rax)
   4bdb2:	44 89 68 10          	mov    %r13d,0x10(%rax)
   4bdb6:	8b 4c 24 0c          	mov    0xc(%rsp),%ecx
   4bdba:	89 48 14             	mov    %ecx,0x14(%rax)
   4bdbd:	4d 89 fe             	mov    %r15,%r14
   4bdc0:	ba 01 00 00 00       	mov    $0x1,%edx
   4bdc5:	4d 39 dc             	cmp    %r11,%r12
   4bdc8:	0f 86 99 fd ff ff    	jbe    4bb67 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xb47>
   4bdce:	4a 8d 04 e5 00 00 00 	lea    0x0(,%r12,8),%rax
   4bdd5:	00 
   4bdd6:	44 89 e9             	mov    %r13d,%ecx
   4bdd9:	48 29 c8             	sub    %rcx,%rax
   4bddc:	48 3b 84 24 d0 00 00 	cmp    0xd0(%rsp),%rax
   4bde3:	00 
   4bde4:	0f 86 7d fd ff ff    	jbe    4bb67 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xb47>
   4bdea:	e9 5a 18 00 00       	jmp    4d649 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2629>
   4bdef:	49 83 fc f7          	cmp    $0xfffffffffffffff7,%r12
   4bdf3:	0f 87 84 0c 00 00    	ja     4ca7d <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1a5d>
   4bdf9:	49 8d 44 24 08       	lea    0x8(%r12),%rax
   4bdfe:	4c 39 d8             	cmp    %r11,%rax
   4be01:	0f 87 76 0c 00 00    	ja     4ca7d <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1a5d>
   4be07:	4b 8b 04 22          	mov    (%r10,%r12,1),%rax
   4be0b:	48 0f c8             	bswap  %rax
   4be0e:	c4 e2 93 f7 c0       	shrx   %r13,%rax,%rax
   4be13:	48 09 c5             	or     %rax,%rbp
   4be16:	b8 3f 00 00 00       	mov    $0x3f,%eax
   4be1b:	44 29 e8             	sub    %r13d,%eax
   4be1e:	89 c1                	mov    %eax,%ecx
   4be20:	c1 e9 03             	shr    $0x3,%ecx
   4be23:	49 01 cc             	add    %rcx,%r12
   4be26:	83 e0 f8             	and    $0xfffffff8,%eax
   4be29:	44 01 e8             	add    %r13d,%eax
   4be2c:	41 89 c5             	mov    %eax,%r13d
   4be2f:	90                   	nop
   4be30:	48 89 e8             	mov    %rbp,%rax
   4be33:	48 c1 e8 36          	shr    $0x36,%rax
   4be37:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4be3a:	89 d0                	mov    %edx,%eax
   4be3c:	c1 e8 1e             	shr    $0x1e,%eax
   4be3f:	74 3b                	je     4be7c <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xe5c>
   4be41:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4be46:	0f b6 ca             	movzbl %dl,%ecx
   4be49:	41 29 cd             	sub    %ecx,%r13d
   4be4c:	4d 89 f7             	mov    %r14,%r15
   4be4f:	44 89 f9             	mov    %r15d,%ecx
   4be52:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4be58:	0f b6 f6             	movzbl %dh,%esi
   4be5b:	66 41 89 34 48       	mov    %si,(%r8,%rcx,2)
   4be60:	c1 ea 10             	shr    $0x10,%edx
   4be63:	0f b6 d2             	movzbl %dl,%edx
   4be66:	66 41 89 54 48 02    	mov    %dx,0x2(%r8,%rcx,2)
   4be6c:	49 01 c7             	add    %rax,%r15
   4be6f:	4d 89 fe             	mov    %r15,%r14
   4be72:	49 39 df             	cmp    %rbx,%r15
   4be75:	76 b9                	jbe    4be30 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xe10>
   4be77:	e9 bb fb ff ff       	jmp    4ba37 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xa17>
   4be7c:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4be81:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4be86:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4be8b:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4be8f:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4be93:	48 89 fe             	mov    %rdi,%rsi
   4be96:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4be9b:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4bea0:	4d 89 d0             	mov    %r10,%r8
   4bea3:	4d 89 d9             	mov    %r11,%r9
   4bea6:	e8 95 ed ff ff       	call   4ac40 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4beab:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4beb0:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4beb5:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4beba:	0f 10 02             	movups (%rdx),%xmm0
   4bebd:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4bec2:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4bec6:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4becb:	4c 8b 64 24 60       	mov    0x60(%rsp),%r12
   4bed0:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
   4bed5:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4beda:	8b 74 24 74          	mov    0x74(%rsp),%esi
   4bede:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4bee2:	0f 85 60 0d 00 00    	jne    4cc48 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1c28>
   4bee8:	44 89 f1             	mov    %r14d,%ecx
   4beeb:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4bef1:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4bef8:	00 
   4bef9:	66 41 89 04 48       	mov    %ax,(%r8,%rcx,2)
   4befe:	49 ff c6             	inc    %r14
   4bf01:	66 3b 44 24 2e       	cmp    0x2e(%rsp),%ax
   4bf06:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4bf0d:	00 
   4bf0e:	0f 84 61 0d 00 00    	je     4cc75 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1c55>
   4bf14:	89 74 24 0c          	mov    %esi,0xc(%rsp)
   4bf18:	4d 89 f7             	mov    %r14,%r15
   4bf1b:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4bf20:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4bf27:	00 
   4bf28:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4bf2d:	4d 89 fe             	mov    %r15,%r14
   4bf30:	49 39 df             	cmp    %rbx,%r15
   4bf33:	0f 86 f7 fe ff ff    	jbe    4be30 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xe10>
   4bf39:	e9 f9 fa ff ff       	jmp    4ba37 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xa17>
   4bf3e:	49 83 fc f7          	cmp    $0xfffffffffffffff7,%r12
   4bf42:	0f 87 41 0e 00 00    	ja     4cd89 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1d69>
   4bf48:	49 8d 44 24 08       	lea    0x8(%r12),%rax
   4bf4d:	4c 39 d8             	cmp    %r11,%rax
   4bf50:	0f 87 33 0e 00 00    	ja     4cd89 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1d69>
   4bf56:	4b 8b 04 22          	mov    (%r10,%r12,1),%rax
   4bf5a:	48 0f c8             	bswap  %rax
   4bf5d:	c4 e2 93 f7 c0       	shrx   %r13,%rax,%rax
   4bf62:	48 09 c5             	or     %rax,%rbp
   4bf65:	b8 3f 00 00 00       	mov    $0x3f,%eax
   4bf6a:	44 29 e8             	sub    %r13d,%eax
   4bf6d:	89 c1                	mov    %eax,%ecx
   4bf6f:	c1 e9 03             	shr    $0x3,%ecx
   4bf72:	49 01 cc             	add    %rcx,%r12
   4bf75:	83 e0 f8             	and    $0xfffffff8,%eax
   4bf78:	44 01 e8             	add    %r13d,%eax
   4bf7b:	41 89 c5             	mov    %eax,%r13d
   4bf7e:	66 90                	xchg   %ax,%ax
   4bf80:	48 89 e8             	mov    %rbp,%rax
   4bf83:	48 c1 e8 36          	shr    $0x36,%rax
   4bf87:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4bf8a:	89 d0                	mov    %edx,%eax
   4bf8c:	c1 e8 1e             	shr    $0x1e,%eax
   4bf8f:	74 35                	je     4bfc6 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xfa6>
   4bf91:	c4 e2 e9 f7 ed       	shlx   %rdx,%rbp,%rbp
   4bf96:	0f b6 ca             	movzbl %dl,%ecx
   4bf99:	41 29 cd             	sub    %ecx,%r13d
   4bf9c:	44 89 f9             	mov    %r15d,%ecx
   4bf9f:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4bfa5:	0f b6 f6             	movzbl %dh,%esi
   4bfa8:	66 41 89 34 48       	mov    %si,(%r8,%rcx,2)
   4bfad:	c1 ea 10             	shr    $0x10,%edx
   4bfb0:	0f b6 d2             	movzbl %dl,%edx
   4bfb3:	66 41 89 54 48 02    	mov    %dx,0x2(%r8,%rcx,2)
   4bfb9:	49 01 c7             	add    %rax,%r15
   4bfbc:	4d 39 f7             	cmp    %r14,%r15
   4bfbf:	76 bf                	jbe    4bf80 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xf60>
   4bfc1:	e9 e3 fc ff ff       	jmp    4bca9 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xc89>
   4bfc6:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4bfcb:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4bfd0:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4bfd5:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4bfd9:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4bfdd:	48 89 fe             	mov    %rdi,%rsi
   4bfe0:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4bfe5:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4bfea:	4d 89 d0             	mov    %r10,%r8
   4bfed:	4d 89 d9             	mov    %r11,%r9
   4bff0:	e8 4b ec ff ff       	call   4ac40 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4bff5:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4bffa:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4bfff:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4c004:	0f 10 02             	movups (%rdx),%xmm0
   4c007:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4c00c:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4c010:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4c015:	4c 8b 64 24 60       	mov    0x60(%rsp),%r12
   4c01a:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
   4c01f:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4c024:	8b 54 24 74          	mov    0x74(%rsp),%edx
   4c028:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4c02c:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4c030:	0f 85 68 14 00 00    	jne    4d49e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x247e>
   4c036:	44 89 f9             	mov    %r15d,%ecx
   4c039:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4c03f:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4c046:	00 
   4c047:	66 41 89 04 48       	mov    %ax,(%r8,%rcx,2)
   4c04c:	49 ff c7             	inc    %r15
   4c04f:	66 3b 84 24 88 00 00 	cmp    0x88(%rsp),%ax
   4c056:	00 
   4c057:	0f 84 82 10 00 00    	je     4d0df <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x20bf>
   4c05d:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4c064:	00 
   4c065:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4c06a:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4c071:	00 
   4c072:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4c077:	4d 39 f7             	cmp    %r14,%r15
   4c07a:	0f 86 00 ff ff ff    	jbe    4bf80 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xf60>
   4c080:	e9 24 fc ff ff       	jmp    4bca9 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xc89>
   4c085:	45 31 ff             	xor    %r15d,%r15d
   4c088:	eb 03                	jmp    4c08d <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x106d>
   4c08a:	41 89 d5             	mov    %edx,%r13d
   4c08d:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4c094:	00 
   4c095:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4c09c:	00 
   4c09d:	89 c2                	mov    %eax,%edx
   4c09f:	c1 ea 08             	shr    $0x8,%edx
   4c0a2:	89 54 24 7c          	mov    %edx,0x7c(%rsp)
   4c0a6:	48 8b 54 24 1e       	mov    0x1e(%rsp),%rdx
   4c0ab:	48 89 94 24 9e 00 00 	mov    %rdx,0x9e(%rsp)
   4c0b2:	00 
   4c0b3:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
   4c0b8:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
   4c0bf:	00 
   4c0c0:	4d 01 f7             	add    %r14,%r15
   4c0c3:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4c0c8:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4c0cf:	00 
   4c0d0:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4c0d5:	49 89 f4             	mov    %rsi,%r12
   4c0d8:	e9 88 00 00 00       	jmp    4c165 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1145>
   4c0dd:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   4c0e3:	eb 03                	jmp    4c0e8 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x10c8>
   4c0e5:	41 89 d5             	mov    %edx,%r13d
   4c0e8:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4c0ef:	00 
   4c0f0:	49 89 f4             	mov    %rsi,%r12
   4c0f3:	4d 01 f7             	add    %r14,%r15
   4c0f6:	49 81 ff 13 04 00 00 	cmp    $0x413,%r15
   4c0fd:	0f 83 38 16 00 00    	jae    4d73b <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x271b>
   4c103:	49 8b 01             	mov    (%r9),%rax
   4c106:	4d 8b 71 10          	mov    0x10(%r9),%r14
   4c10a:	4c 29 f0             	sub    %r14,%rax
   4c10d:	49 39 c7             	cmp    %rax,%r15
   4c110:	0f 87 55 12 00 00    	ja     4d36b <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x234b>
   4c116:	4d 85 ff             	test   %r15,%r15
   4c119:	74 25                	je     4c140 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1120>
   4c11b:	4b 8d 3c 36          	lea    (%r14,%r14,1),%rdi
   4c11f:	49 03 79 08          	add    0x8(%r9),%rdi
   4c123:	4b 8d 14 3f          	lea    (%r15,%r15,1),%rdx
   4c127:	4c 89 c6             	mov    %r8,%rsi
   4c12a:	ff 15 18 56 05 00    	call   *0x55618(%rip)        # a1748 <memcpy@GLIBC_2.14>
   4c130:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4c137:	00 
   4c138:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4c13f:	00 
   4c140:	4d 01 fe             	add    %r15,%r14
   4c143:	4d 89 71 10          	mov    %r14,0x10(%r9)
   4c147:	b0 01                	mov    $0x1,%al
   4c149:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
   4c150:	45 31 ff             	xor    %r15d,%r15d
   4c153:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4c158:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4c15f:	00 
   4c160:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4c165:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   4c16c:	00 
   4c16d:	4c 89 22             	mov    %r12,(%rdx)
   4c170:	48 89 5a 08          	mov    %rbx,0x8(%rdx)
   4c174:	44 89 6a 10          	mov    %r13d,0x10(%rdx)
   4c178:	89 6a 14             	mov    %ebp,0x14(%rdx)
   4c17b:	4d 89 fe             	mov    %r15,%r14
   4c17e:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4c182:	0f 85 9a 16 00 00    	jne    4d822 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2802>
   4c188:	a8 01                	test   $0x1,%al
   4c18a:	0f 84 30 fc ff ff    	je     4bdc0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xda0>
   4c190:	e9 24 15 00 00       	jmp    4d6b9 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2699>
   4c195:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
   4c19a:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
   4c19f:	89 44 24 50          	mov    %eax,0x50(%rsp)
   4c1a3:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4c1a7:	89 44 24 54          	mov    %eax,0x54(%rsp)
   4c1ab:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   4c1b0:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   4c1b5:	4c 89 d2             	mov    %r10,%rdx
   4c1b8:	4c 89 d9             	mov    %r11,%rcx
   4c1bb:	e8 f0 94 ff ff       	call   456b0 <_RNvMNtCs7Z5HuLIcqFl_5mibz24bitsNtB2_3Reg11refill_slow>
   4c1c0:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4c1c5:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4c1cc:	00 
   4c1cd:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4c1d2:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4c1d9:	00 
   4c1da:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4c1e1:	00 
   4c1e2:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   4c1e7:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   4c1ec:	44 8b 6c 24 20       	mov    0x20(%rsp),%r13d
   4c1f1:	8b 44 24 24          	mov    0x24(%rsp),%eax
   4c1f5:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   4c1f9:	48 6b 94 24 88 00 00 	imul   $0x32,0x88(%rsp),%rdx
   4c200:	00 32 
   4c202:	48 83 fa 0a          	cmp    $0xa,%rdx
   4c206:	73 66                	jae    4c26e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x124e>
   4c208:	e9 cc f6 ff ff       	jmp    4b8d9 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x8b9>
   4c20d:	0f 1f 00             	nopl   (%rax)
   4c210:	48 8d 3c 1b          	lea    (%rbx,%rbx,1),%rdi
   4c214:	49 03 79 08          	add    0x8(%r9),%rdi
   4c218:	4b 8d 14 3f          	lea    (%r15,%r15,1),%rdx
   4c21c:	4c 89 c6             	mov    %r8,%rsi
   4c21f:	ff 15 23 55 05 00    	call   *0x55523(%rip)        # a1748 <memcpy@GLIBC_2.14>
   4c225:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4c22c:	00 
   4c22d:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4c234:	00 
   4c235:	4c 01 fb             	add    %r15,%rbx
   4c238:	49 89 59 10          	mov    %rbx,0x10(%r9)
   4c23c:	45 31 f6             	xor    %r14d,%r14d
   4c23f:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4c244:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4c24b:	00 
   4c24c:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4c251:	48 8b 94 24 b8 00 00 	mov    0xb8(%rsp),%rdx
   4c258:	00 
   4c259:	48 03 94 24 c0 00 00 	add    0xc0(%rsp),%rdx
   4c260:	00 
   4c261:	4c 29 fa             	sub    %r15,%rdx
   4c264:	48 83 fa 09          	cmp    $0x9,%rdx
   4c268:	0f 86 6b f6 ff ff    	jbe    4b8d9 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x8b9>
   4c26e:	48 89 94 24 b8 00 00 	mov    %rdx,0xb8(%rsp)
   4c275:	00 
   4c276:	4c 01 f2             	add    %r14,%rdx
   4c279:	48 83 c2 f6          	add    $0xfffffffffffffff6,%rdx
   4c27d:	48 81 fa e8 03 00 00 	cmp    $0x3e8,%rdx
   4c284:	b8 e8 03 00 00       	mov    $0x3e8,%eax
   4c289:	48 0f 43 d0          	cmovae %rax,%rdx
   4c28d:	4d 89 f7             	mov    %r14,%r15
   4c290:	4c 89 b4 24 c0 00 00 	mov    %r14,0xc0(%rsp)
   4c297:	00 
   4c298:	48 89 94 24 a8 00 00 	mov    %rdx,0xa8(%rsp)
   4c29f:	00 
   4c2a0:	49 39 d6             	cmp    %rdx,%r14
   4c2a3:	76 6b                	jbe    4c310 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x12f0>
   4c2a5:	4d 89 fe             	mov    %r15,%r14
   4c2a8:	49 81 ff e8 03 00 00 	cmp    $0x3e8,%r15
   4c2af:	76 a0                	jbe    4c251 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1231>
   4c2b1:	49 81 ff 13 04 00 00 	cmp    $0x413,%r15
   4c2b8:	0f 83 75 13 00 00    	jae    4d633 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2613>
   4c2be:	49 8b 01             	mov    (%r9),%rax
   4c2c1:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4c2c5:	48 29 d8             	sub    %rbx,%rax
   4c2c8:	49 39 c7             	cmp    %rax,%r15
   4c2cb:	0f 86 3f ff ff ff    	jbe    4c210 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x11f0>
   4c2d1:	b9 02 00 00 00       	mov    $0x2,%ecx
   4c2d6:	41 b8 02 00 00 00    	mov    $0x2,%r8d
   4c2dc:	4c 89 cf             	mov    %r9,%rdi
   4c2df:	48 89 de             	mov    %rbx,%rsi
   4c2e2:	4c 89 fa             	mov    %r15,%rdx
   4c2e5:	e8 86 a7 fe ff       	call   36a70 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs7Z5HuLIcqFl_5mibz2>
   4c2ea:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4c2f1:	00 
   4c2f2:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4c2f9:	00 
   4c2fa:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4c2fe:	e9 0d ff ff ff       	jmp    4c210 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x11f0>
   4c303:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   4c30a:	84 00 00 00 00 00 
   4c310:	49 8d 77 12          	lea    0x12(%r15),%rsi
   4c314:	48 81 fe 13 04 00 00 	cmp    $0x413,%rsi
   4c31b:	0f 83 99 12 00 00    	jae    4d5ba <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x259a>
   4c321:	4c 89 e6             	mov    %r12,%rsi
   4c324:	4f 8d 24 78          	lea    (%r8,%r15,2),%r12
   4c328:	48 89 e8             	mov    %rbp,%rax
   4c32b:	48 c1 e8 36          	shr    $0x36,%rax
   4c32f:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4c332:	89 d3                	mov    %edx,%ebx
   4c334:	c1 eb 1e             	shr    $0x1e,%ebx
   4c337:	0f 84 57 01 00 00    	je     4c494 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1474>
   4c33d:	c4 62 e9 f7 f5       	shlx   %rdx,%rbp,%r14
   4c342:	0f b6 c2             	movzbl %dl,%eax
   4c345:	41 29 c5             	sub    %eax,%r13d
   4c348:	0f b6 c6             	movzbl %dh,%eax
   4c34b:	66 41 89 04 24       	mov    %ax,(%r12)
   4c350:	c1 ea 10             	shr    $0x10,%edx
   4c353:	0f b6 c2             	movzbl %dl,%eax
   4c356:	66 41 89 44 24 02    	mov    %ax,0x2(%r12)
   4c35c:	4c 89 f0             	mov    %r14,%rax
   4c35f:	48 c1 e8 36          	shr    $0x36,%rax
   4c363:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4c366:	89 d0                	mov    %edx,%eax
   4c368:	c1 e8 1e             	shr    $0x1e,%eax
   4c36b:	0f 84 cf 01 00 00    	je     4c540 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1520>
   4c371:	c4 42 e9 f7 f6       	shlx   %rdx,%r14,%r14
   4c376:	0f b6 ca             	movzbl %dl,%ecx
   4c379:	41 29 cd             	sub    %ecx,%r13d
   4c37c:	0f b6 ce             	movzbl %dh,%ecx
   4c37f:	66 41 89 0c 5c       	mov    %cx,(%r12,%rbx,2)
   4c384:	c1 ea 10             	shr    $0x10,%edx
   4c387:	0f b6 ca             	movzbl %dl,%ecx
   4c38a:	66 41 89 4c 5c 02    	mov    %cx,0x2(%r12,%rbx,2)
   4c390:	48 01 c3             	add    %rax,%rbx
   4c393:	4c 89 f0             	mov    %r14,%rax
   4c396:	48 c1 e8 36          	shr    $0x36,%rax
   4c39a:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4c39d:	89 d0                	mov    %edx,%eax
   4c39f:	c1 e8 1e             	shr    $0x1e,%eax
   4c3a2:	0f 84 42 02 00 00    	je     4c5ea <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x15ca>
   4c3a8:	c4 42 e9 f7 f6       	shlx   %rdx,%r14,%r14
   4c3ad:	0f b6 ca             	movzbl %dl,%ecx
   4c3b0:	41 29 cd             	sub    %ecx,%r13d
   4c3b3:	0f b6 ce             	movzbl %dh,%ecx
   4c3b6:	66 41 89 0c 5c       	mov    %cx,(%r12,%rbx,2)
   4c3bb:	c1 ea 10             	shr    $0x10,%edx
   4c3be:	0f b6 ca             	movzbl %dl,%ecx
   4c3c1:	66 41 89 4c 5c 02    	mov    %cx,0x2(%r12,%rbx,2)
   4c3c7:	48 01 c3             	add    %rax,%rbx
   4c3ca:	4c 89 f0             	mov    %r14,%rax
   4c3cd:	48 c1 e8 36          	shr    $0x36,%rax
   4c3d1:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4c3d4:	89 d0                	mov    %edx,%eax
   4c3d6:	c1 e8 1e             	shr    $0x1e,%eax
   4c3d9:	0f 84 b5 02 00 00    	je     4c694 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1674>
   4c3df:	c4 42 e9 f7 f6       	shlx   %rdx,%r14,%r14
   4c3e4:	0f b6 ca             	movzbl %dl,%ecx
   4c3e7:	41 29 cd             	sub    %ecx,%r13d
   4c3ea:	0f b6 ce             	movzbl %dh,%ecx
   4c3ed:	66 41 89 0c 5c       	mov    %cx,(%r12,%rbx,2)
   4c3f2:	c1 ea 10             	shr    $0x10,%edx
   4c3f5:	0f b6 ca             	movzbl %dl,%ecx
   4c3f8:	66 41 89 4c 5c 02    	mov    %cx,0x2(%r12,%rbx,2)
   4c3fe:	48 01 c3             	add    %rax,%rbx
   4c401:	4c 89 f0             	mov    %r14,%rax
   4c404:	48 c1 e8 36          	shr    $0x36,%rax
   4c408:	8b 14 87             	mov    (%rdi,%rax,4),%edx
   4c40b:	89 d0                	mov    %edx,%eax
   4c40d:	c1 e8 1e             	shr    $0x1e,%eax
   4c410:	0f 84 28 03 00 00    	je     4c73e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x171e>
   4c416:	c4 42 e9 f7 f6       	shlx   %rdx,%r14,%r14
   4c41b:	0f b6 ca             	movzbl %dl,%ecx
   4c41e:	41 29 cd             	sub    %ecx,%r13d
   4c421:	0f b6 ce             	movzbl %dh,%ecx
   4c424:	66 41 89 0c 5c       	mov    %cx,(%r12,%rbx,2)
   4c429:	c1 ea 10             	shr    $0x10,%edx
   4c42c:	0f b6 ca             	movzbl %dl,%ecx
   4c42f:	66 41 89 4c 5c 02    	mov    %cx,0x2(%r12,%rbx,2)
   4c435:	48 01 c3             	add    %rax,%rbx
   4c438:	44 89 ea             	mov    %r13d,%edx
   4c43b:	49 89 f4             	mov    %rsi,%r12
   4c43e:	48 83 fe f7          	cmp    $0xfffffffffffffff7,%rsi
   4c442:	0f 87 a7 03 00 00    	ja     4c7ef <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x17cf>
   4c448:	49 8d 44 24 08       	lea    0x8(%r12),%rax
   4c44d:	4c 39 d8             	cmp    %r11,%rax
   4c450:	0f 87 99 03 00 00    	ja     4c7ef <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x17cf>
   4c456:	4b 8b 04 22          	mov    (%r10,%r12,1),%rax
   4c45a:	48 0f c8             	bswap  %rax
   4c45d:	c4 e2 eb f7 e8       	shrx   %rdx,%rax,%rbp
   4c462:	4c 09 f5             	or     %r14,%rbp
   4c465:	41 bd 3f 00 00 00    	mov    $0x3f,%r13d
   4c46b:	41 29 d5             	sub    %edx,%r13d
   4c46e:	44 89 e8             	mov    %r13d,%eax
   4c471:	c1 e8 03             	shr    $0x3,%eax
   4c474:	49 01 c4             	add    %rax,%r12
   4c477:	41 83 e5 f8          	and    $0xfffffff8,%r13d
   4c47b:	41 01 d5             	add    %edx,%r13d
   4c47e:	49 01 df             	add    %rbx,%r15
   4c481:	4c 3b bc 24 a8 00 00 	cmp    0xa8(%rsp),%r15
   4c488:	00 
   4c489:	0f 86 81 fe ff ff    	jbe    4c310 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x12f0>
   4c48f:	e9 11 fe ff ff       	jmp    4c2a5 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1285>
   4c494:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4c499:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4c49e:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4c4a3:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4c4a7:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4c4ab:	48 89 fe             	mov    %rdi,%rsi
   4c4ae:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4c4b3:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4c4b8:	4d 89 d0             	mov    %r10,%r8
   4c4bb:	4d 89 d9             	mov    %r11,%r9
   4c4be:	e8 7d e7 ff ff       	call   4ac40 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4c4c3:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4c4c8:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4c4cd:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4c4d2:	0f 10 02             	movups (%rdx),%xmm0
   4c4d5:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4c4da:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4c4de:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4c4e3:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   4c4e8:	4c 8b 74 24 68       	mov    0x68(%rsp),%r14
   4c4ed:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4c4f2:	8b 6c 24 74          	mov    0x74(%rsp),%ebp
   4c4f6:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4c4fa:	0f 85 69 03 00 00    	jne    4c869 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1849>
   4c500:	66 41 89 04 24       	mov    %ax,(%r12)
   4c505:	66 3b 44 24 2e       	cmp    0x2e(%rsp),%ax
   4c50a:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4c511:	00 
   4c512:	0f 84 a8 03 00 00    	je     4c8c0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x18a0>
   4c518:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4c51c:	bb 01 00 00 00       	mov    $0x1,%ebx
   4c521:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4c528:	00 
   4c529:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4c52e:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4c535:	00 
   4c536:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4c53b:	e9 1c fe ff ff       	jmp    4c35c <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x133c>
   4c540:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4c545:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   4c54a:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4c54f:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4c553:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4c557:	48 89 fe             	mov    %rdi,%rsi
   4c55a:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4c55f:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4c564:	4d 89 d0             	mov    %r10,%r8
   4c567:	4d 89 d9             	mov    %r11,%r9
   4c56a:	e8 d1 e6 ff ff       	call   4ac40 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4c56f:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4c574:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4c579:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4c57e:	0f 10 02             	movups (%rdx),%xmm0
   4c581:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4c586:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4c58a:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4c58f:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   4c594:	4c 8b 74 24 68       	mov    0x68(%rsp),%r14
   4c599:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4c59e:	8b 6c 24 74          	mov    0x74(%rsp),%ebp
   4c5a2:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4c5a6:	0f 85 c4 02 00 00    	jne    4c870 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1850>
   4c5ac:	66 41 89 04 5c       	mov    %ax,(%r12,%rbx,2)
   4c5b1:	48 ff c3             	inc    %rbx
   4c5b4:	66 3b 44 24 2e       	cmp    0x2e(%rsp),%ax
   4c5b9:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4c5c0:	00 
   4c5c1:	0f 84 03 03 00 00    	je     4c8ca <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x18aa>
   4c5c7:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4c5cb:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4c5d2:	00 
   4c5d3:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4c5d8:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4c5df:	00 
   4c5e0:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4c5e5:	e9 a9 fd ff ff       	jmp    4c393 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1373>
   4c5ea:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4c5ef:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   4c5f4:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4c5f9:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4c5fd:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4c601:	48 89 fe             	mov    %rdi,%rsi
   4c604:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4c609:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4c60e:	4d 89 d0             	mov    %r10,%r8
   4c611:	4d 89 d9             	mov    %r11,%r9
   4c614:	e8 27 e6 ff ff       	call   4ac40 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4c619:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4c61e:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4c623:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4c628:	0f 10 02             	movups (%rdx),%xmm0
   4c62b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4c630:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4c634:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4c639:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   4c63e:	4c 8b 74 24 68       	mov    0x68(%rsp),%r14
   4c643:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4c648:	8b 6c 24 74          	mov    0x74(%rsp),%ebp
   4c64c:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4c650:	0f 85 1a 02 00 00    	jne    4c870 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1850>
   4c656:	66 41 89 04 5c       	mov    %ax,(%r12,%rbx,2)
   4c65b:	48 ff c3             	inc    %rbx
   4c65e:	66 3b 44 24 2e       	cmp    0x2e(%rsp),%ax
   4c663:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4c66a:	00 
   4c66b:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4c672:	00 
   4c673:	0f 84 59 02 00 00    	je     4c8d2 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x18b2>
   4c679:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4c67d:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4c682:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4c689:	00 
   4c68a:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4c68f:	e9 36 fd ff ff       	jmp    4c3ca <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x13aa>
   4c694:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4c699:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   4c69e:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4c6a3:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4c6a7:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4c6ab:	48 89 fe             	mov    %rdi,%rsi
   4c6ae:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4c6b3:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4c6b8:	4d 89 d0             	mov    %r10,%r8
   4c6bb:	4d 89 d9             	mov    %r11,%r9
   4c6be:	e8 7d e5 ff ff       	call   4ac40 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4c6c3:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4c6c8:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4c6cd:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4c6d2:	0f 10 02             	movups (%rdx),%xmm0
   4c6d5:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4c6da:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4c6de:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4c6e3:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   4c6e8:	4c 8b 74 24 68       	mov    0x68(%rsp),%r14
   4c6ed:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4c6f2:	8b 6c 24 74          	mov    0x74(%rsp),%ebp
   4c6f6:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4c6fa:	0f 85 70 01 00 00    	jne    4c870 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1850>
   4c700:	66 41 89 04 5c       	mov    %ax,(%r12,%rbx,2)
   4c705:	48 ff c3             	inc    %rbx
   4c708:	66 3b 44 24 2e       	cmp    0x2e(%rsp),%ax
   4c70d:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4c714:	00 
   4c715:	0f 84 af 01 00 00    	je     4c8ca <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x18aa>
   4c71b:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4c71f:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4c726:	00 
   4c727:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4c72c:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4c733:	00 
   4c734:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4c739:	e9 c3 fc ff ff       	jmp    4c401 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x13e1>
   4c73e:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4c743:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   4c748:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4c74d:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4c751:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4c755:	48 89 fe             	mov    %rdi,%rsi
   4c758:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4c75d:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4c762:	4d 89 d0             	mov    %r10,%r8
   4c765:	4d 89 d9             	mov    %r11,%r9
   4c768:	e8 d3 e4 ff ff       	call   4ac40 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4c76d:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4c772:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4c777:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4c77c:	0f 10 02             	movups (%rdx),%xmm0
   4c77f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4c784:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4c788:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4c78d:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   4c792:	4c 8b 74 24 68       	mov    0x68(%rsp),%r14
   4c797:	8b 54 24 70          	mov    0x70(%rsp),%edx
   4c79b:	8b 6c 24 74          	mov    0x74(%rsp),%ebp
   4c79f:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4c7a3:	0f 85 c4 00 00 00    	jne    4c86d <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x184d>
   4c7a9:	66 41 89 04 5c       	mov    %ax,(%r12,%rbx,2)
   4c7ae:	48 ff c3             	inc    %rbx
   4c7b1:	66 3b 44 24 2e       	cmp    0x2e(%rsp),%ax
   4c7b6:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4c7bd:	00 
   4c7be:	0f 84 03 01 00 00    	je     4c8c7 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x18a7>
   4c7c4:	89 6c 24 0c          	mov    %ebp,0xc(%rsp)
   4c7c8:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4c7cf:	00 
   4c7d0:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4c7d5:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4c7dc:	00 
   4c7dd:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4c7e2:	49 89 f4             	mov    %rsi,%r12
   4c7e5:	48 83 fe f7          	cmp    $0xfffffffffffffff7,%rsi
   4c7e9:	0f 86 59 fc ff ff    	jbe    4c448 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1428>
   4c7ef:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
   4c7f4:	4c 89 74 24 48       	mov    %r14,0x48(%rsp)
   4c7f9:	89 54 24 50          	mov    %edx,0x50(%rsp)
   4c7fd:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4c801:	89 44 24 54          	mov    %eax,0x54(%rsp)
   4c805:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   4c80a:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   4c80f:	4c 89 d2             	mov    %r10,%rdx
   4c812:	4c 89 d9             	mov    %r11,%rcx
   4c815:	e8 96 8e ff ff       	call   456b0 <_RNvMNtCs7Z5HuLIcqFl_5mibz24bitsNtB2_3Reg11refill_slow>
   4c81a:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4c81f:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4c826:	00 
   4c827:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4c82c:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4c833:	00 
   4c834:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4c83b:	00 
   4c83c:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   4c841:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   4c846:	44 8b 6c 24 20       	mov    0x20(%rsp),%r13d
   4c84b:	8b 44 24 24          	mov    0x24(%rsp),%eax
   4c84f:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   4c853:	49 01 df             	add    %rbx,%r15
   4c856:	4c 3b bc 24 a8 00 00 	cmp    0xa8(%rsp),%r15
   4c85d:	00 
   4c85e:	0f 86 ac fa ff ff    	jbe    4c310 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x12f0>
   4c864:	e9 3c fa ff ff       	jmp    4c2a5 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1285>
   4c869:	31 db                	xor    %ebx,%ebx
   4c86b:	eb 03                	jmp    4c870 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1850>
   4c86d:	41 89 d5             	mov    %edx,%r13d
   4c870:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4c877:	00 
   4c878:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4c87f:	00 
   4c880:	89 c2                	mov    %eax,%edx
   4c882:	c1 ea 08             	shr    $0x8,%edx
   4c885:	89 54 24 7c          	mov    %edx,0x7c(%rsp)
   4c889:	48 8b 54 24 1e       	mov    0x1e(%rsp),%rdx
   4c88e:	48 89 94 24 9e 00 00 	mov    %rdx,0x9e(%rsp)
   4c895:	00 
   4c896:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
   4c89b:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
   4c8a2:	00 
   4c8a3:	4c 01 fb             	add    %r15,%rbx
   4c8a6:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4c8ab:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4c8b2:	00 
   4c8b3:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4c8b8:	49 89 f4             	mov    %rsi,%r12
   4c8bb:	e9 86 00 00 00       	jmp    4c946 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1926>
   4c8c0:	bb 01 00 00 00       	mov    $0x1,%ebx
   4c8c5:	eb 03                	jmp    4c8ca <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x18aa>
   4c8c7:	41 89 d5             	mov    %edx,%r13d
   4c8ca:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4c8d1:	00 
   4c8d2:	49 89 f4             	mov    %rsi,%r12
   4c8d5:	4c 01 fb             	add    %r15,%rbx
   4c8d8:	48 81 fb 13 04 00 00 	cmp    $0x413,%rbx
   4c8df:	0f 83 40 0e 00 00    	jae    4d725 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2705>
   4c8e5:	49 8b 01             	mov    (%r9),%rax
   4c8e8:	4d 8b 79 10          	mov    0x10(%r9),%r15
   4c8ec:	4c 29 f8             	sub    %r15,%rax
   4c8ef:	48 39 c3             	cmp    %rax,%rbx
   4c8f2:	0f 87 83 09 00 00    	ja     4d27b <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x225b>
   4c8f8:	48 85 db             	test   %rbx,%rbx
   4c8fb:	74 25                	je     4c922 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1902>
   4c8fd:	4b 8d 3c 3f          	lea    (%r15,%r15,1),%rdi
   4c901:	49 03 79 08          	add    0x8(%r9),%rdi
   4c905:	48 8d 14 1b          	lea    (%rbx,%rbx,1),%rdx
   4c909:	4c 89 c6             	mov    %r8,%rsi
   4c90c:	ff 15 36 4e 05 00    	call   *0x54e36(%rip)        # a1748 <memcpy@GLIBC_2.14>
   4c912:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4c919:	00 
   4c91a:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4c921:	00 
   4c922:	49 01 df             	add    %rbx,%r15
   4c925:	4d 89 79 10          	mov    %r15,0x10(%r9)
   4c929:	b0 01                	mov    $0x1,%al
   4c92b:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
   4c932:	31 db                	xor    %ebx,%ebx
   4c934:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4c939:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4c940:	00 
   4c941:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4c946:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   4c94d:	00 
   4c94e:	4c 89 22             	mov    %r12,(%rdx)
   4c951:	4c 89 72 08          	mov    %r14,0x8(%rdx)
   4c955:	44 89 6a 10          	mov    %r13d,0x10(%rdx)
   4c959:	89 6a 14             	mov    %ebp,0x14(%rdx)
   4c95c:	49 89 de             	mov    %rbx,%r14
   4c95f:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4c963:	48 8b 94 24 88 00 00 	mov    0x88(%rsp),%rdx
   4c96a:	00 
   4c96b:	0f 85 b1 0e 00 00    	jne    4d822 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2802>
   4c971:	a8 01                	test   $0x1,%al
   4c973:	0f 84 ee f1 ff ff    	je     4bb67 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xb47>
   4c979:	e9 3b 0d 00 00       	jmp    4d6b9 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2699>
   4c97e:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
   4c983:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
   4c988:	89 44 24 50          	mov    %eax,0x50(%rsp)
   4c98c:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4c990:	89 44 24 54          	mov    %eax,0x54(%rsp)
   4c994:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   4c999:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   4c99e:	4c 89 d2             	mov    %r10,%rdx
   4c9a1:	4c 89 d9             	mov    %r11,%rcx
   4c9a4:	e8 07 8d ff ff       	call   456b0 <_RNvMNtCs7Z5HuLIcqFl_5mibz24bitsNtB2_3Reg11refill_slow>
   4c9a9:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4c9ae:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4c9b5:	00 
   4c9b6:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4c9bb:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4c9c2:	00 
   4c9c3:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4c9ca:	00 
   4c9cb:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   4c9d0:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   4c9d5:	44 8b 6c 24 20       	mov    0x20(%rsp),%r13d
   4c9da:	8b 44 24 24          	mov    0x24(%rsp),%eax
   4c9de:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   4c9e2:	e9 d2 e7 ff ff       	jmp    4b1b9 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x199>
   4c9e7:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
   4c9ec:	48 89 6c 24 48       	mov    %rbp,0x48(%rsp)
   4c9f1:	44 89 6c 24 50       	mov    %r13d,0x50(%rsp)
   4c9f6:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4c9fa:	89 44 24 54          	mov    %eax,0x54(%rsp)
   4c9fe:	48 89 fe             	mov    %rdi,%rsi
   4ca01:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   4ca08:	00 
   4ca09:	48 8d 4c 24 40       	lea    0x40(%rsp),%rcx
   4ca0e:	4d 89 d0             	mov    %r10,%r8
   4ca11:	4d 89 d9             	mov    %r11,%r9
   4ca14:	e8 27 e2 ff ff       	call   4ac40 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4ca19:	48 8b 8c 24 30 01 00 	mov    0x130(%rsp),%rcx
   4ca20:	00 
   4ca21:	0f b7 84 24 38 01 00 	movzwl 0x138(%rsp),%eax
   4ca28:	00 
   4ca29:	4c 8b a4 24 50 01 00 	mov    0x150(%rsp),%r12
   4ca30:	00 
   4ca31:	48 8b ac 24 58 01 00 	mov    0x158(%rsp),%rbp
   4ca38:	00 
   4ca39:	44 8b ac 24 60 01 00 	mov    0x160(%rsp),%r13d
   4ca40:	00 
   4ca41:	8b 94 24 64 01 00 00 	mov    0x164(%rsp),%edx
   4ca48:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4ca4c:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4ca50:	0f 85 11 0d 00 00    	jne    4d767 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2747>
   4ca56:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4ca5d:	00 
   4ca5e:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4ca65:	00 
   4ca66:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4ca6b:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4ca72:	00 
   4ca73:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4ca78:	e9 3c f0 ff ff       	jmp    4bab9 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xa99>
   4ca7d:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
   4ca82:	48 89 6c 24 48       	mov    %rbp,0x48(%rsp)
   4ca87:	44 89 6c 24 50       	mov    %r13d,0x50(%rsp)
   4ca8c:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4ca90:	89 44 24 54          	mov    %eax,0x54(%rsp)
   4ca94:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   4ca99:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   4ca9e:	4c 89 d2             	mov    %r10,%rdx
   4caa1:	4c 89 d9             	mov    %r11,%rcx
   4caa4:	e8 07 8c ff ff       	call   456b0 <_RNvMNtCs7Z5HuLIcqFl_5mibz24bitsNtB2_3Reg11refill_slow>
   4caa9:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4caae:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4cab5:	00 
   4cab6:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4cabb:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4cac2:	00 
   4cac3:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4caca:	00 
   4cacb:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   4cad0:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   4cad5:	44 8b 6c 24 20       	mov    0x20(%rsp),%r13d
   4cada:	8b 44 24 24          	mov    0x24(%rsp),%eax
   4cade:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   4cae2:	e9 49 f3 ff ff       	jmp    4be30 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xe10>
   4cae7:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
   4caec:	48 89 6c 24 48       	mov    %rbp,0x48(%rsp)
   4caf1:	44 89 6c 24 50       	mov    %r13d,0x50(%rsp)
   4caf6:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4cafa:	89 44 24 54          	mov    %eax,0x54(%rsp)
   4cafe:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   4cb03:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   4cb08:	4c 89 d2             	mov    %r10,%rdx
   4cb0b:	4c 89 d9             	mov    %r11,%rcx
   4cb0e:	e8 9d 8b ff ff       	call   456b0 <_RNvMNtCs7Z5HuLIcqFl_5mibz24bitsNtB2_3Reg11refill_slow>
   4cb13:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4cb18:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4cb1f:	00 
   4cb20:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4cb25:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4cb2c:	00 
   4cb2d:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4cb34:	00 
   4cb35:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   4cb3a:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   4cb3f:	44 8b 6c 24 20       	mov    0x20(%rsp),%r13d
   4cb44:	8b 44 24 24          	mov    0x24(%rsp),%eax
   4cb48:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   4cb4c:	e9 3e ef ff ff       	jmp    4ba8f <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xa6f>
   4cb51:	b9 02 00 00 00       	mov    $0x2,%ecx
   4cb56:	41 b8 02 00 00 00    	mov    $0x2,%r8d
   4cb5c:	4c 89 cf             	mov    %r9,%rdi
   4cb5f:	48 89 de             	mov    %rbx,%rsi
   4cb62:	4c 89 d2             	mov    %r10,%rdx
   4cb65:	e8 06 9f fe ff       	call   36a70 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs7Z5HuLIcqFl_5mibz2>
   4cb6a:	4d 89 f2             	mov    %r14,%r10
   4cb6d:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4cb74:	00 
   4cb75:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4cb7c:	00 
   4cb7d:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4cb81:	e9 7b ef ff ff       	jmp    4bb01 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xae1>
   4cb86:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4cb8b:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4cb90:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4cb95:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4cb99:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4cb9d:	48 89 fe             	mov    %rdi,%rsi
   4cba0:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4cba5:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4cbaa:	4d 89 d0             	mov    %r10,%r8
   4cbad:	4d 89 d9             	mov    %r11,%r9
   4cbb0:	e8 8b e0 ff ff       	call   4ac40 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4cbb5:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4cbba:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4cbbf:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4cbc4:	0f 10 02             	movups (%rdx),%xmm0
   4cbc7:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4cbcc:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4cbd0:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4cbd5:	4c 8b 64 24 60       	mov    0x60(%rsp),%r12
   4cbda:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
   4cbdf:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4cbe4:	8b 54 24 74          	mov    0x74(%rsp),%edx
   4cbe8:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4cbec:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4cbf0:	0f 85 4d 06 00 00    	jne    4d243 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2223>
   4cbf6:	44 89 f1             	mov    %r14d,%ecx
   4cbf9:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4cbff:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4cc06:	00 
   4cc07:	66 41 89 04 48       	mov    %ax,(%r8,%rcx,2)
   4cc0c:	49 ff c6             	inc    %r14
   4cc0f:	66 3b 44 24 2e       	cmp    0x2e(%rsp),%ax
   4cc14:	0f 84 a6 07 00 00    	je     4d3c0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x23a0>
   4cc1a:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4cc21:	00 
   4cc22:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4cc27:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4cc2e:	00 
   4cc2f:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4cc34:	4d 89 f7             	mov    %r14,%r15
   4cc37:	4d 89 fe             	mov    %r15,%r14
   4cc3a:	49 39 df             	cmp    %rbx,%r15
   4cc3d:	0f 86 11 ed ff ff    	jbe    4b954 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x934>
   4cc43:	e9 e6 ed ff ff       	jmp    4ba2e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xa0e>
   4cc48:	89 c2                	mov    %eax,%edx
   4cc4a:	c1 ea 08             	shr    $0x8,%edx
   4cc4d:	89 54 24 7c          	mov    %edx,0x7c(%rsp)
   4cc51:	48 8b 54 24 1e       	mov    0x1e(%rsp),%rdx
   4cc56:	48 89 94 24 9e 00 00 	mov    %rdx,0x9e(%rsp)
   4cc5d:	00 
   4cc5e:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
   4cc63:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
   4cc6a:	00 
   4cc6b:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4cc72:	00 
   4cc73:	eb 33                	jmp    4cca8 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1c88>
   4cc75:	49 81 fe 13 04 00 00 	cmp    $0x413,%r14
   4cc7c:	0f 83 02 0c 00 00    	jae    4d884 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2864>
   4cc82:	89 f3                	mov    %esi,%ebx
   4cc84:	4c 89 cf             	mov    %r9,%rdi
   4cc87:	4c 89 c6             	mov    %r8,%rsi
   4cc8a:	4c 89 f2             	mov    %r14,%rdx
   4cc8d:	e8 1e e3 ff ff       	call   4afb0 <_RNvMs_NtCsgFX3jaOk65H_5alloc3vecINtB4_3VectE15append_elementsCs7Z5HuLIcqFl_5mibz2>
   4cc92:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4cc99:	00 
   4cc9a:	b0 01                	mov    $0x1,%al
   4cc9c:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
   4cca3:	45 31 f6             	xor    %r14d,%r14d
   4cca6:	89 de                	mov    %ebx,%esi
   4cca8:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   4ccaf:	00 
   4ccb0:	4c 89 22             	mov    %r12,(%rdx)
   4ccb3:	48 89 6a 08          	mov    %rbp,0x8(%rdx)
   4ccb7:	44 89 6a 10          	mov    %r13d,0x10(%rdx)
   4ccbb:	89 72 14             	mov    %esi,0x14(%rdx)
   4ccbe:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4ccc5:	00 
   4ccc6:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4cccb:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4ccd2:	00 
   4ccd3:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4ccd8:	e9 82 fc ff ff       	jmp    4c95f <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x193f>
   4ccdd:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
   4cce2:	48 89 6c 24 48       	mov    %rbp,0x48(%rsp)
   4cce7:	44 89 6c 24 50       	mov    %r13d,0x50(%rsp)
   4ccec:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4ccf0:	89 44 24 54          	mov    %eax,0x54(%rsp)
   4ccf4:	48 89 fe             	mov    %rdi,%rsi
   4ccf7:	48 8d bc 24 f8 00 00 	lea    0xf8(%rsp),%rdi
   4ccfe:	00 
   4ccff:	48 8d 4c 24 40       	lea    0x40(%rsp),%rcx
   4cd04:	4d 89 d0             	mov    %r10,%r8
   4cd07:	4d 89 d9             	mov    %r11,%r9
   4cd0a:	e8 31 df ff ff       	call   4ac40 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4cd0f:	48 8b 8c 24 f8 00 00 	mov    0xf8(%rsp),%rcx
   4cd16:	00 
   4cd17:	0f b7 84 24 00 01 00 	movzwl 0x100(%rsp),%eax
   4cd1e:	00 
   4cd1f:	4c 8b a4 24 18 01 00 	mov    0x118(%rsp),%r12
   4cd26:	00 
   4cd27:	48 8b ac 24 20 01 00 	mov    0x120(%rsp),%rbp
   4cd2e:	00 
   4cd2f:	44 8b ac 24 28 01 00 	mov    0x128(%rsp),%r13d
   4cd36:	00 
   4cd37:	8b 94 24 2c 01 00 00 	mov    0x12c(%rsp),%edx
   4cd3e:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4cd42:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4cd46:	0f 85 94 0a 00 00    	jne    4d7e0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x27c0>
   4cd4c:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4cd53:	00 
   4cd54:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4cd5b:	00 
   4cd5c:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4cd61:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4cd68:	00 
   4cd69:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4cd6e:	66 43 89 04 78       	mov    %ax,(%r8,%r15,2)
   4cd73:	49 ff c7             	inc    %r15
   4cd76:	66 3b 84 24 88 00 00 	cmp    0x88(%rsp),%ax
   4cd7d:	00 
   4cd7e:	0f 85 b5 ef ff ff    	jne    4bd39 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xd19>
   4cd84:	e9 08 09 00 00       	jmp    4d691 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2671>
   4cd89:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
   4cd8e:	48 89 6c 24 48       	mov    %rbp,0x48(%rsp)
   4cd93:	44 89 6c 24 50       	mov    %r13d,0x50(%rsp)
   4cd98:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4cd9c:	89 44 24 54          	mov    %eax,0x54(%rsp)
   4cda0:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   4cda5:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   4cdaa:	4c 89 d2             	mov    %r10,%rdx
   4cdad:	4c 89 d9             	mov    %r11,%rcx
   4cdb0:	e8 fb 88 ff ff       	call   456b0 <_RNvMNtCs7Z5HuLIcqFl_5mibz24bitsNtB2_3Reg11refill_slow>
   4cdb5:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4cdba:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4cdc1:	00 
   4cdc2:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4cdc7:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4cdce:	00 
   4cdcf:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4cdd6:	00 
   4cdd7:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   4cddc:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   4cde1:	44 8b 6c 24 20       	mov    0x20(%rsp),%r13d
   4cde6:	8b 44 24 24          	mov    0x24(%rsp),%eax
   4cdea:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   4cdee:	e9 8d f1 ff ff       	jmp    4bf80 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xf60>
   4cdf3:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
   4cdf8:	48 89 6c 24 48       	mov    %rbp,0x48(%rsp)
   4cdfd:	44 89 6c 24 50       	mov    %r13d,0x50(%rsp)
   4ce02:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4ce06:	89 44 24 54          	mov    %eax,0x54(%rsp)
   4ce0a:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   4ce0f:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   4ce14:	4c 89 d2             	mov    %r10,%rdx
   4ce17:	4c 89 d9             	mov    %r11,%rcx
   4ce1a:	e8 91 88 ff ff       	call   456b0 <_RNvMNtCs7Z5HuLIcqFl_5mibz24bitsNtB2_3Reg11refill_slow>
   4ce1f:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4ce24:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4ce2b:	00 
   4ce2c:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4ce31:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4ce38:	00 
   4ce39:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4ce40:	00 
   4ce41:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   4ce46:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   4ce4b:	44 8b 6c 24 20       	mov    0x20(%rsp),%r13d
   4ce50:	8b 44 24 24          	mov    0x24(%rsp),%eax
   4ce54:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   4ce58:	e9 9c ee ff ff       	jmp    4bcf9 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xcd9>
   4ce5d:	b9 02 00 00 00       	mov    $0x2,%ecx
   4ce62:	41 b8 02 00 00 00    	mov    $0x2,%r8d
   4ce68:	4c 89 cf             	mov    %r9,%rdi
   4ce6b:	48 89 de             	mov    %rbx,%rsi
   4ce6e:	4c 89 fa             	mov    %r15,%rdx
   4ce71:	e8 fa 9b fe ff       	call   36a70 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs7Z5HuLIcqFl_5mibz2>
   4ce76:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4ce7d:	00 
   4ce7e:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4ce85:	00 
   4ce86:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4ce8a:	e9 d3 ee ff ff       	jmp    4bd62 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xd42>
   4ce8f:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4ce94:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4ce99:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4ce9e:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4cea2:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4cea6:	48 89 fe             	mov    %rdi,%rsi
   4cea9:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4ceae:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4ceb3:	4d 89 d0             	mov    %r10,%r8
   4ceb6:	4d 89 d9             	mov    %r11,%r9
   4ceb9:	e8 82 dd ff ff       	call   4ac40 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4cebe:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4cec3:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4cec8:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4cecd:	0f 10 02             	movups (%rdx),%xmm0
   4ced0:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4ced5:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4ced9:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4cede:	4c 8b 64 24 60       	mov    0x60(%rsp),%r12
   4cee3:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
   4cee8:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4ceed:	8b 54 24 74          	mov    0x74(%rsp),%edx
   4cef1:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4cef5:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4cef9:	0f 85 44 03 00 00    	jne    4d243 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2223>
   4ceff:	44 89 f1             	mov    %r14d,%ecx
   4cf02:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4cf08:	48 8b 94 24 a8 01 00 	mov    0x1a8(%rsp),%rdx
   4cf0f:	00 
   4cf10:	66 89 04 4a          	mov    %ax,(%rdx,%rcx,2)
   4cf14:	49 ff c6             	inc    %r14
   4cf17:	66 3b 44 24 2e       	cmp    0x2e(%rsp),%ax
   4cf1c:	0f 84 9e 04 00 00    	je     4d3c0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x23a0>
   4cf22:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4cf29:	00 
   4cf2a:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4cf31:	00 
   4cf32:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4cf37:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4cf3e:	00 
   4cf3f:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4cf44:	4d 89 f7             	mov    %r14,%r15
   4cf47:	4d 89 fe             	mov    %r15,%r14
   4cf4a:	49 39 df             	cmp    %rbx,%r15
   4cf4d:	0f 86 50 ea ff ff    	jbe    4b9a3 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x983>
   4cf53:	e9 d6 ea ff ff       	jmp    4ba2e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xa0e>
   4cf58:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4cf5d:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4cf62:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4cf67:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4cf6b:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4cf6f:	48 89 fe             	mov    %rdi,%rsi
   4cf72:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4cf77:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4cf7c:	4d 89 d0             	mov    %r10,%r8
   4cf7f:	4d 89 d9             	mov    %r11,%r9
   4cf82:	e8 b9 dc ff ff       	call   4ac40 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4cf87:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4cf8c:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4cf91:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4cf96:	0f 10 02             	movups (%rdx),%xmm0
   4cf99:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4cf9e:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4cfa2:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4cfa7:	4c 8b 64 24 60       	mov    0x60(%rsp),%r12
   4cfac:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
   4cfb1:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4cfb6:	8b 54 24 74          	mov    0x74(%rsp),%edx
   4cfba:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4cfbe:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4cfc2:	0f 85 d6 04 00 00    	jne    4d49e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x247e>
   4cfc8:	48 8b 8c 24 a8 01 00 	mov    0x1a8(%rsp),%rcx
   4cfcf:	00 
   4cfd0:	66 42 89 04 79       	mov    %ax,(%rcx,%r15,2)
   4cfd5:	49 ff c7             	inc    %r15
   4cfd8:	66 3b 84 24 88 00 00 	cmp    0x88(%rsp),%ax
   4cfdf:	00 
   4cfe0:	0f 84 06 01 00 00    	je     4d0ec <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x20cc>
   4cfe6:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4cfed:	00 
   4cfee:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4cff5:	00 
   4cff6:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4cffb:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4d002:	00 
   4d003:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4d008:	4d 39 f7             	cmp    %r14,%r15
   4d00b:	0f 86 e0 eb ff ff    	jbe    4bbf1 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xbd1>
   4d011:	e9 8a ec ff ff       	jmp    4bca0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xc80>
   4d016:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4d01b:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4d020:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4d025:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4d029:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4d02d:	48 89 fe             	mov    %rdi,%rsi
   4d030:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4d035:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4d03a:	4d 89 d0             	mov    %r10,%r8
   4d03d:	4d 89 d9             	mov    %r11,%r9
   4d040:	e8 fb db ff ff       	call   4ac40 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4d045:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4d04a:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4d04f:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4d054:	0f 10 02             	movups (%rdx),%xmm0
   4d057:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4d05c:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4d060:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4d065:	4c 8b 64 24 60       	mov    0x60(%rsp),%r12
   4d06a:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
   4d06f:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4d074:	8b 54 24 74          	mov    0x74(%rsp),%edx
   4d078:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4d07c:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4d080:	0f 85 bd 01 00 00    	jne    4d243 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2223>
   4d086:	44 89 f1             	mov    %r14d,%ecx
   4d089:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4d08f:	48 8b 94 24 a8 01 00 	mov    0x1a8(%rsp),%rdx
   4d096:	00 
   4d097:	66 89 04 4a          	mov    %ax,(%rdx,%rcx,2)
   4d09b:	49 ff c6             	inc    %r14
   4d09e:	66 3b 44 24 2e       	cmp    0x2e(%rsp),%ax
   4d0a3:	0f 84 17 03 00 00    	je     4d3c0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x23a0>
   4d0a9:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d0b0:	00 
   4d0b1:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d0b8:	00 
   4d0b9:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4d0be:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4d0c5:	00 
   4d0c6:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4d0cb:	4d 89 f7             	mov    %r14,%r15
   4d0ce:	4d 89 fe             	mov    %r15,%r14
   4d0d1:	49 39 df             	cmp    %rbx,%r15
   4d0d4:	0f 86 14 e9 ff ff    	jbe    4b9ee <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x9ce>
   4d0da:	e9 4f e9 ff ff       	jmp    4ba2e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xa0e>
   4d0df:	49 81 ff 13 04 00 00 	cmp    $0x413,%r15
   4d0e6:	0f 83 c4 07 00 00    	jae    4d8b0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2890>
   4d0ec:	48 8b bc 24 b0 01 00 	mov    0x1b0(%rsp),%rdi
   4d0f3:	00 
   4d0f4:	48 8b b4 24 a8 01 00 	mov    0x1a8(%rsp),%rsi
   4d0fb:	00 
   4d0fc:	4c 89 fa             	mov    %r15,%rdx
   4d0ff:	e8 ac de ff ff       	call   4afb0 <_RNvMs_NtCsgFX3jaOk65H_5alloc3vecINtB4_3VectE15append_elementsCs7Z5HuLIcqFl_5mibz2>
   4d104:	b0 01                	mov    $0x1,%al
   4d106:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
   4d10d:	45 31 ff             	xor    %r15d,%r15d
   4d110:	e9 ac 03 00 00       	jmp    4d4c1 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x24a1>
   4d115:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4d11a:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4d11f:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4d124:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4d128:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4d12c:	48 89 fe             	mov    %rdi,%rsi
   4d12f:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4d134:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4d139:	4d 89 d0             	mov    %r10,%r8
   4d13c:	4d 89 d9             	mov    %r11,%r9
   4d13f:	e8 fc da ff ff       	call   4ac40 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4d144:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4d149:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4d14e:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4d153:	0f 10 02             	movups (%rdx),%xmm0
   4d156:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4d15b:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4d15f:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4d164:	4c 8b 64 24 60       	mov    0x60(%rsp),%r12
   4d169:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
   4d16e:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4d173:	8b 54 24 74          	mov    0x74(%rsp),%edx
   4d177:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4d17b:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4d17f:	0f 85 19 03 00 00    	jne    4d49e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x247e>
   4d185:	48 8b 8c 24 a8 01 00 	mov    0x1a8(%rsp),%rcx
   4d18c:	00 
   4d18d:	66 42 89 04 79       	mov    %ax,(%rcx,%r15,2)
   4d192:	49 ff c7             	inc    %r15
   4d195:	66 3b 84 24 88 00 00 	cmp    0x88(%rsp),%ax
   4d19c:	00 
   4d19d:	0f 84 49 ff ff ff    	je     4d0ec <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x20cc>
   4d1a3:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d1aa:	00 
   4d1ab:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d1b2:	00 
   4d1b3:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4d1b8:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4d1bf:	00 
   4d1c0:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4d1c5:	4d 39 f7             	cmp    %r14,%r15
   4d1c8:	0f 86 5f ea ff ff    	jbe    4bc2d <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xc0d>
   4d1ce:	e9 cd ea ff ff       	jmp    4bca0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xc80>
   4d1d3:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4d1d8:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4d1dd:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4d1e2:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4d1e6:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4d1ea:	48 89 fe             	mov    %rdi,%rsi
   4d1ed:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4d1f2:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4d1f7:	4d 89 d0             	mov    %r10,%r8
   4d1fa:	4d 89 d9             	mov    %r11,%r9
   4d1fd:	e8 3e da ff ff       	call   4ac40 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4d202:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4d207:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4d20c:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4d211:	0f 10 02             	movups (%rdx),%xmm0
   4d214:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4d219:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4d21d:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4d222:	4c 8b 64 24 60       	mov    0x60(%rsp),%r12
   4d227:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
   4d22c:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4d231:	8b 54 24 74          	mov    0x74(%rsp),%edx
   4d235:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4d239:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4d23d:	0f 84 5a 01 00 00    	je     4d39d <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x237d>
   4d243:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d24a:	00 
   4d24b:	89 c2                	mov    %eax,%edx
   4d24d:	c1 ea 08             	shr    $0x8,%edx
   4d250:	89 54 24 7c          	mov    %edx,0x7c(%rsp)
   4d254:	48 8b 54 24 1e       	mov    0x1e(%rsp),%rdx
   4d259:	48 89 94 24 9e 00 00 	mov    %rdx,0x9e(%rsp)
   4d260:	00 
   4d261:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
   4d266:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
   4d26d:	00 
   4d26e:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d275:	00 
   4d276:	e9 82 01 00 00       	jmp    4d3fd <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x23dd>
   4d27b:	b9 02 00 00 00       	mov    $0x2,%ecx
   4d280:	41 b8 02 00 00 00    	mov    $0x2,%r8d
   4d286:	4c 89 cf             	mov    %r9,%rdi
   4d289:	4c 89 fe             	mov    %r15,%rsi
   4d28c:	48 89 da             	mov    %rbx,%rdx
   4d28f:	e8 dc 97 fe ff       	call   36a70 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs7Z5HuLIcqFl_5mibz2>
   4d294:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d29b:	00 
   4d29c:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d2a3:	00 
   4d2a4:	4d 8b 79 10          	mov    0x10(%r9),%r15
   4d2a8:	e9 50 f6 ff ff       	jmp    4c8fd <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x18dd>
   4d2ad:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4d2b2:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4d2b7:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4d2bc:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4d2c0:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4d2c4:	48 89 fe             	mov    %rdi,%rsi
   4d2c7:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4d2cc:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4d2d1:	4d 89 d0             	mov    %r10,%r8
   4d2d4:	4d 89 d9             	mov    %r11,%r9
   4d2d7:	e8 64 d9 ff ff       	call   4ac40 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4d2dc:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4d2e1:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4d2e6:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4d2eb:	0f 10 02             	movups (%rdx),%xmm0
   4d2ee:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4d2f3:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4d2f7:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4d2fc:	4c 8b 64 24 60       	mov    0x60(%rsp),%r12
   4d301:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
   4d306:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4d30b:	8b 54 24 74          	mov    0x74(%rsp),%edx
   4d30f:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4d313:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4d317:	0f 85 81 01 00 00    	jne    4d49e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x247e>
   4d31d:	48 8b 8c 24 a8 01 00 	mov    0x1a8(%rsp),%rcx
   4d324:	00 
   4d325:	66 42 89 04 79       	mov    %ax,(%rcx,%r15,2)
   4d32a:	49 ff c7             	inc    %r15
   4d32d:	66 3b 84 24 88 00 00 	cmp    0x88(%rsp),%ax
   4d334:	00 
   4d335:	0f 84 b1 fd ff ff    	je     4d0ec <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x20cc>
   4d33b:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d342:	00 
   4d343:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d34a:	00 
   4d34b:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4d350:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4d357:	00 
   4d358:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4d35d:	4d 39 f7             	cmp    %r14,%r15
   4d360:	0f 86 03 e9 ff ff    	jbe    4bc69 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xc49>
   4d366:	e9 35 e9 ff ff       	jmp    4bca0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xc80>
   4d36b:	b9 02 00 00 00       	mov    $0x2,%ecx
   4d370:	41 b8 02 00 00 00    	mov    $0x2,%r8d
   4d376:	4c 89 cf             	mov    %r9,%rdi
   4d379:	4c 89 f6             	mov    %r14,%rsi
   4d37c:	4c 89 fa             	mov    %r15,%rdx
   4d37f:	e8 ec 96 fe ff       	call   36a70 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs7Z5HuLIcqFl_5mibz2>
   4d384:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d38b:	00 
   4d38c:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d393:	00 
   4d394:	4d 8b 71 10          	mov    0x10(%r9),%r14
   4d398:	e9 7e ed ff ff       	jmp    4c11b <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x10fb>
   4d39d:	44 89 f1             	mov    %r14d,%ecx
   4d3a0:	81 e1 ff 03 00 00    	and    $0x3ff,%ecx
   4d3a6:	48 8b 94 24 a8 01 00 	mov    0x1a8(%rsp),%rdx
   4d3ad:	00 
   4d3ae:	66 89 04 4a          	mov    %ax,(%rdx,%rcx,2)
   4d3b2:	49 ff c6             	inc    %r14
   4d3b5:	66 3b 44 24 2e       	cmp    0x2e(%rsp),%ax
   4d3ba:	0f 85 4f 01 00 00    	jne    4d50f <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x24ef>
   4d3c0:	4c 89 f2             	mov    %r14,%rdx
   4d3c3:	49 81 fe 13 04 00 00 	cmp    $0x413,%r14
   4d3ca:	0f 83 ca 04 00 00    	jae    4d89a <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x287a>
   4d3d0:	48 8b 9c 24 b0 01 00 	mov    0x1b0(%rsp),%rbx
   4d3d7:	00 
   4d3d8:	48 89 df             	mov    %rbx,%rdi
   4d3db:	4c 8b b4 24 a8 01 00 	mov    0x1a8(%rsp),%r14
   4d3e2:	00 
   4d3e3:	4c 89 f6             	mov    %r14,%rsi
   4d3e6:	e8 c5 db ff ff       	call   4afb0 <_RNvMs_NtCsgFX3jaOk65H_5alloc3vecINtB4_3VectE15append_elementsCs7Z5HuLIcqFl_5mibz2>
   4d3eb:	4d 89 f0             	mov    %r14,%r8
   4d3ee:	49 89 d9             	mov    %rbx,%r9
   4d3f1:	b0 01                	mov    $0x1,%al
   4d3f3:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
   4d3fa:	45 31 f6             	xor    %r14d,%r14d
   4d3fd:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4d402:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4d409:	00 
   4d40a:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4d40f:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   4d416:	00 
   4d417:	4c 89 22             	mov    %r12,(%rdx)
   4d41a:	48 89 6a 08          	mov    %rbp,0x8(%rdx)
   4d41e:	44 89 6a 10          	mov    %r13d,0x10(%rdx)
   4d422:	8b 74 24 0c          	mov    0xc(%rsp),%esi
   4d426:	89 72 14             	mov    %esi,0x14(%rdx)
   4d429:	e9 31 f5 ff ff       	jmp    4c95f <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x193f>
   4d42e:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   4d433:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
   4d438:	44 89 6c 24 20       	mov    %r13d,0x20(%rsp)
   4d43d:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   4d441:	89 44 24 24          	mov    %eax,0x24(%rsp)
   4d445:	48 89 fe             	mov    %rdi,%rsi
   4d448:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
   4d44d:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   4d452:	4d 89 d0             	mov    %r10,%r8
   4d455:	4d 89 d9             	mov    %r11,%r9
   4d458:	e8 e3 d7 ff ff       	call   4ac40 <_RNvMs_NtCs7Z5HuLIcqFl_5mibz24huffNtB4_4Huff17decode_entry_slow>
   4d45d:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   4d462:	0f b7 44 24 48       	movzwl 0x48(%rsp),%eax
   4d467:	48 8d 54 24 4a       	lea    0x4a(%rsp),%rdx
   4d46c:	0f 10 02             	movups (%rdx),%xmm0
   4d46f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   4d474:	48 8b 52 0e          	mov    0xe(%rdx),%rdx
   4d478:	48 89 54 24 1e       	mov    %rdx,0x1e(%rsp)
   4d47d:	4c 8b 64 24 60       	mov    0x60(%rsp),%r12
   4d482:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
   4d487:	44 8b 6c 24 70       	mov    0x70(%rsp),%r13d
   4d48c:	8b 54 24 74          	mov    0x74(%rsp),%edx
   4d490:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   4d494:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4d498:	0f 84 98 00 00 00    	je     4d536 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2516>
   4d49e:	89 c2                	mov    %eax,%edx
   4d4a0:	c1 ea 08             	shr    $0x8,%edx
   4d4a3:	89 54 24 7c          	mov    %edx,0x7c(%rsp)
   4d4a7:	48 8b 54 24 1e       	mov    0x1e(%rsp),%rdx
   4d4ac:	48 89 94 24 9e 00 00 	mov    %rdx,0x9e(%rsp)
   4d4b3:	00 
   4d4b4:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
   4d4b9:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
   4d4c0:	00 
   4d4c1:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   4d4c8:	00 
   4d4c9:	4c 89 22             	mov    %r12,(%rdx)
   4d4cc:	48 89 6a 08          	mov    %rbp,0x8(%rdx)
   4d4d0:	44 89 6a 10          	mov    %r13d,0x10(%rdx)
   4d4d4:	8b 74 24 0c          	mov    0xc(%rsp),%esi
   4d4d8:	89 72 14             	mov    %esi,0x14(%rdx)
   4d4db:	4d 89 fe             	mov    %r15,%r14
   4d4de:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d4e5:	00 
   4d4e6:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d4ed:	00 
   4d4ee:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4d4f3:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4d4fa:	00 
   4d4fb:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4d500:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
   4d504:	0f 84 7e ec ff ff    	je     4c188 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x1168>
   4d50a:	e9 13 03 00 00       	jmp    4d822 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2802>
   4d50f:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d516:	00 
   4d517:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d51e:	00 
   4d51f:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4d524:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4d52b:	00 
   4d52c:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4d531:	e9 f8 e4 ff ff       	jmp    4ba2e <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xa0e>
   4d536:	48 8b 8c 24 a8 01 00 	mov    0x1a8(%rsp),%rcx
   4d53d:	00 
   4d53e:	66 42 89 04 79       	mov    %ax,(%rcx,%r15,2)
   4d543:	49 ff c7             	inc    %r15
   4d546:	66 3b 84 24 88 00 00 	cmp    0x88(%rsp),%ax
   4d54d:	00 
   4d54e:	0f 84 98 fb ff ff    	je     4d0ec <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x20cc>
   4d554:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d55b:	00 
   4d55c:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d563:	00 
   4d564:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4d569:	4c 8b 9c 24 a0 01 00 	mov    0x1a0(%rsp),%r11
   4d570:	00 
   4d571:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   4d576:	e9 25 e7 ff ff       	jmp    4bca0 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0xc80>
   4d57b:	48 8b 9c 24 c8 00 00 	mov    0xc8(%rsp),%rbx
   4d582:	00 
   4d583:	48 39 cb             	cmp    %rcx,%rbx
   4d586:	0f 82 06 db ff ff    	jb     4b092 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x72>
   4d58c:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   4d593:	00 
   4d594:	48 8b 42 10          	mov    0x10(%rdx),%rax
   4d598:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
   4d59f:	00 
   4d5a0:	48 89 41 30          	mov    %rax,0x30(%rcx)
   4d5a4:	0f 10 02             	movups (%rdx),%xmm0
   4d5a7:	0f 11 41 20          	movups %xmm0,0x20(%rcx)
   4d5ab:	48 b8 0b 00 00 00 00 	movabs $0x800000000000000b,%rax
   4d5b2:	00 00 80 
   4d5b5:	e9 bc 00 00 00       	jmp    4d676 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2656>
   4d5ba:	48 8d 0d ef 1d 05 00 	lea    0x51def(%rip),%rcx        # 9f3b0 <_TLS_MODULE_BASE_+0x18f0>
   4d5c1:	ba 12 04 00 00       	mov    $0x412,%edx
   4d5c6:	4c 89 ff             	mov    %r15,%rdi
   4d5c9:	e8 a2 f5 fd ff       	call   2cb70 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4d5ce:	48 8d 0d db 1d 05 00 	lea    0x51ddb(%rip),%rcx        # 9f3b0 <_TLS_MODULE_BASE_+0x18f0>
   4d5d5:	ba 12 04 00 00       	mov    $0x412,%edx
   4d5da:	4c 89 f7             	mov    %r14,%rdi
   4d5dd:	e8 8e f5 fd ff       	call   2cb70 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4d5e2:	4d 89 f2             	mov    %r14,%r10
   4d5e5:	49 81 fe 13 04 00 00 	cmp    $0x413,%r14
   4d5ec:	0f 83 5f 01 00 00    	jae    4d751 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2731>
   4d5f2:	49 8b 01             	mov    (%r9),%rax
   4d5f5:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4d5f9:	48 29 d8             	sub    %rbx,%rax
   4d5fc:	49 39 c2             	cmp    %rax,%r10
   4d5ff:	0f 87 a6 01 00 00    	ja     4d7ab <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x278b>
   4d605:	4d 85 d2             	test   %r10,%r10
   4d608:	74 20                	je     4d62a <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x260a>
   4d60a:	48 8d 3c 1b          	lea    (%rbx,%rbx,1),%rdi
   4d60e:	49 03 79 08          	add    0x8(%r9),%rdi
   4d612:	4b 8d 14 12          	lea    (%r10,%r10,1),%rdx
   4d616:	4c 89 c6             	mov    %r8,%rsi
   4d619:	ff 15 29 41 05 00    	call   *0x54129(%rip)        # a1748 <memcpy@GLIBC_2.14>
   4d61f:	4d 89 f2             	mov    %r14,%r10
   4d622:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d629:	00 
   4d62a:	4c 01 d3             	add    %r10,%rbx
   4d62d:	49 89 59 10          	mov    %rbx,0x10(%r9)
   4d631:	eb 6c                	jmp    4d69f <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x267f>
   4d633:	48 8d 0d 46 1d 05 00 	lea    0x51d46(%rip),%rcx        # 9f380 <_TLS_MODULE_BASE_+0x18c0>
   4d63a:	ba 12 04 00 00       	mov    $0x412,%edx
   4d63f:	31 ff                	xor    %edi,%edi
   4d641:	4c 89 fe             	mov    %r15,%rsi
   4d644:	e8 27 f5 fd ff       	call   2cb70 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4d649:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   4d650:	00 
   4d651:	48 8b 42 10          	mov    0x10(%rdx),%rax
   4d655:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
   4d65c:	00 
   4d65d:	48 89 41 30          	mov    %rax,0x30(%rcx)
   4d661:	0f 10 02             	movups (%rdx),%xmm0
   4d664:	0f 11 41 20          	movups %xmm0,0x20(%rcx)
   4d668:	48 b8 0b 00 00 00 00 	movabs $0x800000000000000b,%rax
   4d66f:	00 00 80 
   4d672:	48 83 c0 06          	add    $0x6,%rax
   4d676:	48 89 01             	mov    %rax,(%rcx)
   4d679:	eb 6c                	jmp    4d6e7 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x26c7>
   4d67b:	48 8d 0d fe 1c 05 00 	lea    0x51cfe(%rip),%rcx        # 9f380 <_TLS_MODULE_BASE_+0x18c0>
   4d682:	ba 12 04 00 00       	mov    $0x412,%edx
   4d687:	31 ff                	xor    %edi,%edi
   4d689:	4c 89 f6             	mov    %r14,%rsi
   4d68c:	e8 df f4 fd ff       	call   2cb70 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4d691:	4c 89 cf             	mov    %r9,%rdi
   4d694:	4c 89 c6             	mov    %r8,%rsi
   4d697:	4c 89 fa             	mov    %r15,%rdx
   4d69a:	e8 11 d9 ff ff       	call   4afb0 <_RNvMs_NtCsgFX3jaOk65H_5alloc3vecINtB4_3VectE15append_elementsCs7Z5HuLIcqFl_5mibz2>
   4d69f:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   4d6a6:	00 
   4d6a7:	4c 89 20             	mov    %r12,(%rax)
   4d6aa:	48 89 68 08          	mov    %rbp,0x8(%rax)
   4d6ae:	44 89 68 10          	mov    %r13d,0x10(%rax)
   4d6b2:	8b 4c 24 0c          	mov    0xc(%rsp),%ecx
   4d6b6:	89 48 14             	mov    %ecx,0x14(%rax)
   4d6b9:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   4d6c0:	00 
   4d6c1:	48 8b 42 10          	mov    0x10(%rdx),%rax
   4d6c5:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
   4d6cc:	00 
   4d6cd:	48 89 41 30          	mov    %rax,0x30(%rcx)
   4d6d1:	48 8b 02             	mov    (%rdx),%rax
   4d6d4:	48 89 41 20          	mov    %rax,0x20(%rcx)
   4d6d8:	48 8b 42 08          	mov    0x8(%rdx),%rax
   4d6dc:	48 89 41 28          	mov    %rax,0x28(%rcx)
   4d6e0:	48 c7 01 ff ff ff ff 	movq   $0xffffffffffffffff,(%rcx)
   4d6e7:	48 81 c4 68 01 00 00 	add    $0x168,%rsp
   4d6ee:	5b                   	pop    %rbx
   4d6ef:	41 5c                	pop    %r12
   4d6f1:	41 5d                	pop    %r13
   4d6f3:	41 5e                	pop    %r14
   4d6f5:	41 5f                	pop    %r15
   4d6f7:	5d                   	pop    %rbp
   4d6f8:	c3                   	ret
   4d6f9:	48 8d 0d 38 1c 05 00 	lea    0x51c38(%rip),%rcx        # 9f338 <_TLS_MODULE_BASE_+0x1878>
   4d700:	ba 12 04 00 00       	mov    $0x412,%edx
   4d705:	31 ff                	xor    %edi,%edi
   4d707:	4c 89 d6             	mov    %r10,%rsi
   4d70a:	e8 61 f4 fd ff       	call   2cb70 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4d70f:	48 8d 0d 22 1c 05 00 	lea    0x51c22(%rip),%rcx        # 9f338 <_TLS_MODULE_BASE_+0x1878>
   4d716:	ba 12 04 00 00       	mov    $0x412,%edx
   4d71b:	31 ff                	xor    %edi,%edi
   4d71d:	4c 89 fe             	mov    %r15,%rsi
   4d720:	e8 4b f4 fd ff       	call   2cb70 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4d725:	48 8d 0d 6c 1c 05 00 	lea    0x51c6c(%rip),%rcx        # 9f398 <_TLS_MODULE_BASE_+0x18d8>
   4d72c:	ba 12 04 00 00       	mov    $0x412,%edx
   4d731:	31 ff                	xor    %edi,%edi
   4d733:	48 89 de             	mov    %rbx,%rsi
   4d736:	e8 35 f4 fd ff       	call   2cb70 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4d73b:	48 8d 0d 56 1c 05 00 	lea    0x51c56(%rip),%rcx        # 9f398 <_TLS_MODULE_BASE_+0x18d8>
   4d742:	ba 12 04 00 00       	mov    $0x412,%edx
   4d747:	31 ff                	xor    %edi,%edi
   4d749:	4c 89 fe             	mov    %r15,%rsi
   4d74c:	e8 1f f4 fd ff       	call   2cb70 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4d751:	48 8d 0d f8 1b 05 00 	lea    0x51bf8(%rip),%rcx        # 9f350 <_TLS_MODULE_BASE_+0x1890>
   4d758:	ba 12 04 00 00       	mov    $0x412,%edx
   4d75d:	31 ff                	xor    %edi,%edi
   4d75f:	4c 89 d6             	mov    %r10,%rsi
   4d762:	e8 09 f4 fd ff       	call   2cb70 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4d767:	89 c2                	mov    %eax,%edx
   4d769:	c1 ea 08             	shr    $0x8,%edx
   4d76c:	89 54 24 7c          	mov    %edx,0x7c(%rsp)
   4d770:	48 8d b4 24 3a 01 00 	lea    0x13a(%rsp),%rsi
   4d777:	00 
   4d778:	48 8b 56 0e          	mov    0xe(%rsi),%rdx
   4d77c:	48 89 94 24 9e 00 00 	mov    %rdx,0x9e(%rsp)
   4d783:	00 
   4d784:	0f 10 06             	movups (%rsi),%xmm0
   4d787:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
   4d78e:	00 
   4d78f:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   4d796:	00 
   4d797:	4c 89 22             	mov    %r12,(%rdx)
   4d79a:	48 89 6a 08          	mov    %rbp,0x8(%rdx)
   4d79e:	44 89 6a 10          	mov    %r13d,0x10(%rdx)
   4d7a2:	8b 74 24 0c          	mov    0xc(%rsp),%esi
   4d7a6:	89 72 14             	mov    %esi,0x14(%rdx)
   4d7a9:	eb 77                	jmp    4d822 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x2802>
   4d7ab:	b9 02 00 00 00       	mov    $0x2,%ecx
   4d7b0:	41 b8 02 00 00 00    	mov    $0x2,%r8d
   4d7b6:	4c 89 cf             	mov    %r9,%rdi
   4d7b9:	48 89 de             	mov    %rbx,%rsi
   4d7bc:	4c 89 d2             	mov    %r10,%rdx
   4d7bf:	e8 ac 92 fe ff       	call   36a70 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs7Z5HuLIcqFl_5mibz2>
   4d7c4:	4d 89 f2             	mov    %r14,%r10
   4d7c7:	4c 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%r8
   4d7ce:	00 
   4d7cf:	4c 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9
   4d7d6:	00 
   4d7d7:	49 8b 59 10          	mov    0x10(%r9),%rbx
   4d7db:	e9 2a fe ff ff       	jmp    4d60a <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x25ea>
   4d7e0:	48 8d b4 24 02 01 00 	lea    0x102(%rsp),%rsi
   4d7e7:	00 
   4d7e8:	48 8b 56 0e          	mov    0xe(%rsi),%rdx
   4d7ec:	48 89 94 24 9e 00 00 	mov    %rdx,0x9e(%rsp)
   4d7f3:	00 
   4d7f4:	0f 10 06             	movups (%rsi),%xmm0
   4d7f7:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
   4d7fe:	00 
   4d7ff:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
   4d806:	00 
   4d807:	4c 89 22             	mov    %r12,(%rdx)
   4d80a:	48 89 6a 08          	mov    %rbp,0x8(%rdx)
   4d80e:	44 89 6a 10          	mov    %r13d,0x10(%rdx)
   4d812:	8b 74 24 0c          	mov    0xc(%rsp),%esi
   4d816:	89 72 14             	mov    %esi,0x14(%rdx)
   4d819:	89 c2                	mov    %eax,%edx
   4d81b:	c1 ea 08             	shr    $0x8,%edx
   4d81e:	89 54 24 7c          	mov    %edx,0x7c(%rsp)
   4d822:	48 8b 94 24 9e 00 00 	mov    0x9e(%rsp),%rdx
   4d829:	00 
   4d82a:	48 8b b4 24 b0 00 00 	mov    0xb0(%rsp),%rsi
   4d831:	00 
   4d832:	48 89 56 18          	mov    %rdx,0x18(%rsi)
   4d836:	0f 28 84 24 90 00 00 	movaps 0x90(%rsp),%xmm0
   4d83d:	00 
   4d83e:	0f 11 46 0a          	movups %xmm0,0xa(%rsi)
   4d842:	48 8b bc 24 80 00 00 	mov    0x80(%rsp),%rdi
   4d849:	00 
   4d84a:	48 8b 17             	mov    (%rdi),%rdx
   4d84d:	48 89 56 20          	mov    %rdx,0x20(%rsi)
   4d851:	48 8b 57 08          	mov    0x8(%rdi),%rdx
   4d855:	48 89 56 28          	mov    %rdx,0x28(%rsi)
   4d859:	48 8b 57 10          	mov    0x10(%rdi),%rdx
   4d85d:	48 89 56 30          	mov    %rdx,0x30(%rsi)
   4d861:	48 89 0e             	mov    %rcx,(%rsi)
   4d864:	88 46 08             	mov    %al,0x8(%rsi)
   4d867:	8b 44 24 7c          	mov    0x7c(%rsp),%eax
   4d86b:	88 46 09             	mov    %al,0x9(%rsi)
   4d86e:	e9 74 fe ff ff       	jmp    4d6e7 <_RNvNtCs7Z5HuLIcqFl_5mibz25block16decode_runs_bmi2+0x26c7>
   4d873:	48 8d 15 36 21 05 00 	lea    0x52136(%rip),%rdx        # 9f9b0 <_TLS_MODULE_BASE_+0x1ef0>
   4d87a:	be 06 00 00 00       	mov    $0x6,%esi
   4d87f:	e8 cd f3 fd ff       	call   2cc51 <_RNvNtCskADBYZwJmSU_4core9panicking18panic_bounds_check>
   4d884:	48 8d 0d dd 1a 05 00 	lea    0x51add(%rip),%rcx        # 9f368 <_TLS_MODULE_BASE_+0x18a8>
   4d88b:	ba 12 04 00 00       	mov    $0x412,%edx
   4d890:	31 ff                	xor    %edi,%edi
   4d892:	4c 89 f6             	mov    %r14,%rsi
   4d895:	e8 d6 f2 fd ff       	call   2cb70 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4d89a:	48 8d 0d 7f 1a 05 00 	lea    0x51a7f(%rip),%rcx        # 9f320 <_TLS_MODULE_BASE_+0x1860>
   4d8a1:	48 89 d6             	mov    %rdx,%rsi
   4d8a4:	ba 12 04 00 00       	mov    $0x412,%edx
   4d8a9:	31 ff                	xor    %edi,%edi
   4d8ab:	e8 c0 f2 fd ff       	call   2cb70 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
   4d8b0:	48 8d 0d b1 1a 05 00 	lea    0x51ab1(%rip),%rcx        # 9f368 <_TLS_MODULE_BASE_+0x18a8>
   4d8b7:	ba 12 04 00 00       	mov    $0x412,%edx
   4d8bc:	31 ff                	xor    %edi,%edi
   4d8be:	4c 89 fe             	mov    %r15,%rsi
   4d8c1:	e8 aa f2 fd ff       	call   2cb70 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
