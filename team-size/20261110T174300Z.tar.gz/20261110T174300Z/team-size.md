# Team size against live tables: wikidata

Runs: 320; errors: 0; output hashes: 1 (same bytes). Reference: `mibz2@8`. Paired ratio: the reference's wall over the cell's, by round (above 1 is faster), its geometric mean and 95% interval.

| teams × k | arm @ threads | tables | MB/s | vs ref | busy cores | leader CPU | helper CPU | scanner CPU | peak RSS | L3 hit share | L3 misses /KB | cycles /B | IPC | L3-miss stall share |
|---|---|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| 1 × 3 | `mibz2-team3@4` | 3.6 MB | 757 | 0.515 (0.501–0.529) | 2.4 | 0.260 | 0.140 | 0.050 | 36 MB | – | – | – | – | – |
| 1 × 3 | `mibz2-team3@5` | 3.6 MB | 754 | 0.510 (0.496–0.523) | 2.4 | 0.260 | 0.143 | 0.050 | 36 MB | – | – | – | – | – |
| 1 × 4 | `mibz2-team4@4` | 3.6 MB | 786 | 0.539 (0.531–0.547) | 2.8 | 0.240 | 0.120 | 0.050 | 36 MB | – | – | – | – | – |
| 1 × 4 | `mibz2-team4@5` | 3.6 MB | 781 | 0.534 (0.524–0.544) | 2.7 | 0.250 | 0.120 | 0.050 | 36 MB | – | – | – | – | – |
| 1 × 4 | `mibz2-team4@6` | 3.6 MB | 766 | 0.531 (0.521–0.541) | 2.8 | 0.250 | 0.125 | 0.050 | 36 MB | – | – | – | – | – |
| 2 × 2 | `mibz2-team2@4` | 7.2 MB | 1,146 | 0.793 (0.780–0.807) | 3.6 | 0.160 | 0.095 | 0.050 | 52 MB | – | – | – | – | – |
| 2 × 2 | `mibz2-team2@5` | 7.2 MB | 1,143 | 0.788 (0.774–0.803) | 3.6 | 0.160 | 0.100 | 0.050 | 51 MB | – | – | – | – | – |
| 2 × 3 | `mibz2-team3@6` | 7.2 MB | 1,285 | 0.879 (0.862–0.896) | 4.5 | 0.140 | 0.074 | 0.050 | 51 MB | – | – | – | – | – |
| 2 × 3 | `mibz2-team3@8` | 7.2 MB | 1,256 | 0.871 (0.859–0.884) | 4.5 | 0.145 | 0.076 | 0.050 | 51 MB | – | – | – | – | – |
| 2 × 4 | `mibz2-team4@8` | 7.2 MB | 1,338 | 0.920 (0.911–0.930) | 5.2 | 0.135 | 0.065 | 0.050 | 52 MB | – | – | – | – | – |
| 3 × 2 | `mibz2@6` | 10.8 MB | 1,463 | 1.013 (1.004–1.022) | 5.1 | 0.117 | 0.070 | 0.050 | 66 MB | – | – | – | – | – |
| 3 × 2 | `mibz2-team2@6` | 10.8 MB | 1,455 | 1.008 (0.995–1.022) | 5.1 | 0.117 | 0.070 | 0.050 | 66 MB | – | – | – | – | – |
| 4 × 1 | `mibz2@4` | 14.4 MB | 1,199 | 0.825 (0.809–0.842) | 4.3 | 0.146 | – | 0.050 | 78 MB | – | – | – | – | – |
| 4 × 2 | `mibz2@8` | 14.4 MB | 1,450 | 1.000 (1.000–1.000) | 6.6 | 0.115 | 0.069 | 0.050 | 79 MB | – | – | – | – | – |
| 4 × 2 | `mibz2-team2@8` | 14.4 MB | 1,466 | 1.011 (0.998–1.024) | 6.6 | 0.113 | 0.068 | 0.060 | 79 MB | – | – | – | – | – |
| 5 × 1 | `mibz2@5` | 18.0 MB | 1,142 | 0.790 (0.778–0.802) | 5.3 | 0.153 | – | 0.060 | 90 MB | – | – | – | – | – |

## The rule's predicates

- Every run of every cell the same output hash and length, no run failed: **yes** (1 hash(es), 1 length(s), 0 failed).
- The reference `mibz2@8`: rounds 0–19 once each, every run 4x2: **yes**.
- The whole grid, 16 cells × 20 rounds, each round once, no failed run: **yes**.
- The control `mibz2-team2@8` 1.011 (0.998–1.024), 20 pairs: **within ±2%**.

| primary | plan in every run | 20 unique pairs | mean ≥ 1.03 | lower bound > 1.00 | raises the ceiling | peak RSS / ref (≤ 1.15) | CPU / ref (≤ 1.5) |
|---|---|---|---|---|---|---|---|
| `mibz2-team3@12` | no runs | | | | **no** | | |
| `mibz2-team4@16` | no runs | | | | **no** | | |

A pass here is not a qualification: the same cell must pass the same predicates, within the adoption limits, in one predeclared second run of 20 rounds. The adoption limits are ratios of medians (the cell's median peak RSS and CPU-seconds over the reference's) and must hold in both runs.
