# The pipelined default: head default against v0.2.5's default

Speed is the base build's wall over the head's, paired by round (above 1 is faster); CPU and RSS are the head's median over the base's.

| threads | role | plans run, base → head | speed (95%) | head/base wall, upper bound | CPU | RSS |
|--:|---|---|--:|--:|--:|--:|
| 8 | identity | 4×2 plain → 4×2 plain | 1.002 (0.991–1.013) | 1.011 | 0.99 | 1.00 |
| 9 | identity | 4×2 plain → 4×2 plain | 1.001 (0.991–1.012) | 1.011 | 1.00 | 1.00 |
| 10 | primary | 3×3 plain → 3×3 pipelined | 1.072 (1.054–1.089) | 0.951 | 1.04 | 1.10 |
| 11 | no harm | 3×3 plain → 3×3 pipelined | 1.070 (1.055–1.085) | 0.950 | 1.05 | 1.12 |
| 12 | no harm | 3×3 plain → 3×3 pipelined | 1.069 (1.054–1.085) | 0.951 | 1.05 | 1.10 |
| 16 | no harm | 3×3 plain → 3×3 pipelined | 1.065 (1.045–1.085) | 0.960 | 1.05 | 1.13 |
| 20 | no harm | 3×3 plain → 3×3 pipelined | 1.070 (1.048–1.092) | 0.957 | 1.04 | 1.12 |

## The predicates

- Valid (rounds, outputs, plans): **yes**
- Identity check at 8 (reported, not judged): 95% interval not wholly beyond ±2%: **yes**
- Identity check at 9 (reported, not judged): 95% interval not wholly beyond ±2%: **yes**
- Primary at 10, speed: **yes**
- Primary at 10, lower bound: **yes**
- No harm at 11: upper bound ≤ 1.02: **yes**
- No harm at 12: upper bound ≤ 1.02: **yes**
- No harm at 16: upper bound ≤ 1.02: **yes**
- No harm at 20: upper bound ≤ 1.02: **yes**

**This run: PASS.** CPU and RSS are reported, not judged. One run, as registered: nothing pooled or switched.
