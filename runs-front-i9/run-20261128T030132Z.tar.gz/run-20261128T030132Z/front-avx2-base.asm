/home/louis/dev/mibz2/target/runs-front-i9/runs-front-i9-v26p_be9/base-ab:     file format elf64-x86-64


Disassembly of section .fini:

Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000010bb70 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2>:
  10bb70:	push   %rbp
  10bb71:	mov    %rsp,%rbp
  10bb74:	push   %r15
  10bb76:	push   %r14
  10bb78:	push   %r13
  10bb7a:	push   %r12
  10bb7c:	push   %rbx
  10bb7d:	and    $0xffffffffffffffc0,%rsp
  10bb81:	sub    $0xa00,%rsp
  10bb88:	mov    %rcx,%r10
  10bb8b:	mov    %rdx,%r12
  10bb8e:	movb   $0x0,0x850(%rcx)
  10bb95:	mov    0x118(%rdi),%rdx
  10bb9c:	cmp    $0x7fffffff,%rdx
  10bba3:	seta   %al
  10bba6:	movq   $0x0,0x848(%rcx)
  10bbb1:	cmp    $0x1000000,%r12
  10bbb8:	setae  %cl
  10bbbb:	or     %al,%cl
  10bbbd:	jne    10bf57 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x3e7>
  10bbc3:	mov    %rsi,%r15
  10bbc6:	mov    %rdi,%r14
  10bbc9:	mov    %rdx,0x58(%rsp)
  10bbce:	mov    %r12,%rbx
  10bbd1:	shr    $0x6,%rbx
  10bbd5:	lea    0x3(%rbx),%rax
  10bbd9:	movq   $0x0,0x28(%r10)
  10bbe1:	cmp    0x18(%r10),%rax
  10bbe5:	mov    %r10,0x40(%rsp)
  10bbea:	mov    %rax,0x80(%rsp)
  10bbf2:	ja     10cae0 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xf70>
  10bbf8:	movq   $0x0,0x40(%r10)
  10bc00:	cmp    0x30(%r10),%rax
  10bc04:	ja     10cb15 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xfa5>
  10bc0a:	mov    0x20(%r10),%rax
  10bc0e:	mov    %rax,0x50(%rsp)
  10bc13:	mov    0x38(%r10),%rax
  10bc17:	mov    %rax,0x48(%rsp)
  10bc1c:	movzwl 0x128(%r14),%ecx
  10bc24:	vmovd  %ecx,%xmm0
  10bc28:	vpbroadcastw %xmm0,%ymm0
  10bc2d:	mov    %r12,0x38(%rsp)
  10bc32:	mov    %r12,%rax
  10bc35:	shr    $0x5,%rax
  10bc39:	xor    %edx,%edx
  10bc3b:	vpbroadcastw -0xda488(%rip),%ymm1        # 317bc <GCC_except_table1575+0x688>
  10bc44:	vpxor  %xmm2,%xmm2,%xmm2
  10bc48:	mov    $0x2,%esi
  10bc4d:	xor    %r13d,%r13d
  10bc50:	jmp    10bc8a <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x11a>
  10bc52:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  10bc60:	mov    $0xffffffffffffffff,%r12
  10bc67:	mov    0x50(%rsp),%r9
  10bc6c:	mov    %edi,(%r9,%r13,4)
  10bc70:	mov    0x48(%rsp),%rdi
  10bc75:	mov    %r8d,(%rdi,%r13,4)
  10bc79:	inc    %r13
  10bc7c:	add    $0x40,%rdx
  10bc80:	cmp    $0xffffffffffffffff,%r12
  10bc84:	jne    10bdd4 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x264>
  10bc8a:	mov    %r13,%r12
  10bc8d:	shl    $0x5,%r12
  10bc91:	cmp    %rax,%r13
  10bc94:	je     10bd23 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x1b3>
  10bc9a:	vmovdqu (%r15,%r12,2),%ymm3
  10bca0:	vmovdqu 0x20(%r15,%r12,2),%ymm4
  10bca7:	vpminuw %ymm1,%ymm3,%ymm5
  10bcac:	vpcmpeqw %ymm5,%ymm3,%ymm5
  10bcb0:	vpminuw %ymm1,%ymm4,%ymm6
  10bcb5:	vpcmpeqw %ymm6,%ymm4,%ymm6
  10bcb9:	vpacksswb %ymm6,%ymm5,%ymm5
  10bcbd:	vpermq $0xd8,%ymm5,%ymm5
  10bcc3:	vpcmpeqw %ymm2,%ymm3,%ymm6
  10bcc7:	vpcmpeqw %ymm2,%ymm4,%ymm7
  10bccb:	vpacksswb %ymm7,%ymm6,%ymm6
  10bccf:	vpermq $0xd8,%ymm6,%ymm6
  10bcd5:	vpcmpeqw %ymm0,%ymm3,%ymm3
  10bcd9:	vpcmpeqw %ymm0,%ymm4,%ymm4
  10bcdd:	vpacksswb %ymm4,%ymm3,%ymm3
  10bce1:	vpermq $0xd8,%ymm3,%ymm3
  10bce7:	vpmovmskb %ymm5,%edi
  10bceb:	not    %edi
  10bced:	vpandn %ymm3,%ymm5,%ymm3
  10bcf1:	vpmovmskb %ymm3,%r9d
  10bcf5:	vpmovmskb %ymm6,%r8d
  10bcf9:	not    %r8d
  10bcfc:	test   %r9d,%r9d
  10bcff:	je     10bc60 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xf0>
  10bd05:	tzcnt  %r9d,%r9d
  10bd0a:	or     %r9,%r12
  10bd0d:	shlx   %r9d,%esi,%r9d
  10bd12:	dec    %r9d
  10bd15:	and    %r9d,%r8d
  10bd18:	shr    $1,%r9d
  10bd1b:	and    %r9d,%edi
  10bd1e:	jmp    10bc67 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xf7>
  10bd23:	mov    0x38(%rsp),%rsi
  10bd28:	cmp    %rsi,%r12
  10bd2b:	ja     10cb6d <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xffd>
  10bd31:	mov    $0xffffffffffffffff,%r9
  10bd38:	xor    %edi,%edi
  10bd3a:	cmp    %rsi,%r12
  10bd3d:	jne    10bd44 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x1d4>
  10bd3f:	xor    %r8d,%r8d
  10bd42:	jmp    10bdba <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x24a>
  10bd44:	lea    (%rsi,%rsi,1),%r9
  10bd48:	xor    %edi,%edi
  10bd4a:	xor    %r8d,%r8d
  10bd4d:	xor    %r10d,%r10d
  10bd50:	jmp    10bd6c <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x1fc>
  10bd52:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  10bd60:	add    $0x2,%rdx
  10bd64:	inc    %r10
  10bd67:	cmp    %rdx,%r9
  10bd6a:	je     10bda1 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x231>
  10bd6c:	mov    %r8d,%esi
  10bd6f:	movzwl (%r15,%rdx,1),%r11d
  10bd74:	xor    %r8d,%r8d
  10bd77:	test   %r11w,%r11w
  10bd7b:	setne  %r8b
  10bd7f:	mov    %r10d,%r13d
  10bd82:	and    $0x1f,%r13d
  10bd86:	shlx   %r13d,%r8d,%r8d
  10bd8b:	or     %esi,%r8d
  10bd8e:	cmp    $0x1,%r11w
  10bd93:	jbe    10bd60 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x1f0>
  10bd95:	cmp    %cx,%r11w
  10bd99:	je     10bdaf <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x23f>
  10bd9b:	bts    %r13d,%edi
  10bd9f:	jmp    10bd60 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x1f0>
  10bda1:	mov    0x40(%rsp),%r10
  10bda6:	mov    $0xffffffffffffffff,%r9
  10bdad:	jmp    10bdba <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x24a>
  10bdaf:	add    %r12,%r10
  10bdb2:	mov    %r10,%r9
  10bdb5:	mov    0x40(%rsp),%r10
  10bdba:	mov    0x50(%rsp),%rcx
  10bdbf:	mov    %edi,(%rcx,%rax,4)
  10bdc2:	mov    0x48(%rsp),%rcx
  10bdc7:	mov    %r8d,(%rcx,%rax,4)
  10bdcb:	inc    %rax
  10bdce:	mov    %rax,%r13
  10bdd1:	mov    %r9,%r12
  10bdd4:	lea    0x3(%rbx),%rcx
  10bdd8:	lea    (%rcx,%rcx,1),%rax
  10bddc:	cmp    %rax,%r13
  10bddf:	jae    10be27 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x2b7>
  10bde1:	mov    0x50(%rsp),%rax
  10bde6:	lea    (%rax,%r13,4),%rdi
  10bdea:	add    %rbx,%rbx
  10bded:	sub    %r13,%rbx
  10bdf0:	lea    0x18(,%rbx,4),%rbx
  10bdf8:	xor    %esi,%esi
  10bdfa:	mov    %rbx,%rdx
  10bdfd:	vzeroupper
  10be00:	call   *0xdc70a(%rip)        # 1e8510 <memset@GLIBC_2.2.5>
  10be06:	mov    0x48(%rsp),%rax
  10be0b:	lea    (%rax,%r13,4),%rdi
  10be0f:	xor    %esi,%esi
  10be11:	mov    %rbx,%rdx
  10be14:	call   *0xdc6f6(%rip)        # 1e8510 <memset@GLIBC_2.2.5>
  10be1a:	mov    0x80(%rsp),%rcx
  10be22:	mov    0x40(%rsp),%r10
  10be27:	mov    %rcx,0x28(%r10)
  10be2b:	mov    %rcx,0x40(%r10)
  10be2f:	cmp    $0xffffffffffffffff,%r12
  10be33:	je     10bf57 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x3e7>
  10be39:	vmovups 0x18(%r14),%xmm0
  10be3f:	vmovaps %xmm0,0x60(%rsp)
  10be45:	vmovups 0x28(%r14),%xmm0
  10be4b:	vmovaps %ymm0,0x80(%rsp)
  10be54:	vmovups 0xf8(%r14),%ymm0
  10be5d:	vmovaps %ymm0,0x180(%rsp)
  10be66:	vmovups 0xd8(%r14),%ymm0
  10be6f:	vmovaps %ymm0,0x160(%rsp)
  10be78:	vmovups 0xb8(%r14),%ymm0
  10be81:	vmovaps %ymm0,0x140(%rsp)
  10be8a:	vmovdqu 0x38(%r14),%ymm0
  10be90:	vmovdqu 0x58(%r14),%ymm1
  10be96:	vmovups 0x78(%r14),%ymm2
  10be9c:	vmovdqu 0x98(%r14),%ymm3
  10bea5:	vmovdqa %ymm3,0x120(%rsp)
  10beae:	vmovaps %ymm2,0x100(%rsp)
  10beb7:	vmovdqa %ymm1,0xe0(%rsp)
  10bec0:	vmovdqa %ymm0,0xc0(%rsp)
  10bec9:	movabs $0x204081020408103,%rax
  10bed3:	mov    0x58(%rsp),%rbx
  10bed8:	mov    %rbx,%rdx
  10bedb:	mulx   %rax,%rax,%rax
  10bee0:	mov    %rbx,%r13
  10bee3:	sub    %rax,%r13
  10bee6:	shr    $1,%r13
  10bee9:	add    %rax,%r13
  10beec:	shr    $0x6,%r13
  10bef0:	movq   $0x0,0x10(%r10)
  10bef8:	mov    0x38(%rsp),%rax
  10befd:	lea    (%rax,%r13,1),%rdx
  10bf01:	add    $0x3,%rdx
  10bf05:	cmp    (%r10),%rdx
  10bf08:	ja     10cb39 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xfc9>
  10bf0e:	mov    0x8(%r10),%rax
  10bf12:	mov    %rax,0x78(%rsp)
  10bf17:	lea    0x1c8(%rsp),%rdi
  10bf1f:	xor    %r14d,%r14d
  10bf22:	mov    $0x800,%edx
  10bf27:	xor    %esi,%esi
  10bf29:	vzeroupper
  10bf2c:	call   *0xdc5de(%rip)        # 1e8510 <memset@GLIBC_2.2.5>
  10bf32:	mov    %r12,%rdx
  10bf35:	shr    $0x6,%rdx
  10bf39:	mov    0x50(%rsp),%rax
  10bf3e:	mov    (%rax),%rax
  10bf41:	test   %rax,%rax
  10bf44:	je     10bf5b <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x3eb>
  10bf46:	vmovdqa 0x80(%rsp),%ymm10
  10bf4f:	vmovdqa 0x60(%rsp),%xmm2
  10bf55:	jmp    10bf87 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x417>
  10bf57:	xor    %eax,%eax
  10bf59:	jmp    10bfb0 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x440>
  10bf5b:	xor    %r9d,%r9d
  10bf5e:	xor    %r14d,%r14d
  10bf61:	vmovdqa 0x80(%rsp),%ymm10
  10bf6a:	vmovdqa 0x60(%rsp),%xmm2
  10bf70:	cmp    %r14,%rdx
  10bf73:	je     10bfc2 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x452>
  10bf75:	mov    0x50(%rsp),%rax
  10bf7a:	mov    0x8(%rax,%r14,8),%rax
  10bf7f:	inc    %r14
  10bf82:	test   %rax,%rax
  10bf85:	je     10bf70 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x400>
  10bf87:	mov    %r13,%r8
  10bf8a:	tzcnt  %rax,%r13
  10bf8f:	blsr   %rax,%r9
  10bf94:	mov    %r14,%rax
  10bf97:	shl    $0x6,%rax
  10bf9b:	or     %r13,%rax
  10bf9e:	xor    %ecx,%ecx
  10bfa0:	cmp    $0x15,%rax
  10bfa4:	jbe    10bfd3 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x463>
  10bfa6:	xor    %eax,%eax
  10bfa8:	mov    0xb8(%rsp),%rdx
  10bfb0:	lea    -0x28(%rbp),%rsp
  10bfb4:	pop    %rbx
  10bfb5:	pop    %r12
  10bfb7:	pop    %r13
  10bfb9:	pop    %r14
  10bfbb:	pop    %r15
  10bfbd:	pop    %rbp
  10bfbe:	vzeroupper
  10bfc1:	ret
  10bfc2:	mov    %r13,%r8
  10bfc5:	mov    $0x1,%cl
  10bfc7:	mov    %rdx,%r14
  10bfca:	mov    %r12,%rax
  10bfcd:	cmp    $0x15,%rax
  10bfd1:	ja     10bfa6 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x436>
  10bfd3:	mov    %rdx,0x80(%rsp)
  10bfdb:	inc    %rax
  10bfde:	mov    0x48(%rsp),%rdx
  10bfe3:	bzhi   %rax,(%rdx),%rdx
  10bfe8:	dec    %rdx
  10bfeb:	movabs $0x204081020408103,%rax
  10bff5:	mulx   %rax,%rax,%rax
  10bffa:	mov    %rdx,%rdi
  10bffd:	sub    %rax,%rdi
  10c000:	shr    $1,%rdi
  10c003:	add    %rax,%rdi
  10c006:	shr    $0x6,%rdi
  10c00a:	movabs $0x7efdfbf7efdfbf7f,%rsi
  10c014:	mov    %rdx,%rax
  10c017:	imul   %rsi,%rax
  10c01b:	movabs $0x204081020408102,%r10
  10c025:	xor    %esi,%esi
  10c027:	cmp    %r10,%rax
  10c02a:	seta   %sil
  10c02e:	add    %rdi,%rsi
  10c031:	xor    %eax,%eax
  10c033:	mov    %rsi,%rdi
  10c036:	sub    $0x1,%rdi
  10c03a:	cmovb  %rax,%rdi
  10c03e:	mov    %rdx,0x38(%rsp)
  10c043:	cmp    %rbx,%rdx
  10c046:	ja     10bfa8 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x438>
  10c04c:	inc    %r8
  10c04f:	sub    %rdi,%r8
  10c052:	mov    %r8,0x60(%rsp)
  10c057:	jb     10bfa8 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x438>
  10c05d:	vmovd  %xmm2,%eax
  10c061:	movzbl %al,%eax
  10c064:	shl    $0x20,%rsi
  10c068:	mov    0x38(%rsp),%rdx
  10c06d:	or     %rdx,%rsi
  10c070:	add    %rsi,0x1c8(%rsp,%rax,8)
  10c078:	mov    0x78(%rsp),%r10
  10c07d:	mov    %r10,%rdi
  10c080:	test   %rdx,%rdx
  10c083:	je     10c0ae <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x53e>
  10c085:	shl    $0x8,%eax
  10c088:	mov    %r10,%rdi
  10c08b:	mov    0x38(%rsp),%rdx
  10c090:	cmp    $0x7f,%rdx
  10c094:	mov    $0x7f,%esi
  10c099:	cmovb  %rdx,%rsi
  10c09d:	lea    (%rsi,%rax,1),%r8d
  10c0a1:	mov    %r8w,(%rdi)
  10c0a5:	add    $0x2,%rdi
  10c0a9:	sub    %rsi,%rdx
  10c0ac:	jne    10c090 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x520>
  10c0ae:	test   %cl,%cl
  10c0b0:	je     10c5a5 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xa35>
  10c0b6:	mov    0x40(%rsp),%rcx
  10c0bb:	mov    0x58(%rsp),%rax
  10c0c0:	vpxor  %xmm0,%xmm0,%xmm0
  10c0c4:	vpblendd $0x55,0x1c8(%rsp),%ymm0,%ymm1
  10c0cf:	vpblendd $0x55,0x1e8(%rsp),%ymm0,%ymm2
  10c0da:	vpblendd $0x55,0x208(%rsp),%ymm0,%ymm3
  10c0e5:	vpblendd $0x55,0x228(%rsp),%ymm0,%ymm4
  10c0f0:	vpblendd $0x55,0x248(%rsp),%ymm0,%ymm5
  10c0fb:	vpaddq %ymm1,%ymm5,%ymm1
  10c0ff:	vpblendd $0x55,0x268(%rsp),%ymm0,%ymm5
  10c10a:	vpaddq %ymm2,%ymm5,%ymm2
  10c10e:	vpblendd $0x55,0x288(%rsp),%ymm0,%ymm5
  10c119:	vpaddq %ymm3,%ymm5,%ymm3
  10c11d:	vpblendd $0x55,0x2a8(%rsp),%ymm0,%ymm5
  10c128:	vpblendd $0x55,0x2c8(%rsp),%ymm0,%ymm6
  10c133:	vpblendd $0x55,0x2e8(%rsp),%ymm0,%ymm7
  10c13e:	vpblendd $0x55,0x308(%rsp),%ymm0,%ymm8
  10c149:	vpblendd $0x55,0x328(%rsp),%ymm0,%ymm9
  10c154:	vpblendd $0x55,0x348(%rsp),%ymm0,%ymm10
  10c15f:	vpaddq %ymm4,%ymm5,%ymm4
  10c163:	vpaddq %ymm6,%ymm10,%ymm5
  10c167:	vpblendd $0x55,0x368(%rsp),%ymm0,%ymm6
  10c172:	vpaddq %ymm1,%ymm5,%ymm1
  10c176:	vpaddq %ymm7,%ymm6,%ymm5
  10c17a:	vpblendd $0x55,0x388(%rsp),%ymm0,%ymm6
  10c185:	vpaddq %ymm2,%ymm5,%ymm2
  10c189:	vpaddq %ymm6,%ymm8,%ymm5
  10c18d:	vpblendd $0x55,0x3a8(%rsp),%ymm0,%ymm6
  10c198:	vpaddq %ymm3,%ymm5,%ymm3
  10c19c:	vpaddq %ymm6,%ymm9,%ymm5
  10c1a0:	vpblendd $0x55,0x3c8(%rsp),%ymm0,%ymm6
  10c1ab:	vpblendd $0x55,0x3e8(%rsp),%ymm0,%ymm7
  10c1b6:	vpblendd $0x55,0x408(%rsp),%ymm0,%ymm8
  10c1c1:	vpblendd $0x55,0x428(%rsp),%ymm0,%ymm9
  10c1cc:	vpblendd $0x55,0x448(%rsp),%ymm0,%ymm10
  10c1d7:	vpaddq %ymm4,%ymm5,%ymm4
  10c1db:	vpaddq %ymm6,%ymm10,%ymm5
  10c1df:	vpblendd $0x55,0x468(%rsp),%ymm0,%ymm6
  10c1ea:	vpaddq %ymm7,%ymm6,%ymm6
  10c1ee:	vpblendd $0x55,0x488(%rsp),%ymm0,%ymm7
  10c1f9:	vpaddq %ymm7,%ymm8,%ymm7
  10c1fd:	vpblendd $0x55,0x4a8(%rsp),%ymm0,%ymm8
  10c208:	vpblendd $0x55,0x4c8(%rsp),%ymm0,%ymm10
  10c213:	vpaddq %ymm9,%ymm8,%ymm8
  10c218:	vpaddq %ymm5,%ymm10,%ymm5
  10c21c:	vpblendd $0x55,0x4e8(%rsp),%ymm0,%ymm9
  10c227:	vpaddq %ymm1,%ymm5,%ymm1
  10c22b:	vpaddq %ymm6,%ymm9,%ymm5
  10c22f:	vpblendd $0x55,0x508(%rsp),%ymm0,%ymm6
  10c23a:	vpaddq %ymm2,%ymm5,%ymm2
  10c23e:	vpaddq %ymm7,%ymm6,%ymm5
  10c242:	vpblendd $0x55,0x528(%rsp),%ymm0,%ymm6
  10c24d:	vpaddq %ymm3,%ymm5,%ymm3
  10c251:	vpaddq %ymm6,%ymm8,%ymm5
  10c255:	vpblendd $0x55,0x548(%rsp),%ymm0,%ymm6
  10c260:	vpblendd $0x55,0x568(%rsp),%ymm0,%ymm7
  10c26b:	vpblendd $0x55,0x588(%rsp),%ymm0,%ymm8
  10c276:	vpblendd $0x55,0x5a8(%rsp),%ymm0,%ymm9
  10c281:	vpblendd $0x55,0x5c8(%rsp),%ymm0,%ymm10
  10c28c:	vpaddq %ymm4,%ymm5,%ymm4
  10c290:	vpaddq %ymm6,%ymm10,%ymm5
  10c294:	vpblendd $0x55,0x5e8(%rsp),%ymm0,%ymm6
  10c29f:	vpaddq %ymm7,%ymm6,%ymm6
  10c2a3:	vpblendd $0x55,0x608(%rsp),%ymm0,%ymm7
  10c2ae:	vpaddq %ymm7,%ymm8,%ymm7
  10c2b2:	vpblendd $0x55,0x628(%rsp),%ymm0,%ymm8
  10c2bd:	vpblendd $0x55,0x648(%rsp),%ymm0,%ymm10
  10c2c8:	vpaddq %ymm9,%ymm8,%ymm8
  10c2cd:	vpaddq %ymm5,%ymm10,%ymm5
  10c2d1:	vpblendd $0x55,0x668(%rsp),%ymm0,%ymm9
  10c2dc:	vpaddq %ymm6,%ymm9,%ymm6
  10c2e0:	vpblendd $0x55,0x688(%rsp),%ymm0,%ymm9
  10c2eb:	vpaddq %ymm7,%ymm9,%ymm7
  10c2ef:	vpblendd $0x55,0x6a8(%rsp),%ymm0,%ymm9
  10c2fa:	vpblendd $0x55,0x6c8(%rsp),%ymm0,%ymm10
  10c305:	vpaddq %ymm8,%ymm9,%ymm8
  10c30a:	vpaddq %ymm5,%ymm10,%ymm5
  10c30e:	vpblendd $0x55,0x6e8(%rsp),%ymm0,%ymm9
  10c319:	vpaddq %ymm1,%ymm5,%ymm1
  10c31d:	vpaddq %ymm6,%ymm9,%ymm5
  10c321:	vpblendd $0x55,0x708(%rsp),%ymm0,%ymm6
  10c32c:	vpaddq %ymm2,%ymm5,%ymm2
  10c330:	vpaddq %ymm7,%ymm6,%ymm5
  10c334:	vpblendd $0x55,0x728(%rsp),%ymm0,%ymm6
  10c33f:	vpaddq %ymm3,%ymm5,%ymm3
  10c343:	vpaddq %ymm6,%ymm8,%ymm5
  10c347:	vpblendd $0x55,0x748(%rsp),%ymm0,%ymm6
  10c352:	vpblendd $0x55,0x768(%rsp),%ymm0,%ymm7
  10c35d:	vpblendd $0x55,0x788(%rsp),%ymm0,%ymm8
  10c368:	vpblendd $0x55,0x7a8(%rsp),%ymm0,%ymm9
  10c373:	vpblendd $0x55,0x7c8(%rsp),%ymm0,%ymm10
  10c37e:	vpaddq %ymm4,%ymm5,%ymm4
  10c382:	vpaddq %ymm6,%ymm10,%ymm5
  10c386:	vpblendd $0x55,0x7e8(%rsp),%ymm0,%ymm6
  10c391:	vpaddq %ymm7,%ymm6,%ymm6
  10c395:	vpblendd $0x55,0x808(%rsp),%ymm0,%ymm7
  10c3a0:	vpaddq %ymm7,%ymm8,%ymm7
  10c3a4:	vpblendd $0x55,0x828(%rsp),%ymm0,%ymm8
  10c3af:	vpblendd $0x55,0x848(%rsp),%ymm0,%ymm10
  10c3ba:	vpaddq %ymm9,%ymm8,%ymm8
  10c3bf:	vpaddq %ymm5,%ymm10,%ymm5
  10c3c3:	vpblendd $0x55,0x868(%rsp),%ymm0,%ymm9
  10c3ce:	vpaddq %ymm6,%ymm9,%ymm6
  10c3d2:	vpblendd $0x55,0x888(%rsp),%ymm0,%ymm9
  10c3dd:	vpaddq %ymm7,%ymm9,%ymm7
  10c3e1:	vpblendd $0x55,0x8a8(%rsp),%ymm0,%ymm9
  10c3ec:	vpblendd $0x55,0x8c8(%rsp),%ymm0,%ymm10
  10c3f7:	vpaddq %ymm8,%ymm9,%ymm8
  10c3fc:	vpaddq %ymm5,%ymm10,%ymm5
  10c400:	vpblendd $0x55,0x8e8(%rsp),%ymm0,%ymm9
  10c40b:	vpaddq %ymm6,%ymm9,%ymm6
  10c40f:	vpblendd $0x55,0x908(%rsp),%ymm0,%ymm9
  10c41a:	vpaddq %ymm7,%ymm9,%ymm7
  10c41e:	vpblendd $0x55,0x928(%rsp),%ymm0,%ymm9
  10c429:	vpblendd $0x55,0x948(%rsp),%ymm0,%ymm10
  10c434:	vpaddq %ymm8,%ymm9,%ymm8
  10c439:	vpaddq %ymm5,%ymm10,%ymm5
  10c43d:	vpblendd $0x55,0x968(%rsp),%ymm0,%ymm9
  10c448:	vpaddq %ymm1,%ymm5,%ymm1
  10c44c:	vpaddq %ymm6,%ymm9,%ymm5
  10c450:	vpaddq %ymm2,%ymm5,%ymm2
  10c454:	vpaddq %ymm1,%ymm2,%ymm1
  10c458:	vpblendd $0x55,0x988(%rsp),%ymm0,%ymm2
  10c463:	vpaddq %ymm7,%ymm2,%ymm2
  10c467:	vpaddq %ymm3,%ymm2,%ymm2
  10c46b:	vpaddq %ymm1,%ymm2,%ymm1
  10c46f:	vpblendd $0x55,0x9a8(%rsp),%ymm0,%ymm0
  10c47a:	vpaddq %ymm0,%ymm8,%ymm0
  10c47e:	vpaddq %ymm4,%ymm0,%ymm0
  10c482:	vpaddq %ymm1,%ymm0,%ymm0
  10c486:	vextracti128 $0x1,%ymm0,%xmm1
  10c48c:	vpaddq %xmm1,%xmm0,%xmm0
  10c490:	vpshufd $0xee,%xmm0,%xmm1
  10c495:	vpaddq %xmm1,%xmm0,%xmm0
  10c499:	vmovq  %xmm0,%rdx
  10c49e:	cmp    %rax,%rdx
  10c4a1:	ja     10bfa6 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x436>
  10c4a7:	sub    %r10,%rdi
  10c4aa:	sar    $1,%rdi
  10c4ad:	mov    %rdi,0x10(%rcx)
  10c4b1:	xor    %eax,%eax
  10c4b3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  10c4c0:	vmovups 0x1c8(%rsp,%rax,8),%xmm0
  10c4c9:	vmovups 0x1d8(%rsp,%rax,8),%xmm1
  10c4d2:	vmovups 0x1e8(%rsp,%rax,8),%xmm2
  10c4db:	vmovups 0x1f8(%rsp,%rax,8),%xmm3
  10c4e4:	vshufps $0x88,%xmm1,%xmm0,%xmm4
  10c4e9:	vshufps $0x88,%xmm3,%xmm2,%xmm5
  10c4ee:	vmovups 0x218(%rsp,%rax,8),%xmm6
  10c4f7:	vmovups 0x208(%rsp,%rax,8),%xmm7
  10c500:	vshufps $0x88,%xmm6,%xmm7,%xmm8
  10c505:	vmovups 0x238(%rsp,%rax,8),%xmm9
  10c50e:	vmovups 0x228(%rsp,%rax,8),%xmm10
  10c517:	vshufps $0x88,%xmm9,%xmm10,%xmm11
  10c51d:	vmovups %xmm4,0x48(%rcx,%rax,4)
  10c523:	vmovups %xmm5,0x58(%rcx,%rax,4)
  10c529:	vmovups %xmm8,0x68(%rcx,%rax,4)
  10c52f:	vmovups %xmm11,0x78(%rcx,%rax,4)
  10c535:	vshufps $0xdd,%xmm1,%xmm0,%xmm0
  10c53a:	vshufps $0xdd,%xmm3,%xmm2,%xmm1
  10c53f:	vshufps $0xdd,%xmm6,%xmm7,%xmm2
  10c544:	vshufps $0xdd,%xmm9,%xmm10,%xmm3
  10c54a:	vmovups %xmm0,0x448(%rcx,%rax,4)
  10c553:	vmovups %xmm1,0x458(%rcx,%rax,4)
  10c55c:	vmovups %xmm2,0x468(%rcx,%rax,4)
  10c565:	vmovups %xmm3,0x478(%rcx,%rax,4)
  10c56e:	add    $0x10,%rax
  10c572:	cmp    $0x100,%rax
  10c578:	jne    10c4c0 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x950>
  10c57e:	cmp    $0x1000000,%rdx
  10c585:	setb   0x850(%rcx)
  10c58c:	mov    %rdx,0xb8(%rsp)
  10c594:	mov    %rdx,0x848(%rcx)
  10c59b:	mov    $0x1,%eax
  10c5a0:	jmp    10bfa8 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x438>
  10c5a5:	mov    0x48(%rsp),%rax
  10c5aa:	mov    (%rax,%r14,8),%rbx
  10c5ae:	shr    $1,%rbx
  10c5b1:	mov    %r14,%r10
  10c5b4:	shl    $0x7,%r10
  10c5b8:	add    %r15,%r10
  10c5bb:	vmovdqa -0xc1da3(%rip),%ymm0        # 4a820 <.LCPI656_0>
  10c5c3:	vmovdqa -0xc1ecb(%rip),%ymm3        # 4a700 <.LCPI732_4>
  10c5cb:	vmovdqa -0xc1e93(%rip),%ymm4        # 4a740 <.LCPI732_5>
  10c5d3:	vmovdqa -0xc1f5b(%rip),%ymm5        # 4a680 <.LCPI732_6>
  10c5db:	vmovdqa -0xc1e23(%rip),%ymm6        # 4a7c0 <.LCPI732_7>
  10c5e3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  10c5f0:	mov    0x80(%rsp),%rsi
  10c5f8:	nopl   0x0(%rax,%rax,1)
  10c600:	movzwl (%r10,%r13,2),%ecx
  10c605:	cmp    $0x21,%rcx
  10c609:	jae    10c6a0 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xb30>
  10c60f:	shl    $0x6,%ecx
  10c612:	lea    -0xd1799(%rip),%rax        # 3ae80 <_RNvNtCslqP6imz8QVM_5mibz24runs5STEPS>
  10c619:	vpshufb -0x40(%rcx,%rax,1),%xmm2,%xmm7
  10c620:	vpshufb -0x30(%rcx,%rax,1),%xmm10,%xmm8
  10c627:	vpshufb -0x10(%rcx,%rax,1),%xmm2,%xmm9
  10c62e:	vpor   %xmm7,%xmm8,%xmm2
  10c632:	vpshufb -0x20(%rcx,%rax,1),%xmm10,%xmm8
  10c639:	vpor   %xmm8,%xmm9,%xmm10
  10c63e:	vmovd  %xmm2,%eax
  10c642:	movzbl %al,%r8d
  10c646:	test   %r9,%r9
  10c649:	je     10c878 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xd08>
  10c64f:	tzcnt  %r9,%r11
  10c654:	blsr   %r9,%r9
  10c659:	bzhi   %r11,%rbx,%rcx
  10c65e:	shrx   %r13,%rcx,%rcx
  10c663:	cmp    $0x7f,%rcx
  10c667:	ja     10ca00 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xe90>
  10c66d:	mov    %cl,(%rdi)
  10c66f:	mov    %al,0x1(%rdi)
  10c672:	add    $0x2,%rdi
  10c676:	movabs $0x100000000,%rax
  10c680:	or     %rax,%rcx
  10c683:	add    %rcx,0x1c8(%rsp,%r8,8)
  10c68b:	mov    %r11,%r13
  10c68e:	jmp    10c600 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xa90>
  10c693:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  10c6a0:	mov    %ecx,%edx
  10c6a2:	dec    %rcx
  10c6a5:	cmp    $0xff,%rcx
  10c6ac:	mov    $0xff,%eax
  10c6b1:	cmovae %rax,%rcx
  10c6b5:	movzbl 0xa0(%rsp,%rcx,1),%eax
  10c6bd:	add    $0xffffffffffffffe0,%rcx
  10c6c1:	vinserti128 $0x1,%xmm10,%ymm10,%ymm7
  10c6c7:	cmp    $0x40,%dx
  10c6cb:	ja     10c700 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xb90>
  10c6cd:	vmovdqa 0xc0(%rsp),%ymm8
  10c6d6:	inc    %cl
  10c6d8:	vmovd  %ecx,%xmm9
  10c6dc:	vpbroadcastb %xmm9,%ymm9
  10c6e1:	vpcmpgtb %ymm0,%ymm9,%ymm9
  10c6e5:	vperm2i128 $0x21,%ymm8,%ymm7,%ymm7
  10c6eb:	vpalignr $0xf,%ymm7,%ymm8,%ymm7
  10c6f1:	vpblendvb %ymm9,%ymm7,%ymm8,%ymm7
  10c6f7:	jmp    10c84b <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xcdb>
  10c6fc:	nopl   0x0(%rax)
  10c700:	vmovd  %ecx,%xmm8
  10c704:	vpbroadcastb %xmm8,%ymm8
  10c709:	vmovdqa %ymm10,%ymm1
  10c70d:	vmovdqa 0xc0(%rsp),%ymm10
  10c716:	vmovdqa 0xe0(%rsp),%ymm11
  10c71f:	vmovdqa 0x100(%rsp),%ymm12
  10c728:	vmovdqa 0x120(%rsp),%ymm13
  10c731:	vmovdqa 0x140(%rsp),%ymm9
  10c73a:	vpmaxub %ymm0,%ymm8,%ymm14
  10c73e:	vpcmpeqb %ymm14,%ymm8,%ymm14
  10c743:	vperm2i128 $0x21,%ymm10,%ymm7,%ymm7
  10c749:	vpalignr $0xf,%ymm7,%ymm10,%ymm7
  10c74f:	vpblendvb %ymm14,%ymm7,%ymm10,%ymm7
  10c755:	vpminub -0xc1f1d(%rip),%ymm8,%ymm14        # 4a840 <.LCPI732_2>
  10c75d:	vpcmpeqb %ymm14,%ymm8,%ymm14
  10c762:	vperm2i128 $0x21,%ymm11,%ymm10,%ymm10
  10c768:	vpalignr $0xf,%ymm10,%ymm11,%ymm10
  10c76e:	vpblendvb %ymm14,%ymm11,%ymm10,%ymm10
  10c774:	vpminub -0xc1f7c(%rip),%ymm8,%ymm14        # 4a800 <.LCPI732_3>
  10c77c:	vpcmpeqb %ymm14,%ymm8,%ymm14
  10c781:	vperm2i128 $0x21,%ymm12,%ymm11,%ymm11
  10c787:	vpalignr $0xf,%ymm11,%ymm12,%ymm11
  10c78d:	vpblendvb %ymm14,%ymm12,%ymm11,%ymm11
  10c793:	vpminub %ymm3,%ymm8,%ymm14
  10c797:	vpcmpeqb %ymm14,%ymm8,%ymm14
  10c79c:	vperm2i128 $0x21,%ymm13,%ymm12,%ymm12
  10c7a2:	vpalignr $0xf,%ymm12,%ymm13,%ymm12
  10c7a8:	vpblendvb %ymm14,%ymm13,%ymm12,%ymm12
  10c7ae:	vpminub %ymm4,%ymm8,%ymm14
  10c7b2:	vpcmpeqb %ymm14,%ymm8,%ymm14
  10c7b7:	vperm2i128 $0x21,%ymm9,%ymm13,%ymm13
  10c7bd:	vpalignr $0xf,%ymm13,%ymm9,%ymm13
  10c7c3:	vpblendvb %ymm14,%ymm9,%ymm13,%ymm13
  10c7c9:	vmovdqa 0x160(%rsp),%ymm14
  10c7d2:	vpminub %ymm5,%ymm8,%ymm15
  10c7d6:	vpcmpeqb %ymm15,%ymm8,%ymm15
  10c7db:	vperm2i128 $0x21,%ymm14,%ymm9,%ymm9
  10c7e1:	vpalignr $0xf,%ymm9,%ymm14,%ymm9
  10c7e7:	vpblendvb %ymm15,%ymm14,%ymm9,%ymm9
  10c7ed:	vpminub %ymm6,%ymm8,%ymm15
  10c7f1:	vpcmpeqb %ymm15,%ymm8,%ymm8
  10c7f6:	vmovdqa 0x180(%rsp),%ymm15
  10c7ff:	vperm2i128 $0x21,%ymm15,%ymm14,%ymm14
  10c805:	vpalignr $0xf,%ymm14,%ymm15,%ymm14
  10c80b:	vpblendvb %ymm8,%ymm15,%ymm14,%ymm8
  10c811:	vmovdqa %ymm10,0xe0(%rsp)
  10c81a:	vmovdqa %ymm1,%ymm10
  10c81e:	vmovdqa %ymm11,0x100(%rsp)
  10c827:	vmovdqa %ymm12,0x120(%rsp)
  10c830:	vmovdqa %ymm13,0x140(%rsp)
  10c839:	vmovdqa %ymm9,0x160(%rsp)
  10c842:	vmovdqa %ymm8,0x180(%rsp)
  10c84b:	vmovdqa %ymm7,0xc0(%rsp)
  10c854:	vpalignr $0xf,%xmm2,%xmm10,%xmm10
  10c85a:	vpslldq $0x1,%xmm2,%xmm7
  10c85f:	vmovd  %eax,%xmm8
  10c863:	vpor   %xmm7,%xmm8,%xmm2
  10c867:	vmovd  %xmm2,%eax
  10c86b:	movzbl %al,%r8d
  10c86f:	test   %r9,%r9
  10c872:	jne    10c64f <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xadf>
  10c878:	mov    %r14,%rcx
  10c87b:	shl    $0x6,%rcx
  10c87f:	add    %r13,%rcx
  10c882:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  10c890:	mov    %r14,%r10
  10c893:	cmp    %r14,%rsi
  10c896:	je     10c8c1 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xd51>
  10c898:	lea    0x1(%r10),%r14
  10c89c:	mov    0x50(%rsp),%rdx
  10c8a1:	mov    0x8(%rdx,%r10,8),%rdx
  10c8a6:	test   %rdx,%rdx
  10c8a9:	je     10c890 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xd20>
  10c8ab:	tzcnt  %rdx,%r13
  10c8b0:	blsr   %rdx,%r9
  10c8b5:	mov    %r14,%rdx
  10c8b8:	shl    $0x6,%rdx
  10c8bc:	or     %r13,%rdx
  10c8bf:	jmp    10c8ca <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xd5a>
  10c8c1:	mov    %rsi,%r14
  10c8c4:	mov    %r12,%rdx
  10c8c7:	xor    %r9d,%r9d
  10c8ca:	sub    %rcx,%rdx
  10c8cd:	cmp    $0x16,%rdx
  10c8d1:	ja     10cac5 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xf55>
  10c8d7:	inc    %rcx
  10c8da:	mov    %rcx,%rsi
  10c8dd:	shr    $0x3,%rsi
  10c8e1:	and    $0x7,%cl
  10c8e4:	mov    0x48(%rsp),%r11
  10c8e9:	shrx   %rcx,(%r11,%rsi,1),%rcx
  10c8ef:	bzhi   %rdx,%rcx,%rcx
  10c8f4:	cmp    $0x7f,%rcx
  10c8f8:	jbe    10c9af <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xe3f>
  10c8fe:	mov    %rcx,%rdx
  10c901:	movabs $0x204081020408103,%rax
  10c90b:	mulx   %rax,%rax,%rax
  10c910:	mov    %rcx,%r11
  10c913:	sub    %rax,%r11
  10c916:	shr    $1,%r11
  10c919:	add    %rax,%r11
  10c91c:	shr    $0x6,%r11
  10c920:	mov    %rcx,%rax
  10c923:	movabs $0x7efdfbf7efdfbf7f,%rdx
  10c92d:	imul   %rdx,%rax
  10c931:	xor    %esi,%esi
  10c933:	movabs $0x204081020408102,%rdx
  10c93d:	cmp    %rdx,%rax
  10c940:	seta   %sil
  10c944:	lea    (%r11,%rsi,1),%rax
  10c948:	dec    %rax
  10c94b:	sub    %rax,0x60(%rsp)
  10c950:	mov    0x58(%rsp),%rdx
  10c955:	jb     10cac5 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xf55>
  10c95b:	mov    0x38(%rsp),%rbx
  10c960:	add    %rcx,%rbx
  10c963:	mov    $0x0,%eax
  10c968:	mov    %rbx,0x38(%rsp)
  10c96d:	cmp    %rdx,%rbx
  10c970:	ja     10bfa8 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x438>
  10c976:	add    %rsi,%r11
  10c979:	shl    $0x20,%r11
  10c97d:	or     %rcx,%r11
  10c980:	add    %r11,0x1c8(%rsp,%r8,8)
  10c988:	shl    $0x8,%r8d
  10c98c:	nopl   0x0(%rax)
  10c990:	cmp    $0x7f,%rcx
  10c994:	mov    $0x7f,%eax
  10c999:	cmovb  %rcx,%rax
  10c99d:	lea    (%rax,%r8,1),%edx
  10c9a1:	mov    %dx,(%rdi)
  10c9a4:	add    $0x2,%rdi
  10c9a8:	sub    %rax,%rcx
  10c9ab:	jne    10c990 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xe20>
  10c9ad:	jmp    10c9cd <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xe5d>
  10c9af:	mov    %cl,(%rdi)
  10c9b1:	mov    %al,0x1(%rdi)
  10c9b4:	add    $0x2,%rdi
  10c9b8:	movabs $0x100000000,%rax
  10c9c2:	or     %rax,%rcx
  10c9c5:	add    %rcx,0x1c8(%rsp,%r8,8)
  10c9cd:	mov    0x80(%rsp),%rsi
  10c9d5:	cmp    %r10,%rsi
  10c9d8:	je     10cacc <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xf5c>
  10c9de:	mov    0x48(%rsp),%rax
  10c9e3:	mov    (%rax,%r14,8),%rbx
  10c9e7:	shr    $1,%rbx
  10c9ea:	mov    %r14,%r10
  10c9ed:	shl    $0x7,%r10
  10c9f1:	add    %r15,%r10
  10c9f4:	jmp    10c600 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xa90>
  10c9f9:	nopl   0x0(%rax)
  10ca00:	mov    %r11,%rax
  10ca03:	sub    %r13,%rax
  10ca06:	cmp    $0x16,%rax
  10ca0a:	ja     10cac5 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xf55>
  10ca10:	mov    %rcx,%rdx
  10ca13:	movabs $0x204081020408103,%rax
  10ca1d:	mulx   %rax,%rax,%rax
  10ca22:	mov    %rcx,%r13
  10ca25:	sub    %rax,%r13
  10ca28:	shr    $1,%r13
  10ca2b:	add    %rax,%r13
  10ca2e:	shr    $0x6,%r13
  10ca32:	mov    %rcx,%rax
  10ca35:	movabs $0x7efdfbf7efdfbf7f,%rdx
  10ca3f:	imul   %rdx,%rax
  10ca43:	xor    %esi,%esi
  10ca45:	movabs $0x204081020408102,%rdx
  10ca4f:	cmp    %rdx,%rax
  10ca52:	seta   %sil
  10ca56:	lea    (%rsi,%r13,1),%rax
  10ca5a:	dec    %rax
  10ca5d:	sub    %rax,0x60(%rsp)
  10ca62:	jb     10cac5 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xf55>
  10ca64:	mov    0x38(%rsp),%rdx
  10ca69:	add    %rcx,%rdx
  10ca6c:	mov    $0x0,%eax
  10ca71:	mov    %rdx,0x38(%rsp)
  10ca76:	cmp    0x58(%rsp),%rdx
  10ca7b:	ja     10bfa8 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x438>
  10ca81:	add    %rsi,%r13
  10ca84:	shl    $0x20,%r13
  10ca88:	or     %rcx,%r13
  10ca8b:	add    %r13,0x1c8(%rsp,%r8,8)
  10ca93:	shl    $0x8,%r8d
  10ca97:	nopw   0x0(%rax,%rax,1)
  10caa0:	cmp    $0x7f,%rcx
  10caa4:	mov    $0x7f,%eax
  10caa9:	cmovb  %rcx,%rax
  10caad:	lea    (%rax,%r8,1),%edx
  10cab1:	mov    %dx,(%rdi)
  10cab4:	add    $0x2,%rdi
  10cab8:	sub    %rax,%rcx
  10cabb:	jne    10caa0 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xf30>
  10cabd:	mov    %r11,%r13
  10cac0:	jmp    10c5f0 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xa80>
  10cac5:	xor    %eax,%eax
  10cac7:	jmp    10bfa8 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x438>
  10cacc:	mov    0x40(%rsp),%rcx
  10cad1:	mov    0x58(%rsp),%rax
  10cad6:	mov    0x78(%rsp),%r10
  10cadb:	jmp    10c0c0 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x550>
  10cae0:	lea    0x18(%r10),%rdi
  10cae4:	mov    $0x8,%ecx
  10cae9:	mov    $0x8,%r8d
  10caef:	xor    %esi,%esi
  10caf1:	lea    0x3(%rbx),%rdx
  10caf5:	call   f66c0 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECslqP6imz8QVM_5mibz2>
  10cafa:	lea    0x3(%rbx),%rax
  10cafe:	mov    0x40(%rsp),%r10
  10cb03:	movq   $0x0,0x40(%r10)
  10cb0b:	cmp    0x30(%r10),%rax
  10cb0f:	jbe    10bc0a <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x9a>
  10cb15:	lea    0x30(%r10),%rdi
  10cb19:	mov    $0x8,%ecx
  10cb1e:	mov    $0x8,%r8d
  10cb24:	xor    %esi,%esi
  10cb26:	lea    0x3(%rbx),%rdx
  10cb2a:	call   f66c0 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECslqP6imz8QVM_5mibz2>
  10cb2f:	mov    0x40(%rsp),%r10
  10cb34:	jmp    10bc0a <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x9a>
  10cb39:	mov    $0x2,%ecx
  10cb3e:	mov    $0x2,%r8d
  10cb44:	mov    %r10,%rdi
  10cb47:	xor    %esi,%esi
  10cb49:	vzeroupper
  10cb4c:	call   f66c0 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECslqP6imz8QVM_5mibz2>
  10cb51:	mov    0x40(%rsp),%r10
  10cb56:	mov    0x20(%r10),%rax
  10cb5a:	mov    %rax,0x50(%rsp)
  10cb5f:	mov    0x38(%r10),%rax
  10cb63:	mov    %rax,0x48(%rsp)
  10cb68:	jmp    10bf0e <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x39e>
  10cb6d:	lea    0xd8d0c(%rip),%rcx        # 1e5880 <_TLS_MODULE_BASE_+0x3bc8>
  10cb74:	mov    %r12,%rdi
  10cb77:	mov    %rsi,%rdx
  10cb7a:	vzeroupper
  10cb7d:	call   e9750 <_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail>
