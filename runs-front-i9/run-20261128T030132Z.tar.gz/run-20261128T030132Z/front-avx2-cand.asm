/home/louis/dev/mibz2/target/runs-front-i9/runs-front-i9-v26p_be9/cand-ab:     file format elf64-x86-64


Disassembly of section .fini:

Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000010bb00 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2>:
  10bb00:	push   %rbp
  10bb01:	mov    %rsp,%rbp
  10bb04:	push   %r15
  10bb06:	push   %r14
  10bb08:	push   %r13
  10bb0a:	push   %r12
  10bb0c:	push   %rbx
  10bb0d:	and    $0xffffffffffffffc0,%rsp
  10bb11:	sub    $0x5c0,%rsp
  10bb18:	movb   $0x0,0x450(%rcx)
  10bb1f:	mov    0x118(%rdi),%rax
  10bb26:	mov    %rax,0x38(%rsp)
  10bb2b:	cmp    $0x7fffffff,%rax
  10bb31:	seta   %al
  10bb34:	movq   $0x0,0x448(%rcx)
  10bb3f:	mov    %rdx,0x18(%rsp)
  10bb44:	cmp    $0x1000000,%rdx
  10bb4b:	setae  %r8b
  10bb4f:	or     %al,%r8b
  10bb52:	jne    10bf26 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x426>
  10bb58:	mov    0x18(%rsp),%rbx
  10bb5d:	shr    $0x6,%rbx
  10bb61:	lea    0x3(%rbx),%r14
  10bb65:	movq   $0x0,0x28(%rcx)
  10bb6d:	cmp    0x18(%rcx),%r14
  10bb71:	ja     10c982 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xe82>
  10bb77:	movq   $0x0,0x40(%rcx)
  10bb7f:	cmp    0x30(%rcx),%r14
  10bb83:	ja     10c9c6 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xec6>
  10bb89:	mov    0x20(%rcx),%r15
  10bb8d:	mov    0x38(%rcx),%rax
  10bb91:	movzwl 0x128(%rdi),%edx
  10bb98:	test   %rbx,%rbx
  10bb9b:	mov    %rax,0x20(%rsp)
  10bba0:	je     10bd2e <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x22e>
  10bba6:	vmovd  %edx,%xmm0
  10bbaa:	vpbroadcastw %xmm0,%ymm0
  10bbaf:	xor    %r13d,%r13d
  10bbb2:	vpbroadcastw -0xda43f(%rip),%ymm1        # 3177c <GCC_except_table1575+0x680>
  10bbbb:	vpxor  %xmm2,%xmm2,%xmm2
  10bbbf:	xor    %r8d,%r8d
  10bbc2:	jmp    10bbfc <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xfc>
  10bbc4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  10bbd0:	shl    $0x20,%r14
  10bbd4:	or     %r14,%r10
  10bbd7:	not    %r10
  10bbda:	shl    $0x20,%r11
  10bbde:	or     %r11,%r9
  10bbe1:	not    %r9
  10bbe4:	mov    %r9,(%r15,%r8,8)
  10bbe8:	mov    %r10,(%rax,%r8,8)
  10bbec:	inc    %r8
  10bbef:	add    $0x40,%r13
  10bbf3:	cmp    %r8,%rbx
  10bbf6:	je     10bd2e <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x22e>
  10bbfc:	vmovdqu (%rsi,%r13,2),%ymm3
  10bc02:	vmovdqu 0x20(%rsi,%r13,2),%ymm4
  10bc09:	vmovdqu 0x40(%rsi,%r13,2),%ymm5
  10bc10:	vmovdqu 0x60(%rsi,%r13,2),%ymm6
  10bc17:	vpminuw %ymm1,%ymm3,%ymm7
  10bc1c:	vpcmpeqw %ymm7,%ymm3,%ymm7
  10bc20:	vpminuw %ymm1,%ymm4,%ymm8
  10bc25:	vpcmpeqw %ymm4,%ymm8,%ymm8
  10bc29:	vpacksswb %ymm8,%ymm7,%ymm7
  10bc2e:	vpminuw %ymm1,%ymm5,%ymm8
  10bc33:	vpcmpeqw %ymm5,%ymm8,%ymm8
  10bc37:	vpminuw %ymm1,%ymm6,%ymm9
  10bc3c:	vpcmpeqw %ymm6,%ymm9,%ymm9
  10bc40:	vpacksswb %ymm9,%ymm8,%ymm8
  10bc45:	vpcmpeqw %ymm2,%ymm3,%ymm9
  10bc49:	vpcmpeqw %ymm2,%ymm4,%ymm10
  10bc4d:	vpacksswb %ymm10,%ymm9,%ymm9
  10bc52:	vpcmpeqw %ymm2,%ymm5,%ymm10
  10bc56:	vpcmpeqw %ymm2,%ymm6,%ymm11
  10bc5a:	vpacksswb %ymm11,%ymm10,%ymm10
  10bc5f:	vpcmpeqw %ymm0,%ymm3,%ymm3
  10bc63:	vpcmpeqw %ymm0,%ymm4,%ymm4
  10bc67:	vpcmpeqw %ymm0,%ymm5,%ymm5
  10bc6b:	vpcmpeqw %ymm0,%ymm6,%ymm6
  10bc6f:	vpor   %ymm3,%ymm4,%ymm11
  10bc73:	vpor   %ymm6,%ymm5,%ymm12
  10bc77:	vpor   %ymm12,%ymm11,%ymm11
  10bc7c:	vpermq $0xd8,%ymm8,%ymm8
  10bc82:	vpermq $0xd8,%ymm7,%ymm7
  10bc88:	vpermq $0xd8,%ymm10,%ymm10
  10bc8e:	vpermq $0xd8,%ymm9,%ymm9
  10bc94:	vptest %ymm11,%ymm11
  10bc99:	vpmovmskb %ymm10,%r14d
  10bc9e:	vpmovmskb %ymm9,%r10d
  10bca3:	vpmovmskb %ymm8,%r11d
  10bca8:	vpmovmskb %ymm7,%r9d
  10bcac:	je     10bbd0 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xd0>
  10bcb2:	vpacksswb %ymm4,%ymm3,%ymm3
  10bcb6:	vpacksswb %ymm6,%ymm5,%ymm4
  10bcba:	vpermq $0xd8,%ymm3,%ymm3
  10bcc0:	vpermq $0xd8,%ymm4,%ymm4
  10bcc6:	vpandn %ymm4,%ymm8,%ymm4
  10bcca:	vpandn %ymm3,%ymm7,%ymm3
  10bcce:	vpmovmskb %ymm3,%eax
  10bcd2:	vpmovmskb %ymm4,%r12d
  10bcd6:	shl    $0x20,%r12
  10bcda:	or     %rax,%r12
  10bcdd:	mov    0x20(%rsp),%rax
  10bce2:	je     10bbd0 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xd0>
  10bce8:	shl    $0x20,%r11
  10bcec:	or     %r11,%r9
  10bcef:	shl    $0x20,%r14
  10bcf3:	or     %r14,%r10
  10bcf6:	tzcnt  %r12,%rax
  10bcfb:	or     %rax,%r13
  10bcfe:	mov    $0x2,%edx
  10bd03:	shlx   %rax,%rdx,%rdx
  10bd08:	dec    %rdx
  10bd0b:	cmp    $0x3f,%rax
  10bd0f:	mov    $0xffffffffffffffff,%rax
  10bd16:	cmovne %rdx,%rax
  10bd1a:	andn   %rax,%r10,%r10
  10bd1f:	shr    $1,%rax
  10bd22:	andn   %rax,%r9,%r9
  10bd27:	mov    $0x1,%al
  10bd29:	jmp    10bdc8 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x2c8>
  10bd2e:	mov    0x18(%rsp),%rax
  10bd33:	mov    %eax,%r8d
  10bd36:	and    $0xffffc0,%r8d
  10bd3d:	cmp    %rax,%r8
  10bd40:	jne    10bd53 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x253>
  10bd42:	xor    %eax,%eax
  10bd44:	mov    0x18(%rsp),%r13
  10bd49:	mov    0x20(%rsp),%rdx
  10bd4e:	jmp    10bddb <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x2db>
  10bd53:	mov    0x18(%rsp),%r11
  10bd58:	and    $0x3f,%r11d
  10bd5c:	cmp    $0x1,%r11
  10bd60:	adc    $0x0,%r11
  10bd64:	lea    (%rsi,%r8,2),%r14
  10bd68:	xor    %r9d,%r9d
  10bd6b:	xor    %r10d,%r10d
  10bd6e:	xor    %r13d,%r13d
  10bd71:	jmp    10bd8c <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x28c>
  10bd73:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  10bd80:	bts    %r13,%r9
  10bd84:	inc    %r13
  10bd87:	cmp    %r13,%r11
  10bd8a:	je     10bdbe <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x2be>
  10bd8c:	mov    %r10,%rax
  10bd8f:	movzwl (%r14,%r13,2),%r12d
  10bd94:	xor    %r10d,%r10d
  10bd97:	test   %r12w,%r12w
  10bd9b:	setne  %r10b
  10bd9f:	shlx   %r13,%r10,%r10
  10bda4:	or     %rax,%r10
  10bda7:	cmp    $0x1,%r12w
  10bdac:	jbe    10bd84 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x284>
  10bdae:	cmp    %dx,%r12w
  10bdb2:	jne    10bd80 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x280>
  10bdb4:	add    %r8,%r13
  10bdb7:	mov    $0x1,%al
  10bdb9:	mov    %rbx,%r8
  10bdbc:	jmp    10bdc8 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x2c8>
  10bdbe:	xor    %eax,%eax
  10bdc0:	mov    %rbx,%r8
  10bdc3:	mov    0x18(%rsp),%r13
  10bdc8:	mov    %r9,(%r15,%r8,8)
  10bdcc:	mov    0x20(%rsp),%rdx
  10bdd1:	mov    %r10,(%rdx,%r8,8)
  10bdd5:	inc    %r8
  10bdd8:	mov    %r8,%rbx
  10bddb:	movq   $0x0,(%r15,%rbx,8)
  10bde3:	movq   $0x0,(%rdx,%rbx,8)
  10bdeb:	movq   $0x0,0x8(%r15,%rbx,8)
  10bdf4:	movq   $0x0,0x8(%rdx,%rbx,8)
  10bdfd:	add    $0x2,%rbx
  10be01:	mov    %rbx,0x28(%rcx)
  10be05:	mov    %rbx,0x40(%rcx)
  10be09:	test   %al,%al
  10be0b:	je     10bf26 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x426>
  10be11:	mov    %rsi,%r12
  10be14:	vmovups 0x18(%rdi),%xmm0
  10be19:	vmovaps %xmm0,0x50(%rsp)
  10be1f:	vmovups 0x28(%rdi),%xmm0
  10be24:	vmovaps %ymm0,0x60(%rsp)
  10be2a:	vmovups 0xf8(%rdi),%ymm0
  10be32:	vmovaps %ymm0,0x140(%rsp)
  10be3b:	vmovups 0xd8(%rdi),%ymm0
  10be43:	vmovaps %ymm0,0x120(%rsp)
  10be4c:	vmovups 0xb8(%rdi),%ymm0
  10be54:	vmovaps %ymm0,0x100(%rsp)
  10be5d:	vmovdqu 0x38(%rdi),%ymm0
  10be62:	vmovdqu 0x58(%rdi),%ymm1
  10be67:	vmovups 0x78(%rdi),%ymm2
  10be6c:	vmovdqu 0x98(%rdi),%ymm3
  10be74:	vmovdqa %ymm3,0xe0(%rsp)
  10be7d:	vmovaps %ymm2,0xc0(%rsp)
  10be86:	vmovdqa %ymm1,0xa0(%rsp)
  10be8f:	vmovdqa %ymm0,0x80(%rsp)
  10be98:	movabs $0x204081020408103,%rax
  10bea2:	mov    0x38(%rsp),%rdx
  10bea7:	mulx   %rax,%rax,%rax
  10beac:	sub    %rax,%rdx
  10beaf:	shr    $1,%rdx
  10beb2:	add    %rax,%rdx
  10beb5:	shr    $0x6,%rdx
  10beb9:	movq   $0x0,0x10(%rcx)
  10bec1:	mov    0x18(%rsp),%rax
  10bec6:	mov    %rdx,0x30(%rsp)
  10becb:	add    %rax,%rdx
  10bece:	add    $0x3,%rdx
  10bed2:	cmp    (%rcx),%rdx
  10bed5:	ja     10c9fd <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xefd>
  10bedb:	mov    %rcx,%r14
  10bede:	mov    0x8(%rcx),%rax
  10bee2:	mov    %rax,0x40(%rsp)
  10bee7:	lea    0x180(%rsp),%rdi
  10beef:	xor    %ebx,%ebx
  10bef1:	mov    $0x400,%edx
  10bef6:	xor    %esi,%esi
  10bef8:	vzeroupper
  10befb:	call   *0xdc417(%rip)        # 1e8318 <memset@GLIBC_2.2.5>
  10bf01:	mov    %r13,%rdi
  10bf04:	shr    $0x6,%rdi
  10bf08:	mov    (%r15),%rax
  10bf0b:	test   %rax,%rax
  10bf0e:	mov    %r12,0x48(%rsp)
  10bf13:	je     10bf2d <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x42d>
  10bf15:	mov    %r14,%r9
  10bf18:	vmovdqa 0x60(%rsp),%ymm10
  10bf1e:	vmovdqa 0x50(%rsp),%xmm2
  10bf24:	jmp    10bf66 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x466>
  10bf26:	xor    %eax,%eax
  10bf28:	jmp    10c926 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xe26>
  10bf2d:	xor    %r10d,%r10d
  10bf30:	xor    %ebx,%ebx
  10bf32:	mov    %r14,%r9
  10bf35:	vmovdqa 0x60(%rsp),%ymm10
  10bf3b:	vmovdqa 0x50(%rsp),%xmm2
  10bf41:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  10bf50:	cmp    %rbx,%rdi
  10bf53:	je     10c065 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x565>
  10bf59:	mov    0x8(%r15,%rbx,8),%rax
  10bf5e:	inc    %rbx
  10bf61:	test   %rax,%rax
  10bf64:	je     10bf50 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x450>
  10bf66:	tzcnt  %rax,%r14
  10bf6b:	blsr   %rax,%r10
  10bf70:	mov    %rbx,%rax
  10bf73:	shl    $0x6,%rax
  10bf77:	or     %r14,%rax
  10bf7a:	xor    %ecx,%ecx
  10bf7c:	cmp    $0x15,%rax
  10bf80:	ja     10c91f <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xe1f>
  10bf86:	incq   0x30(%rsp)
  10bf8b:	inc    %rax
  10bf8e:	mov    0x20(%rsp),%rsi
  10bf93:	bzhi   %rax,(%rsi),%rdx
  10bf98:	dec    %rdx
  10bf9b:	mov    %rdi,0x60(%rsp)
  10bfa0:	je     10c07c <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x57c>
  10bfa6:	movabs $0x204081020408103,%rax
  10bfb0:	mulx   %rax,%rax,%rax
  10bfb5:	mov    %rdx,%rsi
  10bfb8:	sub    %rax,%rsi
  10bfbb:	shr    $1,%rsi
  10bfbe:	add    %rax,%rsi
  10bfc1:	shr    $0x6,%rsi
  10bfc5:	movabs $0x7efdfbf7efdfbf7f,%rax
  10bfcf:	imul   %rdx,%rax
  10bfd3:	movabs $0x204081020408102,%r8
  10bfdd:	xor    %r11d,%r11d
  10bfe0:	cmp    %r8,%rax
  10bfe3:	seta   %r11b
  10bfe7:	add    %rsi,%r11
  10bfea:	xor    %eax,%eax
  10bfec:	sub    $0x1,%r11
  10bff0:	cmovb  %rax,%r11
  10bff4:	cmp    0x38(%rsp),%rdx
  10bff9:	ja     10c921 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xe21>
  10bfff:	mov    %rdx,0x18(%rsp)
  10c004:	sub    %r11,0x30(%rsp)
  10c009:	jb     10c921 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xe21>
  10c00f:	mov    %r9,%rdi
  10c012:	vmovd  %xmm2,%eax
  10c016:	movzbl %al,%eax
  10c019:	mov    0x18(%rsp),%rdx
  10c01e:	add    %edx,0x180(%rsp,%rax,4)
  10c025:	shl    $0x8,%eax
  10c028:	mov    0x40(%rsp),%rsi
  10c02d:	nopl   (%rax)
  10c030:	cmp    $0x7f,%rdx
  10c034:	mov    $0x7f,%r8d
  10c03a:	cmovb  %rdx,%r8
  10c03e:	lea    (%r8,%rax,1),%r9d
  10c042:	mov    %r9w,(%rsi)
  10c046:	add    $0x2,%rsi
  10c04a:	sub    %r8,%rdx
  10c04d:	jne    10c030 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x530>
  10c04f:	mov    0x20(%rsp),%rax
  10c054:	mov    %rdi,%r9
  10c057:	mov    0x60(%rsp),%rdi
  10c05c:	test   %cl,%cl
  10c05e:	je     10c091 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x591>
  10c060:	jmp    10c584 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xa84>
  10c065:	mov    $0x1,%cl
  10c067:	mov    %rdi,%rbx
  10c06a:	mov    %r13,%rax
  10c06d:	cmp    $0x15,%rax
  10c071:	jbe    10bf86 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x486>
  10c077:	jmp    10c91f <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xe1f>
  10c07c:	mov    %rsi,%rax
  10c07f:	mov    %rdx,0x18(%rsp)
  10c084:	mov    0x40(%rsp),%rsi
  10c089:	test   %cl,%cl
  10c08b:	jne    10c584 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xa84>
  10c091:	mov    %r9,0x28(%rsp)
  10c096:	mov    (%rax,%rbx,8),%r9
  10c09a:	shr    $1,%r9
  10c09d:	mov    %rbx,%rcx
  10c0a0:	shl    $0x7,%rcx
  10c0a4:	add    0x48(%rsp),%rcx
  10c0a9:	lea    -0xd12b0(%rip),%r8        # 3ae00 <_RNvNtCslqP6imz8QVM_5mibz24runs5STEPS>
  10c0b0:	vmovdqa -0xc1918(%rip),%ymm0        # 4a7a0 <.LCPI656_0>
  10c0b8:	vmovdqa -0xc1a40(%rip),%ymm3        # 4a680 <.LCPI732_4>
  10c0c0:	vmovdqa -0xc1a08(%rip),%ymm4        # 4a6c0 <.LCPI732_5>
  10c0c8:	vmovdqa -0xc1ad0(%rip),%ymm5        # 4a600 <.LCPI732_6>
  10c0d0:	vmovdqa -0xc1998(%rip),%ymm6        # 4a740 <.LCPI732_7>
  10c0d8:	jmp    10c14b <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x64b>
  10c0da:	nopw   0x0(%rax,%rax,1)
  10c0e0:	shl    $0x6,%edx
  10c0e3:	vpshufb -0x40(%rdx,%r8,1),%xmm2,%xmm7
  10c0ea:	vpshufb -0x30(%rdx,%r8,1),%xmm10,%xmm8
  10c0f1:	vpshufb -0x10(%rdx,%r8,1),%xmm2,%xmm9
  10c0f8:	vpor   %xmm7,%xmm8,%xmm2
  10c0fc:	vpshufb -0x20(%rdx,%r8,1),%xmm10,%xmm8
  10c103:	vpor   %xmm8,%xmm9,%xmm10
  10c108:	vmovd  %xmm2,%eax
  10c10c:	movzbl %al,%r12d
  10c110:	test   %r10,%r10
  10c113:	je     10c338 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x838>
  10c119:	tzcnt  %r10,%r11
  10c11e:	blsr   %r10,%r10
  10c123:	bzhi   %r11,%r9,%rdx
  10c128:	shrx   %r14,%rdx,%rdx
  10c12d:	cmp    $0x7f,%rdx
  10c131:	ja     10c383 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x883>
  10c137:	mov    %dl,(%rsi)
  10c139:	mov    %al,0x1(%rsi)
  10c13c:	add    $0x2,%rsi
  10c140:	add    %edx,0x180(%rsp,%r12,4)
  10c148:	mov    %r11,%r14
  10c14b:	movzwl (%rcx,%r14,2),%edx
  10c150:	cmp    $0x21,%rdx
  10c154:	jb     10c0e0 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x5e0>
  10c156:	mov    %edx,%r11d
  10c159:	dec    %rdx
  10c15c:	cmp    $0xff,%rdx
  10c163:	mov    $0xff,%eax
  10c168:	cmovae %rax,%rdx
  10c16c:	movzbl 0x60(%rsp,%rdx,1),%eax
  10c171:	add    $0xffffffffffffffe0,%rdx
  10c175:	vinserti128 $0x1,%xmm10,%ymm10,%ymm7
  10c17b:	cmp    $0x40,%r11w
  10c180:	ja     10c1c0 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x6c0>
  10c182:	vmovdqa 0x80(%rsp),%ymm8
  10c18b:	inc    %dl
  10c18d:	vmovd  %edx,%xmm9
  10c191:	vpbroadcastb %xmm9,%ymm9
  10c196:	vpcmpgtb %ymm0,%ymm9,%ymm9
  10c19a:	vperm2i128 $0x21,%ymm8,%ymm7,%ymm7
  10c1a0:	vpalignr $0xf,%ymm7,%ymm8,%ymm7
  10c1a6:	vpblendvb %ymm9,%ymm7,%ymm8,%ymm7
  10c1ac:	jmp    10c30b <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x80b>
  10c1b1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  10c1c0:	vmovd  %edx,%xmm8
  10c1c4:	vpbroadcastb %xmm8,%ymm8
  10c1c9:	vmovdqa %ymm10,%ymm1
  10c1cd:	vmovdqa 0x80(%rsp),%ymm10
  10c1d6:	vmovdqa 0xa0(%rsp),%ymm11
  10c1df:	vmovdqa 0xc0(%rsp),%ymm12
  10c1e8:	vmovdqa 0xe0(%rsp),%ymm13
  10c1f1:	vmovdqa 0x100(%rsp),%ymm9
  10c1fa:	vpmaxub %ymm0,%ymm8,%ymm14
  10c1fe:	vpcmpeqb %ymm14,%ymm8,%ymm14
  10c203:	vperm2i128 $0x21,%ymm10,%ymm7,%ymm7
  10c209:	vpalignr $0xf,%ymm7,%ymm10,%ymm7
  10c20f:	vpblendvb %ymm14,%ymm7,%ymm10,%ymm7
  10c215:	vpminub -0xc1a5d(%rip),%ymm8,%ymm14        # 4a7c0 <.LCPI732_2>
  10c21d:	vpcmpeqb %ymm14,%ymm8,%ymm14
  10c222:	vperm2i128 $0x21,%ymm11,%ymm10,%ymm10
  10c228:	vpalignr $0xf,%ymm10,%ymm11,%ymm10
  10c22e:	vpblendvb %ymm14,%ymm11,%ymm10,%ymm10
  10c234:	vpminub -0xc1abc(%rip),%ymm8,%ymm14        # 4a780 <.LCPI732_3>
  10c23c:	vpcmpeqb %ymm14,%ymm8,%ymm14
  10c241:	vperm2i128 $0x21,%ymm12,%ymm11,%ymm11
  10c247:	vpalignr $0xf,%ymm11,%ymm12,%ymm11
  10c24d:	vpblendvb %ymm14,%ymm12,%ymm11,%ymm11
  10c253:	vpminub %ymm3,%ymm8,%ymm14
  10c257:	vpcmpeqb %ymm14,%ymm8,%ymm14
  10c25c:	vperm2i128 $0x21,%ymm13,%ymm12,%ymm12
  10c262:	vpalignr $0xf,%ymm12,%ymm13,%ymm12
  10c268:	vpblendvb %ymm14,%ymm13,%ymm12,%ymm12
  10c26e:	vpminub %ymm4,%ymm8,%ymm14
  10c272:	vpcmpeqb %ymm14,%ymm8,%ymm14
  10c277:	vperm2i128 $0x21,%ymm9,%ymm13,%ymm13
  10c27d:	vpalignr $0xf,%ymm13,%ymm9,%ymm13
  10c283:	vpblendvb %ymm14,%ymm9,%ymm13,%ymm13
  10c289:	vmovdqa 0x120(%rsp),%ymm14
  10c292:	vpminub %ymm5,%ymm8,%ymm15
  10c296:	vpcmpeqb %ymm15,%ymm8,%ymm15
  10c29b:	vperm2i128 $0x21,%ymm14,%ymm9,%ymm9
  10c2a1:	vpalignr $0xf,%ymm9,%ymm14,%ymm9
  10c2a7:	vpblendvb %ymm15,%ymm14,%ymm9,%ymm9
  10c2ad:	vpminub %ymm6,%ymm8,%ymm15
  10c2b1:	vpcmpeqb %ymm15,%ymm8,%ymm8
  10c2b6:	vmovdqa 0x140(%rsp),%ymm15
  10c2bf:	vperm2i128 $0x21,%ymm15,%ymm14,%ymm14
  10c2c5:	vpalignr $0xf,%ymm14,%ymm15,%ymm14
  10c2cb:	vpblendvb %ymm8,%ymm15,%ymm14,%ymm8
  10c2d1:	vmovdqa %ymm10,0xa0(%rsp)
  10c2da:	vmovdqa %ymm1,%ymm10
  10c2de:	vmovdqa %ymm11,0xc0(%rsp)
  10c2e7:	vmovdqa %ymm12,0xe0(%rsp)
  10c2f0:	vmovdqa %ymm13,0x100(%rsp)
  10c2f9:	vmovdqa %ymm9,0x120(%rsp)
  10c302:	vmovdqa %ymm8,0x140(%rsp)
  10c30b:	vmovdqa %ymm7,0x80(%rsp)
  10c314:	vpalignr $0xf,%xmm2,%xmm10,%xmm10
  10c31a:	vpslldq $0x1,%xmm2,%xmm7
  10c31f:	vmovd  %eax,%xmm8
  10c323:	vpor   %xmm7,%xmm8,%xmm2
  10c327:	vmovd  %xmm2,%eax
  10c32b:	movzbl %al,%r12d
  10c32f:	test   %r10,%r10
  10c332:	jne    10c119 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x619>
  10c338:	mov    %rbx,%rdx
  10c33b:	shl    $0x6,%rdx
  10c33f:	add    %r14,%rdx
  10c342:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  10c350:	mov    %rbx,%rcx
  10c353:	cmp    %rbx,%rdi
  10c356:	je     10c45a <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x95a>
  10c35c:	lea    0x1(%rcx),%rbx
  10c360:	mov    0x8(%r15,%rcx,8),%r9
  10c365:	test   %r9,%r9
  10c368:	je     10c350 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x850>
  10c36a:	tzcnt  %r9,%r14
  10c36f:	blsr   %r9,%r10
  10c374:	mov    %rbx,%r9
  10c377:	shl    $0x6,%r9
  10c37b:	or     %r14,%r9
  10c37e:	jmp    10c463 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x963>
  10c383:	mov    %r11,%rax
  10c386:	sub    %r14,%rax
  10c389:	cmp    $0x16,%rax
  10c38d:	ja     10c578 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xa78>
  10c393:	mov    %r15,%r8
  10c396:	movabs $0x204081020408103,%rax
  10c3a0:	mulx   %rax,%rax,%rax
  10c3a5:	mov    %rdx,%r14
  10c3a8:	sub    %rax,%r14
  10c3ab:	shr    $1,%r14
  10c3ae:	add    %rax,%r14
  10c3b1:	shr    $0x6,%r14
  10c3b5:	mov    %rdx,%rax
  10c3b8:	movabs $0x7efdfbf7efdfbf7f,%rdi
  10c3c2:	imul   %rdi,%rax
  10c3c6:	xor    %edi,%edi
  10c3c8:	movabs $0x204081020408102,%r15
  10c3d2:	cmp    %r15,%rax
  10c3d5:	seta   %dil
  10c3d9:	lea    (%r14,%rdi,1),%rax
  10c3dd:	dec    %rax
  10c3e0:	mov    0x30(%rsp),%rdi
  10c3e5:	sub    %rax,%rdi
  10c3e8:	jb     10c578 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xa78>
  10c3ee:	mov    %rdi,0x30(%rsp)
  10c3f3:	mov    0x18(%rsp),%rdi
  10c3f8:	add    %rdx,%rdi
  10c3fb:	mov    $0x0,%eax
  10c400:	mov    %rdi,0x18(%rsp)
  10c405:	cmp    0x38(%rsp),%rdi
  10c40a:	mov    %r8,%r15
  10c40d:	lea    -0xd1614(%rip),%r8        # 3ae00 <_RNvNtCslqP6imz8QVM_5mibz24runs5STEPS>
  10c414:	ja     10c921 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xe21>
  10c41a:	add    %edx,0x180(%rsp,%r12,4)
  10c422:	shl    $0x8,%r12d
  10c426:	cs nopw 0x0(%rax,%rax,1)
  10c430:	cmp    $0x7f,%rdx
  10c434:	mov    $0x7f,%eax
  10c439:	cmovb  %rdx,%rax
  10c43d:	lea    (%rax,%r12,1),%edi
  10c441:	mov    %di,(%rsi)
  10c444:	add    $0x2,%rsi
  10c448:	sub    %rax,%rdx
  10c44b:	jne    10c430 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x930>
  10c44d:	mov    %r11,%r14
  10c450:	mov    0x60(%rsp),%rdi
  10c455:	jmp    10c14b <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x64b>
  10c45a:	mov    %rdi,%rbx
  10c45d:	mov    %r13,%r9
  10c460:	xor    %r10d,%r10d
  10c463:	sub    %rdx,%r9
  10c466:	cmp    $0x16,%r9
  10c46a:	ja     10c578 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xa78>
  10c470:	inc    %rdx
  10c473:	mov    %rdx,%r11
  10c476:	shr    $0x3,%r11
  10c47a:	and    $0x7,%dl
  10c47d:	mov    0x20(%rsp),%rdi
  10c482:	shrx   %rdx,(%rdi,%r11,1),%rdx
  10c488:	bzhi   %r9,%rdx,%rdx
  10c48d:	cmp    $0x7f,%rdx
  10c491:	jbe    10c540 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xa40>
  10c497:	movabs $0x204081020408103,%rax
  10c4a1:	mulx   %rax,%rax,%rax
  10c4a6:	mov    %rdx,%r9
  10c4a9:	sub    %rax,%r9
  10c4ac:	shr    $1,%r9
  10c4af:	add    %rax,%r9
  10c4b2:	shr    $0x6,%r9
  10c4b6:	mov    %rdx,%rax
  10c4b9:	movabs $0x7efdfbf7efdfbf7f,%rdi
  10c4c3:	imul   %rdi,%rax
  10c4c7:	xor    %r11d,%r11d
  10c4ca:	movabs $0x204081020408102,%rdi
  10c4d4:	cmp    %rdi,%rax
  10c4d7:	seta   %r11b
  10c4db:	lea    (%r9,%r11,1),%rax
  10c4df:	dec    %rax
  10c4e2:	sub    %rax,0x30(%rsp)
  10c4e7:	jb     10c578 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xa78>
  10c4ed:	mov    0x18(%rsp),%rdi
  10c4f2:	add    %rdx,%rdi
  10c4f5:	mov    $0x0,%eax
  10c4fa:	mov    %rdi,0x18(%rsp)
  10c4ff:	cmp    0x38(%rsp),%rdi
  10c504:	ja     10c921 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xe21>
  10c50a:	add    %edx,0x180(%rsp,%r12,4)
  10c512:	shl    $0x8,%r12d
  10c516:	cs nopw 0x0(%rax,%rax,1)
  10c520:	cmp    $0x7f,%rdx
  10c524:	mov    $0x7f,%eax
  10c529:	cmovb  %rdx,%rax
  10c52d:	lea    (%rax,%r12,1),%r9d
  10c531:	mov    %r9w,(%rsi)
  10c535:	add    $0x2,%rsi
  10c539:	sub    %rax,%rdx
  10c53c:	jne    10c520 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xa20>
  10c53e:	jmp    10c551 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xa51>
  10c540:	mov    %dl,(%rsi)
  10c542:	mov    %al,0x1(%rsi)
  10c545:	add    $0x2,%rsi
  10c549:	add    %edx,0x180(%rsp,%r12,4)
  10c551:	mov    0x60(%rsp),%rdi
  10c556:	cmp    %rcx,%rdi
  10c559:	mov    0x20(%rsp),%rax
  10c55e:	je     10c57f <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xa7f>
  10c560:	mov    (%rax,%rbx,8),%r9
  10c564:	shr    $1,%r9
  10c567:	mov    %rbx,%rcx
  10c56a:	shl    $0x7,%rcx
  10c56e:	add    0x48(%rsp),%rcx
  10c573:	jmp    10c14b <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x64b>
  10c578:	xor    %eax,%eax
  10c57a:	jmp    10c921 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xe21>
  10c57f:	mov    0x28(%rsp),%r9
  10c584:	vpmovzxdq 0x180(%rsp),%ymm0
  10c58e:	vpmovzxdq 0x190(%rsp),%ymm1
  10c598:	vpmovzxdq 0x1a0(%rsp),%ymm2
  10c5a2:	vpmovzxdq 0x1b0(%rsp),%ymm3
  10c5ac:	vpmovzxdq 0x1c0(%rsp),%ymm4
  10c5b6:	vpaddq %ymm4,%ymm0,%ymm0
  10c5ba:	vpmovzxdq 0x1d0(%rsp),%ymm4
  10c5c4:	vpaddq %ymm4,%ymm1,%ymm1
  10c5c8:	vpmovzxdq 0x1e0(%rsp),%ymm4
  10c5d2:	vpaddq %ymm4,%ymm2,%ymm2
  10c5d6:	vpmovzxdq 0x1f0(%rsp),%ymm4
  10c5e0:	vpmovzxdq 0x200(%rsp),%ymm5
  10c5ea:	vpmovzxdq 0x210(%rsp),%ymm6
  10c5f4:	vpmovzxdq 0x220(%rsp),%ymm7
  10c5fe:	vpmovzxdq 0x230(%rsp),%ymm8
  10c608:	vpmovzxdq 0x240(%rsp),%ymm9
  10c612:	vpaddq %ymm4,%ymm3,%ymm3
  10c616:	vpaddq %ymm5,%ymm9,%ymm4
  10c61a:	vpmovzxdq 0x250(%rsp),%ymm5
  10c624:	vpaddq %ymm4,%ymm0,%ymm0
  10c628:	vpaddq %ymm5,%ymm6,%ymm4
  10c62c:	vpmovzxdq 0x260(%rsp),%ymm5
  10c636:	vpaddq %ymm4,%ymm1,%ymm1
  10c63a:	vpaddq %ymm5,%ymm7,%ymm4
  10c63e:	vpmovzxdq 0x270(%rsp),%ymm5
  10c648:	vpaddq %ymm4,%ymm2,%ymm2
  10c64c:	vpaddq %ymm5,%ymm8,%ymm4
  10c650:	vpmovzxdq 0x280(%rsp),%ymm5
  10c65a:	vpmovzxdq 0x290(%rsp),%ymm6
  10c664:	vpmovzxdq 0x2a0(%rsp),%ymm7
  10c66e:	vpmovzxdq 0x2b0(%rsp),%ymm8
  10c678:	vpmovzxdq 0x2c0(%rsp),%ymm9
  10c682:	vpaddq %ymm4,%ymm3,%ymm3
  10c686:	vpaddq %ymm5,%ymm9,%ymm4
  10c68a:	vpmovzxdq 0x2d0(%rsp),%ymm5
  10c694:	vpaddq %ymm5,%ymm6,%ymm5
  10c698:	vpmovzxdq 0x2e0(%rsp),%ymm6
  10c6a2:	vpaddq %ymm6,%ymm7,%ymm6
  10c6a6:	vpmovzxdq 0x2f0(%rsp),%ymm7
  10c6b0:	vpmovzxdq 0x300(%rsp),%ymm9
  10c6ba:	vpaddq %ymm7,%ymm8,%ymm7
  10c6be:	vpaddq %ymm4,%ymm9,%ymm4
  10c6c2:	vpmovzxdq 0x310(%rsp),%ymm8
  10c6cc:	vpaddq %ymm4,%ymm0,%ymm0
  10c6d0:	vpaddq %ymm5,%ymm8,%ymm4
  10c6d4:	vpmovzxdq 0x320(%rsp),%ymm5
  10c6de:	vpaddq %ymm4,%ymm1,%ymm1
  10c6e2:	vpaddq %ymm5,%ymm6,%ymm4
  10c6e6:	vpmovzxdq 0x330(%rsp),%ymm5
  10c6f0:	vpaddq %ymm4,%ymm2,%ymm2
  10c6f4:	vpaddq %ymm5,%ymm7,%ymm4
  10c6f8:	vpmovzxdq 0x340(%rsp),%ymm5
  10c702:	vpmovzxdq 0x350(%rsp),%ymm6
  10c70c:	vpmovzxdq 0x360(%rsp),%ymm7
  10c716:	vpmovzxdq 0x370(%rsp),%ymm8
  10c720:	vpmovzxdq 0x380(%rsp),%ymm9
  10c72a:	vpaddq %ymm4,%ymm3,%ymm3
  10c72e:	vpaddq %ymm5,%ymm9,%ymm4
  10c732:	vpmovzxdq 0x390(%rsp),%ymm5
  10c73c:	vpaddq %ymm5,%ymm6,%ymm5
  10c740:	vpmovzxdq 0x3a0(%rsp),%ymm6
  10c74a:	vpaddq %ymm6,%ymm7,%ymm6
  10c74e:	vpmovzxdq 0x3b0(%rsp),%ymm7
  10c758:	vpmovzxdq 0x3c0(%rsp),%ymm9
  10c762:	vpaddq %ymm7,%ymm8,%ymm7
  10c766:	vpaddq %ymm4,%ymm9,%ymm4
  10c76a:	vpmovzxdq 0x3d0(%rsp),%ymm8
  10c774:	vpaddq %ymm5,%ymm8,%ymm5
  10c778:	vpmovzxdq 0x3e0(%rsp),%ymm8
  10c782:	vpaddq %ymm6,%ymm8,%ymm6
  10c786:	vpmovzxdq 0x3f0(%rsp),%ymm8
  10c790:	vpmovzxdq 0x400(%rsp),%ymm9
  10c79a:	vpaddq %ymm7,%ymm8,%ymm7
  10c79e:	vpaddq %ymm4,%ymm9,%ymm4
  10c7a2:	vpmovzxdq 0x410(%rsp),%ymm8
  10c7ac:	vpaddq %ymm4,%ymm0,%ymm0
  10c7b0:	vpaddq %ymm5,%ymm8,%ymm4
  10c7b4:	vpmovzxdq 0x420(%rsp),%ymm5
  10c7be:	vpaddq %ymm4,%ymm1,%ymm1
  10c7c2:	vpaddq %ymm5,%ymm6,%ymm4
  10c7c6:	vpmovzxdq 0x430(%rsp),%ymm5
  10c7d0:	vpaddq %ymm4,%ymm2,%ymm2
  10c7d4:	vpaddq %ymm5,%ymm7,%ymm4
  10c7d8:	vpmovzxdq 0x440(%rsp),%ymm5
  10c7e2:	vpmovzxdq 0x450(%rsp),%ymm6
  10c7ec:	vpmovzxdq 0x460(%rsp),%ymm7
  10c7f6:	vpmovzxdq 0x470(%rsp),%ymm8
  10c800:	vpmovzxdq 0x480(%rsp),%ymm9
  10c80a:	vpaddq %ymm4,%ymm3,%ymm3
  10c80e:	vpaddq %ymm5,%ymm9,%ymm4
  10c812:	vpmovzxdq 0x490(%rsp),%ymm5
  10c81c:	vpaddq %ymm5,%ymm6,%ymm5
  10c820:	vpmovzxdq 0x4a0(%rsp),%ymm6
  10c82a:	vpaddq %ymm6,%ymm7,%ymm6
  10c82e:	vpmovzxdq 0x4b0(%rsp),%ymm7
  10c838:	vpmovzxdq 0x4c0(%rsp),%ymm9
  10c842:	vpaddq %ymm7,%ymm8,%ymm7
  10c846:	vpaddq %ymm4,%ymm9,%ymm4
  10c84a:	vpmovzxdq 0x4d0(%rsp),%ymm8
  10c854:	vpaddq %ymm5,%ymm8,%ymm5
  10c858:	vpmovzxdq 0x4e0(%rsp),%ymm8
  10c862:	vpaddq %ymm6,%ymm8,%ymm6
  10c866:	vpmovzxdq 0x4f0(%rsp),%ymm8
  10c870:	vpmovzxdq 0x500(%rsp),%ymm9
  10c87a:	vpaddq %ymm7,%ymm8,%ymm7
  10c87e:	vpaddq %ymm4,%ymm9,%ymm4
  10c882:	vpmovzxdq 0x510(%rsp),%ymm8
  10c88c:	vpaddq %ymm5,%ymm8,%ymm5
  10c890:	vpmovzxdq 0x520(%rsp),%ymm8
  10c89a:	vpaddq %ymm6,%ymm8,%ymm6
  10c89e:	vpmovzxdq 0x530(%rsp),%ymm8
  10c8a8:	vpmovzxdq 0x540(%rsp),%ymm9
  10c8b2:	vpaddq %ymm7,%ymm8,%ymm7
  10c8b6:	vpaddq %ymm4,%ymm9,%ymm4
  10c8ba:	vpmovzxdq 0x550(%rsp),%ymm8
  10c8c4:	vpaddq %ymm4,%ymm0,%ymm0
  10c8c8:	vpaddq %ymm5,%ymm8,%ymm4
  10c8cc:	vpaddq %ymm4,%ymm1,%ymm1
  10c8d0:	vpaddq %ymm0,%ymm1,%ymm0
  10c8d4:	vpmovzxdq 0x560(%rsp),%ymm1
  10c8de:	vpaddq %ymm1,%ymm6,%ymm1
  10c8e2:	vpaddq %ymm1,%ymm2,%ymm1
  10c8e6:	vpaddq %ymm0,%ymm1,%ymm0
  10c8ea:	vpmovzxdq 0x570(%rsp),%ymm1
  10c8f4:	vpaddq %ymm1,%ymm7,%ymm1
  10c8f8:	vpaddq %ymm1,%ymm3,%ymm1
  10c8fc:	vpaddq %ymm0,%ymm1,%ymm0
  10c900:	vextracti128 $0x1,%ymm0,%xmm1
  10c906:	vpaddq %xmm1,%xmm0,%xmm0
  10c90a:	vpshufd $0xee,%xmm0,%xmm1
  10c90f:	vpaddq %xmm1,%xmm0,%xmm0
  10c913:	vmovq  %xmm0,%r14
  10c918:	cmp    0x38(%rsp),%r14
  10c91d:	jbe    10c938 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xe38>
  10c91f:	xor    %eax,%eax
  10c921:	mov    0x50(%rsp),%rdx
  10c926:	lea    -0x28(%rbp),%rsp
  10c92a:	pop    %rbx
  10c92b:	pop    %r12
  10c92d:	pop    %r13
  10c92f:	pop    %r14
  10c931:	pop    %r15
  10c933:	pop    %rbp
  10c934:	vzeroupper
  10c937:	ret
  10c938:	sub    0x40(%rsp),%rsi
  10c93d:	sar    $1,%rsi
  10c940:	mov    %rsi,0x10(%r9)
  10c944:	lea    0x48(%r9),%rdi
  10c948:	lea    0x180(%rsp),%rsi
  10c950:	mov    $0x400,%edx
  10c955:	mov    %r9,%rbx
  10c958:	vzeroupper
  10c95b:	call   *0xdba17(%rip)        # 1e8378 <memcpy@GLIBC_2.14>
  10c961:	cmp    $0x1000000,%r14
  10c968:	setb   0x450(%rbx)
  10c96f:	mov    %r14,0x50(%rsp)
  10c974:	mov    %r14,0x448(%rbx)
  10c97b:	mov    $0x1,%eax
  10c980:	jmp    10c921 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0xe21>
  10c982:	lea    0x18(%rcx),%rax
  10c986:	mov    %rcx,0x28(%rsp)
  10c98b:	mov    $0x8,%ecx
  10c990:	mov    $0x8,%r8d
  10c996:	mov    %rdi,%r12
  10c999:	mov    %rax,%rdi
  10c99c:	mov    %rsi,%r13
  10c99f:	xor    %esi,%esi
  10c9a1:	mov    %r14,%rdx
  10c9a4:	call   f6640 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECslqP6imz8QVM_5mibz2>
  10c9a9:	mov    %r12,%rdi
  10c9ac:	mov    %r13,%rsi
  10c9af:	mov    0x28(%rsp),%rcx
  10c9b4:	movq   $0x0,0x40(%rcx)
  10c9bc:	cmp    0x30(%rcx),%r14
  10c9c0:	jbe    10bb89 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x89>
  10c9c6:	lea    0x30(%rcx),%rax
  10c9ca:	mov    %rcx,0x28(%rsp)
  10c9cf:	mov    $0x8,%ecx
  10c9d4:	mov    $0x8,%r8d
  10c9da:	mov    %rdi,%r12
  10c9dd:	mov    %rax,%rdi
  10c9e0:	mov    %rsi,%r13
  10c9e3:	xor    %esi,%esi
  10c9e5:	mov    %r14,%rdx
  10c9e8:	call   f6640 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECslqP6imz8QVM_5mibz2>
  10c9ed:	mov    %r12,%rdi
  10c9f0:	mov    %r13,%rsi
  10c9f3:	mov    0x28(%rsp),%rcx
  10c9f8:	jmp    10bb89 <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x89>
  10c9fd:	mov    %rcx,%r14
  10ca00:	mov    $0x2,%ecx
  10ca05:	mov    $0x2,%r8d
  10ca0b:	mov    %r14,%rdi
  10ca0e:	xor    %esi,%esi
  10ca10:	vzeroupper
  10ca13:	call   f6640 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECslqP6imz8QVM_5mibz2>
  10ca18:	mov    %r14,%rcx
  10ca1b:	mov    0x20(%r14),%r15
  10ca1f:	mov    0x38(%r14),%rax
  10ca23:	mov    %rax,0x20(%rsp)
  10ca28:	jmp    10bedb <_RNvNtCslqP6imz8QVM_5mibz24runs10front_avx2+0x3db>
