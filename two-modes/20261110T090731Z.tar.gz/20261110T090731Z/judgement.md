# The two modes' discriminator: VALID: GAP BLOCK (primary): THE GAP POLICY GOES WITH THE SLOW MODE: 26/30 slow after a gap, 0/30 without (Fisher p 7.84e-13); PROBE TABLE (secondary): INSUFFICIENT CLASS SUPPORT: 40 fast and 0 slow probed runs (a floor of 5 a class); the rows are described and no signature is assessed; sustained block: constant within error

Label: **VALID**. Fast: wall < 0.21 s. Diagnostic only; the row cutoffs are unvalidated descriptive thresholds.

## pass1: P-idle alone

| reading | fast | slow |
|---|--:|--:|
| n | 40 | 0 |
| wall | 0.158 | - |
| cpu | 1.057 | - |
| p_idle | 4.690 | - |
| p_idle_active | 4.879 | - |
| p_idle_coverage | 0.993 | - |
| p_idle_longest_ms | 1.476 | - |
| p_idle_early | 4.561 | - |
| p_idle_late | 4.802 | - |
| p_idle_cpu_share | 1.000 | - |
| p_sib | - | - |
| clock_ghz | 4.900 | - |
| clock_early | 4.900 | - |
| clock_late | 4.900 | - |
| sibling_running | 0.267 | - |
| sibling_last_cpu | 0.325 | - |
| running_obs | 543.500 | - |
| core_throttle | 0.000 | - |
| package_throttle | 0.000 | - |
| core_throttle_ms | 0.000 | - |
| package_throttle_ms | 0.000 | - |
| core_power_limit | - | - |
| package_power_limit | - | - |
| thp_fault_alloc_global | 0.000 | - |
| anon_huge_kb | 0.000 | - |
| minflt | 20917.500 | - |
| utime_s | 1.012 | - |
| stime_s | 0.050 | - |
| sys_share | 0.047 | - |
| throttle_rose | 0.000 | - |
| power_limit_rose | - | - |
| thp_held | 0.000 | - |
| p_idle_rise | 0.950 | - |
| clock_rise | 1.000 | - |
| observations per row | p_idle 40, clock 40, sibling 40, throttle 40, power_limit 0, thp 40, sys_share 40 | p_idle 0, clock 0, sibling 0, throttle 0, power_limit 0, thp 0, sys_share 0 |

| row | observed | H1 | H2 | H3 | H4 | H5 |
|---|---|---|---|---|---|---|
| P-idle's elapsed-time progress in slow runs | **insufficient** | full or rising | full | half **(decisive)** | full | reduced **(decisive)** |
| the decoder CPUs' clock during slow runs (supporting) | **insufficient** | low, then rising **(decisive)** | full | full | full | reduced **(decisive)** |
| running decoder threads with a running sibling (a proxy) | **insufficient** | same | most **(decisive)** | same | same | same |
| throttle counts rise | **insufficient** | no | no | yes **(decisive)** | no | no |
| power-limit counts rise | **unread** | no | no | no | no | yes **(decisive)** |
| the child's huge pages in fast runs only | **insufficient** | no | no | no | yes **(decisive)** | no |
| system time's share grows | **insufficient** | no | no | no | yes **(decisive)** | no |

- H1 (the governor's ramp): untestable, ['clock']
- H2 (sibling packing): untestable, ['sibling']
- H3 (stop-clock throttling): untestable, ['p_idle', 'throttle']
- H4 (huge pages): untestable, ['sys_share', 'thp']
- H5 (the package power limit): untestable, ['clock', 'p_idle', 'power_limit']

Fast runs with the probe: 40 of 40; without it: 20 of 20 (a randomised schedule, seed 20261110; descriptive, with persistence widening its uncertainty).

Run order: `FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF`

Fast after fast: 59 of 59 (1.000), against 1.000 overall.
Gap between runs (ab's exit to next spawn), median: 0.260 s.

## pass2: P-idle beside P-sib

| reading | fast | slow |
|---|--:|--:|
| n | 60 | 0 |
| wall | 0.162 | - |
| cpu | 1.065 | - |
| p_idle | 2.205 | - |
| p_idle_active | 2.427 | - |
| p_idle_coverage | 0.996 | - |
| p_idle_longest_ms | 2.689 | - |
| p_idle_early | 1.796 | - |
| p_idle_late | 2.385 | - |
| p_idle_cpu_share | 0.980 | - |
| p_sib | 2.208 | - |
| clock_ghz | 4.900 | - |
| clock_early | 4.900 | - |
| clock_late | 4.900 | - |
| sibling_running | 0.221 | - |
| sibling_last_cpu | 0.283 | - |
| running_obs | 552.500 | - |
| core_throttle | 0.000 | - |
| package_throttle | 0.000 | - |
| core_throttle_ms | 0.000 | - |
| package_throttle_ms | 0.000 | - |
| core_power_limit | - | - |
| package_power_limit | - | - |
| thp_fault_alloc_global | 0.000 | - |
| anon_huge_kb | 0.000 | - |
| minflt | 20750.000 | - |
| utime_s | 1.010 | - |
| stime_s | 0.061 | - |
| sys_share | 0.057 | - |
| throttle_rose | 0.000 | - |
| power_limit_rose | - | - |
| thp_held | 0.000 | - |
| p_idle_rise | 0.748 | - |
| clock_rise | 1.000 | - |
| observations per row | p_idle 60, clock 60, sibling 60, throttle 60, power_limit 0, thp 60, sys_share 60 | p_idle 0, clock 0, sibling 0, throttle 0, power_limit 0, thp 0, sys_share 0 |

| row | observed | H1 | H2 | H3 | H4 | H5 |
|---|---|---|---|---|---|---|
| P-idle's elapsed-time progress in slow runs | **insufficient** | full or rising | full | half **(decisive)** | full | reduced **(decisive)** |
| the decoder CPUs' clock during slow runs (supporting) | **insufficient** | low, then rising **(decisive)** | full | full | full | reduced **(decisive)** |
| running decoder threads with a running sibling (a proxy) | **insufficient** | same | most **(decisive)** | same | same | same |
| throttle counts rise | **insufficient** | no | no | yes **(decisive)** | no | no |
| power-limit counts rise | **unread** | no | no | no | no | yes **(decisive)** |
| the child's huge pages in fast runs only | **insufficient** | no | no | no | yes **(decisive)** | no |
| system time's share grows | **insufficient** | no | no | no | yes **(decisive)** | no |

- H1 (the governor's ramp): untestable, ['clock']
- H2 (sibling packing): untestable, ['sibling']
- H3 (stop-clock throttling): untestable, ['p_idle', 'throttle']
- H4 (huge pages): untestable, ['sys_share', 'thp']
- H5 (the package power limit): untestable, ['clock', 'p_idle', 'power_limit']

Fast runs with the probe: 60 of 60; without it: 0 of 0 (a randomised schedule, seed 20261110; descriptive, with persistence widening its uncertainty).

Run order: `FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF`

Fast after fast: 59 of 59 (1.000), against 1.000 overall.
Gap between runs (ab's exit to next spawn), median: 0.260 s.

## The gap block (first, no probe): the primary cheap discriminator

Outcome: **THE GAP POLICY GOES WITH THE SLOW MODE: 26/30 slow after a gap, 0/30 without (Fisher p 7.84e-13)**
- after a 0.25 s gap: 26 slow of 30; CPU per block 0.005140 s (fast 0.002590, slow 0.005267); gap median 0.2501 s
- no gap: 0 slow of 30; CPU per block 0.002337 s (fast 0.002337, slow -); gap median 0.0001 s
- order `GZGZZZGZGZGGZZGZZGGZGZZGZZZZGZGZGGZZGZZZGGGGZZGGGGZZZGGGGGZG`, modes `FFsFFFsFsFssFFsFFssFsFFsFFFFsFFFssFFsFFFssssFFssFsFFFssFssFs`
- slow runs by transition: {'G->Z': [0, 16], 'Z->G': [15, 16], 'Z->Z': [0, 14], 'G->G': [11, 13]}

## The sustained block (first, no probe): input consumption

Shape: **constant within error**; 1 s windows (bytes/s) [92721555, 101107210, 92723535, 96918099], error bound 10300722, chunk 4202153 bytes.

## Pass 2 against pass 1 (serial, not a causal price of a busy sibling)

- P-idle progress, pass 2 over pass 1, all probed runs: 0.470
- fast runs: 0.470
- slow runs: -
- P-sib over P-idle, pass 2: 1.001
