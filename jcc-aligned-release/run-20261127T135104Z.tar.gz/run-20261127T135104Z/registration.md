# 32-Byte Branch Alignment for Release Artefacts: Frozen i9-10900K Adoption Registration

*Frozen 27 November 2026 before any workstation data, under claim [`jcc-aligned-release-build`](../../../frontier/claims/jcc-aligned-release-build.toml). Adoption decision rule under RULES C1a, C2, and C6; no threshold or guard may be relaxed after data is seen.*

*Prior workstation evidence check: `origin/evidence` and `bench/workstation-queue.txt` hold zero prior `jcc-aligned` bundles or queue entries.*

---

## 1. Mechanism and Motivation

Four independent cloud-VM diagnostics (`#1060`, `#1067`, `#1068`, `#1077`) and the confirmed station-balance probe (`#1107`, `e4bef3e6`) showed that compiling `x86_64` release binaries with `-C llvm-args=-x86-branches-within-32B-boundaries` (byte-identical to `-C llvm-args=-x86-align-branch-boundary=32 -C llvm-args=-x86-align-branch=fused+jcc+jmp`, verified in `#1077`) eliminates 100% of unfused and hardware-fusable 32-byte branch crossings inside `mibz2::*` at `+2.9%` to `+3.5%` `.text` size (`+0.5%` binary size) and cuts `OpenCells` worker time by `13.7%` to `15.6%` on Skylake/Cascade Lake Xeon silicon while moving the serial scanner `S` by only `1%` to `4%`.

Two critical questions can only be settled on the target 10-core Intel i9-10900K (`family 6, model 0xA5`, Comet Lake-S):

1. **Whether the i9-10900K actually benefits from 32-byte branch alignment.** `frontier/DECODER.md` and HotSpot's `JDK-8234160` CPU list include `06_A5H`, whereas `#1077` notes Intel's stepping-5 silicon fix; only a direct paired i9 measurement settles the real hardware gain.
2. **Which station (`S` vs `W/k`) binds at `k = 8` on the i9-10900K under aligned vs default codegen.** As derived in the tenth (`#1090`) and twelfth (`#1109`) synthesis passes, a station-uneven shift (`r_aligned = k*_aligned / k*_default < 1`) flips aligned `wikidata` at `k = 8` from worker-bound/tie to scanner-bound, governing the `k = 8` attribution of the queued seam-window (`#1031`), coalesced-scanner (`#1105`), and A6b (`#1053`) i9 runs.

Because `#1107` found `-C target-cpu=native` slowed the serial scanner `S` by `5%–8%` on all eight corpora (since `#1034` already dispatches `decode_runs_bmi2` at runtime), this study strictly compares **baseline x86-64 + `-C llvm-args=-x86-branches-within-32B-boundaries`** against **baseline x86-64 default**, with zero `-C target-cpu` flags and identical `src/` at pinned `master` commit `59cac2c52d7168e09a4b4d6edeb658c16ef9baf7`.

---

## 2. Build Parity, Correctness, and Codegen Verification (VOID if any fail)

1. **Identical source and toolchain (shallow-clone safe):** Both arms (`default` and `aligned`) are built directly from the checked-out `HEAD` tree (with no `git clone --local` or historical commit fetches, so `--depth 1` workstation checkouts run cleanly) using separate `CARGO_TARGET_DIR` directories, pinned `rustc 1.99.1`, and `cargo build --release --locked`. Before building, `bench/jcc_aligned.py` verifies `HEAD:src` (`075be307...`), `HEAD:Cargo.toml` (`e2462676...`), and `HEAD:Cargo.lock` (`677ab990...`) match pinned `master` commit `59cac2c52d7168e09a4b4d6edeb658c16ef9baf7`, and uses identical environment except:
   - `default`: `RUSTFLAGS` unset;
   - `aligned`: `RUSTFLAGS="-C llvm-args=-x86-branches-within-32B-boundaries"`.
2. **Static codegen proof (`codegen_audit.json`):** Both `ab` and `station_balance` binaries must have distinct SHA-256 digests (`aligned != default`), strictly larger `.text` on `aligned`, `> 0` unfused JCC/JMP 32-byte crossings in `mibz2::*` on `default`, and `0` unfused JCC/JMP 32-byte crossings in `mibz2::*` on `aligned`.
3. **Byte-exact parity against independent `libbzip2`:** Before timing, every `(corpus, k)` cell runs an untimed `AB_SHA256=1` decode on both `default` and `aligned` and verifies exact byte length and SHA-256 digest against Python's `bz2` (`libbzip2`). Every timed `ab run` sample must record `"termination": "success"`, empty `"err"` (`""`), exact `"out"`, and matching `"hash"`.

---

## 3. Frozen Decision Rule (Verbatim Transcription of `jcc-aligned-release-build.toml`; C2 Applies)

> Frozen before data (adoption registration, C6 review): on i9-10900K, aligned over default must be faster with a non-overlapping 95% CI at k = 1 by >= 3.0% and at k = 8 by >= 1.5%, with no > 1.0% regression at k = 10 or on any guard corpus, <= 1.02x peak RSS, identical output bytes; and on the CI AMD runner no > 1.0% regression at any thread count. Otherwise STOP with a scoped dead-end row.

### 3.1 Workstation Run Design (`just bench-jcc-aligned-release`)

- **Machine & topology:** 10-core / 20-thread Intel i9-10900K with unrestricted CPU affinity and unlimited cgroup CPU quota.
- **Corpora:**
  - Primary: `wikidata x4` (`SHA-256 = 0b820d14299af637bf7f644d172f5efe91ad59e169cf2a50bd0962f5c89ce08e`, 4× concatenation of pinned 12-window `corpora/wikidata.bz2`, `839 MB` decoded output) at `k ∈ {1, 4, 6, 8, 10}`.
  - Guard corpora: `text`, `records`, and `random` generated by `ab gen <dir> 4` (scale 4) at `k ∈ {1, 8, 10}`.
- **Timed paired `ab run` grid:** 12 balanced rounds (`ab run` rotated + reversed `arm_order`: 6 `default`-first, 6 `aligned`-first) comparing `mibz2` (`default`) vs `mibz2@<aligned-ab>` (`aligned`), `--prespin-ms 100`, `--settle 0.2`, `--max-busy 1.5`, `--pin <core0_cpu0>` for `k = 1`, production unpinned scheduling for `k >= 4`.
- **Diagnostic station-balance measurement (not gated):** Unchanged `examples/station_balance.rs` (`passes = 5`), pinned to `core0_cpu0` (`taskset -c`), 5 paired alternating rounds (`default` vs `aligned`) on single `wikidata` (`82f65ace`) plus `text`, `records`, `random`. Reports `S_ms`, `W_ms`, `k* = W/S`, `S_aligned / S_default`, `W_aligned / W_default`, and `r_aligned = k*_aligned / k*_default`.
- **Estimated workstation time:** ~5.5 to 7 minutes (two builds ~75 s, parity ~15 s, 336 `ab run` decodes ~170 s, 40 `station_balance` runs ~70 s) — well below the 30-minute threshold of `PERFORMANCE-POLICY.md` §4a.

### 3.2 Part A — i9-10900K Quantitative Criteria (Evaluated Automatically by `bench/jcc_aligned.py`)

For every paired cell, `ratio = geomean(aligned / default)` with two-sided 95% Student-t CI `[lo, hi]` (`df = 11`, `paired_ratio_ci`), and `rss_ratio = median(aligned.rss_kb) / median(default.rss_kb)`.

The i9-10900K gate returns **PASS** if and only if **ALL** of the following hold:
1. **`wikidata` at `k = 1`:** `hi <= 0.970` (entire 95% CI of `aligned / default` is `<= 0.970`, i.e., `>= 3.0%` faster and non-overlapping with `1.0`).
2. **`wikidata` at `k = 8`:** `hi <= 0.985` (entire 95% CI of `aligned / default` is `<= 0.985`, i.e., `>= 1.5%` faster and non-overlapping with `1.0`).
3. **No `> 1.0%` regression at `k = 10` or any guard corpus:** `ratio <= 1.010` (which also guarantees `lo <= 1.010`) on `wikidata` at `k = 10` AND on every guard cell (`text`, `records`, `random` at `k ∈ {1, 8, 10}`).
4. **Peak RSS `<= 1.02×`:** `rss_ratio <= 1.020` on every timed cell (`wikidata` at `k ∈ {1, 4, 6, 8, 10}` and `text`, `records`, `random` at `k ∈ {1, 8, 10}`).
5. **Diagnostic cells (`wikidata` `k = 4, 6` and `station_balance`):** Reported in `summary.json` for attribution; `k = 4, 6` enforce byte parity and RSS `<= 1.02×` but do not relax any gate above.

Otherwise, the i9 gate returns **STOP**: do not set release build flags, and record a scoped row in `frontier/dead-ends.tsv`.

### 3.3 Part B — CI AMD Runner Non-Regression Gate (Required Before Merging Release Flags)

An i9 `PASS` authorizes opening the release-flags PR (`pyproject.toml` / `.github/workflows/CI.yml`, scoped strictly to `x86_64` release artefacts). Before merging that PR, the standard CI paired `bench` workflow on the GitHub Actions AMD EPYC runner must show **no `> 1.0%` wall-time regression (`ratio <= 1.010`) at any thread count or corpus**. If AMD EPYC regresses `> 1.0%`, **STOP** and record a scoped dead-end row rather than shipping the flag.

### 3.4 VOID Conditions

The workstation run is **VOID** (exits nonzero, writes `VOID: <reason>` to `outcome.txt`) if any of the following occur:
- Machine is not an i9-10900K, topology is not 10 cores / 20 CPUs with unrestricted affinity, or cgroup CPU quota is limited;
- Recipe checkout has tracked modifications or `rustc` is not `1.99.1`;
- Static codegen audit fails (identical binaries, no `.text` growth, `default` has `0` crossings, or `aligned` has `> 0` unfused JCC/JMP 32B crossings in `mibz2::*`);
- Any `wikidata x4` hash mismatch (`!= 0b820d14...ce08e`), any untimed `AB_SHA256=1` parity mismatch against `libbzip2`, or any timed row has `termination != "success"`, non-empty `err`, `out` mismatch, or `hash` mismatch;
- Any cell is missing/duplicated, any duration or RSS is non-finite/non-positive, any 95% CI is undefined, or `station_balance` fails or returns inconsistent block/byte counts.
